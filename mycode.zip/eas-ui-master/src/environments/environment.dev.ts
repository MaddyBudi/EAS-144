// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --configuration=prod` then `environment.prod.ts` will be used instead and 
// `ng build --configuration=dev` then `environment.dev.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular.json`.
export const environment = {
     production: false,
    OnDemandLocationInterval : "200",
    OnDemandLocationDuration : "1800",
    mapHeight:0,
    adminUser:'ADMIN',
    normalUser:'USER',
    param_iss:'?iss=',
    param_targetUri:'&target_link_uri=',
    providerWest:'west',
    providerGoogle:'google',
    redirectUri: 'https://eas-edge.dev.powerdata.west.com/powerdata/openid_connect_login',
    userServiceUrl:'https://eas-edge.dev.powerdata.west.com/powerdata/api/v1/user/userinfo',
    authServiceUrl:'https://eas-edge.dev.powerdata.west.com/powerdata/api/loginProviderUrl/',
    targetUri: window.location.protocol+'//'+ window.location.hostname+':'+window.location.port +'/appconsole',
    dmsStreamUrl:'https://data-monitor.dev.powerdata.west.com/powerdata/monitorGeoBox',
    RowsPerPageList:[5,10,15],
    DefaultRowsPerPage:5,
    eventServiceUrl:'https://eas-edge.dev.powerdata.west.com/powerdata/api/v1/admin/event',
    locationServiceUrl:'https://eas-edge.dev.powerdata.west.com/powerdata/api/v1/user',
    situationaldataUrl:'https://eas-edge.dev.powerdata.west.com/api/v1/user/situationalData',
    annotationServiceUrl:'https://eas-edge.dev.powerdata.west.com/api/v1/admin/resource',
    resourceServiceUrl:'https://eas-edge.dev.powerdata.west.com/api/v1/admin/resource',
    eventDataModel:'EVENT',
    annotationDataModel:'RESOURCE',
    resourceObject:'ANNOTATION',
    selected_color: "2px solid #789",
    unselected_color: "2px solid #fff",
    defaultZoomSize:"15",
    zoomAdjusterFactor:"4",
    streamZoomLevel:13,
    defaultOrgLat:"34.0522",
    defaultOrgLan:"-118.2437",
	eventIcon:"assets/img/map-event.png",
    annotationIcon:"assets/img/location.png",
    hydrantIcon:"assets/img/mapHydrants.svg",
    annotationType:"annotation"
};
