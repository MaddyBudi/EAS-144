export enum DataModel {
    event="EVENT",
    hospital="HOSPITAL",
    traffic="TRAFFIC",
    fuel="FUEL",
    resource="RESOURCE",
    annotation="ANNOTATION",
    hydrant = "HYDRANT",
    weather = "WEATHER",
    location = "LOCATION"

}
