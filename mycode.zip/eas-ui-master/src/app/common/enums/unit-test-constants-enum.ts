export enum UnitTestConstants {
    eventPayloadUrl = "assets/json/event.json",
    annotationPayloadUrl = "assets/json/annotation.json",
    resourcePayloadUrl = "assets/json/resource.json",
    singleEventPayloadUrl = "assets/json/singleEvent.json",
    twitterPayloadUrl = "assets/json/twitter.json",
    facebookPayloadUrl = "assets/json/facebook.json",
    notificationPayloadUrl = "assets/json/notification.json",
    locationPayloadUrl = "assets/json/location.json",
    resourcegroupPayloadUrl = "assets/json/resourcegroup.json",
    workspacePayloadUrl = "assets/json/workspace.json",
    singleLocationPayloadUrl = "assets/json/singleLocation.json",
    placeObjectUrl = "assets/json/place.json",
    resourceTypePayloadUrl = "assets/json/resourceType.json",
    resourceTypeSinglePayloadUrl="assets/json/resourceTypeSingle.json"
}
