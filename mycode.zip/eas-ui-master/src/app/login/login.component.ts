import { Component, OnInit, OnDestroy } from '@angular/core';
import { SettingsService } from '../core/settings/settings.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import * as EventSource from 'eventsource';
import { HttpClient, HttpParams } from '@angular/common/http';
import { AuthService } from './services/auth.service';
import { environment } from '../../environments/environment';
import { ActivatedRoute } from '@angular/router';
import {  AppGlobals } from '../shared/app.globals';

let controller;

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit, OnDestroy {
    errorMessage: string;
    token: any;
    user: any;
    expiredDate: Date;
    displayGeneralRoutes: boolean;
    displayAdminRoutes: boolean;
    error: String;
    constructor(public settings: SettingsService, private authservice: AuthService,
        fb: FormBuilder, public router: Router, private http: HttpClient, 
        private route: ActivatedRoute,private appglobals: AppGlobals) {
        controller = this;
        const routeConfig = this.route.snapshot.routeConfig;
        let errorValue;
        this.route.url.subscribe((val) => {
            errorValue = val[0].parameters.error;
        });
        if(errorValue) {
            this.error = errorValue;
        } else if (routeConfig && routeConfig.data && routeConfig.data.error) {
            this.error = routeConfig.data.error;
        }
        console.log(this.error);
    }
    ngOnDestroy() {

    }
    ngOnInit() {
    }
    signInWithWest() {
        this.authservice.signIn(this.appglobals.providerWest);
    }
    signInWithGoogle() {
        this.authservice.signIn(this.appglobals.providerGoogle);
    }
}

