import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { UserService } from './user.service';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
import {  AppGlobals } from '../../shared/app.globals';
import {ConfigService} from "../../core/config/config-svc.service";

@Injectable()
export class AuthService {
  // constructor(public jwtHelper: JwtHelperService) {}
  userInfo: any;
  constructor(private http: HttpClient, private userService: UserService, public router: Router,
  private appglobals: AppGlobals) { }
  public isAuthenticated(): boolean {
    this.userService.getUserInfo();
    // this.userInfo = this.userService.getUserData;
    if (this.userInfo != null && this.userInfo !== undefined) {
      return true;
    } else {
      return false;
    }
  }
  public signIn(inputName) {
    // console.log(environment.targetUri);
    let providerURL = '';
    const providerName = inputName;
    this.http.get(ConfigService.config.authServiceUrl + providerName, { responseType: "text" }).subscribe(
      data => {
        providerURL = JSON.parse(data);
        console.log(providerURL);
        const loginUrl = ConfigService.config.redirectUri + this.appglobals.param_iss 
        + providerURL + this.appglobals.param_targetUri + this.appglobals.targetUri;
        // let loginUrl = environment.apiServiceUrl + environment.redirectUri
        // +"?iss=https://oic.dev.powerdata.west.com/oic/" 
        // + "&target_link_uri=http://192.168.24.26:4200/appconsole";  
        console.log(loginUrl);
        window.open(loginUrl, "_self");
      },
      error => {
        this.router.navigate(['LoginComponent', { error: "Invalid URL" }], { skipLocationChange: true });
      });

  }



}


