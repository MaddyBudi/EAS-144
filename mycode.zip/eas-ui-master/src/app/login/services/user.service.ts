import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';
import {ConfigService} from "../../core/config/config-svc.service";

interface Res {
  roles: any;
  userName: string;
}

@Injectable()
export class UserService {
  userInfo: any;
  userName: any;
  zoomlevel: any;
  epttUser = false;
  epttUser_accessToken: string;
  epttUser_mdn: string;
  epttUser_clientType: string;
  twitter = false;
  facebook = false;
  eventType = [];
  userCheckFlag = {
    "traffic" : true,
    "event" : true,
    "hydrant" :true,
    "hospital" :true,
    "data311" :true,
    "fuel" :true,
    "weather" : true,
    "Law" :true,
    "Fire" :true,
    "Medical" : true,
    "agency" : true,
    "eas-users":true,
    "field-personnel":true,
    "annotation":true,
    "location":true,
    "sensor":false
  };
  orgLatLng = {
    lat: "",
    lng: ""
  };
  constructor(private http: HttpClient, private router: Router) { }
  getUserInfo() {
    return this.http.get<any>(ConfigService.config.userServiceUrl, { withCredentials: true }).pipe(map(res => res));
  }
}
