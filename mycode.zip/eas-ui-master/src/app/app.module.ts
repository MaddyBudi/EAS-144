import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { CommonComponent } from './common/common.component';
import { HomeComponent } from './home/home.component';
import { SharedComponent } from './shared/shared.component';
import { ConfigService } from './core/config/config-svc.service';
import { HttpClientModule } from '@angular/common/http';
import { AuthGuardService } from './login/services/auth-guard.service';
import { AuthService } from './login/services/auth.service';
import { SettingsService } from './core/settings/settings.service';
import { UserService } from './login/services/user.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NavigationComponent } from './home/navigation/navigation.component';
import { ContextBarComponent } from './home/context-bar/context-bar.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { MapConsoleComponent } from './home/map-console/map-console.component';
import { EasRightSidebarComponent } from './home/map-console/eas-right-sidebar/eas-right-sidebar.component';
import { EasLeftSidebarComponent } from './home/map-console/eas-left-sidebar/eas-left-sidebar.component';
import { EntitiesMiniListComponent } from './home/map-console/entities-mini-list/entities-mini-list.component';
import { EventInfoComponent } from './home/map-console/event-info/event-info.component';
import { EpttComponent } from './home/map-console/eptt/eptt.component';
import { PersonComponent } from './home/map-console/person/person.component';
import { SocialMediaComponent } from './home/map-console/social-media/social-media.component';
import { FindRouteComponent } from './home/map-console/find-route/find-route.component';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { SharedPipe } from './home/shared.pipe';
import { DataTableModule } from 'angular-6-datatable';
import { ScrollableDirective } from './shared/directives/scrollable/scrollable.directive';
import { EasEventsComponent } from './home/eas-events/eas-events.component';
import { ListEasEventsComponent } from './home/eas-events/list-eas-events/list-eas-events.component';
import { EasAnnotationsComponent } from './home/eas-annotations/eas-annotations.component';
import { ListEasAnnotationsComponent } from './home/eas-annotations/list-eas-annotations/list-eas-annotations.component';
import { EasPredefinedLocationsComponent } from './home/eas-predefined-locations/eas-predefined-locations.component';
import { ListEasPredefinedLocationsComponent } from './home/eas-predefined-locations/list-eas-predefined-locations/list-eas-predefined-locations.component';
import { EasResourcesComponent } from './home/eas-resources/eas-resources.component';
import { ListEasResourcesComponent } from './home/eas-resources/list-eas-resources/list-eas-resources.component';
import { UpdateEasEventsComponent } from './home/eas-events/update-eas-events/update-eas-events.component';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { UpdateEasPredefinedLocationsComponent } from './home/eas-predefined-locations/update-eas-predefined-locations/update-eas-predefined-locations.component';
import { UpdateEasAnnotationsComponent } from './home/eas-annotations/update-eas-annotations/update-eas-annotations.component';
import { AgmCoreModule } from '@agm/core';
import { AgmDirectionModule } from 'agm-direction';
import { EasWorkspaceComponent } from './home/eas-workspace/eas-workspace.component';
import { CreateEasWorkspaceComponent } from './home/eas-workspace/create-eas-workspace/create-eas-workspace.component';
import { ListEasWorkspaceComponent } from './home/eas-workspace/list-eas-workspace/list-eas-workspace.component';
import { EasEventMoreInformationComponent } from './home/eas-event-more-information/eas-event-more-information.component';
import { EasOtherEntitiesInformationComponent } from './home/eas-other-entities-information/eas-other-entities-information.component';
import { ChatWidgetComponent } from './home/map-console/chat-widget/chat-widget.component';
import { MessageItemComponent } from './home/map-console/chat-widget/message-item/message-item.component';
import { MsdsComponent } from './home/map-console/msds/msds.component';
import { BaseMapComponent } from './home/map-console/base-map/base-map.component';

import { CreateEasResourceComponent } from './home/eas-resources/create-eas-resource/create-eas-resource.component';
import { UpdateEasResourceComponent } from './home/eas-resources/update-eas-resource/update-eas-resource.component';
import { CreateEasResourceGroupComponent } from './home/eas-resources/create-eas-resource-group/create-eas-resource-group.component';
import { ListEasResourceGroupComponent } from './home/eas-resources/list-eas-resource-group/list-eas-resource-group.component';
import { UpdateEasResourceGroupComponent } from './home/eas-resources/update-eas-resource-group/update-eas-resource-group.component';
import { SearchEasResourceComponent} from './home/eas-resources/list-eas-resources/search-eas-resource/search-eas-resource.component';
import { NotifierModule } from 'angular-notifier';
import { ToastrModule } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import { AssignEasResourcesComponent } from './home/eas-resources/assign-eas-resources/assign-eas-resources.component';
import { CreateEasAnnotationsComponent } from './home/eas-annotations/create-eas-annotations/create-eas-annotations.component';
import { MapLayersComponent } from './home/map-console/map-layers/map-layers.component';
import { MapLayers } from './home/map-console/map-layers/mapLayers';
import { CreateEasEventsComponent } from './home/eas-events/create-eas-events/create-eas-events.component';
import { CreateEasPredefinedLocationsComponent } from './home/eas-predefined-locations/create-eas-predefined-locations/create-eas-predefined-locations.component';
import { CameraWidgetComponent } from './home/camera-widget/camera-widget.component';
import { NotificationsComponent } from './home/map-console/notifications/notifications.component';
import { SensorComponent } from './home/map-console/sensor/sensor.component';
import { GeoAddressComponent } from './home/geo-address/geo-address.component';
import { CdkDragDrop, DragDropModule, moveItemInArray, transferArrayItem  } from '@angular/cdk/drag-drop';
import { CreateEasResourceTypeComponent } from './home/eas-resources/create-eas-resource-type/create-eas-resource-type.component';
import { ListEasResourceTypeComponent } from './home/eas-resources/list-eas-resource-type/list-eas-resource-type.component';
import { UpdateEasResourceTypeComponent } from './home/eas-resources/update-eas-resource-type/update-eas-resource-type.component';

export function initializeApp(configService: ConfigService) {
  return () => configService.getConfig();
}


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    CommonComponent,
    HomeComponent,
    SharedComponent,
    NavigationComponent,
    ContextBarComponent,
    MapConsoleComponent,
    EasRightSidebarComponent,
    EasLeftSidebarComponent,
    EntitiesMiniListComponent,
    EventInfoComponent,
    EpttComponent,
    PersonComponent,
    SocialMediaComponent,
    FindRouteComponent,
    SharedPipe,
    ScrollableDirective,
    EasEventsComponent,
    ListEasEventsComponent,
    EasAnnotationsComponent,
    ListEasAnnotationsComponent,
    EasPredefinedLocationsComponent,
    ListEasPredefinedLocationsComponent,
    EasResourcesComponent,
    ListEasResourcesComponent,
    UpdateEasEventsComponent,
    UpdateEasPredefinedLocationsComponent,
    UpdateEasAnnotationsComponent,
    EasWorkspaceComponent,
    CreateEasWorkspaceComponent,
    ListEasWorkspaceComponent,
    EasEventMoreInformationComponent,
    EasOtherEntitiesInformationComponent,
    ChatWidgetComponent,
    MessageItemComponent,
    MsdsComponent,
    BaseMapComponent,
    CreateEasResourceComponent,
    UpdateEasResourceComponent,
    CreateEasResourceGroupComponent,
    ListEasResourceGroupComponent,
    UpdateEasResourceGroupComponent,
    SearchEasResourceComponent,
    AssignEasResourcesComponent,
    CreateEasAnnotationsComponent,
    MapLayersComponent,
    CreateEasEventsComponent,
    CreateEasPredefinedLocationsComponent,
    CameraWidgetComponent,
    NotificationsComponent,
    SensorComponent,
    GeoAddressComponent,
    CreateEasResourceTypeComponent,
    ListEasResourceTypeComponent,
    UpdateEasResourceTypeComponent

  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MDBBootstrapModule.forRoot(),
    DeviceDetectorModule.forRoot(),
    SharedModule.forRoot(),
    DragDropModule,
    NotifierModule.withConfig( {
      position: {
 
        horizontal: {
          position: 'right',
          distance: 0
       
        },
       
        vertical: {
         position: 'top',
          distance: 47
             
        }
       
      }
    } ),
    DataTableModule,
    OwlDateTimeModule,
    AgmCoreModule.forRoot(
      { apiKey: 'AIzaSyAsdzEUreLk_wU3PgOrOKqyPmXLrpr_TDA' }),
    OwlNativeDateTimeModule,
    AgmDirectionModule,
    ToastrModule.forRoot()
  
  ],
  providers: [ConfigService, AuthService, AuthGuardService, SettingsService, UserService, ListEasResourcesComponent,{ provide: APP_INITIALIZER, useFactory: initializeApp, deps: [ConfigService], multi: true },MapLayers,DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
