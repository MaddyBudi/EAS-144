import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
// import { CommonComponent } from './common/common.component';
// import { AuthGuardService } from './login/services/auth-guard.service';

export const route = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  {
    path: 'appconsole', component: HomeComponent
    //  canActivate: [AuthGuardService] 
  },
  { path: '**', component: LoginComponent, data: {error: 'Invalid URL'}}
];
