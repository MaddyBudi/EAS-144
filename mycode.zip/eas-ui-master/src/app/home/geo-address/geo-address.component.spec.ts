// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { GeoAddressComponent } from './geo-address.component';

// describe('GeoAddressComponent', () => {
//   let component: GeoAddressComponent;
//   let fixture: ComponentFixture<GeoAddressComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ GeoAddressComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(GeoAddressComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
