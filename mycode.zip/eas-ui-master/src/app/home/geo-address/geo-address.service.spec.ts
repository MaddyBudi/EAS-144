// import { TestBed } from '@angular/core/testing';

// import { GeoAddressService } from './geo-address.service';

// describe('GeoAddressService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: GeoAddressService = TestBed.get(GeoAddressService);
//     expect(service).toBeTruthy();
//   });
// });
