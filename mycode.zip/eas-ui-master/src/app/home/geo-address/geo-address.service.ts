import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GeoAddressService {
  latitude:number;
  longitude:number;
  coordinates = [];
  address:string;
  checkValidation:boolean;
  place:any;
  reset = new Subject<boolean>();
  reset$ = this.reset.asObservable();
  geoAddress = new Subject<any>();
  geoAddress$ = this.geoAddress.asObservable();
  setAddressLatLng = new Subject<any>();
  setAddressLatLng$ = this.setAddressLatLng.asObservable();
  disableAddressLatLng = new Subject<any>();
  disableAddressLatLng$ = this.disableAddressLatLng.asObservable();
  getMapObjects = new Subject<any>();
  getMapObjects$ = this.getMapObjects.asObservable();
  constructor() { }
  resetAll() {
    this.latitude = undefined;
    this.longitude = undefined;
    this.address = undefined;
    this.coordinates = [];
    this.reset.next();
  }
  activeAddressInfo() {
    this.geoAddress.next();
  }
  getLocationObject(data) {
    this.getMapObjects.next(data);
  }
  disableLatLngAddress() {
    this.disableAddressLatLng.next();
  }
}
