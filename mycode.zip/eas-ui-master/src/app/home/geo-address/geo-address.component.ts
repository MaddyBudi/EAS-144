
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { SharedService } from '../../shared/shared.service';
import { GeoAddressService } from './geo-address.service';
import { NotifierService } from 'angular-notifier';
import { DataModel } from '../../dataModelEnum';
import { Subscription } from 'rxjs';
declare let google: any;

@Component({
  selector: 'app-geo-address',
  templateUrl: './geo-address.component.html',
  styleUrls: ['./geo-address.component.scss']
})
export class GeoAddressComponent implements OnInit {
  geoAddressForm = new FormGroup({
    address: new FormControl('', Validators.required),
    latitude: new FormControl('', Validators.required),
    longitude: new FormControl('', Validators.required)
  });
  place;
  loc = [];
  isfromMap = false;
  isDisabled = false;
  fullAddress;
  latLngAddress;
  addressFormatted;
address;
latitude;
longitude;
private geoAddress:Subscription;
private setAddressLatLngSubcription:Subscription;
private getMapObjects:Subscription;
private disableAddressLatLng:Subscription;

  constructor(private sharedService: SharedService, private geoCodeService: GeoAddressService, private notifier: NotifierService) {
    this.geoCodeService.reset$.subscribe(data => {
this.geoAddressForm.controls['latitude'].setValue('');
this.geoAddressForm.controls['longitude'].setValue('');
this.geoAddressForm.controls['address'].setValue('');
this.latitude = '';
this.longitude = '';
this.address = '';
}
);
this.geoAddress=this.geoCodeService.geoAddress$.subscribe(
data => {
this.onSubmit();
});
this.setAddressLatLngSubcription=this.geoCodeService.setAddressLatLng$.subscribe(data => {
this.setAddressLatLng(data);
});
this.getMapObjects=this.geoCodeService.getMapObjects$.subscribe(data => {
this.getCoordinatesForMapObjects(data);
});
this.disableAddressLatLng=this.geoCodeService.disableAddressLatLng$.subscribe(data => {
this.isDisabled = true;
});
// this.initObservables();
  }

  ngOnDestroy(): void {
//Called once, before the instance is destroyed.
//Add 'implements OnDestroy' to the class.
this.geoAddress.unsubscribe();
this.setAddressLatLngSubcription.unsubscribe();
this.getMapObjects.unsubscribe();
this.disableAddressLatLng.unsubscribe();


}
  onSearchChange() {
    const lat = parseFloat((<HTMLInputElement>document.getElementById('latitude')).value);
    this.loc[0] = lat;
    const long = parseFloat((<HTMLInputElement>document.getElementById('longitude')).value);
    this.loc[1] = long;
    const latlng = new google.maps.LatLng(lat, long);
       const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ 'latLng': latlng }, (results, status) => {
      if (status === google.maps.GeocoderStatus.OK) {
        const place = results[0];
        this.fullAddress = this.sharedService.getFullAddress(place);
        this.geoCodeService.address = place.formatted_address;
        this.geoCodeService.place = place;
        this.geoCodeService.latitude = parseFloat(lat.toFixed(6));
        this.geoCodeService.longitude = parseFloat(long.toFixed(6));
        this.geoCodeService.coordinates = [this.geoCodeService.longitude, this.geoCodeService.latitude];
      } else {
        // this.notifier.notify('error', 'Geocoder failed due to: ' + status);
      }
    });
    }
  ngOnInit() {

  }
  setformattedAddress() {
    this.geoAddressForm.controls['address'].setValue(this.geoCodeService.address);
  }
  onSubmit() {
    const lat = parseFloat((<HTMLInputElement>document.getElementById('longitude')).value);
    const long = parseFloat((<HTMLInputElement>document.getElementById('longitude')).value);
     if (lat && long && !this.isfromMap) {
      this.setformattedAddress();
     }
    const address = ((<HTMLInputElement>document.getElementById('address')).value);
    if (address &&  !this.isfromMap) {
      this.addressAutoCompleteSetLatLon();
    }
    for (const c in this.geoAddressForm.controls) {
      if (this.geoAddressForm.controls.hasOwnProperty(c)) {
        this.geoAddressForm.controls[c].markAsTouched();
      }
    }
    if (this.address !== undefined  && this.longitude !== undefined && this.longitude !== 'NaN' &&
    this.latitude !== undefined && this.latitude !== 'NaN' && this.address !== 'NaN' ) {
      this.geoCodeService.checkValidation = true;
    } else {
      this.geoCodeService.checkValidation = false;
    }

  }

  addressAutoComplete() {
    const autocomplete = new google.maps.places.Autocomplete(<HTMLInputElement>document.getElementById('address'));
    autocomplete.addListener('place_changed', () => {
      this.place = autocomplete.getPlace();
      this.loc = [];
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ 'address': (<HTMLInputElement>document.getElementById('address')).value }, (results, status) => {
        if (status === google.maps.GeocoderStatus.OK) {
          this.loc[0] = results[0].geometry.location.lat();
          this.loc[1] = results[0].geometry.location.lng();
          this.setPlaceAndAddress(this.place);
        } else {
          this.notifier.notify('error', 'Geocoder failed due to: ' + status);
        }
      });
    });
  }
  addressAutoCompleteSetLatLon() {
    this.geoAddressForm.controls['latitude'].setValue(this.loc[0]);
    this.geoAddressForm.controls['longitude'].setValue(this.loc[1]);
    this.setLatLngInService(this.loc[0], this.loc[1]);
    this.latitude = this.loc[0];
    this.longitude = this.loc[1];
    this.geoCodeService.coordinates = [this.loc[1], this.loc[0]];
  }
  setAddress() {
    const lat = (<HTMLInputElement>document.getElementById('latitude')).value;
    const long = (<HTMLInputElement>document.getElementById('longitude')).value;
    this.setValueInAddressField(lat, long);
  }
  setPlaceAndAddress(place) {

    this.fullAddress = this.sharedService.getFullAddress(place);
    this.geoAddressForm.controls['address'].setValue(place.formatted_address);
    this.address = place.formatted_address;
    this.geoCodeService.address = place.formatted_address;
    this.geoCodeService.place = place;
  }
  setValueInAddressField(lat, long) {
    const latlng = new google.maps.LatLng(lat, long);
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ 'latLng': latlng }, (results, status) => {
      if (status === google.maps.GeocoderStatus.OK) {
        this.setPlaceAndAddress(results[0]);
        this.setLatLngInService(parseFloat(lat), parseFloat(long));
        if (this.geoCodeService.coordinates.length === 0) {
          this.geoCodeService.coordinates = [this.geoCodeService.longitude, this.geoCodeService.latitude];
        }
      } else {
        this.geoAddressForm.controls['address'].setValue('');
        this.address = '';
        this.notifier.notify('error', 'Geocoder failed due to: ' + status);
      }
    });
  }
  setLatLngInService(lat, long) {
    this.geoCodeService.latitude = lat.toFixed(6);
    this.geoCodeService.longitude = long.toFixed(6);
  }
  getCoordinatesForMapObjects(data) {
      let coordinates = [];
    if (data.shape.type === google.maps.drawing.OverlayType.MARKER) {
      coordinates.push(data.shape.position.lng(), data.shape.position.lat());
      if (data.dataModel === DataModel.location) {
        coordinates = [];
        this.isfromMap = true;
        coordinates.push({ lat: data.shape.position.lat(), lng: data.shape.position.lng() });
      }
      this.setCoordLatLngInService(data.shape.position.lat(), data.shape.position.lng(), coordinates);
    }
    if (data.shape.type === google.maps.drawing.OverlayType.POLYGON) {
      this.isfromMap = true;
      const polygonData = this.sharedService.polygonGetBoundingBox(data.shape, data.dataModel);
      this.setCoordLatLngInService(polygonData.latitude, polygonData.longitude, polygonData.coordinates);
    }
    if (data.shape.type === google.maps.drawing.OverlayType.RECTANGLE) {
      this.isfromMap = true;
      const rectangleData = this.sharedService.getRectangleCoordinates(data.shape, data.dataModel);
      this.setCoordLatLngInService(rectangleData.latitude, rectangleData.longitude, rectangleData.coordinates);
    }
  }
  setAddressLatLng(data) {
    this.geoAddressForm.controls['latitude'].setValue(data[1].toFixed(6));
    this.geoAddressForm.controls['longitude'].setValue(data[0].toFixed(6));
    this.latitude = data[1];
    this.longitude = data[0];
    this.loc[0] = this.latitude;
    this.loc[1] = this.longitude;
    this.setValueInAddressField(data[1], data[0]);
  }
  setCoordLatLngInService(latitude, longitude, coordinates) {
    this.geoCodeService.latitude = latitude.toFixed(6);
    this.geoCodeService.longitude = longitude.toFixed(6);
    this.geoCodeService.coordinates = coordinates;
    this.latitude = latitude.toFixed(6);
    this.longitude = longitude.toFixed(6);
    this.setAddressLatLng([longitude, latitude]);

  }
  isDisableCheck() {
    return this.isDisabled;
  }

}
