// import { TestBed } from '@angular/core/testing';

// import { EasWorkspaceService } from './eas-workspace.service';

// describe('EasWorkspaceService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: EasWorkspaceService = TestBed.get(EasWorkspaceService);
//     expect(service).toBeTruthy();
//   });
// });
