// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EasWorkspaceComponent } from './eas-workspace.component';

// describe('EasWorkspaceComponent', () => {
//   let component: EasWorkspaceComponent;
//   let fixture: ComponentFixture<EasWorkspaceComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EasWorkspaceComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EasWorkspaceComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
