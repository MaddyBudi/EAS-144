import { Component, OnInit } from '@angular/core';
import { CrudView } from './crudview';
import { EasWorkspaceService } from './eas-workspace.service';

@Component({
  selector: 'app-eas-workspace',
  templateUrl: './eas-workspace.component.html',
  styleUrls: ['./eas-workspace.component.scss']
})
export class EasWorkspaceComponent implements OnInit {

  crudView : CrudView = new CrudView();

  constructor(private easWorkspaceService : EasWorkspaceService) { }

  ngOnInit() {
    this.crudView.viewType = 'list';
  }

  crudViewTypeCatcher(viewType) {
    this.crudView.viewType = viewType;
    this.easWorkspaceService.displaySuccess = false;
    this.easWorkspaceService.displayFailure = false;
  }

}
