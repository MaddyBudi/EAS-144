import { Observable, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { UnitTestConstants } from '../../common/enums/unit-test-constants-enum';

@Injectable()
export class MockEasWorkspaceService {


    // workspaceDataFromMap$ = this.workspaceDataFromMap
     workspaceDataFromMap = new Subject<any>();
    workspaceDataFromMap$ = this.workspaceDataFromMap.asObservable();
    constructor(private http: HttpClient) { 
  
    }

    getAllWorkspace() {     
        return this.http.get(UnitTestConstants.workspacePayloadUrl).pipe(map((res: any) =>
         res));
      }

      setWorkspaceData(data) {
        this.workspaceDataFromMap.next(data);
      }
}