import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { ConfigService } from "../../core/config/config-svc.service";
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EasWorkspaceService {

  displaySuccess = false;
  displayFailure = false;
  successMessage: string;
  failureMessage: string;
  selectedWorkspaceId: any;
  workspaceDataFromMap = new Subject<any>();
  workspaceDataFromMap$ = this.workspaceDataFromMap.asObservable();

  constructor(private httpClient: HttpClient) { }

  getHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All'
      }),
      withCredentials: true
    };
    return httpOptions;
  }

  public createWorkspace(formData, fulladdress) {
    const geoJson = {
      'type': 'Point',
      'coordinates': formData.workspaceCoords
    }

    const payload = {
      'easWorkspaceName': formData.easWorkspaceName,
      'geometry': JSON.stringify({
        'type': 'Point',
        'coordinates': [
          parseFloat(formData.longitude),
          parseFloat(formData.latitude)
        ]
      }),
      'address': fulladdress,
      'properties': {
        'zoomLevel': formData.zoomLevel,
        'eventId': formData.eventId,
        'mapTypeInfo': {
          'type': formData.mapType,
          'terrain': formData.terrain,
          'labels': formData.labels
        },
        'mapLayers': {
          'bicycle': formData.bicycle,
          'traffic': formData.traffic,
          'transit': formData.transit
        },
        'filtersState': {
          'EVENT': formData.eventToggle,
          'Location': formData.locationToggle,
          'Law': formData.lawResourceToggle,
          'Fire': formData.fireResourceToggle,
          'Medical': formData.medicalResourceToggle,
          'EAS-Users': formData.easUsersResourceToggle,
          'Field-Person': formData.fieldPersonnelResourceToggle,
          'Agency': formData.agencyResourceToggle,
          'Annotations': formData.annotationToggle,
          'Hydrant': formData.hydrantToggle,
          'Hospital': formData.hospitalToggle,
          'Fuel': formData.fuelToggle,
          '311': formData.threeOneOneToggle,
          'TMC': formData.tmcToggle,
          'Weather': formData.weatherToggle,
          'Sensor': formData.sensorToggle
        }
      }
    }

    return this.httpClient.post(ConfigService.config.eventServiceUrl + '/createEASWorkspace', payload, this.getHeaders()).pipe(map((res: any) => res));

  }

  getAllWorkspace() {
    return this.httpClient.get(ConfigService.config.eventServiceUrl + '/getAllEASWorkspaces', this.getHeaders()).pipe(map((res: any) => res));
  }

  deleteWorkspace(entityId) {
    return this.httpClient.delete(ConfigService.config.eventServiceUrl + '/deleteEASWorkspace?ENTITY_ID=' + entityId, this.getHeaders()).pipe(map((res: any) => res));
  }

  getWorkspace(entityId) {
    return this.httpClient.get(ConfigService.config.eventServiceUrl + '/getEASWorkspace?ENTITY_ID=' + entityId, this.getHeaders()).pipe(map((res: any) => res));
  }

  public updateWorkspace(formData, fulladdress) {
    const geoJson = {
      'type': 'Point',
      'coordinates': formData.workspaceCoords
    }

    const payload = {
      'entityId': formData.entityId,
      'userName': formData.userName,
      'organizationName': formData.organizationName,
      'easWorkspaceName': formData.easWorkspaceName,
      'geometry': JSON.stringify(geoJson),
      'address': fulladdress,
      'createdDate': formData.createdDate,
      'properties': {
        'zoomLevel': formData.zoomLevel,
        'eventId': formData.eventId,
        'mapTypeInfo': {
          'type': formData.mapType,
          'terrain': formData.terrain,
          'labels': formData.labels
        },
        'mapLayers': {
          'bicycle': formData.bicycle,
          'traffic': formData.traffic,
          'transit': formData.transit
        },
        'filtersState': {
          'EVENT': formData.eventToggle,
          'Location': formData.locationToggle,
          'Law': formData.lawResourceToggle,
          'Fire': formData.fireResourceToggle,
          'Medical': formData.medicalResourceToggle,
          'EAS-Users': formData.easUsersResourceToggle,
          'Field-Person': formData.fieldPersonnelResourceToggle,
          'Agency': formData.agencyResourceToggle,
          'Annotations': formData.annotationToggle,
          'Hydrant': formData.hydrantToggle,
          'Hospital': formData.hospitalToggle,
          'Fuel': formData.fuelToggle,
          '311': formData.threeOneOneToggle,
          'TMC': formData.tmcToggle,
          'Weather': formData.weatherToggle,
          'Sensor': formData.sensorToggle
        }
      }
    }

    return this.httpClient.put(ConfigService.config.eventServiceUrl + '/updateEASWorkspace', payload, this.getHeaders()).pipe(map((res: any) => res));

  }

  setWorkspaceData(data) {
    this.workspaceDataFromMap.next(data);
  }

}
