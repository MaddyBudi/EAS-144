import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { EasWorkspaceService } from '../eas-workspace.service';
import { SharedService } from '../../../shared/shared.service';
import * as $ from 'jquery';
import { HomeService } from '../../../home/home.service';
import { PanelHeaders } from '../../../panelHeaders';
import { EasRightSidebarService } from '../../map-console/eas-right-sidebar/eas-right-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { MapConsoleService } from '../../map-console/map-console.service';
import { NotifierService } from 'angular-notifier';
const swal = require('sweetalert');

@Component({
  selector: 'app-list-eas-workspace',
  templateUrl: './list-eas-workspace.component.html',
  styleUrls: ['./list-eas-workspace.component.scss']
})
export class ListEasWorkspaceComponent implements OnInit {
  panelHeader: string;
  @Output() crudViewTypeEmitter = new EventEmitter();
  displayListView = false;
  workspaceData = [];
  defaultRowsPerPage: Number = 5;
  rowsPerPageList: Number[] = [5, 10, 15];
  sortOrder = "desc";
  sortBy = "createdDate";

  constructor(public easRightSideBarService: EasRightSidebarService, private easWorkspaceService: EasWorkspaceService, private sharedService: SharedService,
    private homeService: HomeService, private mapConsoleService: MapConsoleService,
    private notifierService: NotifierService) { }

  ngOnInit() {
    this.panelHeader = PanelHeaders.workspaces;
    this.getAllWorkspace();
  }

  onClose() {
    this.easRightSideBarService.toggleSidebarToggle(TransactionMeasures.close);
  }

  createWorkspace() {
    this.easWorkspaceService.displaySuccess = false;
    this.easWorkspaceService.displayFailure = false;
    this.crudViewTypeEmitter.emit('create');
    this.mapConsoleService.getCurrentWorkspace('');
  }

  deleteWorkspace(workspace) {
    this.easWorkspaceService.displaySuccess = false;
    this.easWorkspaceService.displayFailure = false;
    swal({
      title: 'Are you sure?',
      text: 'Delete the Worksapce ' + workspace.easWorkspaceName,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DD6B55',
      confirmButtonText: 'Yes, Delete',
      cancelButtonText: 'No, cancel',
      closeOnConfirm: true,
      closeOnCancel: true
    }, (isConfirm) => {
      if (isConfirm) {
        this.easWorkspaceService.deleteWorkspace(workspace.entityId).subscribe(
          data => {
            this.getAllWorkspace();
            this.notifierService.notify("success", 'Workspace "' + workspace.easWorkspaceName + '" deleted successfully.');
            this.easWorkspaceService.displaySuccess = false;
            if (workspace.entityId === this.mapConsoleService.workspaceId) {
              this.mapConsoleService.setWorkspaceData(null)
            }
          },
          error => {
            this.easWorkspaceService.failureMessage = 'Unable to delete the Workspace "' + workspace.easWorkspaceName + '". Please try again later';
            this.easWorkspaceService.displayFailure = true;
          }
        );
      }
    });
  }

  viewWorkspace(workspace) {
     this.onClose();
    this.mapConsoleService.setWorkspaceData(workspace);
  }

  getAllWorkspace() {
    this.easWorkspaceService.displaySuccess = false;
    this.easWorkspaceService.displayFailure = false;
    this.easWorkspaceService.getAllWorkspace().subscribe(
      data => {
        this.workspaceData = data;
        this.easWorkspaceService.displayFailure = false;
        this.displayListView = true;
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.easWorkspaceService.failureMessage = 'Unable to get Workspaces. Please try again later';
          this.easWorkspaceService.displayFailure = true;
          this.displayListView = false;
        }
      }
    );
  }

  formattedAddress(address) {
    if (address) {
      const fullAddress = $.extend(true, {}, address);
      return address = this.sharedService.getFormattedAddress(fullAddress);
    } else {
      return '';
    }
  }

}
