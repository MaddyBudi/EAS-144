import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ListEasWorkspaceComponent } from './list-eas-workspace.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfigService } from '../../../core/config/config-svc.service';
import { NotifierModule } from 'angular-notifier';
import { APP_INITIALIZER } from '@angular/core';
import { EasWorkspaceService } from '../eas-workspace.service';
import { MockEasWorkspaceService } from '../eas-mock-workspace.service';
import { SharedPipe } from '../../shared.pipe';
import { DataTableModule } from 'angular-6-datatable';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// export function initializeApp(configService: ConfigService) {
//     return () => configService.getConfig();
//   }
 describe('ListEasWorkspaceComponent', () => {
  let component: ListEasWorkspaceComponent;
  let fixture: ComponentFixture<ListEasWorkspaceComponent>;
 let address =  {
  "city": "Chicago",
  "county": "Cook County",
  "dateFirstReported": null,
  "dateLastReported": null,
  "geocodedAddress": null,
  "locationId": null,
  "poBox": false,
  "searchAddress": false,
  "sourceType": "UNKNOWN",
  "state": "IL",
  "streetAddress1": "",
  "streetAddress2": "",
  "zip": ""
  }
  let data = {
    'easWorkspaceName': '',
    'geometry': '{\"type\":\"Point\",\"coordinates\":[-77.03724499999998,38.910065033571584]}',
    'address':{
        "streetAddress1": '1500, 16th St NW',
        "streetAddress2": '',
        "city": 'Washington',
        "zip": '20036',
        "state": 'DC',
        "county": ''
              },
    'properties': {
      'zoomLevel': 13,
      'eventId':  '',
      'mapTypeInfo': {
        "labels": false,
        "terrain": false,
        "type": "roadmap",
      },
      'mapLayers': {
        "bicycle": false,
         "traffic": false,
         "transit": false,
      },
      'filtersState': {
        "311": true,
        "Agency": true,
        "Annotations": true,
        "EAS-Users": true,
        "EVENT": true,
        "Field-Person": true,
        "Fire": true,
        "Fuel": true,
        "Hospital": true,
        "Hydrant": true,
        "Law": true,
        "Location": true,
        "Medical": true,
        "Sensor": false,
        "TMC": true,
        "Weather": true,
      }
    }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListEasWorkspaceComponent, SharedPipe ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule,
        DataTableModule,
        BrowserAnimationsModule
      ],
      providers: [
        ConfigService,
        // { provide: APP_INITIALIZER, useFactory: initializeApp, deps: [ConfigService], multi: true },
        { provide: EasWorkspaceService, useClass: MockEasWorkspaceService }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListEasWorkspaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  
  it('should get all workspace and count should not be zero', (done) => {
    component.getAllWorkspace()
     setTimeout(()=> {
      expect(component.workspaceData.length).not.toBe(0);
      done();
    }, 1000);
  });

  it('True if the createWorkspace() method is called and perform its action', () => {
    component.crudViewTypeEmitter.emit('create');
    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('create');
    })
    component.createWorkspace();
  });

  
  it('True if the onClose() method is called and perform its action', () => {
    component.easRightSideBarService.easRightSideBarToggle$.subscribe(g => {
      expect(g).toEqual('0%'); //checks the value emitted is list
    })
    component.onClose()
  });


  it('True if the formattedAddress() method is called', () => {
      component.formattedAddress(address)
  });

  
  it('True if the viewWorkspace() method is called', () => {
    component.viewWorkspace(data)
});


});
