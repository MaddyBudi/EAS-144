export class CrudView{
    id : number;
    viewType : string;
}