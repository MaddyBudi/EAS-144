import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { CreateEasWorkspaceComponent } from './create-eas-workspace.component';
import { NotifierModule } from 'angular-notifier';
import { GeoAddressComponent } from '../../geo-address/geo-address.component';
import { UserService } from '../../../login/services/user.service';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { SharedService } from '../../../shared/shared.service';
import { MockEasEventsService } from '../../eas-events/eas-mock-events.service';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { EasWorkspaceService } from '../eas-workspace.service';
import { MockEasWorkspaceService } from '../eas-mock-workspace.service';
import { MapsAPILoader } from '@agm/core';

describe('CreateEasWorkspaceComponent', () => {
  let component: CreateEasWorkspaceComponent;

  let fixture: ComponentFixture<CreateEasWorkspaceComponent>;
  let geoAddressComponent: GeoAddressComponent;
  let geoAddressComponentfixture: ComponentFixture<GeoAddressComponent>;
  let data = {
    'easWorkspaceName': '',
    'geometry': '{\"type\":\"Point\",\"coordinates\":[-77.03724499999998,38.910065033571584]}',
    'address':{
        "streetAddress1": '1500, 16th St NW',
        "streetAddress2": '',
        "city": 'Washington',
        "zip": '20036',
        "state": 'DC',
        "county": ''
              },
    'properties': {
      'zoomLevel': 13,
      'eventId':  '',
      'mapTypeInfo': {
        "labels": false,
        "terrain": false,
        "type": "roadmap",
      },
      'mapLayers': {
        "bicycle": false,
         "traffic": false,
         "transit": false,
      },
      'filtersState': {
        "311": true,
        "Agency": true,
        "Annotations": true,
        "EAS-Users": true,
        "EVENT": true,
        "Field-Person": true,
        "Fire": true,
        "Fuel": true,
        "Hospital": true,
        "Hydrant": true,
        "Law": true,
        "Location": true,
        "Medical": true,
        "Sensor": false,
        "TMC": true,
        "Weather": true,
      }
    }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateEasWorkspaceComponent, GeoAddressComponent ],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule     
             ],
      providers: [
        // { provide: MapsAPILoader }, 
        { provide: EasEventsService, useClass: MockEasEventsService },
        // { provide: EasWorkspaceService, useClass: MockEasWorkspaceService },
        UserService, GeoAddressService, SharedService],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateEasWorkspaceComponent);
    component = fixture.componentInstance;
    geoAddressComponentfixture = TestBed.createComponent(GeoAddressComponent);
    geoAddressComponent = geoAddressComponentfixture.componentInstance;
    fixture.detectChanges();
    geoAddressComponentfixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

    it('should validate create form', () => {
    component.workspaceForm.controls["easWorkspaceName"].setValue("karma Workspace");
    expect(component.workspaceForm.valid).toBeTruthy();
  });

    it(`True if lat,long , address value is fetched from geoAddress component and name is fetched
  from createEventForm`, (done) => { 
      component.workspaceForm.controls["easWorkspaceName"].setValue("karma Workspace");
      geoAddressComponent.geoAddressForm.controls['latitude'].setValue('42.345264');
      geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-71.096381');
      geoAddressComponent.geoAddressForm.controls['address'].setValue('1265 Boylston St, Boston, MA 02215, USA');
      geoAddressComponent.setAddress();
      setTimeout(() => {
        expect(component.workspaceForm.valid).toBeTruthy();
        expect(geoAddressComponent.geoAddressForm.valid).toBeTruthy();
        done();
      }, 1000);
    });

      it('should check for incorrect event name', () => {
      component.workspaceForm.controls["easWorkspaceName"].setValue("");
      expect(component.workspaceForm.valid).toBeFalsy();
     });


    it('True if the closeaction() method is called and perform its action', (done) => {
    component.crudViewTypeEmitter.emit('list');
    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('list'); //checks the value emitted is list
      done();
    })
    component.onClose();

  });

  it('True if the resetCreatePage() method is called and perform its action', (done) => {
    component.easWorkspaceService.setWorkspaceData(data)
    setTimeout(() => {
      component.workspaceForm.controls['easWorkspaceName'].setValue('Test');
      component.resetCreatePage() 
      expect(component.workspaceForm.valid).toBeFalsy();
       done();
  },1000);
  });

  it('True if the createWorksapce() method to check whether both locationform and geoAddressForm are valid', (done) => {
    component.createWorksapce(null,data)
    setTimeout(() => {
      expect(component.workspaceForm.valid).toBeFalsy();
      expect(geoAddressComponent.geoAddressForm.valid).toBeFalsy();
      done();
    }, 1000);
})
});
