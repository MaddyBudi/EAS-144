import { EasRightSidebarService } from '../../map-console/eas-right-sidebar/eas-right-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { SharedService } from '../../../shared/shared.service';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { EasWorkspaceService } from '../eas-workspace.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { NotifierService } from 'angular-notifier';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import * as $ from 'jquery';
declare let google: any;

@Component({
  selector: 'app-create-eas-workspace',
  templateUrl: './create-eas-workspace.component.html',
  styleUrls: ['./create-eas-workspace.component.scss']
})
export class CreateEasWorkspaceComponent implements OnInit {

  @Output() crudViewTypeEmitter = new EventEmitter();
  @Output() workspaceResult = new EventEmitter();
  workspaceForm = new FormGroup({
    easWorkspaceName: new FormControl(),
    workspaceAddress: new FormControl(),
    workspaceLatitude: new FormControl(),
    workspaceLongitude: new FormControl(),
    workspaceCoords: new FormControl(),
    zoomLevel: new FormControl(),
    eventId: new FormControl(),
    eventToggle: new FormControl(),
    locationToggle: new FormControl(),
    lawResourceToggle: new FormControl(),
    fireResourceToggle: new FormControl(),
    medicalResourceToggle: new FormControl(),
    easUsersResourceToggle: new FormControl(),
    fieldPersonnelResourceToggle: new FormControl(),
    agencyResourceToggle: new FormControl(),
    annotationToggle: new FormControl(),
    hydrantToggle: new FormControl(),
    hospitalToggle: new FormControl(),
    fuelToggle: new FormControl(),
    threeOneOneToggle: new FormControl(),
    tmcToggle: new FormControl(),
    weatherToggle: new FormControl(),
    sensorToggle: new FormControl(),
    mapType: new FormControl(),
    terrain: new FormControl(),
    labels: new FormControl(),
    bicycle: new FormControl(),
    traffic: new FormControl(),
    transit: new FormControl()
  });
  fullAddress;
  eventData = [];
  workspaceMapData;
  isFormModified = false;
  constructor(private easRightSideBarService: EasRightSidebarService, private formBuilder: FormBuilder, private sharedService: SharedService,
    private easEventsService: EasEventsService, public easWorkspaceService: EasWorkspaceService,
    private mapConsoleService: MapConsoleService, private notifierService: NotifierService,
    private geocodeAddress: GeoAddressService) { }
  ngOnInit() {
    this.easWorkspaceService.workspaceDataFromMap$.subscribe(
      data => {
        this.workspaceForm.get('workspaceLatitude').disable();
        this.workspaceForm.get('workspaceLongitude').disable();
        this.workspaceMapData = data;
        this.setMapWorkspaceForm(data);
        this.geocodeAddress.setAddressLatLng.next([JSON.parse(data.geometry).coordinates[0], JSON.parse(data.geometry).coordinates[1]]);
      }
    );
    this.getAllEvents();
  }
  onClose() {
    this.easWorkspaceService.displaySuccess = false;
    this.easWorkspaceService.displayFailure = false;
    this.crudViewTypeEmitter.emit('list');
  }
  setMapWorkspaceForm(workspaceData) {
    const geometry = JSON.parse(workspaceData.geometry);
    this.workspaceForm = this.formBuilder.group({
      'easWorkspaceName': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'workspaceAddress': [''],
      'workspaceLatitude': [''],
      'workspaceLongitude': [''],
      'workspaceCoords': [geometry.coordinates],
      'zoomLevel': [workspaceData.properties.zoomLevel, Validators.compose([Validators.min(0), Validators.max(22)])],
      'eventId': [workspaceData.properties.eventId],
      'eventToggle': [workspaceData.properties.filtersState.EVENT],
      'locationToggle': [workspaceData.properties.filtersState.Location],
      'lawResourceToggle': [workspaceData.properties.filtersState.Law],
      'fireResourceToggle': [workspaceData.properties.filtersState.Fire],
      'medicalResourceToggle': [workspaceData.properties.filtersState.Medical],
      'easUsersResourceToggle': [workspaceData.properties.filtersState["EAS-Users"]],
      'fieldPersonnelResourceToggle': [workspaceData.properties.filtersState["Field-Person"]],
      'agencyResourceToggle': [workspaceData.properties.filtersState.Agency],
      'annotationToggle': [workspaceData.properties.filtersState.Annotations],
      'hydrantToggle': [workspaceData.properties.filtersState.Hydrant],
      'hospitalToggle': [workspaceData.properties.filtersState.Hospital],
      'fuelToggle': [workspaceData.properties.filtersState.Fuel],
      'threeOneOneToggle': [workspaceData.properties.filtersState[311]],
      'tmcToggle': [workspaceData.properties.filtersState.TMC],
      'weatherToggle': [workspaceData.properties.filtersState.Weather],
      'sensorToggle': [workspaceData.properties.filtersState.Sensor],
      'mapType': [workspaceData.properties.mapTypeInfo.type],
      'terrain': [workspaceData.properties.mapTypeInfo.terrain],
      'labels': [workspaceData.properties.mapTypeInfo.labels],
      'bicycle': [workspaceData.properties.mapLayers.bicycle],
      'traffic': [workspaceData.properties.mapLayers.traffic],
      'transit': [workspaceData.properties.mapLayers.transit]
    });
    this.workspaceForm.valueChanges.subscribe(data => {
      this.isFormModified = true;
    });
  }
  createWorksapce(event, formData) {
    formData.terrain = (formData.mapType === 'satellite' && formData.terrain) ? false : formData.terrain;
    formData.labels = (formData.mapType === 'roadmap' && formData.labels) ? false : formData.labels;
    this.geocodeAddress.activeAddressInfo();
    formData.address = this.geocodeAddress.address;
    formData.latitude = this.geocodeAddress.latitude;
    formData.longitude = this.geocodeAddress.longitude;
    this.fullAddress = this.sharedService.getFullAddress(this.geocodeAddress.place);
    for (const c in this.workspaceForm.controls) {
      if (this.workspaceForm.controls.hasOwnProperty(c)) {
        this.workspaceForm.controls[c].markAsTouched();
      }
    }
    if (this.workspaceForm.valid  &&  this.geocodeAddress.checkValidation) {
      this.easWorkspaceService.createWorkspace(formData, this.fullAddress).subscribe(
        data => {
          this.onClose();
          this.notifierService.notify("success", 'Workspace "' + formData.easWorkspaceName + '" created successfully.')
          this.geocodeAddress.resetAll();
          this.easWorkspaceService.displaySuccess = false;
          this.easWorkspaceService.displayFailure = false;
          this.geocodeAddress.resetAll();
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.easWorkspaceService.failureMessage = 'Unable to create Workspace. Please try again later';
            this.easWorkspaceService.displayFailure = true;
            this.easWorkspaceService.displaySuccess = false;
            this.workspaceResult.next({ "result": "failure", "message": this.easWorkspaceService.failureMessage });
          }
        }
      );
    }
  }
  resetCreatePage() {
    this.setMapWorkspaceForm(this.workspaceMapData);
    this.geocodeAddress.resetAll();
    this.isFormModified=false
  }
  getAllEvents() {
    this.easEventsService.getAllEvents().subscribe(
      data => {
        data.forEach(element => {
          if (element.status === 'STARTED' && !element.deleted) {
            this.eventData.push(element);
          }
        });
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {

        }
      }
    );
  }
}
