import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class HomeService {
  homeServiceViewOnchange = new Subject<any>();
  homeServiceViewOnchange$ = this.homeServiceViewOnchange.asObservable();

  private contextSource = new Subject<any>();
  contextSource$ = this.contextSource.asObservable();

  setContextEvent(contextEvent: Object) {
    console.log('Inside setContextEvent');
    this.contextSource.next(contextEvent);
  }

  constructor() { }

  public onViewChange(item: any) {
    this.homeServiceViewOnchange.next(item);
  }

  public clearContext(eventId) {
    console.log('Inside clearContext');
    this.contextSource.next(eventId);
  }
}
