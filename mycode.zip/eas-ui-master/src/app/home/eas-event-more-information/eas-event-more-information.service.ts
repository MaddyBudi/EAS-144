import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})

export class EasEventMoreInformationService {
  displayClearIcon = false;
  cLoseCameraFeeds = new Subject<string>();
  cLoseCameraFeeds$ = this.cLoseCameraFeeds.asObservable();
  isToogleCameraOpen = new Subject<string>();
  isToogleCameraOpen$ = this.isToogleCameraOpen.asObservable();
  toggleModifyLocIcon = new Subject<string>();
  toggleModifyLocIcon$ = this.toggleModifyLocIcon.asObservable();


  constructor() { }

  closeCameraFeed() {
    this.cLoseCameraFeeds.next();
  }

  toogleCameraFeed() {
    this.isToogleCameraOpen.next();
  }
  toggleModifyLocationIcon(data) {
    this.toggleModifyLocIcon.next(data);
  }
}
