// import { TestBed } from '@angular/core/testing';

// import { EasEventMoreInformationService } from './eas-event-more-information.service';

// describe('EasEventMoreInformationService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: EasEventMoreInformationService = TestBed.get(EasEventMoreInformationService);
//     expect(service).toBeTruthy();
//   });
// });
