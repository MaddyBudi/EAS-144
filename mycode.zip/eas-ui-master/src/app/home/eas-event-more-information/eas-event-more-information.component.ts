import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { SharedService } from '../../shared/shared.service';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EasResourcesService } from '../eas-resources/eas-resources.service';
import { EasEventsService } from '../eas-events/eas-events.service';
import { EasAnnotationsService } from '../eas-annotations/eas-annotations.service';
import { MapConsoleService } from '../map-console/map-console.service';
import { ConfigService } from '../../core/config/config-svc.service';
import { map } from 'rxjs/operators';
import * as $ from 'jquery';
import { EasLeftSidebarComponent } from '../map-console/eas-left-sidebar/eas-left-sidebar.component';
import { EasLeftSidebarService } from '../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { TransactionMeasures } from '../../transactionMeasures';
import { EntitiesMiniListService } from '../map-console/entities-mini-list/entities-mini-list.service';
import { EasEventMoreInformationService } from './eas-event-more-information.service';
import { FindRouteService } from '../map-console/find-route/find-route.service';
import { PanelHeaders } from '../../panelHeaders';
import { PersonService } from '../map-console/person/person.service';
import { DataModel } from '../../dataModelEnum';
import { NotifierService } from 'angular-notifier';
import { AssignEasResourcesService } from '../eas-resources/assign-eas-resources/assign-eas-resources.service';
import { EpttService } from '../map-console/eptt/eptt.service';
import { EasPredefinedLocationsService } from '../eas-predefined-locations/eas-predefined-locations.service';
import { AppGlobals } from '../../shared/app.globals';

declare let google: any;
let controller;
@Component({
  selector: 'app-eas-event-more-information',
  templateUrl: './eas-event-more-information.component.html',
  styleUrls: ['./eas-event-more-information.component.scss']
})
export class EasEventMoreInformationComponent implements OnInit, OnChanges {
  @Input() selectedEntityId;
  @Input() easOtherEntitiesData: any;
  @Input() selectedLocationId;
  isOpenCameraWidget = false;
  isExtraCameraPanelOpen = false;
  cameraObject: any;
  public eventData = [];
  isToogleCameraOpen = false;
  public weatherData = [];
  public airQualityData = [];
  displayFailure = false;
  displayFailureWeather = false;
  displayFailureAirQuality = false;
  failureMessage: string;
  failureMessageAirQuality: string;
  assignedAnnotations = [];
  showAnnotations;
  assignedResources = [];
  eventToogle = true;
  entitiesToogle = true;
  showResources;
  eventGeometry;
  getMoreInfo = false;
  selectedResource;
  isResourceInfoOpen: boolean;
  locationData = [];
  attachedFileIds = [];
  private readonly notifier: NotifierService;
  hideScroll = false;
  constructor(private http: HttpClient, public epttService: EpttService, public sharedService: SharedService,
    private annotationSvc: EasAnnotationsService, private eventSvc: EasEventsService,
    private resourceService: EasResourcesService, public mapConsoleService: MapConsoleService,
    private easEventMoreInformationService: EasEventMoreInformationService, private easLeftSideBarServe: EasLeftSidebarService,
     private entitiesService: EntitiesMiniListService, private findRouteService: FindRouteService,
     private personService: PersonService, notifierService: NotifierService, public assignEasResourcesService: AssignEasResourcesService,
    private easPredefinedLocationsService: EasPredefinedLocationsService, public appGlobals: AppGlobals) {
    this.eventData = [];
    this.notifier = notifierService;
  }
  getEventDetails(id) {
    if (id) {
      this.eventSvc.getEventDetails(id).subscribe(
        data => {
          this.setEventData(data);
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.eventSvc.setFailureMessage('General error occured. Please try again later.');
          }
        }
      );
    }
  }
  setEventData(data) {
    this.weatherData = [];
    this.displayFailureWeather = false;
    this.displayFailureAirQuality = false;
    this.attachedFileIds = [];
    const tempEventArray = [];
    const fullAddress = $.extend(true, {}, data.address);
    const address = this.sharedService.getFormattedAddress(fullAddress);
    this.eventGeometry = data.geometry;
     if(data.attachedFilesId && null !== data.attachedFilesId && data.attachedFilesId.length>0)
      {
        data.attachedFilesId.forEach(element => {
          this.attachedFileIds.push(ConfigService.config.eventServiceUrl+this.appGlobals.retrieveAttachedFilesEndpoint+element);
        });
      }
    const eventDetail = {
      'id': data.id,
      'eventName': data.eventName,
      'eventStatus': data.status,
      'entityID': data.entityId,
      'eventAddress': address,
      'personAddress': data.address,
      'eventDesc': data.eventDesc,
      'shapeType': data.geometry.type,
      'creator': data.creator,
      'organization_name': data.organizationName,
      'createdDate': data.createdDate,
      'priority': data.priority,
  
    };
    tempEventArray.push(eventDetail);
    this.eventData = tempEventArray;
    if (data.assignedAnnotations && data.assignedAnnotations !== null) {
      this.showAnnotations = true;
      this.getAssignedAnnotations(data);
    }
    if (data.assignedResources && data.assignedResources !== null && data.assignedResources.length !== 0) {
      this.showResources = true;
      this.getAssignedResources(data);
    }
    if (data.attachedFilesId && null !== data.attachedFilesId && data.attachedFilesId.length > 0) {
        data.attachedFilesId.forEach(element => {
          this.attachedFileIds.push(ConfigService.config.eventServiceUrl + this.appGlobals.retrieveAttachedFilesEndpoint + element);
        });
      }
  }
  getWeatherInfo() {
    this.displayFailureWeather = false;
    this.displayFailureAirQuality = false;
    let bounds = '';
    if (this.eventGeometry.type === 'Point') {
      const circle = new google.maps.Circle({
        radius: 12000,
        fillOpacity: 0,
        center: new google.maps.LatLng(this.eventGeometry.coordinates[1], this.eventGeometry.coordinates[0]),
      });
      bounds = circle.getBounds();
    } else if (this.eventGeometry.type === 'Polygon') {
      const coords = this.eventGeometry.coordinates[0];
      const lat = [];
      const lng = [];
      coords.forEach((val) => {
        lng.push(val[0]);
        lat.push(val[1]);
      });
      const rectangle = new google.maps.Rectangle({
        bounds: {
          north: Math.max(...lat),
          south: Math.min(...lat),
          east: Math.max(...lng),
          west: Math.min(...lng)
        }
      });
      bounds = rectangle.getBounds();
    }
    this.getWeather(bounds).subscribe(
      data => {
        this.setWeatherData(data);
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        }
      }

    );
  }
  getAirqualityInfo() {
    this.notifier.notify('error', 'Air Quality data is not available at this time. Please try again later or contact your administrator.');
    // console.log(this.eventData);
    // this.mapConsoleService.getSituationalData('AIRQUALITY', this.eventData[0].entityID);
    // controller.displayFailure = true;
    // controller.failureMessage = 'No Air Quality data found';
    // setTimeout(function () {
    //   controller.displayFailure = false;
    //   controller.failureMessage = '';
    // }, 4000);
  }
  ngOnInit() {
    controller = this;
    this.easEventMoreInformationService.cLoseCameraFeeds$.subscribe(
      data => {
        this.isOpenCameraWidget = false;
        this.isExtraCameraPanelOpen = false;
        this.easLeftSideBarServe.toggleSidebarToggle(TransactionMeasures.miniView);
      }
    );
    this.easEventMoreInformationService.isToogleCameraOpen$.subscribe(
      data => {
        this.isExtraCameraPanelOpen = true;
        this.easLeftSideBarServe.toggleSidebarToggle(TransactionMeasures.maxView);
      }
    );
    this.easEventMoreInformationService.toggleModifyLocIcon$.subscribe(data => {
      if (data === 'displayModifyLocIcon') {
        this.easEventMoreInformationService.displayClearIcon = false;
      } else if (data === 'displayClearIcon') {
        this.easEventMoreInformationService.displayClearIcon = true;
      }

    });
  }
  getHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All'
      }),
      withCredentials: true
    };
    return httpOptions;
  }
  public getWeather(bounds) {
    let payload;
    payload = {
      'first': {
        'y': bounds.getNorthEast().lat(),
        'x': bounds.getNorthEast().lng()
      },
      'second': {
        'y': bounds.getSouthWest().lat(),
        'x': bounds.getSouthWest().lng()
      }
    };
    return this.http.post(ConfigService.config.situationaldataUrl + '/WeatherForecastByView',
      payload, this.getHeaders()).pipe(map((res: any) => res));
  }
  setWeatherData(data) {
    const tempWeatherArray = [];
    this.weatherData = [];
    if (data.entityId != null) {
      let weatherList;
      let weatherDetailMain;
      let weatherDetailWind;
      let weatherDetailDesc;
      weatherList = data.properties.list;
      if (weatherList) {
        weatherDetailMain = weatherList[weatherList.length - 1].main;
        weatherDetailWind = weatherList[weatherList.length - 1].wind;
        weatherDetailDesc = weatherList[weatherList.length - 1].weather;
      } else {
        weatherDetailMain = data.properties.main;
        weatherDetailWind = data.properties.wind;
        weatherDetailDesc = data.properties.weather;
      }
      const weatherData = {
        'id': data.entityId,
        'weather': weatherDetailDesc[0].main,
        'temperature': weatherDetailMain.temp,
        'pressure': weatherDetailMain.pressure,
        'humidity': weatherDetailMain.humidity,
        'min_temp': weatherDetailMain.temp_min,
        'max_temp': weatherDetailMain.temp_max,
        'sea_level': weatherDetailMain.sea_level,
        'ground_level': weatherDetailMain.grnd_level,
        'wind_speed': weatherDetailWind.speed
      };
      tempWeatherArray.push(weatherData);
    }
    this.weatherData = tempWeatherArray;
    if ($('#weatherdata').css('display') === 'none') {
      $('#eventdata').hide();
      $('#weatherdata').show();
    }
  }
  closeAction() {
    $('#weatherdata').hide();
    $('#eventdata').show();
  }
  getAssignedAnnotations(event) {
    const annotations = event.assignedAnnotations;
    annotations.forEach((element) => {
      this.annotationSvc.getAnnotationDetails(element).subscribe(
        data => {
          this.assignedAnnotations.push(data);
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.displayFailure = true;
            this.failureMessage = 'General error occured. Please try again later.';
          }
        }
      );
    });
  }
  getAssignedResources(event) {
    const resources = event.assignedResources;
    resources.forEach((element) => {
      this.resourceService.getResourceDetailsById(element).subscribe(
        data => {
          this.assignedResources.push(data);
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          }
        }
      );
    });
  }
  ngOnChanges(changes) {
    if (changes.hasOwnProperty('selectedEntityId')) {
      if (changes.selectedEntityId.currentValue) {
        this.getEventDetails(changes.selectedEntityId.currentValue);
      }
    }
    if (changes.hasOwnProperty('easOtherEntitiesData')) {
      if (changes.easOtherEntitiesData.currentValue) {
        this.easOtherEntitiesData = changes.easOtherEntitiesData.currentValue;
      }
    }
  }
  onClose() {
    if (this.selectedLocationId) {
      this.selectedLocationId = '';
      this.entitiesService.closeMoreInfoForLocation();
      this.easLeftSideBarServe.cLoseMoreInfo();
    } else if (!this.easOtherEntitiesData) {
      this.easLeftSideBarServe.cLoseMoreInfo();
      this.entitiesService.cLoseMoreInfoEvent();
    } else if (this.selectedEntityId) {
      this.entitiesService.cLoseMoreInfoEvent();
      this.selectedEntityId = '';
      if (!this.eventToogle) {
        this.eventToogle = !this.eventToogle;
      }
    }
  }
  resourceInfo(data) {
    const properties = {
      properties: data
    };
    this.easOtherEntitiesData = {
      dataEntityId: data.entityId,
      dataModel: data.resourceObject,
      payload: properties
    };
    this.isResourceInfoOpen = true;
  }
  onCloseOtherEntities() {
    if (this.easEventMoreInformationService.displayClearIcon) {
      const mapEntityType = (this.easOtherEntitiesData.dataModel === 'ANNOTATION') ? 'Annotation' : 'Resource';
      this.notifier.notify('error', 'Modify ' + mapEntityType + ' location "' +
        this.easOtherEntitiesData.payLoad.payload.properties.resourceName +
        '" is enabled. Kindly clear or update the selected ' + mapEntityType);
    } else if (!this.selectedEntityId) {
      this.easLeftSideBarServe.cLoseMoreInfo();
      this.entitiesService.cLoseMoreInfoOther();
      this.assignEasResourcesService.closeMoreInfo();
    } else {
      this.easOtherEntitiesData = '';
      this.entitiesService.cLoseMoreInfoOther();
      if (!this.entitiesToogle) {
        this.entitiesToogle = !this.entitiesToogle;
      }
    }
  }
  toogleOtherEventInformation() {
    if (this.eventToogle) {
      this.eventToogle = !this.eventToogle;
      document.getElementById('eventCard').style.height = '88vh';
    } else {
      this.eventToogle = !this.eventToogle;
      document.getElementById('eventCard').style.height = '35Vh';
    }

  }
  toogleEventInformation() {
    if (this.entitiesToogle) {
      this.entitiesToogle = !this.entitiesToogle;
      document.getElementById('otherEntitiesCard').style.height = '85vh';
    } else {
      this.entitiesToogle = !this.entitiesToogle;
      document.getElementById('otherEntitiesCard').style.height = '35Vh';
    }
  }
  cameraObjectEmitter(data) {
    this.cameraObject = data;
  }
  openCameraWidget() {
    this.easLeftSideBarServe.toggleSidebarToggle(TransactionMeasures.fullView);
    this.isOpenCameraWidget = !this.isOpenCameraWidget;
  }

  sendPersonLocation(payload) {
    const resourceRouteData = {
      'origin': null,
      'destination': null,
      'assignedEventId': null
    };
    this.mapConsoleService.openRightSidePanel(PanelHeaders.findRoute);
    const fullAddress = $.extend(true, {}, payload.properties.address);
    resourceRouteData.origin = this.sharedService.getFormattedAddress(fullAddress);
    if (payload.properties.assignedTo && payload.properties.assignedTo !== '') {
      resourceRouteData.assignedEventId = payload.properties.assignedTo;
      this.eventSvc.getEventDetails(resourceRouteData.assignedEventId).subscribe(
        data => {
          const fullAddress = $.extend(true, {}, data.address);
          resourceRouteData.destination = this.sharedService.getFormattedAddress(fullAddress);
          this.findRouteService.setResourceRouteData(resourceRouteData);
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.eventSvc.setFailureMessage('General error occured. Please try again later.');
          }
        }
      );
    } else {
      this.findRouteService.setResourceRouteData(resourceRouteData);
    }
    
  }

  viewPersonSearchComponent(personAddress) {
    this.mapConsoleService.openRightSidePanel(PanelHeaders.powerDataSearch);
    this.personService.getPersonDetails(personAddress);
  }
  toggleModifyLocIcons(data) {
    this.easEventMoreInformationService.displayClearIcon = !this.easEventMoreInformationService.displayClearIcon;
    this.mapConsoleService.modifyResourceLoc(data);
  }
  makeEpttCall(data) {
    const  selectedUsers  =  [];
    this.mapConsoleService.openRightSidePanel(PanelHeaders.eptt);
    const  userMdn  =  {  'phoneNumber':  data.properties.kodiakMdn  };
    selectedUsers.push(userMdn);
    this.epttService.setSelectedUsers(selectedUsers);


  }
  makeEpttAlert(data) {
    const  selectedUsers  =  [];
    this.mapConsoleService.openRightSidePanel(PanelHeaders.eptt);
    const  userMdn  =  {  'phoneNumber':  data.properties.kodiakMdn  };
    selectedUsers.push(userMdn);
     this.epttService.setSelectedUserAlert(selectedUsers);
  }

  setScrollHeight( tabName ) {
   this.hideScroll = (tabName === 'notes')?true:false;
       console.log(this.hideScroll);
  }
}
