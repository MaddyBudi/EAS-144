// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EasEventMoreInformationComponent } from './eas-event-more-information.component';

// describe('EasEventMoreInformationComponent', () => {
//   let component: EasEventMoreInformationComponent;
//   let fixture: ComponentFixture<EasEventMoreInformationComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EasEventMoreInformationComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EasEventMoreInformationComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
