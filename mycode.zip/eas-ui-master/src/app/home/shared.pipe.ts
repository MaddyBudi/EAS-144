import { Pipe, PipeTransform, Inject, forwardRef } from '@angular/core';
// import { EventwidgetComponent } from './events/eventwidget/eventwidget.component'
import * as _ from "lodash";
import { SharedService } from '../shared/shared.service';
import * as $ from 'jquery';

@Pipe({
    name: 'shared'
})
export class SharedPipe implements PipeTransform {

    constructor(private sharedService: SharedService) { }

    transform(array: any[], query: string, searchtype: string, fromPage: string): any {
        if (searchtype === "event") {
            if (query && fromPage === "eventMain") {
                return _.filter(array, row => row.eventName.toLowerCase().indexOf(query.toLowerCase().trim()) > -1 ||
                    row.status.toLowerCase().indexOf(query.toLowerCase().trim()) > -1 ||
                    (this.sharedService.getFormattedAddress($.extend(true, {}, row.address))).toLowerCase().indexOf(query.toLowerCase().trim()) > -1);
            } else if (query && fromPage === "eventWidget") {
                return _.filter(array, row => row.eventName.toLowerCase().indexOf(query.toLowerCase().trim()) > -1);
            } else if (query && fromPage === "eventFullList") {
                return _.filter(array, row => row.eventName.toLowerCase().indexOf(query.toLowerCase().trim()) > -1 ||
                    row.eventStatus.toLowerCase().indexOf(query.toLowerCase().trim()) > -1);
            }
            return array;
        }

        if (searchtype === "location") {
            if (query) {
                return _.filter(array, row => row.name.toLowerCase().indexOf(query.toLowerCase().trim()) > -1);
            }
            return array;
        }
        if (searchtype === "resourceType") {
            if (query) {
                return _.filter(array, row => row.name.toLowerCase().indexOf(query.toLowerCase().trim()) > -1);
            }
            return array;
        }
        if (searchtype === "notes") {
            if (query) {
                return _.filter(array, row => row.comment.toLowerCase().indexOf(query.toLowerCase().trim())
                    > -1 || row.creator.toLowerCase().indexOf(query.toLowerCase()) > -1);
            }
            return array;
        }
        if (searchtype === "resource") {
            if (query) {
                return _.filter(array, row => row.resourceName.toLowerCase().indexOf(query.toLowerCase().trim()) > -1
                );
            }
            return array;
        }
        if (searchtype === "resourceGroup") {
            if (query) {
                return _.filter(array, row => row.name.toLowerCase().indexOf(query.toLowerCase().trim()) > -1 );
            }
            return array;
        }
        if (searchtype === "workspace") {
            if (query && fromPage === "workspaceMain") {
                return _.filter(array, row => row.easWorkspaceName.toLowerCase().indexOf(query.toLowerCase().trim()) > -1 ||
                    (this.sharedService.getFormattedAddress($.extend(true, {}, row.address))).toLowerCase().indexOf(query.toLowerCase().trim()) > -1 );
            }
            return array;
        }
    }
}


