// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EasPredefinedLocationsComponent } from './eas-predefined-locations.component';

// describe('EasPredefinedLocationsComponent', () => {
//   let component: EasPredefinedLocationsComponent;
//   let fixture: ComponentFixture<EasPredefinedLocationsComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EasPredefinedLocationsComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EasPredefinedLocationsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
