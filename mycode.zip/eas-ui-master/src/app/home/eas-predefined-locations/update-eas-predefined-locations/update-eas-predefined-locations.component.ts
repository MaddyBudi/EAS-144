import { Component, OnInit, OnChanges, Input, SimpleChange, Inject, forwardRef, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { EasPredefinedLocationsService } from '../eas-predefined-locations.service';
import { SharedService } from '../../../shared/shared.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { NotifierService } from 'angular-notifier';
import { LocationTo } from '../../../shared/models/locationTo';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';


@Component({
  selector: 'app-update-eas-predefined-locations',
  templateUrl: './update-eas-predefined-locations.component.html',
  styleUrls: ['./update-eas-predefined-locations.component.scss']
})
export class UpdateEasPredefinedLocationsComponent implements OnInit {

  @Input() selectedLocationIdFromMap: string;
  @Output() sendUpdatedData = new EventEmitter();
  @Output() crudViewTypeEmitter = new EventEmitter();


  updateLocationForm = new FormGroup({
    name: new FormControl(),
    address: new FormControl(),
    latitude: new FormControl(),
    longitude: new FormControl()
  });
  selectedLocationId;
  primaryCategoryList: any;
  displayUpdateContent = true;
  isFormModified = false;
  locationDetails: LocationTo;
  selectedItems = [];
  resetData: LocationTo;
  public countiesMap = new Map();
  constructor(public formGroup: FormBuilder, public predefinedLocationService: EasPredefinedLocationsService,
    public sharedService: SharedService, public mapConsoleService: MapConsoleService,
    private notificationService: NotifierService, private geoAddressService: GeoAddressService,
    public easLeftSidebarService: EasLeftSidebarService) {
  }
  ngOnInit() {
    this.predefinedLocationService.displayFailure = false;
    this.selectedLocationId = (this.selectedLocationIdFromMap === undefined) ?
      this.predefinedLocationService.getLocationId() : this.selectedLocationIdFromMap;
    console.log(this.selectedLocationId);
    this.predefinedLocationService.getPredefinedLocationsById(this.selectedLocationId).subscribe(
      data => {
        console.log(data);
        console.log(data instanceof LocationTo);
        this.locationDetails = data;
        this.resetData = Object.assign({}, this.locationDetails);
        this.setupdateLocationForm();
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.predefinedLocationService.displayFailure = (this.selectedLocationIdFromMap === undefined) ? true : false;
          this.predefinedLocationService.setFailureMessage('General error occured. Please try again later.');
        }
      }
    );
    this.updateLocationForm = this.formGroup.group({
      'name': ['', Validators.required],
      'address': [''],
      'latitude': [],
      'longitude': []
    });
  }
  setupdateLocationForm() {
    this.updateLocationForm.controls['name'].setValue(this.locationDetails.name);
    this.geoAddressService.coordinates = this.locationDetails.geometry['coordinates'];
    if (this.locationDetails.geometry['type'] !== 'Point') {
      this.geoAddressService.disableAddressLatLng.next();
    }
    this.geoAddressService.setAddressLatLng.next([this.locationDetails.properties['latlng']['longitude'],
      this.locationDetails.properties['latlng']['latitude']]);
    this.updateLocationForm.valueChanges.subscribe(data => {
      this.isFormModified = true;
    });
  }
  updateLocation(event, formData) {
    this.geoAddressService.activeAddressInfo();
    this.locationDetails.properties['address'] = this.geoAddressService.address;
    this.locationDetails.properties['latlng']['latitude'] = Number(this.geoAddressService.latitude);
    this.locationDetails.properties['latlng']['longitude'] = Number(this.geoAddressService.longitude);
    this.locationDetails.geometry['coordinates'] = this.geoAddressService.coordinates;
    // event.preventDefault();
    for (const c in this.updateLocationForm.controls) {
      if (this.updateLocationForm.controls.hasOwnProperty(c)) {
        this.updateLocationForm.controls[c].markAsTouched();
      }
    }
    if (this.isFormModified && this.updateLocationForm.valid && this.geoAddressService.checkValidation) {
      if (this.updateLocationForm.value.locationName !== this.locationDetails.name) {
        this.predefinedLocationService.updatePredefinedLocations(this.locationDetails).subscribe(
          data => {
            if (data.id !== null) {
              const payload = {
                'data': data,
                'isUpdated': true
              };
              this.sendUpdatedData.emit(payload);
              this.getListView();
              this.notificationService.notify('success', 'Location "' + this.locationDetails.name + '" updated successfully.');
            } else {
              this.notificationService.notify('error', 'Unable to update the location now.');
            }
          },
          error => {
            if (error.status === 401) {
              this.sharedService.routeToLoginError(error.status);
            } else if (error.status === 400) {
              this.notificationService.notify('error', 'Location "' + this.locationDetails.name + '"already exists');
            } else {
              this.notificationService.notify('error', 'General error occured. Please try again later.');
            }
          }
        );
      } else {
        this.notificationService.notify('error', 'Please modify the location details to update');
      }
    } else {
      this.notificationService.notify('error', 'Please modify the location details/provide correct details to update');

    }
  }
  resetUpdatePage(location) {
    this.isFormModified = false;
    this.setupdateLocationForm();
    this.updateLocationForm.reset(this.resetData);
  }
  closeAction(event) {
    this.getListView();
  }
  onClose() {
    this.easLeftSidebarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }
  getListView() {
    this.crudViewTypeEmitter.emit('list');
    const payload = {
      'data': this.locationDetails,
      'isUpdated': true
    };
    this.sendUpdatedData.emit(payload);
    this.mapConsoleService.mapConsoleComponentSource.next('closeUpdateLocationComponent');
  }
  hideErrorMessage(event) {
    this.predefinedLocationService.displayFailure = false;
  }

}
