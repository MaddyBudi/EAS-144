import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateEasPredefinedLocationsComponent } from './update-eas-predefined-locations.component';
import { DebugElement } from '@angular/core';
import { GeoAddressComponent } from '../../geo-address/geo-address.component';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { MapsAPILoader } from '@agm/core';
import { LocationTo } from '../../../shared/models/locationTo';
import { UserService } from '../../../login/services/user.service';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { EasPredefinedLocationsService } from '../eas-predefined-locations.service';
import { SharedService } from '../../../shared/shared.service';
import { PredefinedLocationMockService } from '../eas-mock-predefined-locations.service';

describe('UpdateEasPredefinedLocationsComponent', () => {
  let component: UpdateEasPredefinedLocationsComponent;
  let fixture: ComponentFixture<UpdateEasPredefinedLocationsComponent>;
  let geoAddressComponent: GeoAddressComponent;
  let geoAddressComponentfixture: ComponentFixture<GeoAddressComponent>;
  let payload = {
    'name': '',
    'type': 'Predefined Location',
    'geometry': {

    },
    'properties': {
      'latlng': {

      }
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [UpdateEasPredefinedLocationsComponent, GeoAddressComponent],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule
      ],
      providers: [{ provide: EasPredefinedLocationsService, useClass: PredefinedLocationMockService }, UserService, GeoAddressService, SharedService, EasLeftSidebarService],

    })
      .compileComponents();
    fixture = TestBed.createComponent(UpdateEasPredefinedLocationsComponent);
    geoAddressComponentfixture = TestBed.createComponent(GeoAddressComponent);
    component = fixture.componentInstance;
    geoAddressComponent = geoAddressComponentfixture.componentInstance;
    component.locationDetails = new LocationTo(Object.assign({}, payload));
    component.resetData = new LocationTo(Object.assign({}, payload));
  }));

  beforeEach(() => {
    fixture.detectChanges();
    geoAddressComponentfixture.detectChanges();
  });


  it('True if the component is created successfully', (() => {
    expect(component).toBeTruthy();
  }));

  it('should set the locationDetails', (done) => {
    setTimeout(() => {
      expect(geoAddressComponent.geoAddressForm.valid && component.updateLocationForm.valid).toBeTruthy();
    }, 1000);
    done();

  });

  it('True if locationname provided is valid', () => {
    component.updateLocationForm.controls['name'].setValue('Test Location For Karma');
    expect(component.updateLocationForm.valid).toBeTruthy();
  });

  it('False if the inputs are not given in updateLocationForm', () => {
    expect(geoAddressComponent.geoAddressForm.valid && component.updateLocationForm.valid).toBeFalsy();
  });

  it('True if the values for lat,long,address and name is provided in updateLocationForm', (done) => {

    component.updateLocationForm.controls['name'].setValue('Karma Location For Test');
    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('42.345264');
    geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-71.096381');
    geoAddressComponent.geoAddressForm.controls['address'].setValue('1265 Boylston St, Boston, MA 02215, USA');
    setTimeout(() => {
      expect(component.updateLocationForm.valid && geoAddressComponent.geoAddressForm.valid).toBeTruthy();
      done();
    }, 1000);

  });

  it('False if Address is not provided from updateLocationForm', (done) => {   // should get the value from the geocomponent

    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('-73.934306');
    geoAddressComponent.geoAddressForm.controls['longitude'].setValue('40.797878');
    component.updateLocationForm.controls['name'].setValue('Karma Location For Test');
    setTimeout(() => {
      expect(component.updateLocationForm.valid && geoAddressComponent.geoAddressForm.valid).toBeFalsy();
      done();
    }, 1000);
  });

  it('False if lat,long is not provided in updateLocationForm', () => {   // should get the value from the geocomponent
    geoAddressComponent.geoAddressForm.controls['address'].setValue('1265 Boylston St, Boston, MA 02215, USA');
    geoAddressComponent.setAddress();
    expect(component.updateLocationForm.valid && geoAddressComponent.geoAddressForm.valid).toBeFalsy();

  });

  it('False if latitude,name is given and address, longitude are not given in updateLocationForm', (done) => {
    component.updateLocationForm.controls['name'].setValue('Test Location For KArma');
    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('40.739197');
    geoAddressComponent.setAddress();
    setTimeout(() => {
      expect(geoAddressComponent.geoAddressForm.valid && component.updateLocationForm.valid).toBeFalsy();
      done();
    }, 1000);
  });
  
  it('True if the updateLocation() method to check whether both locationform and geoAddressForm are valid', () => {
        geoAddressComponent.geoAddressForm.controls['latitude'].setValue('38.889889');
        geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-76.949526');
        component.updateLocation(null,component.locationDetails);
        expect(component.updateLocationForm.valid && geoAddressComponent.geoAddressForm.valid).toBeFalsy();

    })
  
  it('True if the resetUpdatetemethod() operation is performed ', () => { // resets the page
    component.resetUpdatePage(component.locationDetails);
    expect(geoAddressComponent.geoAddressForm.valid).toBeFalsy();

  });

  it('True if the closeaction() method is called and perform its action', (done) => {

    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('list');
      done();
    });
    component.closeAction(null);

  });

  it("True if onClose() method is called and the component is closed successfully", (done) => {
   
    component.easLeftSidebarService.easleftSidebarToggle$.subscribe(data => {
      expect(data).toEqual('0%');
      done();
    })
     component.onClose();
  })
});
