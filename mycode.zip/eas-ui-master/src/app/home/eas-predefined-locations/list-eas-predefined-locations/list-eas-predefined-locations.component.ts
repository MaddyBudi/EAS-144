import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import * as _ from 'lodash';
import * as $ from 'jquery';
import { EasPredefinedLocationsService } from '../eas-predefined-locations.service';
import { environment } from '../../../../environments/environment';
import { SharedService } from '../../../shared/shared.service';
import { UserService } from '../../../login/services/user.service';
import { AppGlobals } from '../../../shared/app.globals';
import { HomeService } from '../../../home/home.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { NotifierService } from 'angular-notifier';
import { LocationTo } from '../../../shared/models/locationTo';
import { DataModel } from '../../../dataModelEnum';


const swal = require('sweetalert');
@Component({
  selector: 'app-list-eas-predefined-locations',
  templateUrl: './list-eas-predefined-locations.component.html',
  styleUrls: ['./list-eas-predefined-locations.component.scss']
})
export class ListEasPredefinedLocationsComponent implements OnInit {
  easOtherEntitiesData;
  public locationData: LocationTo[];
  displayListView;
  flag = false;
  checkAll = false;
  displayLocationResults = true;
  multiSelectLocation = [];
  selectedAllLocations = false;
  predefinedLocations = [];
  singleLocation;
  viewCheckbox = false;
  marked = false;
  selectedId = [];
  multipleLocations = [];
  markedAll = false;
  locdata;
  enableDrag = true;
  selectedIdForModify;
  isLoading = true;
  selectedEntityId;
  rowsPerPageList: number[] = this.appglobals.RowsPerPageList;
  defaultRowsPerPage: number = this.appglobals.DefaultRowsPerPage;
  @Output() viewMapLocation = new EventEmitter();
  @Output() crudViewTypeEmitter = new EventEmitter();
  sortBy = 'createdDate';
  sortOrder = 'desc';
  isMoreInfo = false;
  constructor(public predefinedLocationService: EasPredefinedLocationsService,
    public userService: UserService, public homeService: HomeService,
    public sharedService: SharedService,
    private appglobals: AppGlobals,
    public easleftSideBarService: EasLeftSidebarService,
    public mapConsoleService: MapConsoleService, private notifierService: NotifierService) {
    this.mapConsoleService.cancelModifyLocation$.subscribe(
      data => {
        this.enableDrag = true;
        this.selectedIdForModify = '';
        this.getLocations();
      }
    );
  }
  ngOnInit() {
    this.getLocations();
    this.predefinedLocationService.closeMoreInformation$.subscribe(data => {
      this.isMoreInfo = false;
      this.selectedEntityId = undefined;
    });
    this.selectedAllLocations = false;
  }
  getLocations() {
    this.predefinedLocationService.getPredefinedLocations().subscribe(
      data => {
        this.predefinedLocationService.displayFailure = false;
        this.isLoading = false;
        data.forEach(element => {
          console.log(element instanceof LocationTo);
        });
        this.locationData = data;
        this.displayListView = true;
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.predefinedLocationService.displayFailure = true;
          this.displayListView = false;
          this.predefinedLocationService.failureMessage = 'Unable to get locations. Please try again later.';

        }
      });
  }
  toggleVisibility(isChecked, item: LocationTo) {
    if (isChecked) {
      this.multipleLocations.push(item);
    } else {
      const index = this.multipleLocations.findIndex(x => x.id === item.id);
      if (~index) {
        this.multipleLocations.splice(index, 1);
      }
    }
  }
  plotSelectedLocations() {
    console.log(this.multipleLocations);
    if (this.multipleLocations.length === 0) {
      this.notifierService.notify('error', 'Please select atleast one location to view');
    } else {
      const entitiesData = this.sharedService.formPayloadForEntitiesMoreInfo(this.multipleLocations, false, true);
      this.mapConsoleService.viewMapLocationMap(entitiesData);
      this.onClose();
    }
  }
  createLocation(e) {
    this.predefinedLocationService.displaySuccess = false;
    this.predefinedLocationService.displayFailure = false;
    this.crudViewTypeEmitter.emit('create');
  }
  editLocation(location: LocationTo) {
    if (this.userService.userName === location.createdBy) {
      this.crudViewTypeEmitter.emit('update');
      this.predefinedLocationService.setLocationId(location.id);
      } else {
        this.notifierService.notify('error', 'Unable to update the location as it is not created by '+ this.userService.userName);
      }
  }

  toggleVisibilityAllLocations(isChecked) {
    this.checkAll = isChecked;
    this.multipleLocations = this.locationData;
  }
  deleteLocation(location: LocationTo) {
    const that = this;
    this.predefinedLocationService.displaySuccess = false;
    this.sharedService.showYesNoAlert('Delete Location: ' + location.name, 'Delete', swalCallback, 'No, cancel');
    function swalCallback(yesNo) {
      if (yesNo) {
        that.predefinedLocationService.deletePredefinedLocations(location.id).subscribe(
          data => {
            that.predefinedLocationService.removeDeletedLocFromMap(location.id);
            that.getLocations();
            that.notifierService.notify('success', 'Location "' + location.name + '" deleted successfully.');
          },
          error => {
            if (error.status === 401) {
              that.sharedService.routeToLoginError(error.status);
            } else {
              that.notifierService.notify('error', 'Please try again');
            }
          }
        );
      }
    }
  }
  viewLocation(item: LocationTo) {
    item.properties['name'] = item.name;
    item.properties['createdBy'] = item.createdBy;
    item.properties['createdDate'] = item.createdDate;
    const entitiesData = this.sharedService.formPayloadForEntitiesMoreInfo([item], false, true);
    this.mapConsoleService.viewMapLocationMap(entitiesData);
  }
  onCompress() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.miniView);
    this.easleftSideBarService.changeEntitiesListTypes(PanelHeaders.entitiesMiniView);
  }
  onClose() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }
  modifyLocation(item) {
    this.enableDrag = false;
    this.selectedIdForModify = item.id;
    const temp = [];
    item.enableModify = true;
    temp.push(item);
    this.notifierService.notify('info', 'Drag an entity icon to the new location on map/click clear button to cancel');
    this.mapConsoleService.viewMapLocationMap(temp);
  }
  cancelModifyLocation(item) {
    this.enableDrag = true;
    this.selectedIdForModify = '';
    this.notifierService.notify('error', 'Modify location is cancelled');
    item.enableModify = false;
    const temp = [];
    temp.push(item);
    this.mapConsoleService.viewMapLocationMap(temp);
  }
  openMoreInfo(item) {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.maxView);
    this.isMoreInfo = true;
    this.selectedEntityId = item.id;
    const properties = {
      payload: {
        properties: item
      }
    };
    this.easOtherEntitiesData = {
      dataEntityId: item.id,
      dataModel: DataModel.location,
      payLoad: properties
    };
  }
}







