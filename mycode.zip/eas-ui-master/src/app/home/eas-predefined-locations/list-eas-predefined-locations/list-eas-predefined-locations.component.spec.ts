import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { ListEasPredefinedLocationsComponent } from './list-eas-predefined-locations.component';
import { EasPredefinedLocationsService } from '../eas-predefined-locations.service';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { SharedService } from '../../../shared/shared.service';
import { UserService } from '../../../login/services/user.service';
import { HomeService } from '../../../home/home.service';
import { SharedPipe } from '../../../home/shared.pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { DataTableModule } from 'angular-6-datatable';
import { LocationTo } from '../../../shared/models/locationTo';
import { PredefinedLocationMockService } from '../eas-mock-predefined-locations.service';
import { EasEventMoreInformationComponent } from '../../eas-event-more-information/eas-event-more-information.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ListEasPredefinedLocationsComponent', () => {
    let component: ListEasPredefinedLocationsComponent;
    let fixture: ComponentFixture<ListEasPredefinedLocationsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                ListEasPredefinedLocationsComponent,
                EasEventMoreInformationComponent,
                SharedPipe
            ],
            imports: [
                FormsModule,
                BrowserModule,
                ReactiveFormsModule,
                HttpClientModule,
                RouterTestingModule,
                NotifierModule,
                TabsModule,
                DataTableModule
            ],
            providers: [{ provide: EasPredefinedLocationsService, useClass: PredefinedLocationMockService }, MapConsoleService, EasLeftSidebarService, UserService],
            schemas: [NO_ERRORS_SCHEMA]
        })
            .compileComponents();
        const latitude = document.createElement('div');
        const longitude = document.createElement('div');
        const address = document.createElement('div');
        latitude.setAttribute('id', 'latitude');
        longitude.setAttribute('id', 'longitude');
        address.setAttribute('id', 'address');
        document.body.appendChild(latitude);
        document.body.appendChild(longitude);
        document.body.appendChild(address);
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ListEasPredefinedLocationsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });


    it('should get all locations and count should not be zero', (done) => {
        setTimeout(() => {
            expect(component.locationData.length).not.toBe(0);
            done();
        }, 1000);
    });

    it('True if the createLocation() method is called and perform its action', (done) => {

        component.crudViewTypeEmitter.subscribe(data => {
            expect(data).toEqual('create');
            done();
        })
        component.createLocation(null);

    });

    it('True if the editLocation() method is called and perform its action', (done) => {

        component.crudViewTypeEmitter.subscribe(data => {
            expect(data).toEqual('update');
            done();
        })
        component.userService.userName = 'sasf';
        component.getLocations();
        setTimeout(() => {
            component.editLocation(component.locationData[0]);
            done();
        }, 1000);
    });


    it('True if toggleVisibility() method is called and data is pushed and spliced on selecting checkbox twice ', (done) => {

        component.getLocations();
        setTimeout(() => {
            component.toggleVisibility(true, component.locationData[0]);
            component.toggleVisibility(false, component.locationData[0]);
            expect(component.multipleLocations.length).toBe(0);
            done();
        }, 1000);
    })

    it('True if modifyLocation() method is called and data is passed to map component', (done) => {

        component.mapConsoleService.viewMapLocations$.subscribe(data => {
            expect(data[0].id).toBe('713');
            done();
        })
        component.getLocations();
        setTimeout(() => {
            component.modifyLocation(component.locationData[0]);
            done();
        }, 1000);
    })

    it('True if cancelModifyLocation() method is called and data is passed to map component', (done) => {

        component.mapConsoleService.viewMapLocations$.subscribe(data => {
            expect(data[0].id).toBe('713');
            done();
        })
        component.getLocations();
        setTimeout(() => {
            component.cancelModifyLocation(component.locationData[0]);
            done();
        }, 1000);
    })

    it('True if openMoreInfo() method is called and window size is resized', (done) => {

        component.easleftSideBarService.easleftSidebarToggle$.subscribe(data => {
            expect(data).toEqual('75%');
            done();
        })

        component.getLocations();
        setTimeout(() => {
            component.openMoreInfo(component.locationData[0]);
            done();
        }, 1000);
    })

    it('True if onClose() method is called and perform its action', (done) => {

        component.easleftSideBarService.easleftSidebarToggle$.subscribe(data => {
            expect(data).toEqual('0%');
            done();
        })
        component.onClose();
    })


    it('True if onCompress() method is called and perform its action', (done) => {

        component.easleftSideBarService.easleftSidebarToggle$.subscribe(data => {
            expect(data).toEqual('25%');
            done();
        })
        component.onCompress();
    })


});
