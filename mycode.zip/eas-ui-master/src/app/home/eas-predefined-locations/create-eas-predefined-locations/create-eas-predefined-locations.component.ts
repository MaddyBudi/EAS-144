import { Component, OnInit, Inject, forwardRef, Input, SimpleChange, OnChanges, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { EasPredefinedLocationsService } from '../eas-predefined-locations.service';
import { SharedService } from '../../../shared/shared.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { NotifierService } from 'angular-notifier';
import { LocationTo } from '../../../shared/models/locationTo';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { DataModel } from '../../../dataModelEnum';
declare let google: any;
let controller;

@Component({
  selector: 'app-create-eas-predefined-locations',
  templateUrl: './create-eas-predefined-locations.component.html',
  styleUrls: ['./create-eas-predefined-locations.component.scss']
})
export class CreateEasPredefinedLocationsComponent implements OnInit {
  @Input() markerEventData;
  @Output() sendCreatedData = new EventEmitter();
  @Output() crudViewTypeEmitter = new EventEmitter();
  _markerEventData = new FormGroup({ locationData: new FormControl() });
  displayCreateContent = true;
  locationform = new FormGroup({
    name: new FormControl(),
    latitude: new FormControl(),
    longitude: new FormControl(),
    coordinates: new FormControl(),
    address: new FormControl(),
    fillcolor: new FormControl(),
    type: new FormControl()
  });
  // enableReset = false;
  // showRestBtn = true;
  payload = {
    'name': '',
    'type': 'Predefined Location',
    'geometry': {

    },
    'properties': {
      'latlng': {

      }
    }
  };
  locationDetails: LocationTo;
  // model:
  fullAddress;
  locationData;
  locationAddress;
  locationLat;
  locationLng;
  locationShapeType = 'Point';
  isFormModified = false;
  panelHeader = PanelHeaders.createContextLocation;
  constructor(public formGroup: FormBuilder, private predefinedLocationService: EasPredefinedLocationsService,
    public sharedService: SharedService, public mapConsoleService: MapConsoleService,
     public easleftSideBarService: EasLeftSidebarService, private notifierService: NotifierService,
      public geoAddressService: GeoAddressService) {
    controller = this;
    this.locationDetails = new LocationTo(this.payload);
  }
  ngOnInit() {
    this.setLocationForm();
    if (this.markerEventData) {
      this.getLocationShapeFromMap(this.markerEventData);
    }
  }

  resetCreatePage() {
    if (!this.markerEventData) { this.geoAddressService.resetAll(); }
    this.setLocationForm();
    this.isFormModified = false;
  }
  hideErrorMessage(event) {
    // this.predefinedLocationService.displayFailure = false;
  }
  setLocationForm() {
    this.locationform = this.formGroup.group({
      'name': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'address': [''],
      'latitude': [''],
      'longitude': [''],
      'coordinates': [],
      'color': '',
      'type': this.locationShapeType
    });
    this.locationform.valueChanges.subscribe(data => {
      this.isFormModified = true;
    });
  }

  getLocationShapeFromMap(shapeObject) {
    const data = {
      shape: shapeObject,
      dataModel: DataModel.location
    };
    if (shapeObject.type === google.maps.drawing.OverlayType.MARKER) {
      this.locationShapeType = 'Point';
    } else {
      this.locationShapeType = 'Polygon';
      this.geoAddressService.disableAddressLatLng.next();
    }
    this.geoAddressService.getMapObjects.next(data);
  }

  createlocation() {
    this.geoAddressService.activeAddressInfo();
    this.locationDetails.properties['address'] = this.geoAddressService.address;
    this.locationDetails.properties['latlng']['latitude'] = Number(this.geoAddressService.latitude);
    this.locationDetails.properties['latlng']['longitude'] = Number(this.geoAddressService.longitude);
    const geometry = {
      'coordinates': this.geoAddressService.coordinates,
      'type': this.locationShapeType
    };
    this.locationDetails.setGeoMetry(geometry);
    for (const c in this.locationform.controls) {
      if (this.locationform.controls.hasOwnProperty(c)) {
        this.locationform.controls[c].markAsTouched();
      }
    }
    if (this.locationform.valid && this.geoAddressService.checkValidation) {
      this.predefinedLocationService.createPredefinedLocations(this.locationDetails).subscribe(
        data => {
          this.notifierService.notify('success', 'Location "' + this.locationDetails.name + '" created successfully.');
          this.geoAddressService.resetAll();
          this.getListView();
          this.onClose();
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else if (error.status === 400) {
            this.notifierService.notify('error', 'Location "' + this.locationDetails.name + '" already exists');
          } else {
            this.notifierService.notify('error', error.error.message);
          }
        }
      );
    } else {
      this.notifierService.notify('error', 'Please provide the correct details to create location');
    }
  }
  closeAction(event) {
    this.getListView();
  }
  getListView() {
    this.crudViewTypeEmitter.emit('list');
    this.easleftSideBarService.changeEntitiesListTypes(PanelHeaders.locations);
  }
  onClose() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }
}
