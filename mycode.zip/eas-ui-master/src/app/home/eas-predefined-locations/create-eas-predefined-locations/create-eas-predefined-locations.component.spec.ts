import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CreateEasPredefinedLocationsComponent } from './create-eas-predefined-locations.component';
import { GeoAddressComponent } from '../../geo-address/geo-address.component';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { DebugElement } from '@angular/core';
import { BrowserModule, By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedService } from '../../../shared/shared.service';
import { EasPredefinedLocationsService } from '../eas-predefined-locations.service';
import { ExpectedConditions } from 'protractor';
import { MapConsoleService } from '../../map-console/map-console.service';
import { UserService } from '../../../login/services/user.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { MapsAPILoader } from '@agm/core';

describe('CreateEasPredefinedLocationsComponent', () => {

    let component: CreateEasPredefinedLocationsComponent;
    let fixture: ComponentFixture<CreateEasPredefinedLocationsComponent>;//creates a fixture for CreateEasPredefinedLocationsComponent
    // var originalTimeout;
    // let debugElement: DebugElement;
    let geoAddressComponent: GeoAddressComponent;
    let geoAddressComponentfixture: ComponentFixture<GeoAddressComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CreateEasPredefinedLocationsComponent, GeoAddressComponent],
            imports: [
                BrowserModule,
                FormsModule,
                ReactiveFormsModule,
                HttpClientModule,
                RouterTestingModule,
                NotifierModule
            ],
            providers: [{ provide: MapsAPILoader}, UserService, GeoAddressService, SharedService, EasLeftSidebarService],//inject geoaddress service into create-eas-predefined-location spec.ts file

        }).compileComponents().then(() => {
            fixture = TestBed.createComponent(CreateEasPredefinedLocationsComponent);
            geoAddressComponentfixture = TestBed.createComponent(GeoAddressComponent);
            component = fixture.componentInstance;
            geoAddressComponent = geoAddressComponentfixture.componentInstance;
            const latitude = document.createElement('div');
            const longitude = document.createElement('div');
            const address = document.createElement('div');
            latitude.setAttribute('id', 'latitude');
            longitude.setAttribute('id', 'longitude');
            address.setAttribute('id', 'address');
            document.body.appendChild(latitude);
            document.body.appendChild(longitude);
            document.body.appendChild(address);

        });

    }));

    beforeEach(() => {
        fixture.detectChanges();
        geoAddressComponentfixture.detectChanges();
    });


    it(`True if the component is created successfully`, (() => {
        expect(component).toBeTruthy();

    }));

    it(`True if locationform is valid`, () => {
        component.locationform.controls['name'].setValue("Karma Test Predefined Location");
        expect(component.locationform.valid).toBeTruthy();

    });

    it(`Fails if  lat,long and name value is fetched from geoAddress component and address`, (done) => {   //should get the value from the geocomponent
        geoAddressComponent.setValueInAddressField('38.889889', '-76.949526');
        component.locationform.controls['name'].setValue("Karma Test Predefined Location");
        expect(component.locationform.valid).toBeTruthy();
        expect(geoAddressComponent.geoAddressForm.valid).toBeFalsy();
        done();

    });

    it(`True if  lat,long , address value is fetched from geoAddress component and name is fetched from locationform`, (done) => {   //should get the value from the geocomponent
        geoAddressComponent.geoAddressForm.controls['latitude'].setValue('38.889889');
        geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-76.949526');
        component.locationform.controls['name'].setValue("Karma Test Predefined Location");
        geoAddressComponent.geoAddressForm.controls['address'].setValue('3914 East Capitol St NE, Washington, DC 20019, USA');

        geoAddressComponent.setAddress();
        setTimeout(() => {
            expect(component.locationform.valid).toBeTruthy();
            expect(geoAddressComponent.geoAddressForm.valid).toBeTruthy();
            done();
        }, 1000);

    });





    it(`Fails address value is fetched and lat,long is not fetched from from geoAddress component and name is fetched from locationform`, (done) => {   //should get the value from the geocomponent
        geoAddressComponent.setPlaceAndAddress('3914 East Capitol St NE, Washington, DC 20019, USA');
        component.locationform.controls['name'].setValue("Karma Test Predefined Location");
        setTimeout(() => {
            geoAddressComponent.onSubmit();
            expect(component.locationform.valid).toBeTruthy();
            expect(geoAddressComponent.geoAddressForm.valid).toBeFalsy();
            done();
        }, 1000);

    });
    
    it('True if the createLocation() method to check whether both locationform and geoAddressForm are valid', () => {
        geoAddressComponent.geoAddressForm.controls['latitude'].setValue('38.889889');
        geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-76.949526');
        component.createlocation();
        expect(component.locationform.valid && geoAddressComponent.geoAddressForm.valid).toBeFalsy();

    })
   
    it(`True if the resetCreatemethod() operation is performed `, () => {
        component.resetCreatePage();
        geoAddressComponent.setAddress();
        expect(geoAddressComponent.geoAddressForm.valid).toBeFalsy();
    });


    it('True if the closeaction() method is called and perform its action', (done) => {

        component.crudViewTypeEmitter.subscribe(data => {
            expect(data).toEqual('list');
            done();
        })
        component.closeAction(null);
    });
    
    it('true if the onClose() method is called and perform its action', (done) => {

        component.easleftSideBarService.easleftSidebarToggle$.subscribe(data => {
            expect(data).toEqual('0%');
            done();
        })
        component.onClose();
    });
    

});