import { Component, OnInit } from '@angular/core';
import { CrudView } from './crudview';
import { EasPredefinedLocationsService } from './eas-predefined-locations.service';
@Component({
  selector: 'app-eas-predefined-locations',
  templateUrl: './eas-predefined-locations.component.html',
  styleUrls: ['./eas-predefined-locations.component.scss']
})
export class EasPredefinedLocationsComponent implements OnInit {
  crudview: CrudView = new CrudView();
  constructor(public locationSvc: EasPredefinedLocationsService) {
  }

  ngOnInit() {
    this.crudview.viewType = 'list';
    this.locationSvc.displaySuccess = false;
    this.locationSvc.displayFailure = false;
  }

  crudViewTypeCatcher(viewType) {
    console.log(viewType);
    this.crudview.viewType = viewType;
  }

}
