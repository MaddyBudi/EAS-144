import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { ConfigService } from '../../core/config/config-svc.service';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { LocationTo } from '../../shared/models/locationTo';
import { UnitTestConstants } from '../../common/enums/unit-test-constants-enum';


@Injectable()

export class PredefinedLocationMockService {
    locationId = '713';
    selectedLocationId;
    closeMoreInformation = new Subject<string>();
    closeMoreInformation$ = this.closeMoreInformation.asObservable();
    removeLocFromMapOnLocDelete = new Subject<string>();
    removeLocFromMapOnLocDelete$ = this.removeLocFromMapOnLocDelete.asObservable();

    constructor(private http: HttpClient) { }


    public getPredefinedLocations() {
        return this.http.get(UnitTestConstants.locationPayloadUrl).pipe(map((event => this.convertListToListObject(event))));
    }
    
    public getPredefinedLocationsById(locationId):Observable<LocationTo>{

    return this.http.get<LocationTo>(UnitTestConstants.singleLocationPayloadUrl).pipe(map((event => this.convertResponseToObject(event))));
  }
    
    setLocationId(locationId) {
    this.selectedLocationId = locationId;
  }
    getLocationId() {
        return this.locationId;
    }

    convertListToListObject(object: any) {
        const locationTo = [];
        object.forEach(element => {
            const location = new LocationTo(element);
            locationTo.push(location);
            console.log(locationTo);
        });
        return locationTo;
    }

    convertResponseToObject(object) {
        const location = new LocationTo(object);
        return location;
    }
}
