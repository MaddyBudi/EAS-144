// import { TestBed } from '@angular/core/testing';

// import { EasPredefinedLocationsService } from './eas-predefined-locations.service';

// describe('EasPredefinedLocationsService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: EasPredefinedLocationsService = TestBed.get(EasPredefinedLocationsService);
//     expect(service).toBeTruthy();
//   });
// });
