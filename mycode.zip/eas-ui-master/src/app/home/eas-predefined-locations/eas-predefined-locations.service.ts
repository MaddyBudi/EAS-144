import { Injectable } from '@angular/core';
import { HttpClient ,HttpHeaders} from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import {  AppGlobals } from '../../shared/app.globals';
import {ConfigService} from '../../core/config/config-svc.service';
import { Observable } from 'rxjs';
import { LocationTo } from '../../shared/models/locationTo';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class EasPredefinedLocationsService {
  locationData = [];
  selectedLocationId;
  successMessage;
  failureMessage;
  displayFailure;
  displaySuccess;
  closeMoreInformation = new Subject<string>();
  closeMoreInformation$ = this.closeMoreInformation.asObservable();
  removeLocFromMapOnLocDelete = new Subject<string>();
  removeLocFromMapOnLocDelete$ = this.removeLocFromMapOnLocDelete .asObservable();

  constructor(private http: HttpClient, private appglobals: AppGlobals) { }
  getHeaders() {
    const httpOptions = {
     headers: new HttpHeaders({
       'Content-Type':  'application/json'
     }),
     withCredentials: true
      };
      return httpOptions;
 }
 setLocationId(locationId) {
    this.selectedLocationId = locationId;
  }
  getLocationId() {
    return this.selectedLocationId;
  }
  setSuccessMessage(message) {
    this.successMessage = message;
  }
  getSuccessMessage() {
    return this.successMessage;
  }
  setFailureMessage(message) {
    this.failureMessage = message;
  }
  getFailureMessage() {
    return this.failureMessage;
  }
  closeMoreInformations() {
this.closeMoreInformation.next();
  }
  removeDeletedLocFromMap(data) {
    this.removeLocFromMapOnLocDelete.next(data);
  }
public createPredefinedLocations(payload)  {
  return this.http.post(ConfigService.config.locationServiceUrl+'/loc/create',payload, this.getHeaders()).pipe(map((res:any) => res));
}
public getPredefinedLocations():Observable<LocationTo[]>{

    return this.http.get<LocationTo[]>(ConfigService.config.locationServiceUrl+'/locs',this.getHeaders()).pipe(map((event => this.convertListToListObject(event))));
  }
 public getPredefinedLocationsById(id):Observable<LocationTo>{

    return this.http.get<LocationTo>(ConfigService.config.locationServiceUrl+'/location/'+id, this.getHeaders()).pipe(map((event => this.convertResponseToObject(event))));
  }
 public updatePredefinedLocations(locationData:LocationTo){
              return this.http.put(ConfigService.config.locationServiceUrl+'/loc/update',locationData,this.getHeaders()).pipe(map((res:any) => res));
 }

 public deletePredefinedLocations(id) {

  return this.http.delete(ConfigService.config.locationServiceUrl+'/loc/delete/'+id, this.getHeaders()).pipe(map((res:any) => res));
 }

 convertListToListObject(object: any) {
  const locationTo = [];
  object.forEach(element => {
    const location = new LocationTo(element);
    locationTo.push(location);
  });
  return locationTo;
 }

 convertResponseToObject(object) {
  const location = new LocationTo(object);
  return location;
 }
  public updateLocation(payload) {
    return this.http.put(ConfigService.config.locationServiceUrl+'/loc/update',payload,this.getHeaders()).pipe(map((res:any) => res));
 }
}



