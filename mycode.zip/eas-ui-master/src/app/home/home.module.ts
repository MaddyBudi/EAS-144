import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { LoginComponent } from '../login/login.component';
import { HomeComponent } from './home.component';
import { NavigationComponent } from './navigation/navigation.component';
import { MapConsoleComponent } from './map-console/map-console.component';
import { MapConsoleService } from './map-console/map-console.service';
import { FindRouteComponent } from './map-console/find-route/find-route.component';
import { CommonComponent } from '../common/common.component';
import { route } from '../route';
import { DataTableModule } from "angular-6-datatable";
import { SharedPipe } from './shared.pipe';
import { AngularDraggableModule } from 'angular2-draggable';
import { ContextBarComponent } from './context-bar/context-bar.component';
import { EasEventsComponent } from './eas-events/eas-events.component';
import { EasResourcesComponent } from './eas-resources/eas-resources.component';
import { EasPredefinedLocationsComponent } from './eas-predefined-locations/eas-predefined-locations.component';
import { ListEasEventsComponent } from './eas-events/list-eas-events/list-eas-events.component';
import { EasAnnotationsComponent } from './eas-annotations/eas-annotations.component';
import { AssignEasResourcesComponent } from './eas-resources/assign-eas-resources/assign-eas-resources.component';
import { AssociateEasResourcesComponent } from './eas-resources/associate-eas-resources/associate-eas-resources.component';
import { CreateEasResourceGroupComponent } from './eas-resources/create-eas-resource-group/create-eas-resource-group.component';
import { ListEasResourceGroupComponent } from './eas-resources/list-eas-resource-group/list-eas-resource-group.component';
import { UpdateEasResourceGroupComponent } from './eas-resources/update-eas-resource-group/update-eas-resource-group.component';
import { ListEasAnnotationsComponent } from './eas-annotations/list-eas-annotations/list-eas-annotations.component';
import { ListEasPredefinedLocationsComponent } from './eas-predefined-locations/list-eas-predefined-locations/list-eas-predefined-locations.component';
import { ListEasResourcesComponent } from './eas-resources/list-eas-resources/list-eas-resources.component';
import { UpdateEasEventsComponent } from './eas-events/update-eas-events/update-eas-events.component';
import { UpdateEasPredefinedLocationsComponent } from './eas-predefined-locations/update-eas-predefined-locations/update-eas-predefined-locations.component';
import { UpdateEasAnnotationsComponent } from './eas-annotations/update-eas-annotations/update-eas-annotations.component';
import { EasEventMoreInformationComponent } from './eas-event-more-information/eas-event-more-information.component';
import { EasOtherEntitiesInformationComponent } from './eas-other-entities-information/eas-other-entities-information.component';
import { ChatWidgetComponent } from './map-console/chat-widget/chat-widget.component';
import { MessageItemComponent } from './map-console/chat-widget/message-item/message-item.component';
import { MsdsComponent } from './map-console/msds/msds.component';
import { BaseMapComponent } from './map-console/base-map/base-map.component';
import { CreateEasResourceComponent } from './eas-resources/create-eas-resource/create-eas-resource.component';
import { UpdateEasResourceComponent } from './eas-resources/update-eas-resource/update-eas-resource.component';
import { SearchEasResourceComponent } from './eas-resources/list-eas-resources/search-eas-resource/search-eas-resource.component';
import { CreateEasAnnotationsComponent } from './eas-annotations/create-eas-annotations/create-eas-annotations.component';
import { MapLayersComponent } from './map-console/map-layers/map-layers.component';
import { CreateEasEventsComponent } from './eas-events/create-eas-events/create-eas-events.component';
import { CreateEasPredefinedLocationsComponent } from './eas-predefined-locations/create-eas-predefined-locations/create-eas-predefined-locations.component';
import { CameraWidgetComponent } from './camera-widget/camera-widget.component';
import { NotificationsComponent } from './map-console/notifications/notifications.component';
import { SensorComponent } from './map-console/sensor/sensor.component';
import { EasLeftSidebarComponent } from './map-console/eas-left-sidebar/eas-left-sidebar.component';
import { GeoAddressComponent } from './geo-address/geo-address.component';
import { CreateEasResourceTypeComponent } from './eas-resources/create-eas-resource-type/create-eas-resource-type.component';
import { ListEasResourceTypeComponent } from './eas-resources/list-eas-resource-type/list-eas-resource-type.component';
import { UpdateEasResourceTypeComponent } from './eas-resources/update-eas-resource-type/update-eas-resource-type.component';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forRoot(route),
    DataTableModule,
    AngularDraggableModule
  ],
  declarations: [
    LoginComponent,
    HomeComponent,
    NavigationComponent,
    MapConsoleComponent,
    CommonComponent,
    FindRouteComponent,
    SharedPipe,
   ContextBarComponent,
   EasEventsComponent,
   EasResourcesComponent,
   EasPredefinedLocationsComponent,
   ListEasEventsComponent,
   EasAnnotationsComponent,
   AssignEasResourcesComponent,
   AssociateEasResourcesComponent,
   CreateEasResourceGroupComponent,
   ListEasResourceGroupComponent,
   UpdateEasResourceGroupComponent,
   ListEasAnnotationsComponent,
   ListEasPredefinedLocationsComponent,
   ListEasResourcesComponent,
   UpdateEasEventsComponent,
   UpdateEasPredefinedLocationsComponent,
   UpdateEasAnnotationsComponent,
   EasEventMoreInformationComponent,
   EasOtherEntitiesInformationComponent,
   ChatWidgetComponent,
   MessageItemComponent,
   MsdsComponent,
   BaseMapComponent,
   CreateEasResourceComponent,
   UpdateEasResourceComponent,
   SearchEasResourceComponent,
   CreateEasAnnotationsComponent,
   MapLayersComponent,
   CreateEasEventsComponent,
   CreateEasPredefinedLocationsComponent,
   CameraWidgetComponent,
   NotificationsComponent,
   SensorComponent,
   EasLeftSidebarComponent,
   GeoAddressComponent,
   CreateEasResourceTypeComponent,
   ListEasResourceTypeComponent,
   UpdateEasResourceTypeComponent
  ],
  exports: [],
  providers: [MapConsoleService
]
})
export class HomeModule { }
