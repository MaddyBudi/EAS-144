// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EasAnnotationsComponent } from './eas-annotations.component';

// describe('EasAnnotationsComponent', () => {
//   let component: EasAnnotationsComponent;
//   let fixture: ComponentFixture<EasAnnotationsComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EasAnnotationsComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EasAnnotationsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
