import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateEasAnnotationsComponent } from './update-eas-annotations.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GeoAddressComponent } from '../../geo-address/geo-address.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { ConfigService } from '../../../core/config/config-svc.service';
import { APP_INITIALIZER } from '@angular/core';
import { AnnotationTo } from '../../../shared/models/annotationTo';
import { AppGlobals } from '../../../shared/app.globals';
import { EasAnnotationsService } from '../eas-annotations.service';
import { MockEasAnnotationsService } from '../eas-mock-annotations.service';
declare let google: any;

export class DefaultEvent {
  preventDefault() {

  }
}

describe('UpdateEasAnnotationsComponent', () => {
  let component: UpdateEasAnnotationsComponent;
  let fixture: ComponentFixture<UpdateEasAnnotationsComponent>;
  let geoAddressComponent: GeoAddressComponent;
  let geoAddressComponentFixure: ComponentFixture<GeoAddressComponent>;
  let appglobals = new AppGlobals();
  let service: EasAnnotationsService;
  let mockEasAnnotationsService: MockEasAnnotationsService;
  let payload: any = {
    "dataModel": appglobals.annotationDataModel,
    "resourceObject": appglobals.resourceObject,
    "assignedTo": "",
    "annotationType": 'Public',
    "status": 'Available',
    "properties": {
      "capabilities": '',
      "color": ''
    },
    "address": {
      "streetAddress1": "2010, Upshur St NE",
      "streetAddress2": "",
      "city": "Washington",
      "zip": "20018-3244",
      "state": "DC",
      "county": "",
      "sourceType": "UNKNOWN"
    },
    "resourceName": '',
    "geometry": "{\"type\":\"Point\",\"coordinates\":[-76.802938,38.986243]}",
    "type": appglobals.annotationType
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        UpdateEasAnnotationsComponent,
        GeoAddressComponent
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule
      ],
      providers: [
        ConfigService,
        MockEasAnnotationsService,
        { provide: EasAnnotationsService, useClass: MockEasAnnotationsService }
      ]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(UpdateEasAnnotationsComponent);
      component = fixture.componentInstance;
      service = TestBed.get(EasAnnotationsService);
      mockEasAnnotationsService = TestBed.get(MockEasAnnotationsService);
      geoAddressComponentFixure = TestBed.createComponent(GeoAddressComponent);
      geoAddressComponent = geoAddressComponentFixure.componentInstance;
      component.annotationDetails = new AnnotationTo(payload);
      component.resetData = new AnnotationTo(payload);
    })
  }));

  beforeEach(() => {
    fixture.detectChanges();
    geoAddressComponentFixure.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should valid update annotation form with existing data', (done) => {
    setTimeout(() => {
      expect(component.updateAnnotationForm.valid).toBeTruthy();
      done();
    }, 1000);
  });

  it('should valid update annotation form if annotation name,annotation desc and coordinates are changed', () => {
    component.updateAnnotationForm.controls['resourceName'].setValue('Test Annotation');
    component.updateAnnotationForm.controls['annotationDesc'].setValue('sample testing');
    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('40.739197');
    geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-73.990860');
    geoAddressComponent.geoAddressForm.controls['address'].setValue('123 5th Ave, New York, NY 10003, USA');
    expect(geoAddressComponent.geoAddressForm.valid && component.updateAnnotationForm.valid).toBeTruthy();
  });

  it('should invalid update annotation form if the inputs were does not given', () => {
    expect(geoAddressComponent.geoAddressForm.valid && component.updateAnnotationForm.valid).toBeFalsy();
  });

  it('should invalid update annotation form if annotation name, annotation description are given but address, coordinates are empty', () => {
    component.updateAnnotationForm.controls['resourceName'].setValue('Test Annotation');
    component.updateAnnotationForm.controls['annotationDesc'].setValue('sample testing');
    expect(geoAddressComponent.geoAddressForm.valid && component.updateAnnotationForm.valid).toBeFalsy();
  });

  it('should invalid update annotation form if address, coordinates are given but annotation name, annotation description are empty', () => {
    geoAddressComponent.geoAddressForm.controls['address'].setValue('123 5th Ave, New York, NY 10003, USA');
    expect(geoAddressComponent.geoAddressForm.valid && component.updateAnnotationForm.valid).toBeFalsy();
  });

  it('should invalid update annotation form if latitude is given and address, longitude are not given', (done) => {
    component.updateAnnotationForm.controls['resourceName'].setValue('Test Annotation');
    component.updateAnnotationForm.controls['annotationDesc'].setValue('sample testing');
    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('40.739197');
    geoAddressComponent.setAddress();
    setTimeout(() => {
      expect(geoAddressComponent.geoAddressForm.valid && component.updateAnnotationForm.valid).toBeFalsy();
      done();
    }, 1000);
  });

  it('should invalid update annotation form if coordinates are wrong and address is not given', (done) => {
    component.updateAnnotationForm.controls['resourceName'].setValue('Test Annotation');
    component.updateAnnotationForm.controls['annotationDesc'].setValue('sample testing');
    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('-10.02');
    geoAddressComponent.geoAddressForm.controls['longitude'].setValue('10.3');
    geoAddressComponent.setAddress();
    setTimeout(() => {
      expect(geoAddressComponent.geoAddressForm.valid && component.updateAnnotationForm.valid).toBeFalsy();
      done();
    }, 1000);
  });

  it('should close update annotation form when clicking cancel button', (done) => {
    component.crudViewEmitter.subscribe(
      data => {
        expect(data).toEqual('list');
        done();
      }
    );
    component.closeAction();
  });

  it('should call addCustomKeyValue', () => {
    component.updateAnnotationForm.value.capabilities[component.updateAnnotationForm.value.capabilities.length - 1].key = 'Test';
    component.updateAnnotationForm.value.capabilities[component.updateAnnotationForm.value.capabilities.length - 1].value = 'Test';
    component.addCustomKeyValue();
    expect(component.updateAnnotationForm.value.capabilities.length).not.toBe(1);
  });

  it('should call addCustomKeyValue and should go to else condition', () => {
    component.addCustomKeyValue();
    expect(component.updateAnnotationForm.value.capabilities.length).toBe(1);
  });

  it('should call deleteCustomKeyValue', () => {
    component.updateAnnotationForm.value.capabilities[component.updateAnnotationForm.value.capabilities.length - 1].key = 'Test';
    component.updateAnnotationForm.value.capabilities[component.updateAnnotationForm.value.capabilities.length - 1].value = 'Test';
    component.addCustomKeyValue();
    component.deleteCustomKeyValue(component.updateAnnotationForm.value.capabilities.length - 1);
    expect(component.updateAnnotationForm.value.capabilities.length).toBe(1);
  });

  it('should call deleteCustomKeyValue and should go to else condition', () => {
    component.deleteCustomKeyValue(component.updateAnnotationForm.value.capabilities.length - 1);
    expect(component.updateAnnotationForm.value.capabilities.length).toBe(1);
  });

  it('should call formatCustomAttributes', () => {
    component.updateAnnotationForm.value.capabilities[component.updateAnnotationForm.value.capabilities.length - 1].key = 'Test';
    component.updateAnnotationForm.value.capabilities[component.updateAnnotationForm.value.capabilities.length - 1].value = 'Test';
    let formatted_attr = component.formatCustomAttributes(component.updateAnnotationForm.value);
    expect(formatted_attr["Test"]).toEqual("Test");
  });

  it('should close update annotation form when clicking close icon', (done) => {
    component.easleftSideBarService.easleftSidebarToggle$.subscribe(
      data => {
        expect(data).toEqual('0%');
        done();
      }
    );
    component.onClose();
  });

  it('should call blockSpecialChar method', () => {
    let event = {
      'keyCode': 32
    };
    expect(component.blockSpecialChar(event)).toBe(true);
  });

  it('should call assignEventData method', () => {
    component.assignEventData(null);
    component.assignEventData('594c5106-a1a0-413a-bedd-b6abde26b6ce');
    expect(component.displayAlert).toBe(false);
  });

  it('should call resetUpdatePage method', () => {
    component.resetData = new AnnotationTo(Object.assign({}, payload));
    component.longitude = -75.1796767;
    component.latitude = 39.954392;
    component.resetUpdatePage(null);
    expect(component.resetFlag).toBe(true);
  });

  it('should call setCustomAttributes method', () => {
    component.annotationDetails.properties['capabilities'] = { '': '' };
    component.resetFlag = true;
    component.setCustomAttributes(component.annotationDetails.properties['capabilities']);
    component.annotationDetails.properties['capabilities'] = { 'Test': 'Test' };
    component.setCustomAttributes(component.annotationDetails.properties['capabilities']);
    expect(component.customKeyValuPair.length).not.toBe(0);
  });

  it('should call updateAnnotation method', (done) => {
    mockEasAnnotationsService.getPlaceObject().subscribe(
      data => {
        component.geoAddressService.place = data;
        let defaultEvent = new DefaultEvent();
        component.updateAnnotation(defaultEvent, component.updateAnnotationForm.getRawValue());
        expect(component.geoAddressService.checkValidation).toBe(false);
        done();
      }
    );
  });

});
