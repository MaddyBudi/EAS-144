import { Component, OnInit, OnChanges, Input, Output, SimpleChange, Inject, forwardRef, EventEmitter, DebugNode } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { SharedService } from '../../../shared/shared.service';
import * as $ from 'jquery';
import { EasAnnotationsService } from '../eas-annotations.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { NotifierService } from 'angular-notifier';
import { AnnotationTo } from '../../../shared/models/annotationTo';
import { GeoAddressService } from '../../geo-address/geo-address.service';

@Component({
  selector: 'app-update-eas-annotations',
  templateUrl: './update-eas-annotations.component.html',
  styleUrls: ['./update-eas-annotations.component.scss']
})
export class UpdateEasAnnotationsComponent implements OnInit {

  @Input() selectedAnnotationIdFromMap: string;
  @Input() isCancel: boolean;
  @Output() crudViewEmitter = new EventEmitter();
  failureMessage = "";
  displayFailure = false;

  // @Output() assignEventUpdate: EventEmitter<any> = new EventEmitter<any>();
  updateAnnotationForm = new FormGroup({
    resourceName: new FormControl(),
    capabilities: new FormArray([
      new FormControl('key'),
      new FormControl('value'),
    ]),
    annotationDesc: new FormControl(),
    address: new FormControl(),
    annotationLatitude: new FormControl(),
    annotationLongitude: new FormControl(),
    coordinates: new FormControl(),
    status: new FormControl(),
    annotationType: new FormControl(),
    // annotationDate: new FormControl(),
    color: new FormControl(),
    assignedTo: new FormControl()
  });
  primaryCategoryList: any;
  displayUpdateContent = true;
  isFormModified = false;
  annotationDetails: AnnotationTo;
  selectedItems = [];
  dropdownSettings = {};
  stateList = [];
  countyList = [];
  eventData = [];
  currentEventId;
  capabilities;
  resetFlag = false;
  selectedAnnotationID;
  public displayAlert = false;
  alertMessage = '';
  latitude;
  longitude;
  public countiesMap = new Map();
  resetData:AnnotationTo;
  constructor(public formGroup: FormBuilder, private annotationSvc: EasAnnotationsService,
    public sharedService: SharedService, public mapConsoleService: MapConsoleService, private notifierService: NotifierService,
    private fb: FormBuilder, public easleftSideBarService: EasLeftSidebarService, public geoAddressService: GeoAddressService)
     {

  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {

  }
  // sets initial update form
  ngOnInit() {
    this.selectedAnnotationID = (this.selectedAnnotationIdFromMap === undefined) ?
      this.annotationSvc.getEventEntityID() : this.selectedAnnotationIdFromMap;
    this.annotationSvc.getAnnotationDetails(this.selectedAnnotationID).subscribe(
      data => {
        this.annotationDetails = Object.assign({}, data);
        this.resetData=Object.assign({}, data);  
        this.resetFlag = false;
        this.setupdateAnnotationForm(false);
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.notifierService.notify("error", 'General error occured. Please try again later.');
        }
      }
    );
    this.getEvents();
    this.updateAnnotationForm = this.formGroup.group({
      'resourceName': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'annotationDesc': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(250)])],
      'address': [''],
      'annotationLatitude': [],
      'annotationLongitude': [],
      'coordinates': [],
      'status': [],
      'assignedTo': [],
      'annotationType': [],
      // 'annotationDate': [],
      'color': [],
      'capabilities': this.formGroup.array([this.formGroup.group({ key: '', value: '' })]),
      'key': [],
      'value': [],
    });
  }
  getEvents() {
    this.annotationSvc.getAllEvents().subscribe(
      data => {
        data.forEach(element => {
          if (element.status === 'STARTED' && element.deleted === false) {
            this.eventData.push(element);
          }
        });
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.notifierService.notify("error", 'General error occured. Please try again later.');
        }

      }
    );
  }
  // binds value from annotationDetails to UI fields on update page
  setupdateAnnotationForm(isReset) {
    let latCenter;
    let lngCenter;
    let latlngCenter = [];
    if (this.annotationDetails.geometry['type'] !== 'Point') {
      this.geoAddressService.disableAddressLatLng.next();
      latlngCenter = this.sharedService.getPolygonCenter(this.annotationDetails.geometry['coordinates'][0]);
      lngCenter = latlngCenter[0];
      latCenter = latlngCenter[1];
    } else {
      latCenter = this.annotationDetails.geometry['coordinates'][1];
      lngCenter = this.annotationDetails.geometry['coordinates'][0];
    }
    this.latitude = latCenter;
    this.longitude = lngCenter;
    this.geoAddressService.setAddressLatLng.next([this.longitude, this.latitude]);
    this.geoAddressService.coordinates = this.annotationDetails.geometry['coordinates'];
    this.updateAnnotationForm.controls['resourceName'].setValue(this.annotationDetails.resourceName);
    this.updateAnnotationForm.controls['annotationDesc'].setValue(this.annotationDetails.annotationDesc);
    this.updateAnnotationForm.controls['status'].setValue(this.annotationDetails.status);
    this.updateAnnotationForm.controls['status'].disable();
    this.updateAnnotationForm.controls['annotationType'].setValue(this.annotationDetails.annotationType);
    this.updateAnnotationForm.controls['assignedTo'].setValue(this.annotationDetails.assignedTo);
    this.updateAnnotationForm.controls['color'].setValue(this.annotationDetails.properties['color']);
    this.setCustomAttributes(this.annotationDetails.properties['capabilities']);
    this.updateAnnotationForm.valueChanges.subscribe(data => {
      this.isFormModified = true;
    });
    if (isReset)
      this.isFormModified = false;
  }
  updateAnnotation(annotation, formData) {
    this.geoAddressService.activeAddressInfo();
    formData.address = this.sharedService.getFullAddress(this.geoAddressService.place);
    formData.annotationLatitude = this.geoAddressService.latitude;
    formData.annotationLongitude = this.geoAddressService.longitude;
    formData.coordinates = this.geoAddressService.coordinates;
    this.annotationDetails.address['city'] = formData.address.city;
    this.annotationDetails.address['county'] = formData.address.county;
    this.annotationDetails.address['state'] = formData.address.state;
    this.annotationDetails.address['streetAddress1'] = formData.address.streetAddress1;
    this.annotationDetails.address['streetAddress2'] = formData.address.streetAddress2;
    this.annotationDetails.address['zip'] = formData.address.zip;
    if (this.annotationDetails.geometry['type'] === 'Point') { this.annotationDetails.geometry['coordinates'] = formData.coordinates; }
    annotation.preventDefault();
    this.annotationDetails.status = this.annotationDetails.assignedTo === "" ? 'Available' : 'NotAvailable';
    if (this.updateAnnotationForm.valid && this.isFormModified  && this.geoAddressService.checkValidation) {
      this.annotationDetails.properties['capabilities'] = this.formatCustomAttributes(this.updateAnnotationForm.value)
      this.displayAlert = false;
      this.annotationSvc.updateAnnotation(this.annotationDetails).subscribe(
        data => {
          this.geoAddressService.resetAll();
          if (data.entityId != null && data.status !== "Closed") {
            if (this.annotationDetails.assignedTo != "" && data.status === 'NotAvailable') {
              this.assignEvent(data.entityId, data.resourceName, data.assignedTo);
            } else if (this.annotationDetails.assignedTo === "" && data.status === "Available") {
              this.releaseEvent(data.entityId, data.resourceName, data.assignedTo);
            }
            this.getListView();
          }
          this.notifierService.notify("success", 'Annotation "' + data.resourceName + '"updated successfully ');
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            // this.notifierService.notify("error",'General error occured. Please try again later.');
          }
        }
      );
    } else {
      $('#annotationName').focus();
      this.notifierService.notify('error', 'Plese modify the annotation detail/provide the correct details to update');

    }
  }

  resetUpdatePage(annotation) {
    this.isFormModified = false;
    this.resetFlag = true;
    this.geoAddressService.resetAll();
    this.geoAddressService.setAddressLatLng.next([this.longitude, this.latitude]);
    this.annotationDetails=Object.assign({}, this.resetData);
    this.setupdateAnnotationForm(true);
    this.updateAnnotationForm.reset(this.resetData);  
  }

  assignEventData(item) {
    this.displayAlert = false;
    this.currentEventId = item;
    if (item) {
      this.updateAnnotationForm.controls['status'].setValue("NotAvailable");
    } else {
      this.updateAnnotationForm.controls['status'].setValue("Available");
    }
  }
  assignEvent(annotationId, annotationName, eventId) {
    this.annotationSvc.mergeAnnotn(annotationId, eventId).subscribe(
      data => {
        // this.notifierService.notify("success",'Annotation: "' + annotationName + '" is assigned successfully');
      },
      error => {
        // this.notifierService.notify("error",'General error occured. Please try again later.');
      }
    );
  }

  releaseEvent(annotationId, annotationName, eventId) {
    this.annotationSvc.releaseAnnotn(annotationId, eventId).subscribe(
      data => {
        // this.notifierService.notify("success",'Annotation: "' + annotationName + '" is released successfully');
      },
      error => {
        // this.notifierService.notify("error",'General error occured. Please try again later.');
      }
    );
  }
  closeAction() {
    this.getListView();
  }
  getListView() {
    this.crudViewEmitter.emit("list");
    this.mapConsoleService.mapConsoleComponentSource.next('closeUpdateAnnotationComponent');
  }

  get customKeyValuPair() {
    return this.updateAnnotationForm.get('capabilities') as FormArray;
  }
  setCustomAttributes(capabilities) {
    const count = Object.keys(capabilities).length;
    if (count === 1) {
      const key = Object.keys(capabilities)[0];
      const value = capabilities[key];
      if (key) {
        this.clearFormArray(<FormArray>this.updateAnnotationForm.get('capabilities'));
        this.addCustomKeyValuePair(key, value);
      } else {
        if (this.resetFlag) {
          this.clearFormArray(<FormArray>this.updateAnnotationForm.get('capabilities'));
          this.addCustomKeyValuePair("", "");
        }
      }
    } else {
      this.clearFormArray(<FormArray>this.updateAnnotationForm.get('capabilities'));
      for (const capability in capabilities) {
        if (capability) {
          const key = capability;
          const value = capabilities[capability];
          this.addCustomKeyValuePair(key, value);
        }
      }
    }

  }

  clearFormArray = (formArray: FormArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }

  addCustomKeyValuePair(K, V) {
    this.customKeyValuPair.push(this.fb.group({ key: K, value: V }));
  }
  addCustomKeyValue() {
    if (this.updateAnnotationForm.value.capabilities[this.updateAnnotationForm.value.capabilities.length - 1].key &&
      this.updateAnnotationForm.value.capabilities[this.updateAnnotationForm.value.capabilities.length - 1].value) {
      this.customKeyValuPair.push(this.fb.group({ key: '', value: '' }));
      this.failureMessage = "";
      this.displayFailure = false;
    } else {
      this.failureMessage = "key and value should have proper value";
      this.displayFailure = true;
      setTimeout(() => {
        this.failureMessage = "";
        this.displayFailure = false;
      }, 4000);
    }
  }

  deleteCustomKeyValue(index) {
    if (this.updateAnnotationForm) {
      if (this.updateAnnotationForm.value.capabilities.length > 1) {
        this.customKeyValuPair.removeAt(index);
      } else {
        this.customKeyValuPair.removeAt(0);
        this.addCustomKeyValuePair("", "");
      }
    }

  }

  formatCustomAttributes(customAttr) {
    const formatted_attr = {};
    customAttr.capabilities.forEach(element => {
      formatted_attr[element.key] = element.value;
    });
    return formatted_attr;
  }

  blockSpecialChar(e) {

    const k = e.keyCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k === 8 || (k >= 48 && k <= 57) || k === 32);
  }

  onClose() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }
}
