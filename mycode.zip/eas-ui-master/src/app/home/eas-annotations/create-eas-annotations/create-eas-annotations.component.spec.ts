import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateEasAnnotationsComponent } from './create-eas-annotations.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GeoAddressComponent } from '../../geo-address/geo-address.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { ConfigService } from '../../../core/config/config-svc.service';
import { APP_INITIALIZER } from '@angular/core';
import { EasAnnotationsService } from '../eas-annotations.service';
import { MockEasAnnotationsService } from '../eas-mock-annotations.service';

export class DefaultEvent {
    preventDefault() {

    }
}

describe('CreateEasAnnotationsComponent', () => {
    let component: CreateEasAnnotationsComponent;
    let fixture: ComponentFixture<CreateEasAnnotationsComponent>;
    let geoAddressComponent: GeoAddressComponent;
    let geoAddressComponentFixure: ComponentFixture<GeoAddressComponent>;
    let service: EasAnnotationsService;
    let mockEasAnnotationsService: MockEasAnnotationsService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                CreateEasAnnotationsComponent,
                GeoAddressComponent
            ],
            imports: [
                FormsModule,
                ReactiveFormsModule,
                HttpClientModule,
                RouterTestingModule,
                NotifierModule
            ],
            providers: [
                ConfigService,
                MockEasAnnotationsService,
                { provide: EasAnnotationsService, useClass: MockEasAnnotationsService }
            ]
        }).compileComponents().then(() => {
            fixture = TestBed.createComponent(CreateEasAnnotationsComponent);
            component = fixture.componentInstance;
            service = TestBed.get(EasAnnotationsService);
            mockEasAnnotationsService = TestBed.get(MockEasAnnotationsService);
            geoAddressComponentFixure = TestBed.createComponent(GeoAddressComponent);
            geoAddressComponent = geoAddressComponentFixure.componentInstance;
        })
    }));

    beforeEach(() => {
        fixture.detectChanges();
        geoAddressComponentFixure.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should valid create annotation form if mandatory fields are given', () => {
        component.annotationForm.controls['resourceName'].setValue('Test Annotation');
        component.annotationForm.controls['annotationDesc'].setValue('sample testing');
        geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-73.990860');
        geoAddressComponent.geoAddressForm.controls['latitude'].setValue('40.739197');
        geoAddressComponent.geoAddressForm.controls['address'].setValue('123 5th Ave, New York, NY 10003, USA');
        expect(component.annotationForm.valid && geoAddressComponent.geoAddressForm.valid).toBeTruthy();
    });

    it('should invalid create annotation form if the inputs were does not given', () => {
        expect(geoAddressComponent.geoAddressForm.valid && component.annotationForm.valid).toBeFalsy();
    });

    it('should invalid create annotation form if annotation name, annotation description are given but address, coordinates are empty', () => {
        component.annotationForm.controls['resourceName'].setValue('Test Annotation');
        component.annotationForm.controls['annotationDesc'].setValue('sample testing');
        expect(geoAddressComponent.geoAddressForm.valid && component.annotationForm.valid).toBeFalsy();
    });

    it('should invalid create annotation form if address, coordinates are given but annotation name, annotation description are empty', () => {
        geoAddressComponent.geoAddressForm.controls['address'].setValue('123 5th Ave, New York, NY 10003, USA');
        expect(geoAddressComponent.geoAddressForm.valid && component.annotationForm.valid).toBeFalsy();
    });

    it('should invalid create annotation form if latitude is given and address, longitude are not given', (done) => {
        component.annotationForm.controls['resourceName'].setValue('Test Annotation');
        component.annotationForm.controls['annotationDesc'].setValue('sample testing');
        geoAddressComponent.geoAddressForm.controls['latitude'].setValue('40.739197');
        geoAddressComponent.setAddress();
        setTimeout(() => {
            expect(geoAddressComponent.geoAddressForm.valid && component.annotationForm.valid).toBeFalsy();
            done();
        }, 1000);
    });

    it('should invalid create annotation form if longitude is given and address, latitude are not given', (done) => {
        component.annotationForm.controls['resourceName'].setValue('Test Annotation');
        component.annotationForm.controls['annotationDesc'].setValue('sample testing');
        geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-73.990860');
        geoAddressComponent.setAddress();
        setTimeout(() => {
            expect(geoAddressComponent.geoAddressForm.valid && component.annotationForm.valid).toBeFalsy();
            done();
        }, 1000);
    });

    it('should invalid create annotation form if coordinates are wrong and address is not given', (done) => {
        component.annotationForm.controls['resourceName'].setValue('Test Annotation');
        component.annotationForm.controls['annotationDesc'].setValue('sample testing');
        geoAddressComponent.geoAddressForm.controls['latitude'].setValue('-10.02');
        geoAddressComponent.geoAddressForm.controls['longitude'].setValue('10.3');
        geoAddressComponent.setAddress();
        setTimeout(() => {
            expect(geoAddressComponent.geoAddressForm.valid && component.annotationForm.valid).toBeFalsy();
            done();
        }, 1000);
    });

    it('should close create annotation form when clicking cancel button', (done) => {
        component.crudViewEmitter.subscribe(
            data => {
                expect(data).toEqual('list');
                done();
            }
        );
        component.closeAction();
    });

    it('should reset create annotation', () => {
        component.annotationForm.controls['resourceName'].setValue('Test Annotation');
        component.annotationForm.controls['annotationDesc'].setValue('sample testing');
        geoAddressComponent.geoAddressForm.controls['latitude'].setValue('40.739197');
        geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-73.990860');
        geoAddressComponent.geoAddressForm.controls['address'].setValue('123 5th Ave, New York, NY 10003, USA');
        expect(geoAddressComponent.geoAddressForm.valid && component.annotationForm.valid).toBeTruthy();
        component.resetCreatePage(null);
        expect(geoAddressComponent.geoAddressForm.valid && component.annotationForm.valid).toBeFalsy();
    });

    it('should close create annotation form when clicking close icon', (done) => {
        component.easleftSideBarService.easleftSidebarToggle$.subscribe(
            data => {
                expect(data).toEqual('0%');
                done();
            }
        );
        component.onClose();
    });

    it('should call getEvents method', (done) => {
        component.getEvents();
        setTimeout(() => {
            expect(component.eventData.length).not.toBe(0);
            done();
        }, 1000);
    });

    it('should call setAnnotationForm', () => {
        component.setAnnotationForm(true);
        expect(component.isFormModified).toEqual(false);
    });

    it('should call addCustomKeyValue', () => {
        component.annotationForm.value.capabilities[component.annotationForm.value.capabilities.length - 1].key = 'Test';
        component.annotationForm.value.capabilities[component.annotationForm.value.capabilities.length - 1].value = 'Test';
        component.addCustomKeyValue();
        expect(component.annotationForm.value.capabilities.length).not.toBe(1);
    });

    it('should call addCustomKeyValue and should go to else condition', () => {
        component.addCustomKeyValue();
        expect(component.annotationForm.value.capabilities.length).toBe(1);
    });

    it('should call deleteCustomKeyValue', () => {
        component.annotationForm.value.capabilities[component.annotationForm.value.capabilities.length - 1].key = 'Test';
        component.annotationForm.value.capabilities[component.annotationForm.value.capabilities.length - 1].value = 'Test';
        component.addCustomKeyValue();
        component.deleteCustomKeyValue(component.annotationForm.value.capabilities.length - 1);
        expect(component.annotationForm.value.capabilities.length).toBe(1);
    });

    it('should call deleteCustomKeyValue and should go to else condition', () => {
        component.deleteCustomKeyValue(component.annotationForm.value.capabilities.length - 1);
        expect(component.annotationForm.value.capabilities.length).toBe(1);
    });

    it('should call formatCustomAttributes', () => {
        component.annotationForm.value.capabilities[component.annotationForm.value.capabilities.length - 1].key = 'Test';
        component.annotationForm.value.capabilities[component.annotationForm.value.capabilities.length - 1].value = 'Test';
        let formatted_attr = component.formatCustomAttributes(component.annotationForm.value);
        expect(formatted_attr["Test"]).toEqual("Test");
    });

    it('should call blockSpecialChar method', () => {
        let event = {
            'keyCode': 32
        };
        expect(component.blockSpecialChar(event)).toBe(true);
    });

    it('should call createAnnotation method', (done) => {
        mockEasAnnotationsService.getPlaceObject().subscribe(
            data => {
                component.geoAddressService.place = data;
                let defaultEvent = new DefaultEvent();
                component.createAnnotation(defaultEvent, component.annotationForm.getRawValue());
                expect(component.annotationForm.valid).toBe(false);
                done();
            }
        );
    });

});
