import { Component, OnInit, Inject, forwardRef, Input, Output, OnChanges, SimpleChange, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import * as $ from 'jquery';
import { SharedService } from '../../../shared/shared.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { EasAnnotationsService } from '../eas-annotations.service';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { NotifierService } from 'angular-notifier';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { AppGlobals } from '../../../shared/app.globals';
import { AnnotationTo } from '../../../shared/models/annotationTo';
import { DataModel } from '../../../dataModelEnum';
declare let google: any;
@Component({
  selector: 'app-create-eas-annotations',
  templateUrl: './create-eas-annotations.component.html',
  styleUrls: ['./create-eas-annotations.component.scss']
})
export class CreateEasAnnotationsComponent implements OnInit {
  @Input() markerEventData: any;
  @Output() crudViewEmitter = new EventEmitter();
  failureMessage = "";
  displayFailure = false;
  // @Output() associateDetails: EventEmitter<any> = new EventEmitter<any>();
  _markerAnnotationData = new FormGroup({ annotationData: new FormControl() });
  // customForm: FormGroup;
  annotationForm = new FormGroup({
    resourceName: new FormControl(),
    capabilities: new FormArray([
      new FormControl('key'),
      new FormControl('value'),
    ]),
    annotationDesc: new FormControl(),
    address: new FormControl(),
    annotationLatitude: new FormControl(),
    annotationLongitude: new FormControl(),
    coordinates: new FormControl(),
    status: new FormControl(),
    annotationType: new FormControl(),
    // annotationDate: new FormControl(),
    color: new FormControl(),
    assignedTo: new FormControl()
  });
  annotationNames = [];
  currentAnnotnId; // default Variable
  isAssignEvent;
  openEventData = [];
  allEventData = [];
  isCheck: boolean;
  displayCreateContent = true;
  annotationAddr = '';
  showRestBtn = true;
  showCancelBtn = false;
  formedCoords = [];
  enableDelete = false;
  isFormModified: boolean = false;
  customAttributes: any;
  eventData = [];
  customReset;
  fullAddress;
  annotationLatitude;
  annotationLongitude;
  annotationAddress;
  annotation: AnnotationTo;
  annotationShapeType = "Point";
  payload = {
    "dataModel": this.appglobals.annotationDataModel,
    "resourceObject": this.appglobals.resourceObject,
    "assignedTo": "",
    "annotationType": 'Public',
    "status": 'Available',
    "properties": {
      "capabilities": '',
      "color": ''
    },
    "resourceName": '',
    "type": this.appglobals.annotationType
  };
  // fromAnnotation:string="fromAnnotation";
  constructor(public formGroup: FormBuilder,
    public annotationSvc: EasAnnotationsService, public appglobals: AppGlobals, public sharedService: SharedService, public mapConsoleService: MapConsoleService,
    public easleftSideBarService: EasLeftSidebarService, private fb: FormBuilder, private notifierService: NotifierService, public geoAddressService: GeoAddressService)
     {
    this.annotationForm.controls['annotationType'].setValue("Public", { onlySelf: true });
    this.annotationForm.controls['status'].setValue("Available", { onlySelf: true });
    this.annotationForm.controls['assignedTo'].setValue("", { onlySelf: true });
    this.annotation = new AnnotationTo(this.payload);
    }
  ngOnInit() {
    this.getEvents();
    this.annotationForm.get('coordinates').disable();
    this.setAnnotationForm(false);
    if (this.markerEventData) {
      this.getAnnotationShapeFromMap(this.markerEventData);
    }
  }
  createAnnotation(annotation, formData) {
    this.geoAddressService.activeAddressInfo();
    formData.address = this.geoAddressService.address;
    formData.latitude = this.geoAddressService.latitude;
    formData.longitude = this.geoAddressService.longitude;
    formData.coordinates = this.geoAddressService.coordinates;
    annotation.preventDefault();
    this.annotation.resourceName = formData.resourceName;
    this.annotation.assigned = formData.assignedTo ? true : false;
    this.annotation.assignedTo = formData.assignedTo;
    this.annotation.status = formData.assignedTo ? "NotAvailable" : "Available";;
    this.annotation.assignedTo = formData.assignedTo;
    this.annotation.annotationDesc = formData.annotationDesc;
    this.annotation.annotationType = formData.annotationType;
    this.annotation.setAddress(this.sharedService.getFullAddress(this.geoAddressService.place));
    this.annotation.properties['capabilities'] = this.formatCustomAttributes(this.annotationForm.value);
    const geometry = {
      'type': this.annotationShapeType,
      'coordinates': (this.annotationShapeType === 'Point') ? formData.coordinates : [formData.coordinates]
    };
    this.annotation.setGeometry(geometry);
    for (const c in this.annotationForm.controls) {
      this.annotationForm.controls[c].markAsTouched();
    }
    if (this.annotationForm.valid && this.geoAddressService.checkValidation) {
      if (formData.type === undefined || formData.type === null) {
        formData.type = 'Point';
      }
      this.annotationSvc.createAnnotation(this.annotation).subscribe(
        data => {
          if (data) {
            if (this.annotation.assignedTo) {
              this.assignEvent(data.entityId, this.annotation.resourceName, this.annotation.assignedTo);
            } else {
              this.notifierService.notify('success', 'Annotation "' + this.annotation.resourceName + '" created successfully.');
            }
            this.getListView();
            this.geoAddressService.resetAll();
            this.onClose();
          } else {
            this.notifierService.notify("error", 'Unable to create annotation. Please try again later');
          }
        },
        error => {
          this.notifierService.notify('error', error.error.message);
        }
      );
    } else {
      $('#annotationName').focus();
      this.notifierService.notify('error', 'Please provide the correct details to create an annotation');
    }
  }
  getEvents() {
    this.annotationSvc.getAllEvents().subscribe(
      data => {
        data.forEach(element => {
          if (element.status === 'STARTED' && !element.deleted) {
            this.openEventData.push(element);
          }
        });
        this.eventData = this.openEventData;
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.notifierService.notify("error", 'General error occured. Please try again later.');
        }
      }
    );
  }
  setAnnotationForm(isReset) {
    this.annotationForm = this.formGroup.group({
      'resourceName': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'annotationDesc': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(250)])],
      'address': [''],
      'annotationLatitude': [''],
      'annotationLongitude': [''],
      'coordinates': [],
      'status': ['Available'],
      'assignedTo': '',
      'annotationType': ['Public'],
      'color': [],
      'formedCoords': [],
      // 'annotationDate': [],
      'type': this.annotationShapeType,
      'capabilities': this.formGroup.array([this.formGroup.group({ key: '', value: '' })]),
      'key': [],
      'value': []
    });
    this.annotationForm.get('status').disable();
    this.annotationForm.valueChanges.subscribe(data => {
      this.isFormModified = true;
    });
    if (isReset)
      this.isFormModified = false;
  }
  resetCreatePage(annotation) {
    if (!this.markerEventData) { this.geoAddressService.resetAll(); }
    this.annotationForm.reset();
  }
  getAnnotationShapeFromMap(shapeObject) {
    if (shapeObject.type === google.maps.drawing.OverlayType.MARKER) {
      this.annotationShapeType = 'Point';
    } else {
      this.annotationShapeType = 'Polygon';
      this.geoAddressService.disableAddressLatLng.next();
    }
    const data = {
      shape: shapeObject,
      dataModel: DataModel.annotation
    };
    this.geoAddressService.getMapObjects.next(data);
  }
  assignEvent(annotationId, annotationName, eventId) {
    this.annotationSvc.mergeAnnotn(annotationId, eventId).subscribe(
      data => {
          this.notifierService.notify('success', 'Annotation "' + annotationName + '" created and assigned to an event successfully');
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.notifierService.notify('error', 'General error occured. Please try again later.');
        }
      }
    );
  }
  closeAction() {
    this.getListView();
  }
  getListView() {
    this.crudViewEmitter.emit("list");
    this.easleftSideBarService.changeEntitiesListTypes(PanelHeaders.annotations);
  }
  get customKeyValuPair() {
    return this.annotationForm.get('capabilities') as FormArray;
  }
  addCustomKeyValuePair(K, V) {
    this.customKeyValuPair.push(this.fb.group({ key: K, value: V }));
  }
  addCustomKeyValue() {
    if (this.annotationForm.value.capabilities[this.annotationForm.value.capabilities.length - 1].key &&
      this.annotationForm.value.capabilities[this.annotationForm.value.capabilities.length - 1].value) {
      this.customKeyValuPair.push(this.fb.group({ key: '', value: '' }));
      this.failureMessage = "";
      this.displayFailure = false;
    } else {
      this.failureMessage = "key and value should have proper value";
      this.displayFailure = true;
      setTimeout(() => {
        this.failureMessage = "";
        this.displayFailure = false;
      }, 4000);
    }
  }
  deleteCustomKeyValue(index) {
    if (this.annotationForm) {
      if (this.annotationForm.value.capabilities.length > 1) {
        this.customKeyValuPair.removeAt(index);
      } else {
        this.customKeyValuPair.removeAt(0);
        this.addCustomKeyValuePair("", "");
      }
    }
  }
  formatCustomAttributes(customAttr) {
    const formatted_attr = {};
    customAttr.capabilities.forEach(element => {
      formatted_attr[element.key] = element.value;
    });
    return formatted_attr;
  }
  blockSpecialChar(e) {
    const k = e.keyCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k === 8 || (k >= 48 && k <= 57) || k === 32);
  }
  onClose() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }
}
