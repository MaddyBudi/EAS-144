// import { TestBed } from '@angular/core/testing';

// import { EasAnnotationsService } from './eas-annotations.service';

// describe('EasAnnotationsService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: EasAnnotationsService = TestBed.get(EasAnnotationsService);
//     expect(service).toBeTruthy();
//   });
// });
