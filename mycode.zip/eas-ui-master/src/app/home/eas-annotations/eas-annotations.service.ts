import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { SharedService } from '../../shared/shared.service';
import { environment } from '../../../environments/environment';
import { AppGlobals } from '../../shared/app.globals';
import { ConfigService } from "../../core/config/config-svc.service";
import { Observable } from 'rxjs';
import { Subject } from 'rxjs';
import { AnnotationTo } from '../../shared/models/annotationTo';

@Injectable({
  providedIn: 'root'
})
export class EasAnnotationsService {
  eventEntityId: String;
  displaySuccess: boolean = false;
  displayFailure: boolean = false;
  successMessage: String;
  failureMessage: String;
  closeMoreInformation = new Subject<string>();
  closeMoreInformation$ = this.closeMoreInformation.asObservable();
  
  constructor(private http: HttpClient, public sharedService: SharedService, private appglobals: AppGlobals) { }
  getHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'ANNOTATION'
      }),
      withCredentials: true
    };
    return httpOptions;
  }
  // sends annotation details to create endpoint and creates an annotation
  public createAnnotation(payload) {
     payload.geometry=JSON.stringify(payload.geometry)
    return this.http.post(ConfigService.config.annotationServiceUrl + '/create', payload, this.getHeaders()).pipe(map((res: any) => res));
  }
  // gets all annotation from DB 
  public getAllAnnotation():Observable<AnnotationTo[]> {
    return this.http.get<AnnotationTo[]>(ConfigService.config.annotationServiceUrl
      + '/getAll?resourceObject=ANNOTATION', this.getHeaders()).pipe(map((event => this.convertListToListObject(event))));
  }

  // closes an annotation by passing its ID
  public closeAnnotation(annotation) {
    const geo = {
      "type": annotation.shapeType,
      "coordinates": annotation.coordinates
    };

    const payload = {
      "dataModel": this.appglobals.annotationDataModel,
      "entityId": annotation.entityId,
      "resourceObject": this.appglobals.resourceObject,
      "assignedTo": annotation.assigned,
      "annotationType": annotation.annotationType,
      "organizationName": annotation.organizationName,
      "status": "Closed",
      "attributes": {
      },
      "geometry": JSON.stringify(geo),
      "properties": {
        "color": annotation.fillColor
      },
      "resourceName": annotation.annotationName === undefined ? annotation.resourceName : annotation.annotationName,
      "address": {
        "streetAddress1": annotation.address.streetAddress1,
        "streetAddress2": annotation.address.streetAddress2,
        "city": annotation.address.city,
        "zip": annotation.address.zip,
        "state": annotation.address.state,
        "county": annotation.address.county
      },
      "annotationDesc": annotation.annotationDesc,
      "type": this.appglobals.annotationType

    };

    return this.http.put(ConfigService.config.annotationServiceUrl + '/update', payload, this.getHeaders()).pipe(map((res: any) => res));
  }
  // gets an annotation by its ID
  public getAnnotationDetails(annotationId):Observable<AnnotationTo> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'ANNOTATION'
      }), withCredentials: true
    };
    return this.http.get<AnnotationTo>(ConfigService.config.annotationServiceUrl +
      '/get?ENTITY_ID=' + annotationId, httpOptions).pipe(map((event => this.convertResponseToObject(event))));
  }

  // updates an annotation by passing updated data
  public updateAnnotation(annotation:AnnotationTo) {
    annotation.geometry=JSON.stringify(annotation.geometry)
    return this.http.put(ConfigService.config.annotationServiceUrl + '/update', annotation, this.getHeaders()).pipe(map((res: any) => res));
  }
  public mergeAnnotn(anntID, evnID) {
    const temp = [];
    temp.push(anntID);
    return this.http.put(ConfigService.config.eventServiceUrl +
      '/assignAnnotationsToEvent?ENTITY_ID=' + evnID, temp, this.getHeaders()).pipe(map((res: any) => res));
  }
  // gets all events from DB 
  public getAllEvents() {
    return this.http.get(ConfigService.config.eventServiceUrl + '/getAllEvents', this.getHeaders()).pipe(map((res: any) => res));
  }
  public releaseAnnotn(anntID, evnID) {
    const temp = [];
    temp.push(anntID);
    return this.http.put(ConfigService.config.eventServiceUrl +
      '/releaseAnnotationsToEvent?ENTITY_ID=' + evnID, temp, this.getHeaders()).pipe(map((res: any) => res));
  }

  public releaseAnnotations(releaseAnnotations, eventId) {
    return this.http.put(ConfigService.config.eventServiceUrl +
      '/releaseAnnotationsToEvent?ENTITY_ID=' + eventId, releaseAnnotations, this.getHeaders()).pipe(map((res: any) => res));
  }

  public closeAnnotationFromMap(annotation) {
    this.getAnnotationDetails(annotation.entityId).subscribe(
      data => {
        data.status = "Closed";
        this.http.put(ConfigService.config.annotationServiceUrl +
          '/update', data, this.getHeaders()).pipe(map((res: any) => res)).subscribe(
            res => {
              if (res.assignedTo) {
                this.releaseAnnotn(res.entityId, res.assignedTo).subscribe(
                  realeaseResponse => {
                    return "Annotation closed successfully";

                  },
                  error => {
                    return "Unable to close annotation";
                  }
                );
              }
            },
            error => {
              return "Unable to close annotation";
            }
          );

      },
      error => {
        return "Unable to close annotation";
      }
    );
  }

  public setEventEntityID(entityId) {
    this.eventEntityId = entityId;
  }

  public getEventEntityID() {
    return this.eventEntityId;
  }

  public setdisplaySuccess(displaySuccess) {
    this.displaySuccess = displaySuccess;
  }

  public getdisplaySuccess() {
    return this.displaySuccess;
  }

  public setdisplayFailure(displayFailure) {
    this.displayFailure = displayFailure;
  }

  public getdisplayFailure() {
    return this.displayFailure;
  }


  public setSuccessMessage(successMessage) {
    this.successMessage = successMessage;
  }

  public getSuccessMessage() {
    return this.successMessage;
  }
  public getfailureMessage() {
    return this.failureMessage;
  }

  public setfailureMessage(failureMessage) {
    this.failureMessage = failureMessage;
  }

  closeMoreInfo(){
    this.closeMoreInformation.next();
  }

  
 convertListToListObject(object:any){
  let annotationTo=[];
  object.forEach(element => {
    if(element.address){
    const annotationTO=new AnnotationTo(element);
    annotationTo.push(annotationTO);
    }
  });

  return annotationTo;
 }

 convertResponseToObject(object){
  const annotationTo=new AnnotationTo(object);
  return annotationTo;

 }
  
}
