import { Component, OnInit, Input } from '@angular/core';
import { CrudView } from './crudview';
import {EasAnnotationsService} from './eas-annotations.service';

@Component({
  selector: 'app-eas-annotations',
  templateUrl: './eas-annotations.component.html',
  styleUrls: ['./eas-annotations.component.scss']
})
export class EasAnnotationsComponent implements OnInit {
@Input() contextEventId;
@Input() contextEventName;
  crudView: CrudView = new CrudView();
  constructor(public easAnnotationService:EasAnnotationsService) { }

  ngOnInit() {
      this.crudView.viewType = 'list';
     // this.crudView.viewType = 'create';
    this.easAnnotationService.setdisplaySuccess(false);
    this.easAnnotationService.setdisplayFailure(false);
  }

  crudViewEmitter(event:String){
    this.crudView.viewType=event;
  }
}
