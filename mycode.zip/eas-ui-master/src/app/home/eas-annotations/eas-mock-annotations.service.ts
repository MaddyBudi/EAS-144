import { Observable, Subject } from 'rxjs';
import { EventTo } from '../../shared/models/eventTo'
import { ConfigService } from "../../core/config/config-svc.service";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { AnnotationTo } from '../../shared/models/annotationTo';
import { UnitTestConstants } from '../../common/enums/unit-test-constants-enum';

@Injectable()
export class MockEasAnnotationsService {
  eventEntityId = 'adc6f275-e7df-4e52-89af-8b561ec7fde1';
  closeMoreInformation = new Subject<string>();
  closeMoreInformation$ = this.closeMoreInformation.asObservable();
  constructor(private http: HttpClient) { }

  public getEventEntityID() {
    return this.eventEntityId;
  }

  closeMoreInfo() {
    this.closeMoreInformation.next();
  }

  public setEventEntityID(entityId) {
    this.eventEntityId = entityId;
  }

  public getAllEvents(): Observable<EventTo[]> {
    return this.http.get<EventTo[]>(UnitTestConstants.eventPayloadUrl).pipe(map((res) => this.convertEventListToListObject(res)));
  }

  public getAnnotationDetails(annotationId): Observable<AnnotationTo> {
    return this.http.get<AnnotationTo>(UnitTestConstants.annotationPayloadUrl).pipe(map((res => this.convertResponseToObject(res[0]))));
  }

  public getAllAnnotation(): Observable<AnnotationTo[]> {
    return this.http.get<AnnotationTo[]>(UnitTestConstants.annotationPayloadUrl).pipe(map((res => this.convertAnnotationListToListObject(res))));
  }

  public getPlaceObject(): Observable<any> {
    return this.http.get<any>(UnitTestConstants.placeObjectUrl).pipe(map((res => res)));
  }

  convertEventListToListObject(object: any) {
    let eventTo = [];
    object.forEach(element => {

      const event = new EventTo(element);
      eventTo.push(event);

    });
    return eventTo;
  }

  convertAnnotationListToListObject(object: any) {
    let annotationTo = [];
    object.forEach(element => {
      if (element.address) {
        const annotationTO = new AnnotationTo(element);
        annotationTo.push(annotationTO);
      }
    });

    return annotationTo;
  }

  convertResponseToObject(object) {
    const annotationTo = new AnnotationTo(object);
    return annotationTo;

  }

}