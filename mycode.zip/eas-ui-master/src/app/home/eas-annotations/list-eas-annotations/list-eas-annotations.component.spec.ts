import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ListEasAnnotationsComponent } from './list-eas-annotations.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfigService } from '../../../core/config/config-svc.service';
import { NotifierModule } from 'angular-notifier';
import { APP_INITIALIZER } from '@angular/core';
import { EasAnnotationsService } from '../eas-annotations.service';
import { MockEasAnnotationsService } from '../eas-mock-annotations.service'
import { SharedPipe } from '../../../home/shared.pipe';
import { DataTableModule } from 'angular-6-datatable';
import { EasEventMoreInformationComponent } from '../../../home/eas-event-more-information/eas-event-more-information.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { PanelHeaders } from '../../../panelHeaders'

describe('ListEasAnnotationsComponent', () => {
  let component: ListEasAnnotationsComponent;
  let fixture: ComponentFixture<ListEasAnnotationsComponent>;
  let eventMoreInfoComponent: EasEventMoreInformationComponent;
  let eventMoreInfoCFixture: ComponentFixture<EasEventMoreInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ListEasAnnotationsComponent,
        SharedPipe,
        EasEventMoreInformationComponent
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule,
        DataTableModule
      ],
      providers: [
        ConfigService,
        { provide: EasAnnotationsService, useClass: MockEasAnnotationsService }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListEasAnnotationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get all annotaions and count should not be zero', (done) => {
    component.getAnnoations()
    setTimeout(() => {
      expect(component.annotationAllData.length).not.toBe(0);
      done();
    }, 1000);
  });

  it('should open create annotation form when clicking create icon', (done) => {
    component.crudViewEmitter.subscribe(
      data => {
        expect(data).toEqual('create');
        done();
      }
    );
    component.createAnnotation();
  });

  it('should open update annotation form when clicking update icon', (done) => {
    component.crudViewEmitter.subscribe(
      data => {
        expect(data).toEqual('update');
        done();
      }
    );
    component.getAnnoations()
    setTimeout(() => {
      component.editAnnotation(component.annotationAllData[0]);
      done();
    }, 1000);
  });

  it('should call more info observable', (done) => {
    component.annotationService.closeMoreInfo();
    setTimeout(() => {
      expect(component.isMoreInfo).toBe(false);
      done();
    }, 1000);
  });

  it('should call clearContext observable', (done) => {
    component.entitiesMiniListService.clearEventContext();
    setTimeout(() => {
      expect(component.eventContextRadioButton).toBe(false);
      done();
    }, 1000);
  });

  it('should call onViewChange method', (done) => {
    component.getAnnoations();
    setTimeout(() => {
      component.onViewChange(component.annotationAllData[0]);
      expect(component.annotationAllData.length).not.toBe(0);
      done();
    }, 1000);
  });

  it('should call onCompress method', (done) => {
    component.easleftSideBarService.easleftSidebarToggle$.subscribe(
      data => {
        expect(data).toBe('25%');
        done();
      }
    );
    component.onCompress();
  });

  it('should call onClose method', (done) => {
    component.easleftSideBarService.easleftSidebarToggle$.subscribe(
      data => {
        expect(data).toBe('0%');
        done();
      }
    );
    component.onClose();
  });

  it('should call onOpenInfo method', (done) => {
    component.easleftSideBarService.easleftSidebarToggle$.subscribe(
      data => {
        expect(data).toBe('75%');
        done();
      }
    );
    component.getAnnoations();
    setTimeout(() => {
      component.onOpenInfo(component.annotationAllData[0]);
      done();
    }, 1000);
  });

  it('should call onOpenInfo method', (done) => {
    component.getAnnoations();
    setTimeout(() => {
      component.getAssignedAnnotations();
      expect(component.annotationNotAssociateData.length).not.toBe(0);
      done();
    }, 1000);
  });

  it('should call handleChange method', () => {
    let event = {
      'target': {
        'id': 'currentEvent'
      }
    };
    component.handleChange(event);
    event.target.id = 'allEvents';
    component.handleChange(event);
    event.target.id = 'notAssignedToEvent';
    component.handleChange(event);
    expect(component.displayFailureAnnotation).toBe(true);
  });

});
