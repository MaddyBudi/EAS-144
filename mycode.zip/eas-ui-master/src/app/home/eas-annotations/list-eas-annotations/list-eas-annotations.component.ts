import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SharedService } from '../../../shared/shared.service';
import { AppGlobals } from '../../../shared/app.globals';
import { EasAnnotationsService } from '../eas-annotations.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { HomeComponent } from '../../home.component';
import * as $ from 'jquery';
import { HomeService } from '../../home.service';
import { EasResourcesService } from '../../eas-resources/eas-resources.service';
import { PersonService } from '../../map-console/person/person.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders'
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { NotifierService } from 'angular-notifier';
import { EntitiesMiniListService } from '../../map-console/entities-mini-list/entities-mini-list.service';
import { AnnotationTo } from '../../../shared/models/annotationTo';
import { debug } from 'util';

const swal = require('sweetalert');
@Component({
  selector: 'app-list-eas-annotations',
  templateUrl: './list-eas-annotations.component.html',
  styleUrls: ['./list-eas-annotations.component.scss']
})
export class ListEasAnnotationsComponent implements OnInit {
    @Input() contextEventId;
    @Input() contextEventName;
    sortBy = "createdDate";
    sortOrder = "desc";
    displayFailure: boolean = false;
    failureMessage: String;
    annotationAllData = [];
    isMoreInfo: boolean = false;
    easOtherEntitiesData: any;
    rowsPerPageList: Number[] = this.appglobals.RowsPerPageList;
    defaultRowsPerPage: Number = this.appglobals.DefaultRowsPerPage;
    annotationData = [];
    annotationAssociateData = [];
    annotationNotAssociateData = [];
    displayFailureAnnotation = false;
    failureMsgAnnotation = '';
    noAnnotationsAvailable = 'No Annotations available';
    eventContextRadioButton = false;
    isLoading = true;
    @Output() crudViewEmitter = new EventEmitter();
    selectedEventId: String;
    selectedEntityId;
    selectedAnnotations = [];

  constructor(public annotationService: EasAnnotationsService, public sharedService: SharedService, private appglobals: AppGlobals, private mapConsoleService: MapConsoleService, private homeService: HomeService, private resourceService: EasResourcesService,
    private personService: PersonService, public easleftSideBarService: EasLeftSidebarService, private notifierService: NotifierService, public entitiesMiniListService: EntitiesMiniListService) { }

    ngOnInit() {
        this.getAnnoations();
        this.annotationService.closeMoreInformation$.subscribe(
            data => {
                this.isMoreInfo = false;
                this.selectedEntityId = undefined;
            }
        );
        this.entitiesMiniListService.clearContext$.subscribe(
            data => {
                this.eventContextRadioButton = false;
                this.annotationData = this.annotationAllData.slice();
                this.displayFailureAnnotation = false;
            }
        );
    }
    ngOnChanges(changes: any) {
        if (changes.hasOwnProperty("contextEventId")) {
            if (changes.contextEventId.currentValue !== '') {
                this.eventContextRadioButton = true;
            }
        }
    }
  getAnnoations() {
    this.annotationService.getAllAnnotation().subscribe(
      data => {
        // this.setannotationAllData(data);
        this.annotationAllData = data;
        this.annotationData = data;
        this.displayFailure = false;
        this.isLoading = false

      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.displayFailure = true;
          this.failureMessage = "Unable to get Annotation. Please try again later.";
        }
      }
    );
  }
  createAnnotation() {
    this.crudViewEmitter.emit("create");
  }
  editAnnotation(item: AnnotationTo) {
    this.crudViewEmitter.emit("update");
    this.annotationService.setEventEntityID(item.entityId);
  }
  onViewChange(data) {
    if (typeof data.geometry !== "object")
      data.geometry = JSON.parse(data.geometry);
    const entityData = this.sharedService.formPayloadForEntitiesMoreInfo([data], false, true);
    this.mapConsoleService.viewMapEntitiesMap(entityData);
  }
  closeAnnotation(annotation: AnnotationTo) {
    let that = this;
    this.sharedService.showYesNoAlert("Delete Annotation: " + annotation.resourceName, 'Delete', swalCallback, 'No, cancel');
    function swalCallback(yesNo) {
      if (yesNo) {
        that.selectedEventId = annotation.assignedTo;
        that.resourceService.deleteResource(annotation.entityId).subscribe(
          data => {
            if (data) {
              that.getAnnoations();
              that.notifierService.notify("success", annotation.resourceName + " has been deleted successfully");
              if (that.selectedEventId) {
                that.annotationService.releaseAnnotn(data.entityId, that.selectedEventId).subscribe(
                  data => {
                    // that.notifierService.notify("success", annotation.resourceName + " has been closed successfully");
                  },
                  error => {
                    that.notifierService.notify("error", "General error occured. Please try again later.");
                  }
                );
              } else {
              }
            } else {
              swal('Not Removed!', data.status, 'Failure');
            }
          },
          error => {
            swal('Not Removed!', "Please try again", 'Failure');
          }
        );
      }
    }
  }

  viewPersonSearchComponent(address) {
    this.mapConsoleService.openRightSidePanel(PanelHeaders.powerDataSearch);
    this.personService.getPersonDetails(address);
  }

  onCompress() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.miniView);
    this.easleftSideBarService.changeEntitiesListTypes(PanelHeaders.entitiesMiniView);
  }
  onClose() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }
  onOpenInfo(data) {
    this.isMoreInfo = true;
    this.selectedEntityId = data.entityId;
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.maxView);
    this.easOtherEntitiesData = {
      dataEntityId: data.entityId,
      dataModel: data.resourceObject
    };
  }
  getAssignedAnnotations() {
    this.annotationAssociateData = [];
    this.annotationNotAssociateData = [];
    this.annotationAllData.forEach(data => {
      if (data.hasOwnProperty("assignedTo")) {
        if (data.assignedTo === this.contextEventId) {
          this.annotationAssociateData.push(data);
        }
        if (data.assignedTo !== this.contextEventId) {
          this.annotationNotAssociateData.push(data);
        }
      }
    })
  }

  handleChange(event) {
    this.displayFailureAnnotation = false;
    this.annotationData = [];
    this.getAssignedAnnotations();
    if (event.target.id === "currentEvent") {
      this.annotationData = this.annotationAssociateData.slice();
    } else if (event.target.id === "allEvents") {
      this.annotationData = this.annotationAllData.slice();
    } else if (event.target.id === "notAssignedToEvent") {
      this.annotationData = this.annotationNotAssociateData.slice();
    }
    if (this.annotationData.length === 0) {
      this.displayFailureAnnotation = true;
      this.failureMsgAnnotation = this.noAnnotationsAvailable;
    }
  }
toggleVisibility(isChecked, item) {
    if (isChecked) {
      // item = JSON.parse(JSON.stringify(item))
      if (typeof item.geometry !== "object")
      item.geometry = JSON.parse(item.geometry);

      if(item.geometry['type'] === 'Point')
      item.geometry['coordinates']=[[item.geometry['coordinates']]];

      this.selectedAnnotations.push(item);
      this.annotationData.forEach(element => {
                if (item.entityId === element.id) {
                    element.properties.checkboxFlag = true;
                }
            });
    }
    else {
      var index = this.selectedAnnotations.findIndex(x => x.entityId === item.entityId);
      if (~index) {
        this.selectedAnnotations.splice(index, 1);
        this.annotationData.forEach(element => {
                    if (item.entityId === element.id) {
                        element.properties.checkboxFlag = false;
                    }
                });
      }
    }
  }
plotSelectedAnnotations() {
    if (this.selectedAnnotations.length === 0) {
      this.notifierService.notify('error', 'Please select atleast one event to view');
    } else {
      const entityData = this.sharedService.formPayloadForEntitiesMoreInfo(this.selectedAnnotations, false, true);
      this.mapConsoleService.viewMapEntitiesMap(entityData);
      this.onClose();
    }
  }

}
