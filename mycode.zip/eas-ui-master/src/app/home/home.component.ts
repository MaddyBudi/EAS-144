import { Component, OnInit, NgZone, enableProdMode } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { AppGlobals } from '../shared/app.globals';
import { UserService } from '../login/services/user.service';
import { HttpClient, HttpParams, } from '@angular/common/http';
import * as $ from 'jquery';
import { MapConsoleService } from './map-console/map-console.service';
import { HomeService } from './home.service';
import { DeviceDetectorService } from 'ngx-device-detector';
declare  var  require:  any;
enableProdMode();
const clearContext = "ClearContext";
interface response {
  role: any;
}
interface Res {
  roles: any;
  userName: string;
  org: string;
}
let controller;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements OnInit {
  version:  string  =  require( '../../../package.json').version;
  public moduleName: string;
  public userName: string;
  public eas_Zoom_Size: string;
  public userProfile: any;
  displayAdminRoutes: boolean;
  displayGeneralRoutes: boolean;
  userInfo: any;
  eventPosition: any;
  locationPosition: any;
  viewFromModule = false;
  showMap = false;
  // eventData2:any;
  /** eventContextId and eventName created from event context EAS-185*/
  eventContextId: String;
  eventName: String;
  constructor(public router: Router, private http: HttpClient, private userService: UserService,
    public ngZone: NgZone, private appglobals:  AppGlobals, private mapConsoleService: MapConsoleService,
    private homeService: HomeService, private deviceDetectorService: DeviceDetectorService) {
    const self = this;
    homeService.homeServiceViewOnchange$.subscribe(
      data => {
        this.eventPosition = data;
        this.viewFromModule = true;
        this.moduleName = 'Incident';
      }

    );
  }

  ngOnInit() {

    this.getUserInfo();
    controller = this;
  }

  handleUserActions(event) {
    if (event) {
      console.log("handleUserActions");
      console.log(event.target);
      console.log(event.currentTarget);
      if (event.target !== event.currentTarget) {
        return;
      } else {
        controller.extendSession();
      }
      alert("Outer element is clicked");
    }
  }
  //   viewChatEvent(event){
  // console.log(event);
  // // this.eventData2=event;
  //   }
  getUserInfo() {

    this.userService.getUserInfo().subscribe(
      data => {
        console.log(data);
        const role = data.roles;
        this.userService.eventType = data.org.allowedEventTypes;
        let trimOrgValue;
        this.userName = data.userName;
        if (data.org.settings.ORG_LOCATION !== undefined) {
          trimOrgValue = data.org.settings.ORG_LOCATION.match(/coordinates\"\:(.*)\},/)[1];
          this.userService.orgLatLng.lng = trimOrgValue.match(/\[(.*)\,/)[1];
          this.userService.orgLatLng.lat = trimOrgValue.match(/\,(.*)\]/)[1];
        } else {
          this.userService.orgLatLng.lng = this.appglobals.defaultOrgLan;
          this.userService.orgLatLng.lat = this.appglobals.defaultOrgLat;
        }
        if (data.org.settings.MAP_ZOOM_LEVEL !== undefined) {
          this.eas_Zoom_Size = data.org.settings.MAP_ZOOM_LEVEL;
        } else {
          this.eas_Zoom_Size = this.appglobals.defaultZoomSize;
        }
        this.userService.zoomlevel = this.eas_Zoom_Size;
        if (role.length === 0) {
          console.log('Invalid User');
          this.router.navigate(['LoginComponent', { error: 'Invalid User' }], { skipLocationChange: true });
        }
        if (role.includes(this.appglobals.adminUser)) { this.displayAdminRoutes = true; }
        if (role.includes(this.appglobals.normalUser)) {
          this.displayGeneralRoutes = true;
          this.moduleName = 'Incident';
          this.userService.userName = data.userName;
        }
        if (data.org.entitlements.includes("EPTT_CALL") && this.deviceDetectorService.os === 'Windows') {
          this.userService.epttUser = true;
           this.userService.epttUser_mdn = data.userPreferences.EPTT_MDN;
          this.userService.epttUser_accessToken = data.userPreferences.EPTT_ACCESS_TOKEN;
          this.userService.epttUser_clientType = data.userPreferences.EPTT_CLIENT_TYPE;
        }
        data.userPackages.forEach(element  =>  {
          if  (element.packageEntitlements.includes("TWITTER")) {
            this.userService.twitter  =  true;
          }
          if  (element.packageEntitlements.includes("FACEBOOK")) {
            this.userService.facebook  =  true;
          }
        });
        this.showMap = true;
        console.log('EAS Version: '  +  this.version);
      },
      error => {
        console.error('Error Getting User info....');
        this.router.navigate(['LoginComponent', { error: 'Invalid User' }], { skipLocationChange: true });
      });

  }
  getModuleDetails(event: any) {
    this.moduleName = event;
    this.viewFromModule = false;
  }
  clearUserName() {
    this.userName = '';
    this.displayAdminRoutes = false;
    this.displayGeneralRoutes = false;
    console.log('logout success');
  }


  /** eventContext and clearContext created from event context EAS-185*/
  public eventContext(event: any) {
    this.eventContextId = event.eventContextId;
    this.eventName = event.eventContextName;

  }

  public clearContext() {
    this.eventContextId = "";
    this.eventName = "";
    if (this.eventPosition && this.eventPosition[0].type !== 'Workspace') {
      this.eventPosition = "";
    }
    this.mapConsoleService.clearContext();
  }
}


