import { Component, OnInit, Input } from '@angular/core'
import { EasLeftSidebarService } from './eas-left-sidebar.service'
import * as $ from 'jquery'
import { TransactionMeasures } from '../../../transactionMeasures'
import { PanelHeaders } from '../../../panelHeaders'
import { MapConsoleService } from '../map-console.service'
import { EntitiesMiniListService } from '../entities-mini-list/entities-mini-list.service'
import { EasEventsService } from '../../eas-events/eas-events.service'
import { EasResourcesService } from '../../eas-resources/eas-resources.service'
import { EasAnnotationsService } from '../../eas-annotations/eas-annotations.service'
import { EasPredefinedLocationsService} from '../../eas-predefined-locations/eas-predefined-locations.service'

@Component({
  selector: 'app-eas-left-sidebar',
  templateUrl: './eas-left-sidebar.component.html',
  styleUrls: ['./eas-left-sidebar.component.scss']
})
export class EasLeftSidebarComponent implements OnInit {
  @Input() listEntitiesType;
  @Input() entitiesType;
  @Input() contextEventId;
  @Input() contextEventName;
  @Input() contextEventData;
  @Input() selectedShape;
  @Input() easOtherEntitiesData;
  isfullView = false;
  entityId: String;
  panelHeader: any;
  displayGeocall = true;
  toggleSubscriber;

  constructor(private easLeftBarService: EasLeftSidebarService, private easResourcesService: EasResourcesService,
    private mapConsoleService: MapConsoleService, private enititiesService: EntitiesMiniListService,
    private eventService: EasEventsService, private annotationService: EasAnnotationsService,
  private easPredefinedLocationsService: EasPredefinedLocationsService) {
   this.toggleSubscriber=this.easLeftBarService.easleftSidebarToggle$.subscribe(
      data => {
console.log(data)
        this.togglePosition(data)
        if (data === TransactionMeasures.miniView)
          this.isfullView = false
        else if (data === TransactionMeasures.fullView)
          this.isfullView = true
      }
    );
    this.easLeftBarService.moreInfoDataId$.subscribe(
      data => {
        this.entityId = data;
      }
    );
    this.easLeftBarService.changeEntitiesListType$.subscribe(
      data => {
        this.changeEntitiesList(data);
      }
    );
    this.easLeftBarService.clsoeMoreInfPanel$.subscribe(
      data => {
        this.closeMoreInfoPanel();
      }
    );
  }

  ngDestroy(){
    this.toggleSubscriber.unsubscribe();
  }

  ngOnChanges(changes): void {
    if (changes.hasOwnProperty('listEntitiesType'))
      if (changes.listEntitiesType.currentValue === PanelHeaders.updateContextEvent || this.listEntitiesType === PanelHeaders.msdnSearch || this.listEntitiesType === PanelHeaders.assignReleaseResources|| changes.listEntitiesType.currentValue === PanelHeaders.createEvent)
        this.togglePosition(TransactionMeasures.fullView);
      else
        this.togglePosition(TransactionMeasures.miniView);
    if (changes.hasOwnProperty('contextEventData'))
      this.contextEventData = changes.contextEventData.currentValue;

    if (changes.hasOwnProperty("contextEventId"))
      this.contextEventId = changes.contextEventId.currentValue;

    if (changes.hasOwnProperty("contextEventName"))
      this.contextEventName = changes.contextEventName.currentValue;

    if (changes.hasOwnProperty("easOtherEntitiesData"))
      this.easOtherEntitiesData = changes.easOtherEntitiesData.currentValue;
    if (changes.hasOwnProperty('selectedShape')) {
      this.selectedShape = changes.selectedShape.currentValue;

      if (this.selectedShape && this.selectedShape.type === 'marker') {
        this.displayGeocall = false;
      }
    }

    if (changes.hasOwnProperty('entitiesType')){
      
      if (this.isfullView && this.listEntitiesType != changes.entitiesType.currentValue) {
        this.togglePosition(TransactionMeasures.fullView)
        this.listEntitiesType = changes.entitiesType.currentValue
      }
      // if (!this.isfullView && this.entitiesType === PanelHeaders.entitiesMiniView) {
      //         this.togglePosition(TransactionMeasures.fullView);
      // }
    }

  }
  ngOnInit() {
    if (this.listEntitiesType === PanelHeaders.updateContextEvent || this.listEntitiesType === PanelHeaders.msdnSearch || this.listEntitiesType === PanelHeaders.assignReleaseResources|| this.listEntitiesType === PanelHeaders.createEvent)
      this.togglePosition(TransactionMeasures.fullView);
    else
      this.togglePosition(TransactionMeasures.miniView);
    this.panelHeader = PanelHeaders;
  }

  togglePosition(length: string) {
    if (length !== TransactionMeasures.close) {
      document.getElementById('easleftSideBar').style.width = length;
    } else {
      document.getElementById('easleftSideBar').style.width = 'auto';
      document.getElementById('easleftSideBarComponent').style.width = length;
    }
  }

  changeEntitiesList(listEntitiesType: string) {
    this.listEntitiesType = listEntitiesType;
    if (this.entitiesType === PanelHeaders.updateContextEvent && PanelHeaders.entitiesMiniView) {
      this.entitiesType = PanelHeaders.events;
    }
  }
  closeMoreInfoPanel() {
    if (this.listEntitiesType === PanelHeaders.contextEventInfo) {
      this.togglePosition(TransactionMeasures.close);
      this.mapConsoleService.closeSideBar();
    } else if (this.listEntitiesType === PanelHeaders.entitiesMiniView) {
      this.enititiesService.closeMoreInfo();
      this.togglePosition(TransactionMeasures.miniView);
    } else if (this.listEntitiesType === PanelHeaders.events) {
      this.eventService.closeMoreInfo();
      this.togglePosition(TransactionMeasures.fullView);
    } else if (this.listEntitiesType === PanelHeaders.resources) {
      this.easResourcesService.closeSearchResource();
      this.togglePosition(TransactionMeasures.fullView);
      this.easResourcesService.closeMoreInfo();
      this.easOtherEntitiesData = '';
    } else if (this.listEntitiesType === PanelHeaders.annotations) {
      this.annotationService.closeMoreInfo();
      this.togglePosition(TransactionMeasures.fullView);
      this.easOtherEntitiesData = '';
    } else if (this.listEntitiesType === PanelHeaders.locations) {
      this.togglePosition(TransactionMeasures.fullView);
      this.easPredefinedLocationsService.closeMoreInformations();
    }
    this.mapConsoleService.clearMoreInfoDatas();
  }
  onClose() {
    this.togglePosition(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }
  changePanel(id) {
    this.togglePosition(TransactionMeasures.fullView);
    this.listEntitiesType = id;
  }
  initiateEpttGeocall() {
    this.onClose();
    this.mapConsoleService.initiateGeocall();
  }
}
