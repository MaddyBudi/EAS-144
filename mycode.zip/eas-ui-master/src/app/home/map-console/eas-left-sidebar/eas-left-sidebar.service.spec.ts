import { TestBed } from '@angular/core/testing';

import { EasLeftSidebarService } from './eas-left-sidebar.service';

describe('EasLeftSidebarService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  // it('should be created', () => {
  //   const service: EasLeftSidebarService = TestBed.get(EasLeftSidebarService);
  //   expect(service).toBeTruthy();
  // });
});
