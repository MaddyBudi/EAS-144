import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EasLeftSidebarService {
  easleftSidebarToggle = new Subject<string>();
  easleftSidebarToggle$ = this.easleftSidebarToggle.asObservable();

  changeEntitiesListType = new Subject<string>();
  changeEntitiesListType$ = this.changeEntitiesListType.asObservable();

  moreInfoDataId = new Subject<string>();
  moreInfoDataId$ = this.moreInfoDataId.asObservable();

  clsoeMoreInfPanel = new Subject<string>();
  clsoeMoreInfPanel$ = this.clsoeMoreInfPanel.asObservable();

  constructor() { }
  toggleSidebarToggle(id: string) {
      this.easleftSidebarToggle.next(id);
  }
  changeEntitiesListTypes(entitiesListType) {
    this.changeEntitiesListType.next(entitiesListType);
  }

  moreInfoData(entityId: string) {
    this.moreInfoDataId.next(entityId);
  }

  cLoseMoreInfo() {
    this.clsoeMoreInfPanel.next();
  }
}
