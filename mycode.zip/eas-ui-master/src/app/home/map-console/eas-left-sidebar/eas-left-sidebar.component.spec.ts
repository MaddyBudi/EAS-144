import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EasLeftSidebarComponent } from './eas-left-sidebar.component';

describe('EasLeftSidebarComponent', () => {
  let component: EasLeftSidebarComponent;
  let fixture: ComponentFixture<EasLeftSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EasLeftSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EasLeftSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
