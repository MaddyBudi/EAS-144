import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FindRouteService {

  findRouteResponse = new Subject<any>();
  findRouteResponse$ = this.findRouteResponse.asObservable();
  
  resourceRouteData = new Subject<any>();
  resourceRouteData$ = this.resourceRouteData.asObservable();

  mapRouteData = new Subject<any>();
  mapRouteData$ = this.mapRouteData.asObservable();

  constructor() { }

  setFindRouteResponse(data) {
    this.findRouteResponse.next(data);
  }

  setResourceRouteData(data){
    this.resourceRouteData.next(data);
  }

  setMapRouteData(data){
    this.mapRouteData.next(data);
  }

}
