import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChange } from '@angular/core';
import { EasRightSidebarService } from '../eas-right-sidebar/eas-right-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import * as $ from 'jquery';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { SharedService } from '../../../shared/shared.service';
import { MapConsoleService } from '../map-console.service';
import { FindRouteService } from './find-route.service';

declare let google: any;
let controller;

@Component({
  selector: 'app-find-route',
  templateUrl: './find-route.component.html',
  styleUrls: ['./find-route.component.scss']
})

export class FindRouteComponent implements OnInit {
  panelHeader: string;

  @Input() resourceEventAddress: any[];

  travelModes: any[];
  showFindRouteForm = false;
  geoCoder: any;
  origin: any;
  destination: any;
  waypoints: any = [];
  originAddress: any;
  travelMode: any;
  destinationAddress: any;
  displayFailure = false;
  failureMessage: string;
  events = [];
  displayEventList = false;
  _markerFindRouteData = new FormGroup({ showFindRouteForm: new FormControl() });
  findRouteForm = new FormGroup({
    srcLocation: new FormControl(),
    destLocation: new FormControl(),
    travelMode: new FormControl()
  });
  viewDetails = 'View Details';
  distance;
  time;
  summary;
  selectedEventGeometry;
  resourceRouteData;

  constructor(private easRightSideBarService: EasRightSidebarService, public fb: FormBuilder, public easEventsService: EasEventsService, public sharedService: SharedService,
    private mapConsoleService: MapConsoleService, private findRouteService: FindRouteService) {
    this.travelModes = ["DRIVING", "BICYCLING", "TRANSIT", "WALKING"];
    this.geoCoder = new google.maps.Geocoder();

  }

  ngOnInit() {

    this.panelHeader = PanelHeaders.findRoute;
    controller = this;
    this.resetFindRouteForm();

    this.findRouteService.findRouteResponse$.subscribe(
      data => {
        if (data.routes[0]) {
          this.summary = data.routes[0].summary;
          this.computeTotalDistance(data);
          this.computeTotalTime(data);
          this.displayFailure = false;
        } else {
          this.clearRoute();
          this.failureMessage = "Sorry, we could not calculate the " + this.travelMode.toLowerCase()
            + " directions from " + this.originAddress + " to " + this.destinationAddress
            + ". \nPlease try another travel mode.";
          this.displayFailure = true;
        }
      }
    );

    this.findRouteService.resourceRouteData$.subscribe(
      data => {
        this.resourceRouteData = data;
        this.getAllEvents();
        this.findRouteForm.get('srcLocation').setValue(data.origin);
        this.origin = data.origin;
        if (data.destination) {
          this.findRouteForm.get('destLocation').setValue(data.destination);
          this.destination = data.destination;
          this.findRouteSubmit(null);
        }
        if (data.assignedEventId) {
          this.findRouteForm.controls['destinationEvent'].setValue(data.assignedEventId);
        }
      }
    );

    this.findRouteService.mapRouteData$.subscribe(
      data => {
        if (!this.origin) {
          let address = this.sharedService.getFormattedAddressFromCenter(data.lat(), data.lng());
          address.then((res) => {
            this.findRouteForm.get('srcLocation').setValue(res);
          });
          this.origin = data;
        } else if (!this.destination) {
          let address = this.sharedService.getFormattedAddressFromCenter(data.lat(), data.lng());
          address.then((res) => {
            this.findRouteForm.get('destLocation').setValue(res);
          });
          this.destination = data;
        } else if (this.origin && this.destination) {
          this.waypoints.push(
            {
              location: this.destination,
              stopover: true
            }
          );
          let address = this.sharedService.getFormattedAddressFromCenter(data.lat(), data.lng());
          address.then((res) => {
            this.findRouteForm.get('destLocation').setValue(res);
          });
          this.destination = data;
        }
      }
    );
  }

  onClose() {
    this.clearRoute();
    this.easRightSideBarService.toggleSidebarToggle(TransactionMeasures.close);
  }

  resetFindRouteForm() {
    this.clearRoute();
    this.displayFailure = false;
    this.resourceEventAddress = [];
    this.origin = undefined;
    this.destination = undefined;
    this.originAddress = '';
    this.destinationAddress = '';
    this.distance = '';
    this.time = '';
    this.summary = '';
    this.waypoints = [];
    this.mapConsoleService.setDeleteAllShape('');
    this.setFindRouteForm();
    if (this.resourceRouteData) {
      this.setFindRouteFormData(this.resourceRouteData);
    }
  }

  clearRoute() {
    this.mapConsoleService.findRouteOrigin = null;
    this.mapConsoleService.findRouteDestination = null;
    this.mapConsoleService.findRouteTravelMode = null;
    this.mapConsoleService.findRouteWaypoints = null;
  }

  setFindRouteForm() {
    this.showFindRouteForm = true;
    this.findRouteForm = this.fb.group({
      'srcLocation': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(100)])],
      'destLocation': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(100)])],
      'travelMode': [this.travelModes[0], Validators.required],
      'destinationEvent': ['']
    });
    if (!this.travelMode) {
      this.travelMode = 'DRIVING';
    }

    if (this.resourceEventAddress && this.resourceEventAddress.length === 2) {

      this.getAddressForLatLng(this.resourceEventAddress[0][1], this.resourceEventAddress[0][0], true);
      this.origin = new google.maps.LatLng(this.resourceEventAddress[0][1], this.resourceEventAddress[0][0]);
      this.getAddressForLatLng(this.resourceEventAddress[1][1], this.resourceEventAddress[1][0], false);
      this.destination = new google.maps.LatLng(this.resourceEventAddress[1][1], this.resourceEventAddress[1][0]);
      this.findRouteSubmit(null);
    } else if (this.resourceEventAddress && this.resourceEventAddress.length === 1) {

      this.getAddressForLatLng(this.resourceEventAddress[0][1], this.resourceEventAddress[0][0], true);
      this.origin = new google.maps.LatLng(this.resourceEventAddress[0][1], this.resourceEventAddress[0][0]);

      // this.getAllEvents();

    }
  }

  setFindRouteFormData(data) {
    this.findRouteForm.get('srcLocation').setValue(data.origin);
    this.origin = data.origin;
    if (data.destination) {
      this.findRouteForm.get('destLocation').setValue(data.destination);
      this.destination = data.destination;
    }
    if (data.assignedEventId) {
      this.findRouteForm.controls['destinationEvent'].setValue(data.assignedEventId);
    }
  }

  toggleAddressAndLatLng(fieldName: string) {
    controller = this;
    this.displayFailure = false;
    const pattern = /^(-|\+)?([1-9][0-9]{0,1})\.{1}\d{1,9}\,(-|\+)?([1-9][0-9]{0,1})\.{1}\d{1,9}/;
    let inputStr = ($('#' + fieldName)).val();
    inputStr = inputStr.replace(/\s/g, "");

    if (pattern.test(inputStr)) {
      this.getAddressFromLatLng(inputStr,fieldName);

    } else {
      const autocomplete = new google.maps.places.Autocomplete($('#' + fieldName)[0]);
      autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();
        const loc = [];
        this.geoCoder.geocode({ 'address': place.formatted_address }, (results, status) => {
          if (status === google.maps.GeocoderStatus.OK) {
            loc[0] = results[0].geometry.location.lat();
            loc[1] = results[0].geometry.location.lng();
            if (fieldName === "srcLocation") {
              this.originAddress = place.formatted_address;
              this.origin = new google.maps.LatLng(loc[0], loc[1]);

            } else {
              this.destinationAddress = place.formatted_address;
              this.destination = new google.maps.LatLng(loc[0], loc[1]);
            }

          } else {
            console.log('Address to LatLng conversion failed due to: ' + status);
          }
        });
      });
    }
    if (this.origin === undefined && fieldName === "srcLocation") {
      this.origin = ($('#' + fieldName)).val();
    }
    if (this.destination === undefined && fieldName === "destLocation") {
      this.destination = ($('#' + fieldName)).val();
    }

    if (fieldName === "destLocation" && ($('#' + fieldName)).val() === '') {
      this.findRouteForm.controls['destinationEvent'].setValue('');
    }
  }

  getAddressFromLatLng(latlng , fieldName){
     let locationCoords;
      const locationArray = JSON.parse("[" + latlng + "]");
      console.log(locationArray)
      locationCoords = new google.maps.LatLng(locationArray[0], locationArray[1]);
      console.log(locationCoords)
      this.geoCoder.geocode({ 'latLng': locationCoords }, (results, status) => {
        if (status === google.maps.GeocoderStatus.OK) {
          const place = results[0];
          if (fieldName === "srcLocation") {
            this.originAddress = place.formatted_address;
            this.origin = locationCoords;
            console.log(this.originAddress)
          } else {
            this.destinationAddress = place.formatted_address;
            this.destination = locationCoords;
            console.log(this.destinationAddress)
          }
          console.log('find rout form');
          console.log(this.findRouteForm);
          console.log(this.findRouteForm.valid)
        } else {
           console.log('Address to LatLng conversion failed due to: ' + status);
        }
      });

  }

  findRouteSubmit(event) {

    for (const c in this.findRouteForm.controls) {
      if (this.findRouteForm.controls.hasOwnProperty(c)) {
        this.findRouteForm.controls[c].markAsTouched();
      }
    }

    this.mapConsoleService.setDeleteAllShape('');
    this.mapConsoleService.findRouteOrigin = this.origin;
    this.mapConsoleService.findRouteDestination = this.destination;
    this.mapConsoleService.findRouteTravelMode = this.travelMode;
    this.mapConsoleService.findRouteWaypoints = this.waypoints;

  }

  getAddressForLatLng(lat: any, lng: any, isSrc: boolean) {
    this.displayFailure = false;
    const latlng = new google.maps.LatLng(lat, lng);
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ 'latLng': latlng }, (results, status) => {
      if (status === google.maps.GeocoderStatus.OK) {
        const place = results[0];
        if (isSrc === true) {
          this.originAddress = place.formatted_address;
          this.findRouteForm.get('srcLocation').setValue(this.originAddress);
        } else if (isSrc === false) {
          this.destinationAddress = place.formatted_address;
          this.findRouteForm.get('destLocation').setValue(this.destinationAddress);
        }
      }
    });
  }

  setTravelMode(travelModeInput: String) {
    this.travelMode = travelModeInput;
    $('a').toggleClass("travel-mode-selected", false);
    $('#' + travelModeInput).toggleClass("travel-mode-selected", true);
    this.findRouteSubmit(null);
  }

  computeTotalDistance(result) {
    let total = 0;
    const myroute = result.routes[0];
    for (let i = 0; i < myroute.legs.length; i++) {
      total += myroute.legs[i].distance.value;
    }
    total = Math.round(total / 1609.34);
    this.distance = total + ' miles';
  }

  computeTotalTime(result) {
    const route = result.routes[0];
    let secondsValue = 0;
    let seconds = 0;
    let totalTime = "";
    for (let i = 0; i < route.legs.length; i++) {
      secondsValue += route.legs[i].duration.value;
    }
    const secondsStr = secondsValue + '';
    seconds = parseInt(secondsStr, 10);
    const days = Math.floor(seconds / (3600 * 24));
    seconds -= days * 3600 * 24;
    const hrs = Math.floor(seconds / 3600);
    seconds -= hrs * 3600;
    const mnts = Math.floor(seconds / 60);
    seconds -= mnts * 60;

    totalTime = mnts + " mins ";
    if (!(days === 0 && hrs === 0)) {
      totalTime = hrs + " hours " + totalTime;
    }
    if (days > 0) {
      totalTime = days + " days " + totalTime;
    }
    this.time = totalTime;
  }

  showRouteDetails() {
    if (this.viewDetails === 'View Details') {
      this.viewDetails = 'Hide Details';
    } else if (this.viewDetails === 'Hide Details') {
      this.viewDetails = 'View Details';
    }
  }

  getAllEvents() {
    this.easEventsService.getAllEvents().subscribe(data => {
      data.forEach(element => {
        if (element.status !== 'TERMINATED' && !element.deleted) {
          this.events.push(element);
        }
      });
      this.displayEventList = true;
    }, error => {
      console.log(error);
    });
  }
  eventSelection(eventId) {
    if (eventId) {
      let center = [];
      let latitude;
      let longitude;
      this.getEventGeometry(eventId);
      if (this.selectedEventGeometry.type === 'Polygon') {
        center = this.sharedService.getPolygonCenter(this.selectedEventGeometry.coordinates[0]);
        latitude = center[1];
        longitude = center[0];
      } else if (this.selectedEventGeometry.type === 'Point') {
        latitude = this.selectedEventGeometry.coordinates[1];
        longitude = this.selectedEventGeometry.coordinates[0];
      } else if (this.selectedEventGeometry.type === 'LineString') {
        latitude = (this.selectedEventGeometry.coordinates[0][1] + this.selectedEventGeometry.coordinates[1][1]) / 2;
        longitude = (this.selectedEventGeometry.coordinates[0][0] + this.selectedEventGeometry.coordinates[1][0]) / 2;
      }
      this.getAddressForLatLng(latitude, longitude, false);
      this.destination = new google.maps.LatLng(latitude, longitude);
      this.findRouteSubmit(null);
    } else {
      this.findRouteForm.get('destLocation').setValue('');
      this.destination = '';
      this.clearRoute();
    }
  }
  getEventGeometry(eventId) {
    if (this.events.length > 0) {
      this.events.forEach(eachEvent => {
        if (eachEvent.entityId === eventId) {
          this.selectedEventGeometry = eachEvent.geometry;
        }
      });
    }
  }
}


