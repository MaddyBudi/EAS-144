import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FindRouteComponent } from './find-route.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { MapConsoleService } from '../map-console.service';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { MockEasEventsService} from '../../eas-events/eas-mock-events.service';
import { FindRouteService } from './find-route.service';

describe('FindRouteComponent', () => {
  let component: FindRouteComponent;
  let fixture: ComponentFixture<FindRouteComponent>;
  let consoleService: MapConsoleService;
  let eventService: EasEventsService;
  let service: FindRouteService;
 
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindRouteComponent ],
      imports : [
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule
      ] ,
      providers : [
        { provide: EasEventsService, useClass: MockEasEventsService }, MapConsoleService, FindRouteService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindRouteComponent);
    component = fixture.componentInstance;
    consoleService = TestBed.get(MapConsoleService);
    eventService = TestBed.get(EasEventsService);
    service = TestBed.get(FindRouteService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('True if src and dest address are valid', () => {
   component.findRouteForm.controls['srcLocation'].setValue("989 6th Avenue, New York, NY, USA");
   component.findRouteForm.controls['destLocation'].setValue("120 Broadway, New York, NY, USA");
    expect(component.findRouteForm.valid).toBeTruthy();
  
  });
  it('False if srcLocation is invalid', () => {
   component.findRouteForm.controls['srcLocation'].setValue("");
   component.findRouteForm.controls['destLocation'].setValue("120 Broadway, New York, NY, USA");
    expect(component.findRouteForm.valid).toBeFalsy();
  
  });
  it('True if destLocation is invalid', () => {
   component.findRouteForm.controls['srcLocation'].setValue("989 6th Avenue, New York, NY, USA");
   component.findRouteForm.controls['destLocation'].setValue("");
    expect(component.findRouteForm.valid).toBeFalsy();
  
  });

  it('True if src and dest field has latlng are valid', (done) => {
  component.findRouteForm.controls['srcLocation'].setValue("13.0827, 80.2707");
   component.findRouteForm.controls['destLocation'].setValue("28.7041, 77.1025");
   component.getAddressFromLatLng("13.0827, 80.2707", "srcLocation");
   setTimeout(() => {
     component.getAddressFromLatLng("28.7041, 77.1025", "destLocation");
      setTimeout(() => {
        console.log("this.findRouteForm.valid")
        console.log(component.findRouteForm)
        console.log(component.findRouteForm.valid)
       expect(component.findRouteForm.valid).toBeTruthy();
       done();
     }, 2000);
  }, 2000);
  });

    it('False if src has latlng and dest field is empty', (done) => {
  component.findRouteForm.controls['srcLocation'].setValue("13.0827, 80.2707");
   component.getAddressFromLatLng("13.0827, 80.2707", "srcLocation");
      setTimeout(() => {
       expect(component.findRouteForm.valid).toBeFalsy();
       done();
  }, 2000);
  });

    it('False if dest has latlng and src field is empty', (done) => {
   component.findRouteForm.controls['destLocation'].setValue("28.7041, 77.1025");
     component.getAddressFromLatLng("28.7041, 77.1025", "destLocation");
      setTimeout(() => {
       expect(component.findRouteForm.valid).toBeFalsy();
       done();
     }, 2000);
  });

   it('True if the findRouteSubmit() method is called and perform its action', () => {
    component.origin = '989 6th Avenue, New York, NY, USA';
    component.destination = '120 Broadway, New York, NY, USA';
    component.travelMode = 'BICYCLING';
    
    component.findRouteSubmit(null);
    expect(consoleService.findRouteOrigin).toEqual("989 6th Avenue, New York, NY, USA");
    expect(consoleService.findRouteDestination).toEqual("120 Broadway, New York, NY, USA");
    expect(consoleService.findRouteTravelMode).toEqual("BICYCLING");
  });

  it('True if source and destination address is fetched from field personnel resource assigned to event', () => {
    const payload = {
      origin: '2301, Market St, Philadelphia, PA, Philadelphia County, 19103',
      destination: '3386, Longhorn Rd, Boulder, CO, Boulder County, 80302-9361',
      assignedEventId: 'bb0cfc17-8156-45fe-b3bf-565fc40549ed'
    };
    service.setResourceRouteData(payload);
    expect(consoleService.findRouteOrigin).toEqual('2301, Market St, Philadelphia, PA, Philadelphia County, 19103');
    expect(consoleService.findRouteDestination).toEqual('3386, Longhorn Rd, Boulder, CO, Boulder County, 80302-9361');
  });

  // it('True if source address is fetched from field personnel not assigned to event and destination is chosen from findrouteform',(done)=> {
  //   const payload = {
  //     origin: '2301, Market St, Philadelphia, PA, Philadelphia County, 19103',
  //     destination: null,
  //     assignedEventId: null
  //   };
  //   // selected an event as destination
  //   // component.getAllEvents();
  //   // component.eventSelection('acc0a104-eb60-4fad-aa9b-c9a0fdab0eff');
  //   service.setResourceRouteData(payload);
  //   component.setDestinationEventAddress({"type": "Point","coordinates":[-87.629798,41.878114]});
  //   setTimeout(function() {
  //     // component.getAddressForLatLng('-87.629798', '41.878114', false);
  //     // component.findRouteSubmit();
  //     console.log(component.findRouteForm)
  //     expect(component.findRouteForm.valid).toBeTruthy();
  //     done();
  //   }, 2000);
  // });

  it('False after form reset', () => {
    component.origin = '989 6th Avenue, New York, NY, USA';
    component.destination = '120 Broadway, New York, NY, USA';
    component.travelMode = 'BICYCLING';
    component.resetFindRouteForm();
    expect(component.findRouteForm.valid).toBeFalsy();
  });
});
