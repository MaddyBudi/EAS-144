import { TestBed } from '@angular/core/testing';

import { FindRouteService } from './find-route.service';

describe('FindRouteService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FindRouteService = TestBed.get(FindRouteService);
    expect(service).toBeTruthy();
  });
});
