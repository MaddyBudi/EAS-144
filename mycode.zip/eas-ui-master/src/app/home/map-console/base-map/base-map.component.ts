import { Component, OnInit } from '@angular/core';
import { EasRightSidebarService } from '../eas-right-sidebar/eas-right-sidebar.service';
import { PanelHeaders } from '../../../panelHeaders';
import { TransactionMeasures } from '../../../transactionMeasures';
import { MapConsoleService } from '../map-console.service';

@Component({
  selector: 'app-base-map',
  templateUrl: './base-map.component.html',
  styleUrls: ['./base-map.component.scss']
})
export class BaseMapComponent implements OnInit {
  panelHeader: string;
  baseMapType: any;
  mapViewType: any;
  terrain = false;
  hybrid = false;

  constructor(private easRightSideBarService: EasRightSidebarService, private mapConsoleService: MapConsoleService) { }

  ngOnInit() {
    this.panelHeader = PanelHeaders.baseMap;
    this.mapViewType = this.mapConsoleService.mapTypeId;
    this.baseMapType = this.mapConsoleService.mapLayers;

    if (this.mapViewType === 'terrain') {
      this.terrain = true;
    } else if (this.mapViewType === 'hybrid') {
      this.hybrid = true;
    }
  }

  onClose() {
    this.easRightSideBarService.toggleSidebarToggle(TransactionMeasures.close);
  }

  setBaseMapType(layerType) {
    if (layerType === 'bicycling') {
      this.baseMapType.bicycleLayer = this.baseMapType.bicycleLayer ? false : true;
    } else if (layerType === 'traffic') {
      this.baseMapType.trafficLayer = this.baseMapType.trafficLayer ? false : true;
    } else if (layerType === 'transit') {
      this.baseMapType.transitLayer = this.baseMapType.transitLayer ? false : true;
    }

    this.mapConsoleService.setBaseMapType(this.baseMapType);
  }

  setMapViewType(viewType) {
    if (viewType === 'roadmap' && this.terrain) {
      this.mapViewType = 'terrain';
    } else if (viewType === 'satellite' && this.hybrid) {
      this.mapViewType = 'hybrid';
    } else {
      this.mapViewType = viewType;
    }

    this.mapConsoleService.mapTypeId = this.mapViewType;
  }

  setTerrain() {
    if (this.terrain) {
      this.mapViewType = 'terrain';
    } else {
      this.mapViewType = 'roadmap';
    }

    this.mapConsoleService.mapTypeId = this.mapViewType;
  }

  setHybrid() {
    if (this.hybrid) {
      this.mapViewType = 'hybrid';
    } else {
      this.mapViewType = 'satellite';
    }

    this.mapConsoleService.mapTypeId = this.mapViewType;
  }

}
