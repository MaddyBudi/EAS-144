import { Component, OnInit, Input, SimpleChange } from '@angular/core';
import { EasRightSidebarService } from '../eas-right-sidebar/eas-right-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import * as $ from 'jquery';
import { SharedService } from '../../../shared/shared.service';
import { UserService } from '../../../login/services/user.service';
import { SocialMediaService } from './social-media.service';
import { MapConsoleService } from '../map-console.service';
import { EasEventsService } from '../../eas-events/eas-events.service';

@Component({
  selector: 'app-social-media',
  templateUrl: './social-media.component.html',
  styleUrls: ['./social-media.component.scss']
})

export class SocialMediaComponent implements OnInit {
  @Input() contextEventId: any;

  panelHeader: string;
  socialMediaKeywords: any;
  twitterFeedResults = [];
  facebookFeedResults = [];
  toggleTwitter = true;
  toggleFacebook = true;
  socialMediaKeyword = "";
  point: any;
  eventId = "";
  submitted = false;
  smKeys = [];
  showTwitter: boolean;
  showFacebook: boolean;
  twitterTab: boolean;
  facebookTab: boolean;
  defaultRowsPerPage: Number = 5;
  rowsPerPageList: Number[] = [5, 10, 15];
  loading = false;
  constructor(private easRightSideBarService: EasRightSidebarService, public sharedService: SharedService,
    private userService: UserService, public mapConsoleService: MapConsoleService, private eventService: EasEventsService) { }
  ngOnInit() {
    this.panelHeader = PanelHeaders.socialMedia;
    this.showTwitter = this.userService.twitter;
    this.showFacebook = this.userService.facebook;
    this.initMethod(this.contextEventId);
  }
  onClose() {
    this.easRightSideBarService.toggleSidebarToggle(TransactionMeasures.close);
  }
  ngOnChanges(changes) {
    if (changes.hasOwnProperty("contextEventId")) {
      this.initMethod(this.contextEventId);
    }
  }
  initMethod(eventEntityId) {
    if (!eventEntityId) {
      this.eventId = '';
      this.smKeys = [];
      this.socialMediaKeyword = '';
    } else {
      this.eventId = eventEntityId;
      this.eventService.getEventDetails(this.eventId).subscribe(
        data => {
          this.socialMediaKeywords = data.properties['socialMediaKeywords'];
          this.smKeys = [];
          if (this.socialMediaKeywords) {
            for (const key of Object.keys(this.socialMediaKeywords)) {
              this.smKeys.push(this.socialMediaKeywords[key]);
            }
          }
          this.socialMediaKeyword = this.smKeys[0];
          this.showDataList();
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          }
        }
      );
    }
  }
  showDataList() {
    function putValueBackFromPlaceholder() {
      var $this = $('#socialMediaSearch');
      if ($this.val() === '') {
        $this.val($this.attr('placeholder'));
        $this.attr('placeholder', '');
      }
    }
    $('#socialMediaSearch')
      .on('click', function (e) {
        var $this = $(this);
        var inpLeft = $this.offset().left;
        var inpWidth = $this.width();
        var clickedLeft = e.clientX;
        var clickedInInpLeft = clickedLeft - inpLeft;
        var arrowBtnWidth = 12;
        if ((inpWidth - clickedInInpLeft) < arrowBtnWidth) {
          $this.attr('placeholder', $this.val());
          $this.val('');
        }
        else {
          putValueBackFromPlaceholder();
        }
      })
      .on('mouseleave', putValueBackFromPlaceholder);
  }
  searchFeeds() {
    const geoPoint = this.mapConsoleService.getMapCenter();
    this.point = { "x": geoPoint.lng(), "y": geoPoint.lat() };
    this.submitted = true;
    this.twitterTab = false;
    this.facebookTab = false;
    if (this.socialMediaKeyword.trim() !== '') {
      this.loading = true;
      if (this.toggleTwitter) {
        this.eventService.getTwitterFeeds(this.socialMediaKeyword, this.point, this.eventId).subscribe(
          data => {
            if (data.socialMediaPosts) {
              for (const post of data.socialMediaPosts) {
                if (post.text) {
                  post.text = this.convertText(post.text);
                }
              }
            }
            this.twitterFeedResults = data.socialMediaPosts;
            this.twitterTab = this.toggleTwitter;
            this.facebookTab = this.toggleFacebook;
            this.loading = false;
            this.easRightSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
          },
          error => {
            if (error.status === 401) {
              this.sharedService.routeToLoginError(error.status);
            } else {
              // this.displayFailure = true;
              // this.failureMessage = "Unable to get events. Please try again later.";
            }
            this.twitterTab = this.toggleTwitter;
            this.facebookTab = this.toggleFacebook;
            this.loading = false;
          }
        );
      }
      if (this.toggleFacebook) {
        this.eventService.getFacebookFeeds(this.socialMediaKeyword, this.point, this.eventId).subscribe(
          data => {
            this.facebookFeedResults = data.socialMediaPosts;
            this.twitterTab = this.toggleTwitter;
            this.facebookTab = this.toggleFacebook;
            this.loading = false;
            this.easRightSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
          },
          error => {
            if (error.status === 401) {
              this.sharedService.routeToLoginError(error.status);
            } else {
              // this.displayFailure = true;
              // this.failureMessage = "Unable to get events. Please try again later.";
            }
            this.twitterTab = this.toggleTwitter;
            this.facebookTab = this.toggleFacebook;
            this.loading = false;
          }
        );
      }
    }
  }
  convertText(text: string): string {
    const exp = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
    const text1 = text.replace(exp, "<a target='_blank' href='$1'>$1</a>");
    const exp2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
    text = text1.replace(exp2, '$1<a target="_blank" href="http://$2">$2</a>');
    return text;
  }
  onKey(event) {
    if ((event.key == 'Enter' && this.socialMediaKeyword.length <= 500) && (this.toggleTwitter || this.toggleFacebook)) {
      this.searchFeeds();
    }
  }
}
