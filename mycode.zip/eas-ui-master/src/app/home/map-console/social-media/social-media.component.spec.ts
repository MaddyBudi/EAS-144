import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SocialMediaComponent } from './social-media.component';
import { UserService } from '../../../login/services/user.service';
import { MapsAPILoader } from '@agm/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { DataTableModule } from 'angular-6-datatable';
import { SharedModule } from '../../../shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { GeoAddressComponent } from '../../geo-address/geo-address.component';
import { NotifierModule } from 'angular-notifier';
import { SocialMediaService } from './social-media.service';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { MockEasEventsService } from '../../eas-events/eas-mock-events.service';
import { exec } from 'child_process';

describe('SocialMediaComponent', () => {
  let component: SocialMediaComponent;
  let fixture: ComponentFixture<SocialMediaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SocialMediaComponent, GeoAddressComponent],
      imports: [BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        DataTableModule,
        SharedModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule],
      providers: [{ provide: MapsAPILoader }, UserService, { provide: EasEventsService, useClass: MockEasEventsService }],//inject geoaddress service into create-eas-predefined-location spec.ts file

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SocialMediaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should default enable twitter and facebook', () => {
    expect(component.toggleTwitter).toBeTruthy();
    expect(component.toggleFacebook).toBeTruthy();
  });
  it('should disable twitter and facebook', () => {
    component.toggleTwitter = false;
    component.toggleFacebook = false;
    expect(component.toggleTwitter).toBeFalsy();
    expect(component.toggleFacebook).toBeFalsy();
  });
  it('should input to be defined', () => {
    component.socialMediaKeyword = "Fire";
    expect(component.socialMediaKeyword).toBeDefined();
  });
  it('should input to be undefined', () => {
    component.socialMediaKeyword = undefined;
    expect(component.socialMediaKeyword).toBeUndefined();
  });
  it('should input to be "" for no event context', () => {
    component.contextEventId = ""
    expect(component.socialMediaKeyword === "").toBeTruthy();
  });


  it('should  no event context and search for facebook Feed feeds', () => {
    const mapCenter = {
      lat() {
        return 38.91006749719391;
      },
      lng() {
        return -77.03724499999998;
      },
    }
    component.socialMediaKeyword = "fire"
    component.mapConsoleService.mapCenter = mapCenter;
    component.searchFeeds();
    setTimeout(() => {
      expect(component.facebookFeedResults.length > 0).toBeTruthy();
    }, 1000)


  });

  it('should  no event context and search for twitter Feed feeds', () => {
    const mapCenter = {
      lat() {
        return 38.91006749719391;
      },
      lng() {
        return -77.03724499999998;
      },
    }
    component.socialMediaKeyword = "fire"
    component.mapConsoleService.mapCenter = mapCenter;
    component.searchFeeds();
    setTimeout(() => {
      expect(component.twitterFeedResults.length > 0).toBeTruthy();
    }, 1000)


  });

  // it('should  event context load social media keywords', (done) => {
  //   component.contextEventId = "944d3dff-870e-4329-9d7d-c22f6a3ffa8e"; 
  //   component.initMethod(component.contextEventId);
  //    setTimeout(() => {
  //     console.log(component.socialMediaKeyword)
  //     expect(component.socialMediaKeyword.toString() === "fire").toBeFalsy();
  //     done();
  //   }, 2000)
  // });

  // it('should  event context and search for facebook Feed feeds', () => {
  //   component.contextEventId = "944d3dff-870e-4329-9d7d-c22f6a3ffa8e"; 
  //   component.initMethod(component.contextEventId);
  //   const mapCenter = {
  //     lat() {
  //       return 38.91006749719391;
  //     },
  //     lng() {
  //       return -77.03724499999998;
  //     },
  //   }
  //   component.mapConsoleService.mapCenter = mapCenter;
  //   setTimeout(() => {
  //   component.searchFeeds();},2000);
  //   setTimeout(() => {
  //     console.log(component.socialMediaKeyword)
  //     expect(component.facebookFeedResults.length > 0).toBeTruthy();
  //   }, 1000)


  // });

  // it('should  event context and search for twitter Feed feeds', () => {
  //   component.contextEventId = "944d3dff-870e-4329-9d7d-c22f6a3ffa8e"; 
  //   component.initMethod(component.contextEventId);
  //   const mapCenter = {
  //     lat() {
  //       return 38.91006749719391;
  //     },
  //     lng() {
  //       return -77.03724499999998;
  //     },
  //   }
  //   component.mapConsoleService.mapCenter = mapCenter;
  //   setTimeout(() => {
  //     component.searchFeeds();},2000);
  //   setTimeout(() => {
  //     console.log(component.socialMediaKeyword)
  //     expect(component.twitterFeedResults.length > 0).toBeTruthy();
  //   }, 1000)


  // });
});
