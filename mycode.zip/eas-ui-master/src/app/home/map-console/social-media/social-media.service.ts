import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { EasEventsService } from '../../eas-events/eas-events.service';

@Injectable({
  providedIn: 'root'
})

export class SocialMediaService {

  constructor(private eventService: EasEventsService) { }


  public getTwitterFeeds(socialMediaKeyword, point, eventId) {

    return this.eventService.getTwitterFeeds(socialMediaKeyword, point, eventId);

  }

  public getFacebookFeeds(socialMediaKeyword, point, eventId) {

    return this.eventService.getFacebookFeeds(socialMediaKeyword, point, eventId);

  }

}
