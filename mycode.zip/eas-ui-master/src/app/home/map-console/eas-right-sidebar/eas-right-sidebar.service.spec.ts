import { TestBed } from '@angular/core/testing';

import { EasRightSidebarService } from './eas-right-sidebar.service';

describe('EasRightSidebarService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  // it('should be created', () => {
  //   const service: EasRightSidebarService = TestBed.get(EasRightSidebarService);
  //   expect(service).toBeTruthy();
  // });
});
