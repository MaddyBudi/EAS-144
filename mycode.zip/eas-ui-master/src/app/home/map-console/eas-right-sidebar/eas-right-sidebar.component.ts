import { Component, OnInit, Input } from '@angular/core';
import * as $ from 'jquery';
import { EasRightSidebarService } from './eas-right-sidebar.service';
import { MapConsoleService } from '../map-console.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';

@Component({
  selector: 'app-eas-right-sidebar',
  templateUrl: './eas-right-sidebar.component.html',
  styleUrls: ['./eas-right-sidebar.component.scss']
})
export class EasRightSidebarComponent implements OnInit {
  @Input() contextEventId;
  @Input() entitiesType;
  panelHeaders: any;
  constructor(private easRightSideBar: EasRightSidebarService, private mapConsoleService: MapConsoleService) {

    this.easRightSideBar.easRightSideBarToggle$.subscribe(
      data => {
        this.togglePosition(data);
      }

    );

  }

  ngOnInit() {
    this.panelHeaders = PanelHeaders;
  }

  ngOnChanges(changes) {
    if (this.entitiesType === PanelHeaders.workspaces || this.entitiesType === PanelHeaders.powerDataSearch) {
      this.togglePosition(TransactionMeasures.fullView);
    } else {
      this.togglePosition(TransactionMeasures.miniView);
    }

    if (changes.hasOwnProperty("contextEventId"))
      this.contextEventId = changes.contextEventId.currentValue;
  }

  togglePosition(length: string) {
    if (length !== TransactionMeasures.close) {
      document.getElementById("easRightSideBar").style.width = length;
    } else {
      document.getElementById("easRightSideBar").style.width = "auto";
      document.getElementById("easRightSideComponent").style.width = length;
      this.mapConsoleService.closeSideBar();
    }
  }
}
