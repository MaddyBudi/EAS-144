import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class EasRightSidebarService {

  easRightSideBarToggle = new Subject<any>();
  easRightSideBarToggle$ = this.easRightSideBarToggle.asObservable();
  constructor() { 
  }
  toggleSidebarToggle(id:string){
      this.easRightSideBarToggle.next(id);
  }
}
