import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EasRightSidebarComponent } from './eas-right-sidebar.component';

describe('EasRightSidebarComponent', () => {
  let component: EasRightSidebarComponent;
  let fixture: ComponentFixture<EasRightSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EasRightSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EasRightSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
