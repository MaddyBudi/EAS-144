import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { AppGlobals } from '../../shared/app.globals';
import { ConfigService } from '../../core/config/config-svc.service';
import { map } from 'rxjs/operators';
import { SharedService } from '../../shared/shared.service';
import { EasEventsService } from '../eas-events/eas-events.service';
import { NotifierService } from 'angular-notifier';
import { EasResourcesService } from '../eas-resources/eas-resources.service';
import { EasPredefinedLocationsService } from '../eas-predefined-locations/eas-predefined-locations.service';
import { EasEventMoreInformationService } from '../eas-event-more-information/eas-event-more-information.service';
import { Entities } from '../../entities';
import { DataModel } from '../../dataModelEnum';
import { EventTo } from '../../shared/models/eventTo';
declare let google: any;
const clearContext = 'ClearContext';
const swal = require('sweetalert');
let that;
@Injectable({
  providedIn: 'root'
})
export class MapConsoleService {
  mapConsoleComponentSource = new Subject<string>();
  mapConsoleComponent$ = this.mapConsoleComponentSource.asObservable();
  closeSideBarPanel = new Subject<any>();
  closeSideBarPanel$ = this.closeSideBarPanel.asObservable();
  openEventInfo = new Subject<any>();
  openEventInfo$ = this.openEventInfo.asObservable();
  viewMapEntities = new Subject<any>();
  viewMapEntities$ = this.viewMapEntities.asObservable();
  clearMoreInfoData = new Subject<any>();
  clearMoreInfoData$ = this.clearMoreInfoData.asObservable();
  viewMapLocations = new Subject<any>();
  viewMapLocations$ = this.viewMapLocations.asObservable();
  mapCenter: any;
  isClickedPowerdataSearch: boolean;
  findRouteOrigin: any;
  findRouteDestination: any;
  findRouteTravelMode: any;
  findRouteWaypoints: any = [];
  mapTypeId: any = 'roadmap';
  mapLayers: any = {
    bicycleLayer: false,
    trafficLayer: false,
    transitLayer: false
  };
  baseMapType = new Subject<any>();
  baseMapType$ = this.baseMapType.asObservable();
  workspaceData = new Subject<any>();
  workspaceData$ = this.workspaceData.asObservable();
  filterEpttUsers = new Subject<string>();
  filterEpttUsers$ = this.filterEpttUsers.asObservable();
  currentWorkspace = new Subject<any>();
  currentWorkspace$ = this.currentWorkspace.asObservable();
  rightSidePanel = new Subject<any>();
  rightSidePanel$ = this.rightSidePanel.asObservable();
  eventContext = new Subject<any>();
  eventContext$ = this.eventContext.asObservable();
  workspaceId;
  notifications = new Subject<any>();
  notifications$ = this.notifications.asObservable();
  viewEpttLocation = new Subject<any>();
  viewEpttLocation$ = this.viewEpttLocation.asObservable();
  getModifyLocationResponse = new Subject<any>();
  getModifyLocationResponse$ = this.getModifyLocationResponse.asObservable();
  modifyResourceLocation = new Subject<string>();
  modifyResourceLocation$ = this.modifyResourceLocation.asObservable();
  assignedAddress = new Subject<any>();
  assignedAddress$ = this.assignedAddress.asObservable();
  customPolygonObject;
  currentDataModel;
  currentEntityName;
  cancelModifyLocation = new Subject<string>();
  cancelModifyLocation$ = this.cancelModifyLocation.asObservable();
  private readonly notifier: NotifierService;
  deleteAllShape = new Subject<any>();
  deleteAllShape$ = this.deleteAllShape.asObservable();
  isMoreInfoOpen = new Subject<any>();
  isMoreInfoOpen$ = this.isMoreInfoOpen.asObservable();
  displayOnlyEventAssociatedData = new Subject<string>();
  displayOnlyEventAssociatedData$ = this.displayOnlyEventAssociatedData.asObservable();
  constructor(private http: HttpClient, private appglobals: AppGlobals, private sharedService: SharedService,
     private eventService: EasEventsService, private notifierService: NotifierService, private easResourcesService: EasResourcesService,
    private easEventMoreInformationService: EasEventMoreInformationService, private locationSvc: EasPredefinedLocationsService) {
    that = this;
    that.notifier = notifierService;
  }
  getHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All'
      }),
      withCredentials: true
    };
    return httpOptions;
  }
  closeSideBar() {
    this.closeSideBarPanel.next();
  }
  openEventInformation(entityId: string) {
    this.openEventInfo.next(entityId);
  }
 clearContext() {
    this.mapConsoleComponentSource.next();
  }
  getMapCenter() {
    return this.mapCenter;
  }
  public getSituationalData(dataModel, eventId) {
    console.log(dataModel + '' + eventId);
    return this.http.get(ConfigService.config.situationaldataUrl + this.appglobals.situationalDataURL[dataModel] + eventId,
      this.getHeaders()).pipe(map((res: any) => res));

  }
  deletEvent(payload) {
    this.sharedService.showYesNoAlert('Delete event: ' + payload.properties.eventName, 'Close', swalCallback, 'No, Cancel');
    function swalCallback(yesNo) {
      if (yesNo) {
        that.releaseEventAnnotationsAndResources(payload);
        that.eventService.deleteEvent(payload.entityId).subscribe(
          data => {
            if (data) {
              that.notifierService.notify('success', 'Event "' + payload.properties.eventName + '" deleted successfully.');
              that.setEventContext(null);

              // that.eventService.releaseEventAnnotations(payload.properties.assignedAnnotations, payload.entityId);
            } else {
              this.notifierService.notify('error', 'Unable to delete the event');
            }
          },
          error => {
            if (error.status === 401) {
              that.sharedService.routeToLoginError(error.status);
            } else {
              this.notifierService.notify('error', 'Unable to delete the event');
            }
          }
        );
      }
    }
  }

  releaseEventAnnotationsAndResources(payload) {
  //   let assignedAnnotations;
  //   let assignedResources;
  //   if (payload instanceof EventTo) {
  //  assignedAnnotations = payload.assignedAnnotations;
  //  assignedResources = payload.assignedResources;
  //   } else {
  //  assignedAnnotations = payload.properties.assignedAnnotations;
  //  assignedResources = payload.properties.assignedResources;
  //   }
    if (payload.properties.assignedAnnotations) {
      this.eventService.releaseEventAnnotations(payload.properties.assignedAnnotations, payload.entityId);
    }
    if (payload.properties.assignedResources) {
      this.eventService.getResourceInfoToRelease(payload.properties.assignedResources, payload.entityId);

    }
  }

  setBaseMapType(baseMap) {
    this.mapLayers = baseMap;
    this.baseMapType.next(baseMap);
  }

  viewMapEntitiesMap(object: any) {
    this.viewMapEntities.next(object);
  }
  viewMapLocationMap(object: any) {
    this.viewMapLocations.next(object);
  }
  setWorkspaceData(data) {
    this.workspaceData.next(data);
  }
  initiateGeocall() {
    this.filterEpttUsers.next();
  }
  displayNotifications() {
    this.notifications.next();
  }
  getPolygonBounds(polygon) {
    google.maps.Polygon.prototype.getBoundingBox = function () {
      const bounds = new google.maps.LatLngBounds();
      this.getPath().forEach(function (element, index) {
        bounds.extend(element);
      });
      return (bounds);
    };
    return polygon.getBoundingBox();
  }

  getCurrentWorkspace(data) {
    this.currentWorkspace.next(data);
  }
  clearMoreInfoDatas() {
    this.clearMoreInfoData.next();
  }
  openRightSidePanel(data) {
    this.rightSidePanel.next(data);
  }

  setEventContext(data) {
    this.eventContext.next(data);
  }
  viewEpttLocations(data) {
    this.viewEpttLocation.next(data);
  }

  initiateUpdateEventServiceCall(requestPayload) {
    this.eventService.updateEventLocation(requestPayload).subscribe(response => {
        this.notifier.notify('success', 'Event "' + response.properties.eventName + '" location is modified successfully');
        this.clearCustomPolygonObject();
        this.getModifyLocationResponse.next(DataModel.event);
    }, error => {
     this.notifier.notify('error', 'General error occurred, unable to update event location');

    });
  }
  modifyResourceLoc(data) {
    this.modifyResourceLocation.next(data);
  }
  findPointInfo(center, data) {
    const address = this.sharedService.getAddressFromCenter(center[1], center[0]);
    address.then((res) => {
      if (data.payload && data.payload.dataModel === DataModel.event) {
        this.getEventById(data.payload.entityId, res, center);
      } else if (data.payload && data.payload.dataModel === DataModel.resource) {
        this.getResourceById(data.payload.entityId, res, center);
      } else {
         this.getLocationById(data.id, res, center , null);
      }
    });
  }
  displayConfirmationWindow(shapeType, shapeObject, data, entityName) {
    const that = this;
    this.sharedService.showYesNoAlert('Modify location ' + entityName, 'Update', swalCallback, 'No');
    function swalCallback(yesNo) {
      if (yesNo) {
        if (shapeType === 'Polygon') {
          that.findPolygonInfo(shapeObject);
        } else if (shapeType === 'Point') {
          that.findPointInfo(shapeObject, data);
        }
      }
    }
  }
  findPolygonInfo(polygon) {
    const polygonPath = [];
    polygon.getPath().forEach(eachPath => {
      const geoJsonArrayList = [eachPath.lng(), eachPath.lat()];
      polygonPath.push(geoJsonArrayList);
    }
    );
    const polygonCenter = this.sharedService.getPolygonCenter(polygonPath);
    const address = this.sharedService.getAddressFromCenter(polygonCenter[1], polygonCenter[0]);
    address.then((res) => {
      if (polygon.dataModel === DataModel.event) {
        this.getEventById(polygon.id, res, [polygonPath]);
      } else if (polygon.dataModel === 'Predefined Location') {
        this.getLocationById(polygon.id, res, polygon.getPath(), polygonCenter);
      } else if (polygon.dataModel === DataModel.resource) {
        this.getResourceById(polygon.id, res, [polygonPath]);
      }
    });
  }
  getLocationById(id, address, coordinates , center) {
    this.locationSvc.getPredefinedLocationsById(id).subscribe(response => {
      if (response.geometry['type'] === 'Point') {
        this.updatePointLocation(response , address , coordinates);
      } else {
        this.updatePolygonLocation(response , address , coordinates , center);
      }
    }, error => {
      this.notifierService.notify('error', 'General error occured. Please try again later');
    });
  }
  updatePointLocation(response, address, coordinates) {
      response.geometry.coordinates[0].lat = coordinates[1];
      response.geometry.coordinates[0].lng = coordinates[0];
      response.properties.address = this.sharedService.getFormattedAddress(address);
      response.properties.latlng.latitude = coordinates[1];
      response.properties.latlng.longitude = coordinates[0];
      response.name = response.name + ' updated';
      this.updateLocation(response);
  }
    updatePolygonLocation(response, address, coordinates, center) {
      const polyCoordinates = [];
      coordinates.forEach(element => {
       const geoJsonArrayList = {'lat': element.lat(), 'lng': element.lng()};
       polyCoordinates.push(geoJsonArrayList);
     });
      response.geometry.coordinates = polyCoordinates;
      response.properties.address = this.sharedService.getFormattedAddress(address);
      response.properties.latlng.latitude = center[1];
      response.properties.latlng.longitude = center[0];
      response.name = response.name + ' updated';
      this.updateLocation(response);
    }
    updateLocation(response) {
    this.locationSvc.updateLocation(response).subscribe(res => {
       const data = {
        'dataModel': 'Predefined Location',
        'status': 'success',
        'entityName': res.name,
        'type': res.geometry.type,
        'payload': res
      };
      this.getModifyLocationResponse.next(data);
      }, error => {
       const data = {
        'dataModel': 'Predefined Location',
        'status': 'failure',
      };
      this.getModifyLocationResponse.next(data);
      console.log('Error occured' + error);
      });
    }
  getResourceById(entityId, address, coordinates) {
    this.easResourcesService.getResourceDetailsById(entityId).subscribe(response => {
      this.formPayloadForMapEntity(response, address, coordinates, DataModel.resource);
    }, error => {
      console.log('Error occured' + error);
    });
  }
  getEventById(entityId, address, coordinates) {
    that.eventService.getEventDetails(entityId).subscribe(data => {
      this.formPayloadForMapEntity(data, address, coordinates, DataModel.event);
    }, error => {
      console.log('Error occured' + error);
    });
  }
  initiateUpdateResourceServiceCall(payload) {
    this.easResourcesService.updateResourceLocation(payload).subscribe(response => {
      this.easEventMoreInformationService.toggleModifyLocationIcon('displayModifyLocIcon');
      this.notifier.notify('success', this.currentDataModel + '"' + response.resourceName
        + '" location is modified successfully');
      this.clearCustomPolygonObject();
      this.getModifyLocationResponse.next(DataModel.resource);
    }, error => {
      console.log('Error occured' + error);
      this.notifier.notify('error', 'General error occurred, unable to update ' + this.currentDataModel + ' location');
    });
  }
  formPayloadForMapEntity(payload, address, coordinates, mapEntityType) {
    if (typeof payload.geometry !== "object")
     payload.geometry = JSON.parse(payload.geometry);
    payload.geometry.coordinates = coordinates;
    payload.geometry = JSON.stringify(payload.geometry);
    payload.address.city = address.city;
    payload.address.county = address.county;
    payload.address.state = address.state;
    payload.address.streetAddress1 = address.streetAddress1;
    payload.address.streetAddress2 = address.streetAddress2;
    payload.address.zip = address.zip;

    (mapEntityType === DataModel.event) ? this.initiateUpdateEventServiceCall(payload) : this.initiateUpdateResourceServiceCall(payload);
  }
  assignAddress(data) {
    this.assignedAddress.next(data);
  }
  clearCustomPolygonObject() {
    if (this.customPolygonObject) {
      this.customPolygonObject.setMap(null);
    }
  }
  setCustomPolygonObject(polygonObject) {
    this.customPolygonObject = polygonObject;
  }
  showModifyLocationAlert() {
      this.notifier.notify('error', 'Modify ' + this.currentDataModel + ' location "' +
        this.currentEntityName +
        '" is enabled. Kindly clear or update the selected ' + this.currentDataModel);
  }
  modifyLocationMessage() {
  this.notifier.notify('info', 'Drag an entity icon to the new location on map/click clear button to cancel');
  }

  setDeleteAllShape(data) {
    this.deleteAllShape.next(data);
  }
}
