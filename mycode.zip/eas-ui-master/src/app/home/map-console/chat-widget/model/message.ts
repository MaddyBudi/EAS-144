export class Message {
    comment: string;
    createdDate: Date;
    creator:string;

  constructor(content: string,  creator:string,timestamp?: Date){
    this.comment = content;
    this.createdDate = timestamp;
    this.creator=creator;
  }
}
