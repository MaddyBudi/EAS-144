import { Component, OnInit ,Input} from '@angular/core';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { SharedService } from '../../../shared/shared.service';
import * as moment from 'moment';
import { TransactionMeasures } from '../../../transactionMeasures';
import * as $ from 'jquery';
import { MapConsoleService } from '../map-console.service';
import { EasLeftSidebarService } from '../eas-left-sidebar/eas-left-sidebar.service';
import { PanelHeaders } from '../../../panelHeaders';
import { NotifierService } from 'angular-notifier';


@Component({
  selector: 'app-chat-widget',
  templateUrl: './chat-widget.component.html',
  styleUrls: ['./chat-widget.component.scss']
})
export class ChatWidgetComponent implements OnInit {

  @Input() contextEventId;
  @Input() blockHeader;
  @Input() changeHeight;
  eventDetail;
  messages:any=[];
  newNotes:string;
  containsHtmlTags=false;
   filterQuery:'';
   panelHeader: any;
    constructor(public evtSvc:EasEventsService ,public sharedService: SharedService,private notifierService: NotifierService,
    private mapConsoleService:MapConsoleService,private easLeftSideBarPanelService:EasLeftSidebarService) { }
   ngOnChanges(changes) {
      this.messages = [];
      console.log(this.contextEventId)
      if(this.contextEventId !== undefined)
      this.getEventNotes(this.contextEventId);
      // this.setMessages(this.contextEventData.properties.eventNotes);
     
    }
    ngOnInit() {
      this.panelHeader = PanelHeaders;
    }
    getEventNotes(id) {
      this.evtSvc.getEventDetails(id).subscribe(
      data => {
        this.eventDetail = data;
        this.setMessages(data.eventNotes);
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.notifierService.notify('error', 'General error occured. Please try again later.');
        }
      }
    );
    }
    setMessages(eventNotes) {
      if (null != eventNotes) {
            const arry = eventNotes;
            this.messages = [];
            arry.forEach(element => {
            console.log(element);
            this.messages.push({
              comment: element.comment,
              createdDate: this.getLocalDate(element.createdDate),
              creator: element.creator
            });
          });
        }
    }
  sendMessage(e) {
    e.preventDefault();
    this.newNotes = $('#newNotes').val().trim();
    this.containsHtmlTags = false;
    const reg = /<(.|\n)*?>/g;
  if (reg.test(this.newNotes)) {
      this.containsHtmlTags = true;
     }  else if (this.newNotes !== '') {
        const eventNotes = [{
          'comment': this.newNotes
        }];
         this.evtSvc.updateEventFromChat(this.contextEventId, eventNotes).subscribe(
             data => {
               if (data.entityId != null) {
               console.log(data);
               this.newNotes = '';
               this.setMessages(data.eventNotes);
               }
             },
             error => {
               if (error.status === 401) {
                         this.sharedService.routeToLoginError(error.status);
                     }
             }
           );
      }
  }
  getLocalDate(date) {
     if (date !== null && date !== undefined) {
              console.log(date);
              const dateArr = date.split('T');
              console.log(dateArr);
              const newDate = moment(dateArr[0], 'DD-MM-YYYY').format('YYYY-MM-DD');
              const newDate1 = dateArr[0] + ' ' + dateArr[1];
              const stillUtc = moment.utc(newDate1);
              const local = moment(newDate1).local().format('YYYY-MM-DD HH:mm:ss');
              return local;
          } else {
              return null;
          }
  }
  onClose() {
    this.easLeftSideBarPanelService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }

}
