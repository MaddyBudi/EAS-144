import { Component, OnInit, NgZone, ViewChild, ElementRef } from '@angular/core';
import { EasRightSidebarService } from './eas-right-sidebar/eas-right-sidebar.service';
import * as $ from 'jquery';
import { EasLeftSidebarService } from './eas-left-sidebar/eas-left-sidebar.service';
import { MapConsoleService } from './map-console.service';
import { TransactionMeasures } from '../../transactionMeasures';
import { PanelHeaders } from '../../panelHeaders';
import { Entities } from '../../entities';
import { UserService } from '../../login/services/user.service';
import { HomeService } from '../home.service';
import { AppGlobals } from '../../shared/app.globals';
import { ConfigService } from '../../core/config/config-svc.service';
import { DataModel } from '../../dataModelEnum';
import MeasureTool from 'measuretool-googlemaps-v3/lib/MeasureTool';
import { SharedService } from '../../shared/shared.service';
import { PersonService } from './person/person.service';
import { NotifierService } from 'angular-notifier';
import { EasWorkspaceService } from '../eas-workspace/eas-workspace.service';
import { EpttService } from './eptt/eptt.service';
import { FormControl } from '@angular/forms';
import { MapsAPILoader } from '@agm/core';
import { MapLayers } from './map-layers/mapLayers';
import { EasEventsService } from '../eas-events/eas-events.service';
import { FindRouteService } from './find-route/find-route.service';
import { EasPredefinedLocationsService } from '../eas-predefined-locations/eas-predefined-locations.service';
import { EasEventMoreInformationService } from '../eas-event-more-information/eas-event-more-information.service';
import { AssignEasResourcesService } from '../eas-resources/assign-eas-resources/assign-eas-resources.service';
import { AddressTo } from '../../shared/models/addressTo';
import { EntitiesMiniListService } from './entities-mini-list/entities-mini-list.service';
declare let google: any;
let controller;
let allOverlays = [];
const swal = require('sweetalert');
@Component({
  selector: 'app-map-console',
  templateUrl: './map-console.component.html',
  styleUrls: ['./map-console.component.scss']
})
export class MapConsoleComponent implements OnInit {
  isLeftSideBarOpen: boolean;
  isRightSideBarOpen: boolean;
  listEntitiesType: string;
  entitiesType: string;
  eventInfo: boolean;
  enitityId: string;
  panelHeaders: any;
  entities: any;
  organisationLat: number;
  isabsorbEnable = false;
  organisationLng: number;
  organisationZoom: number;
  infoMessage: string;
  isInfoAlertOpen: boolean;
  isfuelDMSDataVisible = false;
  eventSource;
  selectedShape;
  easOtherEntitiesData: any;
  map;
  lat;
  lng;
  tempData = [];
  fuelDMSData = [];
  hospitalDMSData = [];
  trafficDMSData = [];
  pointAnnotationDMSData = [];
  ploygonAnnotationData = [];
  pointEventDMSData = [];
  ploygonEventData = [];
  LineStringEventData = [];
  easUserResourceDMSData = [];
  fieldPersonnelResourceDMSData = [];
  lawResourceDMSData = [];
  fireResourceDMSData = [];
  medicalResourceDMSData = [];
  agencyResourceDMSData = [];
  kodiakUserResourceDMSData = [];
  pointLocationData = [];
  polygonLocationData = [];
  sensorDMSData = [];
  hydrantDMSData = [];
  weatherDMSData = [];
  contextEventId = '';
  contextEventName: string;
  contextEventData: any;
  measureTool: any;
  isEventDraggable = false;
  locationInfo = {
    locationName: '',
    locationCoords: '',
    locationAddress: '',
    locationLatitude: '',
    locationLongitude: '',
    locationType: '',
    locationFillcolor: ''
  };
  draggableCursor = '';
  drawingManager;
  assignAddress: boolean;
  bicycleLayer = new google.maps.BicyclingLayer();
  trafficLayer = new google.maps.TrafficLayer();
  transitLayer = new google.maps.TransitLayer();
  private readonly notifier: NotifierService;
  entitiesBounds;
  workspaceData: any;
  shapeBounds;
  selectedLocations;
  epttData = [];
  currentView;
  currentEntitiesType;
  customPolygonObject;
  pointDragEndCoordinates = [];
  resourceDragEndCoordinates = [];
  locationDragEndCoordinates = [];
  selectedIdToChangeLocation;
  modifyLocationInfo;
  isClickable = true;
  selectedEntitiesToView = [];
  moreInfoOpenInMiniView = false;
  constructor(private mapConsoleService: MapConsoleService,
    private easLeftSideBarService: EasLeftSidebarService,
    private easRightSideBarService: EasRightSidebarService,
    private userService: UserService, private homeService: HomeService, private appglobals: AppGlobals,
    private sharedService: SharedService, private personService: PersonService, notifierService: NotifierService,
    private easWorkspaceService: EasWorkspaceService, private mapsAPILoader: MapsAPILoader, private ngZone: NgZone,
    private mapLayers: MapLayers, private userservice: UserService, private epttService: EpttService,
    private easEventsService: EasEventsService, private predefinedLocationService: EasPredefinedLocationsService,
    private findRouteService: FindRouteService, private easEventMoreInformationService: EasEventMoreInformationService,
    private assignEasResourceService: AssignEasResourcesService, private entitiesMiniListService:EntitiesMiniListService) {

    this.initObservable();
    this.notifier = notifierService;
  }

  ngOnInit() {
    if (this.userservice.epttUser) {
      this.epttService.loadEPTTPlugin();
    }
    controller = this;
    this.eventInfo = false;
    this.isRightSideBarOpen = false;
    this.isLeftSideBarOpen = false;
    this.panelHeaders = PanelHeaders;
    this.entities = Entities;
    this.organisationZoom = this.userService.zoomlevel ? parseInt(this.userService.zoomlevel) : parseInt(this.appglobals.zoomAdjusterFactor, 10);
    this.organisationLat = parseFloat(this.userservice.orgLatLng.lat);
    this.organisationLng = parseFloat(this.userservice.orgLatLng.lng);
  }
  openLeftSideNavBar(id: string, entitiesType: string) {
    if (id !== this.panelHeaders.powerDataSearch) {
      this.clearPowerdata();
    }
    if (id === this.panelHeaders.assignReleaseResources) {
      const address = new AddressTo(this.contextEventData.address);
      const data = {
        'payload': {
          'entityId': this.contextEventId,
          'properties': {
            'eventAddress': address,
            'eventName': this.contextEventName
          }
        }
      };
      this.easEventsService.setSelectedEventPayload(data);
    }
    this.currentEntitiesType = entitiesType;
    if (this.isRightSideBarOpen) {
      this.easRightSideBarService.toggleSidebarToggle(TransactionMeasures.close);
      this.closeSideBar();
    }
    if (this.moreInfoOpenInMiniView) {
      this.easLeftSideBarService.toggleSidebarToggle(TransactionMeasures.miniView);
      this.entitiesMiniListService.cLoseMoreInfoOther();
      this.entitiesMiniListService.cLoseMoreInfoEvent();
     }
    this.isLeftSideBarOpen = true;
    this.listEntitiesType = id;
    this.entitiesType = entitiesType;
    if (id !== this.panelHeaders.createEntities) {
      this.deleteAllShape();
    }
    this.currentView = id;
  }
  defaultZoomOut() {
    this.map.setZoom(parseInt(this.userservice.zoomlevel, 10));
    this.organisationZoom = parseInt(this.userservice.zoomlevel, 10);
    this.map.setCenter({ lat: parseFloat(this.userservice.orgLatLng.lat), lng: parseFloat(this.userservice.orgLatLng.lng) });
    this.mapConsoleService.mapTypeId = 'roadmap';
    this.mapConsoleService.mapLayers.bicycleLayer = false;
    this.mapConsoleService.mapLayers.trafficLayer = false;
    this.mapConsoleService.mapLayers.transitLayer = false;
    this.setBaseMapType(this.mapConsoleService.mapLayers);
    this.setDefaultFilters();
    // this.mapConsoleService.setEventContext(null);
  }
  defaultZoomIn() {
    this.organisationZoom = this.appglobals.streamZoomLevel;
    this.map.setZoom(this.appglobals.streamZoomLevel);
  }
  closeSideBar() {
    this.currentView = '';
    this.isLeftSideBarOpen = false;
    this.isRightSideBarOpen = false;
    this.deleteAllShape();
    this.clearPowerdata();
    document.getElementById("easRightSideBar").style.width = "auto";
    document.getElementById("easleftSideBar").style.width = "auto";
  }

  openEventInfo(enitityId: string) {
    this.eventInfo = true;
    this.enitityId = enitityId;
  }
  initObservable() {
    this.mapConsoleService.closeSideBarPanel$.subscribe(
      data => {
        this.closeSideBar();
      }
    );
    this.mapConsoleService.clearMoreInfoData$.subscribe(
      data => {
        this.easOtherEntitiesData = "";
      }
    );
    this.mapConsoleService.openEventInfo$.subscribe(
      data => {
        this.openEventInfo(data);
      }
    );
    this.mapConsoleService.baseMapType$.subscribe(
      data => {
        this.setBaseMapType(data);
      }
    );

    this.mapConsoleService.viewMapEntities$.subscribe(
      data => {
        this.viewMapEntities(data);
      });

    this.mapConsoleService.viewMapLocations$.subscribe(
      data => {
        this.viewMapLocations(data);
      });


    this.mapConsoleService.workspaceData$.subscribe(
      data => {
        this.setWorkspace(data);
      }
    );
    this.mapConsoleService.filterEpttUsers$.subscribe(
      data => {
        this.findEpttUsersInGeofence();
      });

    this.mapConsoleService.currentWorkspace$.subscribe(
      data => {
        this.getCurrentWorkspace();
      }
    );

    this.mapConsoleService.rightSidePanel$.subscribe(
      data => {
        this.openRightSidebar(data);
      }
    );
    this.mapConsoleService.mapConsoleComponent$.subscribe(
      data => {
        this.clearContext();
      }
    );
    this.mapConsoleService.assignedAddress$.subscribe(
      data => {
        this.assignAddress = true;
        this.assignResourceToAddress(data);
      }
    );

    this.mapConsoleService.eventContext$.subscribe(
      data => {
        if (data) {
          data.properties.eventName = data.eventName;
          this.contextEventData = data;
          this.contextEventId = data.entityId;
          this.contextEventName = data.eventName;
          this.homeService.setContextEvent(data);
          this.displayEventAssociatedData();
        } else {
          this.clearContext();
          this.homeService.setContextEvent(null);
        }
      }
    );
    this.mapConsoleService.notifications$.subscribe(
      data => {
        this.displayNotificationsInRightsidepanel();
      });
    this.mapConsoleService.viewEpttLocation$.subscribe(
      data => {
        this.viewEpttLocations(data);
      }
    );
    this.mapConsoleService.getModifyLocationResponse$.subscribe(
      data => {
        if (data === DataModel.event) {
          this.currentView = '';
          this.isEventDraggable = !this.isEventDraggable;
        } else if (data === DataModel.resource) {
          this.selectedIdToChangeLocation = '';
          this.closeSideBar();
        } else if (data.dataModel === 'Predefined Location') {
          this.displayModifyPredefinedLocation(data);
        }
      });
    this.mapConsoleService.modifyResourceLocation$.subscribe(data => {
      (data === 'setResourceDrag') ? this.modifyResourceLocation() : this.clearResourceDrag();
    });

    this.mapConsoleService.deleteAllShape$.subscribe(
      data => {
        this.deleteAllShape();
      }
    );
    this.predefinedLocationService.removeLocFromMapOnLocDelete$.subscribe(data => {
      this.deleteStearmDatum(data);
    });
    this.mapConsoleService.isMoreInfoOpen$.subscribe(data => {
      this.moreInfoOpenInMiniView = data;
    });
    this.mapConsoleService.displayOnlyEventAssociatedData$.subscribe(
      data => {
        this.displayEventAssociatedData();
      }
    );
  }
  openRightSidebar(id: string) {
    if (id !== this.panelHeaders.powerDataSearch) {
      this.clearPowerdata();
    }
    if (this.isLeftSideBarOpen) {
      this.easLeftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
      this.closeSideBar();
    }
    this.listEntitiesType = id;
    this.entitiesType = id;
    this.isRightSideBarOpen = true;

    this.deleteAllShape();
    this.currentView = id;
  }
  ChangeMap(boundaries) {
    this.mapConsoleService.mapCenter = boundaries.getCenter();
  }
  idleMap() {
    const rectangle = new google.maps.Rectangle({
      bounds: this.map.getBounds()
    });
    const bounds = rectangle.getBounds();
    if (this.map.getZoom() >= this.appglobals.streamZoomLevel) {
      setTimeout(() => {
        this.plotStreamData(bounds.getSouthWest().lat(), bounds.getSouthWest().lng(), bounds.getNorthEast().lat(), bounds.getNorthEast().lng());
      }, 600);
    }

  }

  convertGeoJsonToMapObject(data) {
    let path = [];
    let object = data.payload.geometry.coordinates[0]
    object.forEach(element => {
      {
        const object = {
          lat: parseFloat(element[1]),
          lng: parseFloat(element[0])
        }
        path.push(object);
      }
    });
    data.path = path;
    var latitudes = [];
    var longitudes = [];
    // put all latitudes and longitudes in arrays
    for (var i = 0; i < object.length; i++) {
      longitudes.push(object[i][0]);
      latitudes.push(object[i][1]);
    }

    // sort the arrays low to high
    latitudes.sort();
    longitudes.sort();
    // get the min and max of each
    const lowX = latitudes[0];
    const highX = latitudes[latitudes.length - 1];
    const lowy = longitudes[0];
    const highy = longitudes[latitudes.length - 1];
    // center of the polygon is the starting point plus the midpoint
    const centerX = lowX + ((highX - lowX) / 2);
    const centerY = lowy + ((highy - lowy) / 2);
    const labelData = [centerY, centerX];
    data.labelData = labelData;

    return data;
  }

  plotStreamData(southWestLat, southWestLng, northEastLat, northEastLng) {
    if (this.eventSource) { this.eventSource.close(); }
    const url = ConfigService.config.dmsStreamUrl + '?lat1=' + southWestLat + '&lng1='
      + southWestLng + '&lat2=' + northEastLat + '&lng2=' + northEastLng;
    this.eventSource = new EventSource(url, { withCredentials: true });
    this.eventSource.onmessage = (event) => {
      this.ngZone.run(() => this.plotToMap(event));
    };
  }
  pushStreamData(data, datum) {
    const index = data.findIndex(x => x.payload.id === datum.payload.id);
    if (!~index) {
      data.push(datum);
    } else if(~index && datum.displayEntity) {
      data.splice(index, 1);
      data.push(datum);
    }
  }
  popStreamData(data, datum) {
    const index = data.findIndex(x => x.payload.id === datum.payload.id);
    if (~index) {
      data.splice(index, 1);
      data.push(datum);
      if (this.contextEventId === datum.payload.entityId) {
        this.contextEventData = datum.payload;
      }
    } else {
      data.push(datum);
    }
  }
  pushLocationData(data, datum) {
    const index = data.findIndex(x => x.id === datum.id);
    if (!~index) {
      data.push(datum);
    }
  }
  setEventData(eventData) {
    const isVisible = true;
    eventData.isVisible = isVisible;
    if (eventData.payload.geometry.type === 'Point') {
      if (eventData.opType === 'INSERT') {
        this.pushStreamData(this.pointEventDMSData, eventData);
      } else {
        this.popStreamData(this.pointEventDMSData, eventData);
      }
    } else if (eventData.payload.geometry.type === 'Polygon') {
      eventData.fillColor = 'green';
      if (eventData.opType === 'REPLACE') {
        // this.pushStreamData(this.ploygonEventData,  this.convertGeoJsonToMapObject(eventData));
      }
      if (eventData.opType === 'INSERT') {
        this.pushStreamData(this.ploygonEventData, this.convertGeoJsonToMapObject(eventData));
      } else {
        this.deleteStearmDatum(eventData.id);
        this.popStreamData(this.ploygonEventData, this.convertGeoJsonToMapObject(eventData));
      }
    } else if (eventData.payload.geometry.type === 'LineString') {
      if (eventData.opType === 'INSERT') {
        this.pushStreamData(this.LineStringEventData, eventData);
      } else {
        this.deleteStearmDatum(eventData.id);
        this.popStreamData(this.LineStringEventData, eventData);
      }

    }
  }


  setResourceData(eventData) {
    const isVisible = true;
    const displayEntity = false;
    eventData.isVisible = isVisible;
    eventData.displayEntity = displayEntity;
    if (this.selectedEntitiesToView.length > 0) {
      this.selectedEntitiesToView.forEach(eachElement => {
        if (eventData.payload.entityId === eachElement.entityId ) {
        eventData.displayEntity = true;
      }
      });
    }
    if (eventData.payload.properties.resourceType === 'eas-users') {
      if (eventData.opType === 'INSERT') {
        if (eventData.payload.properties.kodiakMdn !== null) {
          this.pushStreamData(this.kodiakUserResourceDMSData, eventData);
        }
        this.pushStreamData(this.easUserResourceDMSData, eventData);
      } else {
        if (eventData.payload.properties.kodiakMdn !== null) {
          this.popStreamData(this.kodiakUserResourceDMSData, eventData);
        }
        this.popStreamData(this.easUserResourceDMSData, eventData);
      }
    } else if (eventData.payload.properties.resourceType === 'field-personnel') {
      if (eventData.opType === 'INSERT') {
        this.pushStreamData(this.fieldPersonnelResourceDMSData, eventData);
      } else {
        this.popStreamData(this.fieldPersonnelResourceDMSData, eventData);
      }
    } else if (eventData.payload.properties.resourceObject === 'Agency') {
      if (eventData.opType === 'INSERT') {
        this.pushStreamData(this.agencyResourceDMSData, eventData);
      } else {
        this.popStreamData(this.agencyResourceDMSData, eventData);
      }
    } else if (eventData.payload.properties.resourceType === 'Law') {
      if (eventData.opType === 'INSERT') {
        this.pushStreamData(this.lawResourceDMSData, eventData);
      } else {
        this.popStreamData(this.lawResourceDMSData, eventData);
      }
    } else if (eventData.payload.properties.resourceType === 'Fire') {
      if (eventData.opType === 'INSERT') {
        this.pushStreamData(this.fireResourceDMSData, eventData);
      } else {
        this.popStreamData(this.fireResourceDMSData, eventData);
      }
    } else if (eventData.payload.properties.resourceType === 'Medical') {
      if (eventData.opType === 'INSERT') {
        this.pushStreamData(this.medicalResourceDMSData, eventData);
      } else {
        this.popStreamData(this.medicalResourceDMSData, eventData);
      }
    } else if (eventData.payload.properties.resourceObject === DataModel.annotation) {
      if (eventData.payload.geometry.type === 'Point') {
        if (eventData.opType === 'INSERT') {
          this.pushStreamData(this.pointAnnotationDMSData, eventData);
        } else {
          this.popStreamData(this.pointAnnotationDMSData, eventData);
        }
      } else if (eventData.payload.geometry.type === 'Polygon') {
        if (eventData.opType === 'INSERT') {
          this.pushStreamData(this.ploygonAnnotationData, this.convertGeoJsonToMapObject(eventData))
        } else {
          this.popStreamData(this.ploygonAnnotationData, this.convertGeoJsonToMapObject(eventData))
        }
      }
    }
  }
  setFuelData(eventData) {
    if (eventData.opType === 'INSERT') {
      this.pushStreamData(this.fuelDMSData, eventData);
    } else {
      this.popStreamData(this.fuelDMSData, eventData);
    }
  }
  setHospitalData(eventData) {
    if (eventData.opType === 'INSERT') {
      this.pushStreamData(this.hospitalDMSData, eventData);
    } else {
      this.popStreamData(this.hospitalDMSData, eventData);
    }
  }
  setTrafficData(eventData) {
    if (eventData.opType === 'INSERT') {
      this.pushStreamData(this.trafficDMSData, eventData);
    } else {
      this.popStreamData(this.trafficDMSData, eventData);
    }
  }
  setHydrantData(eventData) {
    if (eventData.opType === 'INSERT') {
      this.pushStreamData(this.hydrantDMSData, eventData);
    } else {
      this.popStreamData(this.hydrantDMSData, eventData);
    }
  }
  setSenSorData(eventData) {
    if (eventData.opType === 'INSERT') {
      this.pushStreamData(this.sensorDMSData, eventData);
    } else {
      this.popStreamData(this.sensorDMSData, eventData);
    }
  }
  setWeatherData(eventData) {
    if (eventData.opType === 'INSERT') {
      this.pushStreamData(this.weatherDMSData, eventData);
    } else {
      this.popStreamData(this.weatherDMSData, eventData);
    }
  }
  plotToMap(event): any {

    const eventData = JSON.parse(event.data);

    if (eventData.opType !== 'PING') {
      if (eventData.opType === 'DELETE') {
        this.deleteStearmDatum(eventData.id);
      }

      else {
        eventData.payload.geometry = JSON.parse(eventData.payload.geometry);
        if (eventData.payload.dataModel === DataModel.event) {
          this.setEventData(eventData);
        } else if (eventData.payload.dataModel === DataModel.resource) {
          this.setResourceData(eventData);
        }
        else if (eventData.payload.dataModel === DataModel.fuel) {
          this.setFuelData(eventData);
        }
        else if (eventData.payload.dataModel === DataModel.hospital) {
          this.setHospitalData(eventData);
        } else if (eventData.payload.dataModel === DataModel.traffic) {
          this.setTrafficData(eventData);
        } else if (eventData.payload.dataModel === DataModel.hydrant) {
          this.setHydrantData(eventData);
        } else if (eventData.payload.dataModel === 'SENSOR') {
          this.setSenSorData(eventData);
        } else if (eventData.payload.dataModel === DataModel.weather) {
          this.setWeatherData(eventData);
        }
      }
    }
  }


  onMapReady(map) {
    let that = this;
    this.map = map;
    const searchBox = new google.maps.places.SearchBox(document.getElementById('pac-input'));
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(document.getElementById('pac-closeAll'));
    map.controls[google.maps.ControlPosition.TOP_CENTER].push(document.getElementById('pac-input'));
    google.maps.event.addListener(searchBox, 'places_changed', function () {
      searchBox.set('map', null);

      const places = searchBox.getPlaces();

      const bounds = new google.maps.LatLngBounds();
      let i, place;
      for (i = 0; place = places[i]; i++) {
        (function (place) {
          const marker = new google.maps.Marker({
            position: place.geometry.location
          });
          marker.bindTo('map', searchBox, 'map');
          google.maps.event.addListener(marker, 'map_changed', function () {
            if (!this.getMap()) {
              this.unbindAll();
            }
          });
          bounds.extend(place.geometry.location);
        } (place));
      }
      map.fitBounds(bounds);
      searchBox.set('map', map);
      const organisationZoom = (this.userService.zoomlevel ? parseInt(this.userService.zoomlevel) :
      parseInt(this.appglobals.zoomAdjusterFactor, 10)) + parseInt(this.appglobals.zoomAdjusterFactor);
      map.setZoom(Math.min(map.getZoom(), organisationZoom));

    });
    this.drawingManager = new google.maps.drawing.DrawingManager({
      drawingMode: google.maps.drawing.OverlayType.MARKER,
      drawingControl: true,
      drawingControlOptions: {
        position: google.maps.ControlPosition.TOP_CENTER,
        drawingModes: ['marker', 'polygon', 'rectangle', 'circle']
      }
    });
    this.drawingManager.setDrawingMode(null);
    this.drawingManager.setMap(map);
    google.maps.event.addListener(this.drawingManager, "drawingmode_changed", function() {
      map.setZoom(13);
      this.organisationZoom = 13;
    });

    let path;
    google.maps.event.addListener(this.drawingManager, 'overlaycomplete', function (e) {
      allOverlays.push(e);
      const newShape = e.overlay;
      newShape.type = e.type;
      that.selectedShape = newShape;
      that.drawingManager.setDrawingMode(null);
      if (that.selectedShape.type === 'rectangle') {
        that.shapeBounds = that.selectedShape.getBounds();
      } else if (that.selectedShape.type === 'polygon') {
        that.shapeBounds = that.mapConsoleService.getPolygonBounds(that.selectedShape);
      }
      if (that.currentView !== that.panelHeaders.findRoute) {
        that.drawingManager.setMap(null);
        that.openLeftSideNavBar(that.panelHeaders.createEntities, that.panelHeaders.createEntities);
      } else if (that.currentView === that.panelHeaders.findRoute) {
        that.findRouteService.setMapRouteData(newShape.position);
      }
    });
    this.measureTool = new MeasureTool(map, {
      showSegmentLength: false,
      showAccumulativeLength: true,
      contextMenu: true,
      unit: MeasureTool.UnitTypeId.METRIC
    });

    this.measureTool._helper.formatLength = function (value) {
      return this._formatLengthImperial(value * 3.28084) + " (" + this._formatLengthMetric(value) + ")";
    };

    this.measureTool._helper.formatArea = function (value) {
      return this._formatAreaImperial(value * 10.7639) + " (" + this._formatAreaMetric(value) + ")";
    };
    // To enable click event on all default POI icons.
    map.setClickableIcons(true);
    this.map = map;
    //  this.mapClicked(this.map) ;
    this.idleMap();
  }

  deleteAllShape() {
    for (var i = 0; i < allOverlays.length; i++) {
      allOverlays[i].overlay.setMap(null);
    }
    allOverlays = [];
    this.drawingManager.setMap(this.map);
    this.clearPowerdata();
  }
  clicked(clickEvent) {
  }

  mapClicked(map) {
    if (this.mapConsoleService.isClickedPowerdataSearch) {
      this.isClickable = true;
      const address = this.sharedService.getAddressFromCenter(map.coords.lat, map.coords.lng)
      address.then((res) => {
        controller.personService.getPersonDetails(res);
        this.openRightSidebar(this.panelHeaders.powerDataSearch);
        this.clearPowerdata();
      });
    } else if (this.assignAddress) {
      const address = this.sharedService.getAddressFromCenter(map.coords.lat, map.coords.lng)
      address.then((res) => {
        controller.assignEasResourceService.assignAddress(res);
        this.clearPowerdata();
      });
    }
  }
  clearPowerdata() {
    this.mapConsoleService.isClickedPowerdataSearch = false;
    this.draggableCursor = '';
  }
  powerDataSearch() {
    this.isClickable = false;
    this.closeSideBar();
    document.getElementById('easRightSideBar').style.width = 'auto';
    this.drawingManager.setDrawingMode(null);
    this.draggableCursor = 'crosshair';
    this.mapConsoleService.isClickedPowerdataSearch = true;
    this.currentView = 'PowerData Search';
  }

  onZoomChange(zoomChangeEvent) {
    if (zoomChangeEvent < 13) {
      this.fuelDMSData = [];
      this.hospitalDMSData = [];
      this.trafficDMSData = [];
      this.pointAnnotationDMSData = [];
      this.ploygonAnnotationData = [];
      this.pointEventDMSData = [];
      this.LineStringEventData = [];
      this.ploygonEventData = [];
      this.easUserResourceDMSData = [];
      this.fieldPersonnelResourceDMSData = [];
      this.lawResourceDMSData = [];
      this.fireResourceDMSData = [];
      this.medicalResourceDMSData = [];
      this.agencyResourceDMSData = [];
      this.pointLocationData = [];
      this.polygonLocationData = [];
    }
  }
  absorbeEvent(data) {
    let that = this;
    const payload = {
      'absorber': this.contextEventId,
      'absorbee': data.entityId
    };
    this.sharedService.showYesNoAlert('Absorb event: ' + data.properties.eventName, 'Absorb', swalCallback, 'No, cancel');
    function swalCallback(yesNo) {
      if (yesNo) {
        that.easEventsService.absorbEvent(payload).subscribe(
          data => {
            if (data) {
              that.notifier.notify('success', 'Event "' + data.eventName + '" absorbed successfully.');
              that.absorbDisable();
            } else {
              swal('Not Absorbed!', data.status, 'Failure');
            }
          },
          error => {
            if (error.status === 401) {
              that.sharedService.routeToLoginError(error.status);
            } else if (error.status === 500) {
              that.notifier.notify('error', error.error.message);
              that.absorbDisable();
              this.isabsorbEnable = false;
              that.notifier.notify('Not Absorbed!', 'Please try again', 'Failure');
            } else {
              swal('Not Absorbed!', 'Please try again', 'Failure');
            }
          }
        );
      }
    }
  }
  eventClick(data) {
    if (this.isabsorbEnable) {
      if (data.payload.entityId !== this.contextEventId) {
        this.absorbeEvent(data.payload);
      } else {
        this.notifier.notify('info', 'Cannot Abosrb the same EVENT,Kindly choose another Event');
      }
    } else {
      if (this.isEventDraggable) {
        this.notifier.notify('error', 'Modify Event location "' +
          this.contextEventName + '" is enabled. Kindly clear or update the selected event');

      } else {
        this.contextEventData = data.payload;
        this.contextEventId = data.payload.entityId;
        this.contextEventName = data.payload.properties.eventName;
        this.homeService.setContextEvent(data.payload);
      }
    }
  }
  dragEnable() {
    this.mapConsoleService.modifyLocationMessage();
    if (this.selectedIdToChangeLocation) {
      this.mapConsoleService.showModifyLocationAlert();
    } else {
      const tempData = this.contextEventData;
      (tempData.geometry.coordinates) ? tempData.coordinates = tempData.geometry.coordinates : tempData.geometry = JSON.parse(tempData.geometry);
      this.viewContextEvent(tempData);
      this.currentView = 'dragEnable';
      this.isEventDraggable = true;
      const index = this.ploygonEventData.findIndex(x => x.payload.entityId === this.contextEventId);
      if (~index) {
        const data = this.ploygonEventData[index];
        data.isVisible = false;
        if (data.payload.geometry.type === 'Polygon') {
          this.getPolygonObject(data, data.payload.entityId, data.payload.dataModel,
            data.payload.properties.eventName, data.path);
        }
      }
      const indexPoint = this.pointEventDMSData.findIndex(x => x.payload.entityId === this.contextEventId);
      if (~indexPoint) {
        const data = this.pointEventDMSData[indexPoint];
        data.isVisible = false;
      }
      // const indexLine = this.LineStringEventData.findIndex(x => x.payload.entityId === this.contextEventId);
      // if(~indexLine){
      //   const data = this.LineStringEventData[indexLine];
      //   data.isVisible = false;

      // }

    }
  }
  markerEventClick(data) {
    if (this.isEventDraggable && this.contextEventId === data.payload.entityId) {
      this.mapConsoleService.displayConfirmationWindow('Point', this.pointDragEndCoordinates, data, data.payload.properties.eventName);
    } else {
      this.eventClick(data);
    }
  }
  markerDragEnd($event) {
    this.pointDragEndCoordinates = [];
    this.pointDragEndCoordinates.push($event.coords.lng, $event.coords.lat);
  }
  getPolygonObject(data, entityId, datamodel, entityName, path) {
    const that = this;
    const polygonObject = new google.maps.Polygon({
      paths: path,
      map: this.map,
      id: entityId,
      name: entityName,
      dataModel: datamodel,
      draggable: true,
      editable: true,
      fillColor: this.appglobals.fillColor,
      fillOpacity : this.appglobals.fillOpacity,
      strokeOpacity: this.appglobals.strokeOpacity
    });
    this.mapConsoleService.setCustomPolygonObject(polygonObject);
    polygonObject.addListener('click', (e) => {
      if (polygonObject.dataModel === DataModel.resource) {
        this.openLeftSideNavBar(this.panelHeaders.contextEventInfo, this.panelHeaders.contextEventInfo);
        this.easEventMoreInformationService.toggleModifyLocationIcon('displayClearIcon');
        that.mapConsoleService.displayConfirmationWindow('Polygon', polygonObject, data, polygonObject.name);
      } else {
        that.mapConsoleService.displayConfirmationWindow('Polygon', polygonObject, data, polygonObject.name);
      }
    });
  }

  clearEventDrag(id) {
    this.currentView = '';
    this.isEventDraggable = !this.isEventDraggable;
    const polygonIndex = this.ploygonEventData.findIndex(x => x.payload.entityId === id);
    if (~polygonIndex) {
      const polygonEventData = this.ploygonEventData[polygonIndex];
      this.mapConsoleService.clearCustomPolygonObject();
      polygonEventData.isVisible = true;
    }
    const pointIndex = this.pointEventDMSData.findIndex(x => x.payload.entityId === id);
    if (~pointIndex) {
      const data = this.pointEventDMSData[pointIndex];
      data.isVisible = true;
      this.pointEventDMSData.splice(pointIndex, 1);
      data.payload.geometry = JSON.stringify(data.payload.geometry);
      const eventData = {
        'data': JSON.stringify(data)
      };
      this.plotToMap(eventData);
    }
    this.notifier.notify('info', 'Modify event location is cancelled');

  }
  markerClick(data) {
    if (this.selectedIdToChangeLocation && this.selectedIdToChangeLocation === data.payload.entityId) {
      this.mapConsoleService.displayConfirmationWindow('Point',
        this.resourceDragEndCoordinates, data, data.payload.properties.resourceName);
      this.openMoreInfoPanel(data);
      this.easEventMoreInformationService.toggleModifyLocationIcon('displayClearIcon');
    } else if (this.selectedIdToChangeLocation && this.selectedIdToChangeLocation !== data.payload.entityId) {
      this.mapConsoleService.showModifyLocationAlert();
    } else {
      this.openMoreInfoPanel(data);
    }
  }
  openMoreInfoPanel(data) {
    this.openLeftSideNavBar(this.panelHeaders.contextEventInfo, this.panelHeaders.contextEventInfo);
    this.easOtherEntitiesData = {
      dataEntityId: (data.payload.entityId) ? data.payload.entityId : data.payload.id,
      dataModel: (data.payload.dataModel) ? (data.payload.dataModel === DataModel.resource ? data.payload.properties.resourceObject : data.payload.dataModel) : DataModel.location,
      payLoad: data,
      isFromMap: (data.payload.properties.isFromMap === false) ? data.payload.properties.isFromMap : true
    };
    this.mapConsoleService.currentDataModel = (this.easOtherEntitiesData.dataModel === DataModel.annotation) ? 'Annotation' : 'Resource';
    this.mapConsoleService.currentEntityName = this.easOtherEntitiesData.payLoad.payload.properties.resourceName;
  }
  absorbEnable() {
    this.currentView = 'absorbEnable';
    this.isabsorbEnable = true;
    var index = this.ploygonEventData.findIndex(x => x.payload.entityId === this.contextEventId);
    if (~index) {
      let datum = this.ploygonEventData[index];
      datum.payload.properties.orginalfillcolor = datum.payload.properties.fillcolor;
      datum.payload.properties.fillcolor = 'red';
    }
    this.notifier.notify('info', 'Kindly Choose an Event to absorb');
  }

  absorbDisable() {
    this.currentView = 'absorbDisable';
    this.isabsorbEnable = false;
    var index = this.ploygonEventData.findIndex(x => x.payload.entityId === this.contextEventId);
    if (~index) {
      let datum = this.ploygonEventData[index];
      datum.payload.properties.fillcolor = datum.payload.properties.orginalfillcolor;
    }
  }
  setStreamData(datum, data) {
    if (!data.get(datum.id))
      data.set(datum.id, datum);
  }

  replaceStreamData(datum, data) {
    data.set(datum.id, datum);
    if (datum.payload.entityId === this.contextEventData.entityId)
      this.contextEventData = datum.payload;

  }

  deleteStearmDatum(id) {
    var index;
    index = this.pointEventDMSData.findIndex(x => x.id === id);
    if (~index) { this.pointEventDMSData.splice(index, 1); }
    index = this.LineStringEventData.findIndex(x => x.id === id);
    if (~index) { this.LineStringEventData.splice(index, 1); }
    index = this.ploygonEventData.findIndex(x => x.id === id);
    if (~index) { this.ploygonEventData.splice(index, 1); }
    index = this.fuelDMSData.findIndex(x => x.id === id);
    if (~index) { this.fuelDMSData.splice(index, 1); }
    index = this.hospitalDMSData.findIndex(x => x.id === id);
    if (~index) { this.hospitalDMSData.splice(index, 1); }
    index = this.trafficDMSData.findIndex(x => x.id === id);
    if (~index) { this.trafficDMSData.splice(index, 1); }
    index = this.easUserResourceDMSData.findIndex(x => x.id === id);
    if (~index) { this.easUserResourceDMSData.splice(index, 1); }
    index = this.fieldPersonnelResourceDMSData.findIndex(x => x.id === id);
    if (~index) { this.fieldPersonnelResourceDMSData.splice(index, 1); }
    index = this.lawResourceDMSData.findIndex(x => x.id === id);
    if (~index) { this.lawResourceDMSData.splice(index, 1); }
    index = this.fireResourceDMSData.findIndex(x => x.id === id);
    if (~index) { this.fireResourceDMSData.splice(index, 1); }
    index = this.medicalResourceDMSData.findIndex(x => x.id === id);
    if (~index) { this.medicalResourceDMSData.splice(index, 1); }
    index = this.agencyResourceDMSData.findIndex(x => x.id === id);
    if (~index) { this.agencyResourceDMSData.splice(index, 1); }
    index = this.kodiakUserResourceDMSData.findIndex(x => x.id === id);
    if (~index) { this.kodiakUserResourceDMSData.splice(index, 1); }
    index = this.pointAnnotationDMSData.findIndex(x => x.id === id);
    if (~index) { this.pointAnnotationDMSData.splice(index, 1); }
    index = this.ploygonAnnotationData.findIndex(x => x.id === id);
    if (~index) { this.ploygonAnnotationData.splice(index, 1); }
    index = this.polygonLocationData.findIndex(x => x.id === id);
    if (~index) { this.polygonLocationData.splice(index, 1); }
    index = this.pointLocationData.findIndex(x => x.id === id);
    if (~index) { this.pointLocationData.splice(index, 1); }
  }
  zoomIn() {
    if (this.organisationZoom < 22) {
      this.organisationZoom = this.organisationZoom + 1;
      this.map.setZoom(this.organisationZoom);
    }
  }
  zoomOut() {
    if (this.organisationZoom !== 0) {
      this.organisationZoom = this.organisationZoom - 1;
      this.map.setZoom(this.organisationZoom);
    }

  }
  clearContext() {
    if (this.isEventDraggable) {
      this.clearEventDrag(this.contextEventId);
    }
    if (this.isabsorbEnable) {
      this.absorbDisable();
    }
    if (this.currentEntitiesType === PanelHeaders.contextEventInfo || this.currentEntitiesType === PanelHeaders.chatWidget || this.currentEntitiesType === PanelHeaders.updateContextEvent) {
      this.closeSideBar();
    }
    this.contextEventData = '';
    this.contextEventId = '';
    this.contextEventName = '';
  }
  deletEvent() {
    this.currentView = 'deletEvent';
    this.mapConsoleService.deletEvent(this.contextEventData);
  }


  setBaseMapType(baseMap) {
    if (baseMap.bicycleLayer) {
      this.bicycleLayer.setMap(this.map);
    } else {
      this.bicycleLayer.setMap(null);
    }

    if (baseMap.trafficLayer) {
      this.trafficLayer.setMap(this.map);
    } else {
      this.trafficLayer.setMap(null);
    }

    if (baseMap.transitLayer) {
      this.transitLayer.setMap(this.map);
    } else {
      this.transitLayer.setMap(null);
    }
  }
  checkEventAbsorbAndDrag(entityData) {
    const object = entityData.payload;
    if (!this.isabsorbEnable && !this.isEventDraggable) {
      if (object.length === 1 && object[0].dataModel === Entities.events) {
        this.contextEventData = object[0];
        this.contextEventId = object[0].entityId;
        this.contextEventName = object[0].properties.eventName;
        this.homeService.setContextEvent(object[0]);
        if (entityData.payload[0].properties.isFromFullList) {
          this.easOtherEntitiesData = undefined;
          this.openLeftSideNavBar(this.panelHeaders.contextEventInfo, this.panelHeaders.contextEventInfo);
        }
      } else if (object.length > 1 && object[0].dataModel === Entities.events) {
        this.clearContext();
        this.homeService.setContextEvent(null);
      }
    } else {
      this.notifier.notify('info', 'Event context cannot be set,since absorbe/modify Location is enabled.');
    }
  }
  viewMapEntities(entityData) {
    const object = entityData.payload;
    this.checkEventAbsorbAndDrag(entityData);
    if (object.length === 1 && object[0].geometry['type'] === 'Point') {
      this.organisationZoom = (this.userService.zoomlevel ? parseInt(this.userService.zoomlevel) :
        parseInt(this.appglobals.zoomAdjusterFactor, 10)) + parseInt(this.appglobals.zoomAdjusterFactor);
      this.map.setCenter({ lat: parseFloat(object[0].geometry['coordinates'][1]), lng: parseFloat(object[0].geometry['coordinates'][0]) });
    } else if (object.length === 1 && object[0].geometry['type'] === 'LineString') {
      this.organisationZoom = (this.userService.zoomlevel ? parseInt(this.userService.zoomlevel) :
        parseInt(this.appglobals.zoomAdjusterFactor, 10)) + parseInt(this.appglobals.zoomAdjusterFactor);
      const latitude = (object[0].geometry['coordinates'][0][1] + object[0].geometry['coordinates'][1][1]) / 2;
      const longitude = (object[0].geometry['coordinates'][0][0] + object[0].geometry['coordinates'][1][0]) / 2;
      this.map.setCenter({ lat: latitude, lng: longitude });
    } else {
      this.entitiesBounds = undefined;
      const bounds = new google.maps.LatLngBounds();
      for (let i = 0; i < object.length; i++) {
        for (let j = 0; j < object[i].geometry['coordinates'][0].length; j++) {
          bounds.extend({
            lat: object[i].geometry['coordinates'][0][j][1],
            lng: object[i].geometry['coordinates'][0][j][0]
          });
        }
      }
      bounds.getCenter();
      this.map.fitBounds(bounds);
      if ((this.map.getZoom() < 13) && (object.length > 1)) {
        this.notifier.notify('error', 'The selected ' + object[0].type.toLowerCase() + 's' + ' are too far to be viewed together .' +
          'Please select geographically closer ' + object[0].type.toLowerCase() + 's');
      }
    }
    if (object.length === 1 && object[0].dataModel !== DataModel.event && entityData.payload[0].properties.isFromFullList) {
      object[0].properties.resourceName = object[0].resourceName;
      object[0].properties.resourceObject = object[0].resourceObject;
      entityData.payload = entityData.payload[0];
      this.openMoreInfoPanel(entityData);
    }
    if (object[0].dataModel !== DataModel.event) {
      object.forEach(data => {
        data.displayEntity = true;
      this.selectedEntitiesToView.push(data);
    });
  }
  }
  viewMapLocations(locationData) {
    const object = locationData.payload;
    if (object.length === 1 && object[0].geometry.type === 'Point') {
      this.organisationZoom = (this.userService.zoomlevel ? parseInt(this.userService.zoomlevel) :
        parseInt(this.appglobals.zoomAdjusterFactor, 10)) + parseInt(this.appglobals.zoomAdjusterFactor);
      this.organisationLat = object[0].geometry.coordinates[0].lat;
      this.organisationLng = object[0].geometry.coordinates[0].lng;
      this.map.setCenter({ lat: object[0].geometry.coordinates[0].lat, lng: object[0].geometry.coordinates[0].lng });
      object[0].isVisible = true;
      object[0].displayEntity = true;
      this.selectedEntitiesToView.push(object[0]);
      this.pushLocationData(this.pointLocationData, object[0]);
    } else {
      this.entitiesBounds = undefined;
      const bounds = new google.maps.LatLngBounds();
      for (let i = 0; i < object.length; i++) {
        object[i].isVisible = true;
        for (let j = 0; j < object[i].geometry.coordinates.length; j++) {
          bounds.extend(object[i].geometry.coordinates[j]);
        }
        if (object[i].geometry.type === 'Point') {
          object[i].displayEntity = true;
          this.selectedEntitiesToView.push(object[i]);
          this.pushLocationData(this.pointLocationData, object[i]);
        } else {
          object[i].displayEntity = true;
          this.selectedEntitiesToView.push(object[i]);
          // object[i].geometry.coordinates.push(object[i].geometry.coordinates[length - 1]);
          this.pushLocationData(this.polygonLocationData, object[i]);
        }
      }
      bounds.getCenter();
      this.map.fitBounds(bounds);
    }
    if (this.map.getZoom() < 13 && object.length > 1) {
      this.notifier.notify('error',
        'The selected locations are too far to be viewed together .Please select geographically closer locations');
    }
    this.checkLocationDrag(object);
    if (object.length === 1 && locationData.payload[0].properties.isFromFullList) {
      locationData.payload = locationData.payload[0];
      this.openMoreInfoPanel(locationData);
    }
  }
  checkLocationDrag(object) {
    if (object[0].enableModify) {
      this.modifyPredefinedLocationData(object);
    } else {
      let index = this.polygonLocationData.findIndex(x => x.id === object[0].id);
      if (~index) {
        this.polygonLocationData.splice(index, 1);
        object[0].isVisible = true;
        this.polygonLocationData.push(object[0]);
        this.mapConsoleService.clearCustomPolygonObject();
      }
      index = this.pointLocationData.findIndex(x => x.id === object[0].id);
      if (~index) {
        this.pointLocationData.splice(index, 1);
        object[0].isVisible = true;
        this.pointLocationData.push(object[0]);
      }
    }
  }
  getCurrentWorkspace() {
    const geoPoint = this.mapConsoleService.getMapCenter();
    const geometry = {
      'type': 'Point',
      'coordinates': [geoPoint.lng(), geoPoint.lat()]
    };
    let mapType = '';
    let terrian = false;
    let labels = false;
    if (this.mapConsoleService.mapTypeId === 'roadmap' || this.mapConsoleService.mapTypeId === 'terrain') {
      mapType = 'roadmap';
    } else if (this.mapConsoleService.mapTypeId === 'satellite' || this.mapConsoleService.mapTypeId === 'hybrid') {
      mapType = 'satellite';
    }
    if (this.mapConsoleService.mapTypeId === 'terrain') {
      terrian = true;
    }
    if (this.mapConsoleService.mapTypeId === 'hybrid') {
      labels = true;
    }
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ 'latLng': geoPoint }, (results, status) => {
      if (status === google.maps.GeocoderStatus.OK) {
        const place = results[0];
        controller.address = controller.sharedService.getFullAddress(place);
      }
    });
    setTimeout(() => {
      this.workspaceData = {
        'easWorkspaceName': '',
        'geometry': JSON.stringify(geometry),
        'address': controller.address,
        'properties': {
          'zoomLevel': this.map.getZoom(),
          'eventId': this.contextEventId ? this.contextEventId : '',
          'mapTypeInfo': {
            'type': mapType,
            'terrain': terrian,
            'labels': labels
          },
          'mapLayers': {
            'bicycle': this.mapConsoleService.mapLayers.bicycleLayer,
            'traffic': this.mapConsoleService.mapLayers.trafficLayer,
            'transit': this.mapConsoleService.mapLayers.transitLayer
          },
          'filtersState': {
            'EVENT': this.mapLayers.isEventVisible,
            'Location': this.mapLayers.isLocationVisible,
            'Law': this.mapLayers.isLawVisible,
            'Fire': this.mapLayers.isFireVisible,
            'Medical': this.mapLayers.isMedicalVisible,
            'EAS-Users': this.mapLayers.isEASUsersVisible,
            'Field-Person': this.mapLayers.isFieldPersonVisible,
            'Agency': this.mapLayers.isAgencyVisible,
            'Annotations': this.mapLayers.isAnnotationsVisible,
            'Hydrant': this.mapLayers.isHydrantVisible,
            'Hospital': this.mapLayers.isHospitalVisible,
            'Fuel': this.mapLayers.isFuelVisible,
            '311': this.mapLayers.is311Visible,
            'TMC': this.mapLayers.isTMCVisible,
            'Weather': this.mapLayers.isWeatherVisible,
            'Sensor': this.mapLayers.isSensorVisible
          }
        }
      };
      this.easWorkspaceService.setWorkspaceData(this.workspaceData);
    }, 1000);
  }

  setWorkspace(workspace) {
    if (workspace) {
      this.mapConsoleService.workspaceId = workspace.entityId;

      const geometry = JSON.parse(workspace.geometry);
      if (workspace.properties.zoomLevel) {
        this.organisationZoom = parseInt(workspace.properties.zoomLevel);
        this.map.setZoom(parseInt(workspace.properties.zoomLevel));
      }

      this.organisationLat = geometry.coordinates[1];
      this.organisationLng = geometry.coordinates[0];
      this.map.setCenter({ lat: parseFloat(geometry.coordinates[1]), lng: parseFloat(geometry.coordinates[0]) });
      this.mapConsoleService.mapTypeId = workspace.properties.mapTypeInfo.type;

      if (workspace.properties.mapTypeInfo.terrain) {
        this.mapConsoleService.mapTypeId = 'terrain';
      }

      if (workspace.properties.mapTypeInfo.labels) {
        this.mapConsoleService.mapTypeId = 'hybrid';
      }

      this.mapConsoleService.mapLayers.bicycleLayer = workspace.properties.mapLayers.bicycle;
      this.mapConsoleService.mapLayers.trafficLayer = workspace.properties.mapLayers.traffic;
      this.mapConsoleService.mapLayers.transitLayer = workspace.properties.mapLayers.transit;

      this.setBaseMapType(this.mapConsoleService.mapLayers);

      if (workspace.properties.eventId) {
        this.easEventsService.getEventDetails(workspace.properties.eventId).subscribe(
          data => {
            if (data.status === 'TERMINATED' || data.deleted) {
              this.mapConsoleService.setEventContext(null);
            } else {
              this.mapConsoleService.setEventContext(data);
            }
          },
          error => {
            if (error.status === 401) {
              this.sharedService.routeToLoginError(error.status);
            } else {

            }
          }
        );
      } else {
        this.mapConsoleService.setEventContext(null);
      }

      this.setFilters(workspace.properties.filtersState);
    } else {
      this.defaultZoomOut();
    }

  }

  setFilters(filtersState) {
    this.mapLayers.isEventVisible = filtersState.EVENT;
    this.mapLayers.isLocationVisible = filtersState.Location;
    this.mapLayers.isLawVisible = filtersState.Law;
    this.mapLayers.isFireVisible = filtersState.Fire;
    this.mapLayers.isMedicalVisible = filtersState.Medical;
    this.mapLayers.isEASUsersVisible = filtersState['EAS-Users'];
    this.mapLayers.isFieldPersonVisible = filtersState['Field-Person'];
    this.mapLayers.isAgencyVisible = filtersState.Agency;
    this.mapLayers.isAnnotationsVisible = filtersState.Annotations;
    this.mapLayers.isHydrantVisible = filtersState.Hydrant;
    this.mapLayers.isHospitalVisible = filtersState.Hospital;
    this.mapLayers.isFuelVisible = filtersState.Fuel;
    this.mapLayers.is311Visible = filtersState[311];
    this.mapLayers.isTMCVisible = filtersState.TMC;
    this.mapLayers.isWeatherVisible = filtersState.Weather;
    this.mapLayers.isSensorVisible = filtersState.Sensor;
  }

  setDefaultFilters() {
    this.mapLayers.isEventVisible = true;
    this.mapLayers.isLocationVisible = true;
    this.mapLayers.isLawVisible = true;
    this.mapLayers.isFireVisible = true;
    this.mapLayers.isMedicalVisible = true;
    this.mapLayers.isEASUsersVisible = true;
    this.mapLayers.isFieldPersonVisible = true;
    this.mapLayers.isAgencyVisible = true;
    this.mapLayers.isAnnotationsVisible = true;
    this.mapLayers.isHydrantVisible = true;
    this.mapLayers.isHospitalVisible = true;
    this.mapLayers.isFuelVisible = true;
    this.mapLayers.is311Visible = true;
    this.mapLayers.isTMCVisible = true;
    this.mapLayers.isWeatherVisible = true;
    this.mapLayers.isSensorVisible = false;
  }

  findEpttUsersInGeofence() {
    const epttUsersInGeofence = [];
    this.fieldPersonnelResourceDMSData.forEach(eachElement => {
      if (eachElement.payload.properties.kodiakMdn) {
        const point = new google.maps.LatLng(eachElement.payload.geometry.coordinates[1], eachElement.payload.geometry.coordinates[0]);
        if (this.shapeBounds.contains(point)) {
          const userMdn = { 'phoneNumber': eachElement.payload.properties.kodiakMdn };
          epttUsersInGeofence.push(userMdn);
        }
      }
    });
    if (epttUsersInGeofence.length > 0) {
      this.isRightSideBarOpen = true;
      this.openRightSidebar(this.panelHeaders.eptt);
      this.epttService.setSelectedUsers(epttUsersInGeofence);
    } else {
      this.notifier.notify('info', 'No eptt users in this geofence area');
    }
  }
  displayNotificationsInRightsidepanel() {
    this.isRightSideBarOpen = true;
    this.openRightSidebar(this.panelHeaders.notification);
  }
  public setPanel() {
    return document.querySelector('#responsePanel');
  }

  findRouteResponse(event) {
    this.findRouteService.setFindRouteResponse(event);
  }
  viewEpttLocations(contact) {
    if (this.epttData.length > 0) {
      this.epttData.forEach(user => {
        if (user.mdn !== contact.mdn) {
          const location = contact.latlng.split(',');
          contact.location = location;
          this.epttData.push(contact);
          this.map.setCenter({ lat: parseFloat(location[0]), lng: parseFloat(location[1]) });
        }
      })
    } else {
      const location = contact.latlng.split(',');
      contact.location = location;
      this.epttData.push(contact);
      this.map.setCenter({ lat: parseFloat(location[0]), lng: parseFloat(location[1]) });
    }
    this.organisationZoom = (this.userService.zoomlevel ? parseInt(this.userService.zoomlevel) : parseInt(this.appglobals.zoomAdjusterFactor, 10)) + parseInt(this.appglobals.zoomAdjusterFactor);
  }
  resourceDragend($event, data) {
    this.resourceDragEndCoordinates = [];
    this.resourceDragEndCoordinates.push($event.coords.lng, $event.coords.lat);
  }
  modifyResourceLocation() {
    if (this.isEventDraggable) {
      this.easEventMoreInformationService.toggleModifyLocationIcon('displayModifyLocIcon');
      this.notifier.notify('error', 'Modify Event location "' +
        this.contextEventName + '" is enabled. Kindly clear or update the selected event');
    } else {
      this.mapConsoleService.modifyLocationMessage();
      this.selectedIdToChangeLocation = this.easOtherEntitiesData.dataEntityId;
      this.easOtherEntitiesData.payLoad.isVisible = false;
      // const entityData = this.easOtherEntitiesData;
      // entityData.payLoad.dataModel = entityData.dataModel;
      // entityData.payLoad.geometry = entityData.payLoad.payload.geometry;
      // entityData.payLoad.coordinates = entityData.payLoad.payload.geometry.coordinates;
      // this.viewContextEvent(entityData.payLoad);
      if (this.easOtherEntitiesData.payLoad.payload.geometry.type === 'Polygon') {
        this.getPolygonObject(this.easOtherEntitiesData.payLoad, this.easOtherEntitiesData.payLoad.payload.entityId,
          this.easOtherEntitiesData.payLoad.payload.dataModel, this.easOtherEntitiesData.payLoad.payload.properties.resourceName
          , this.easOtherEntitiesData.payLoad.path);
      }
    }
  }
  clearResourceDrag() {
    this.easOtherEntitiesData.payLoad.isVisible = true;
    const data = this.easOtherEntitiesData.payLoad;
    data.opType = 'REPLACE';
    data.payload.geometry = JSON.stringify(data.payload.geometry);
    const eventdata = {
      'data': JSON.stringify(data)
    };
    this.plotToMap(eventdata);
    this.closeSideBar();
    this.selectedIdToChangeLocation = '';
    this.mapConsoleService.clearCustomPolygonObject();
    this.notifier.notify('info', 'Modify ' + this.mapConsoleService.currentDataModel + ' location is cancelled');
  }
  assignResourceToAddress(data) {
    this.drawingManager.setDrawingMode(null);
    this.draggableCursor = 'crosshair';
  }
  modifyPredefinedLocationData(data) {
    if (this.selectedIdToChangeLocation) {
      this.mapConsoleService.showModifyLocationAlert();
      this.mapConsoleService.cancelModifyLocation.next('cancel');
    } else if (this.isEventDraggable) {
      this.notifier.notify('error', 'Modify Event location "' + this.contextEventName + '" is enabled. Kindly clear or update the selected event');
      this.mapConsoleService.cancelModifyLocation.next('cancel');
    } else {
      data[0].isVisible = false;
      const index = this.polygonLocationData.findIndex(x => x.id == data[0].id);
      if (~index) {
        const data = this.polygonLocationData[index];
        data.isVisible = false;
        this.getPolygonObject(data, data.id, data.type, data.name, data.geometry.coordinates);
      }
    }
  }
  locationDragEnd($event) {
    this.locationDragEndCoordinates = [];
    this.locationDragEndCoordinates.push($event.coords.lng, $event.coords.lat);
  }
  markerPointLocationClick(data) {
    this.mapConsoleService.displayConfirmationWindow('Point', this.locationDragEndCoordinates, data, data.name);
  }
  displayModifyPredefinedLocation(data) {
    if (data.status === 'success') {
      var index = this.polygonLocationData.findIndex(x => x.id === data.payload.id);
      if (~index) {
        this.polygonLocationData.splice(index, 1);
        data.payload.isVisible = true;
        this.polygonLocationData.push(data.payload);
        this.mapConsoleService.clearCustomPolygonObject();
      }
      var index = this.pointLocationData.findIndex(x => x.id === data.payload.id);
      if (~index) {
        this.pointLocationData.splice(index, 1);
        data.payload.isVisible = true;
        this.pointLocationData.push(data.payload);
      }
      this.mapConsoleService.cancelModifyLocation.next('cancel');
      this.notifier.notify('success', 'Predefined Location "' + data.entityName + '" location is modified successfully.');

    } else if (data.status === 'failure') {
      this.notifier.notify('error', 'General error occurred, unable to update location.');
    }
  }
  assignReleaseResources() {
    const data = {
      'eventName': this.contextEventName,
      'entityId': this.contextEventId,
      'eventAddress': this.contextEventData.properties.eventAddress
    };
    this.easEventsService.setSelectedEventPayload(data);
    this.isLeftSideBarOpen = true;
  }
  viewContextEvent(data) {
    this.currentView = 'viewEvent';
    this.viewMapEntities({ 'payload': [data] });
  }
  // locationClick(locData) {
  //   locData.properties.isFromMap = true;
  //   locData.properties.name = locData.name;
  //   locData.properties.createdBy = locData.createdBy;
  //   locData.properties.createdDate = locData.createdDate;
  //   const data = { 'payload': locData };
  //   this.openMoreInfoPanel(data);
  // }
  displayEventAssociatedData() {
    this.selectedEntitiesToView.forEach(data => {
      data.displayEntity = false;
    });
    this.selectedEntitiesToView = [];
  }
}
