import { EasRightSidebarService } from '../eas-right-sidebar/eas-right-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { PersonService } from './person.service';
import { EasResourcesService } from '../../eas-resources/eas-resources.service';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { EasAnnotationsService } from '../../eas-annotations/eas-annotations.service';

let controller;

@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.scss']
})

export class PersonComponent implements OnInit {
  panelHeader: string;
  result: any = '';
  jqueryEvent = true;
  private physicalAttributesString: string;
  showPersonSearchComponent = false;

  constructor(private easRightSideBarService: EasRightSidebarService, private personService: PersonService,
    private resourcesService: EasResourcesService, private easEventsService: EasEventsService,
    public annotationService: EasAnnotationsService) { }

  ngOnInit() {
    this.panelHeader = PanelHeaders.powerDataSearch;
    controller = this;

    this.personService.person$.subscribe(
      data => {
        this.showPersonSearchComponent = data;
      }
    );

    this.personService.personComponent.subscribe(
      data => {
        controller.result = data;
        this.jqueryEvent = true;
      }
    );
  }

  onClose() {
    this.easRightSideBarService.toggleSidebarToggle(TransactionMeasures.close);
  }

  physicalAttributes(criminalRecords): string {
    this.physicalAttributesString = "";
    if (criminalRecords != undefined && criminalRecords.length != null &&
      criminalRecords.length && criminalRecords[0].physicalAttributes) {
      for (let criminalRecord of criminalRecords) {
        this.toMap(criminalRecord.physicalAttributes).forEach((v, k) => {
          this.physicalAttributesString += (k + "/" + v.toLowerCase() + " ")
        });
      }
    }
    return this.physicalAttributesString;
  }


  toMap(item: any): Map<string, string> {
    let map = new Map();
    Object.keys(item).filter(k => item[k] != null && k != 'sourceType').forEach(k => map.set(k, item[k]))
    return map;
  }

  fullName(name) {
    if (this.jqueryEvent) {
      this.panelToggle();
      this.jqueryEvent = false;
    }
    return [name.namePrefix, name.firstName, name.middleName, name.lastName, name.nameSuffix]
      .filter((val) => val).join(' ');
  }

  age(dob) {
    if (dob && dob.age)
      return ', ' + dob.age + ' years old';
    else
      return '';
  }

  getPhones(phones) {
    let retval: string = '';
    for (let phone of phones) {
      retval += this.getPhone(phone);
      if (phone.phoneType) {
        retval += (phone.phoneType.startsWith('WIRELINE') ? '(Wireline) ' : '(Unknown) ');
      }
    }
    return retval;
  }

  getPhone(phone) {
    if (phone && phone.number) {
      let number = phone.number;
      return '(' + number.substring(0, 3) + ') ' + number.substring(3, 6) + '-' + number.substring(6, 10);
    } else {
      return ' ';
    }
  }

  getAddress(addr): string {
    let retval = (addr.streetAddress1 || '');
    if (addr.streetAddress2) {
      retval += (', ' + addr.streetAddress2);
    }
    if (addr.city) {
      retval += (', ' + addr.city);
    }
    if (addr.state) {
      retval += (', ' + addr.state);
    }
    if (addr.zip) {
      retval += (' ' + addr.zip);
    }
    return retval;
  }

  getDateLastReported(dateLastReported) {
    if (dateLastReported) {
      return '[' + dateLastReported.month + '/' + dateLastReported.day + '/' + dateLastReported.year + ']';
    } else {
      return "[unknown]";
    }
  }

  panelToggle() {
    $(document).ready(function () {
      $('.card-header.clickable').on('click', function (e) {
        var $this = $(this);
        if (!$this.parent().find('.card-body').first().hasClass('hide')) {
          $this.parent().find('.card-body').first().removeClass('show').addClass('hide');
          $this.find('i').removeClass('fas fa-chevron-up').addClass('fas fa-chevron-down');
        } else {
          $this.parent().find('.card-body').first().removeClass('hide').addClass('show');
          $this.find('i').removeClass('fas fa-chevron-down').addClass('fas fa-chevron-up');
        }
      })
    });
  }

}

