import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ConfigService } from "../../../core/config/config-svc.service";
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { SharedService } from '../../../shared/shared.service';
import * as $ from 'jquery';

@Injectable({
  providedIn: 'root'
})
export class PersonService {

  personComponentSubject = new Subject<any>();
  personComponent = this.personComponentSubject.asObservable();

  personSubject = new Subject<boolean>();
  person$ = this.personSubject.asObservable();

  formattedAddress;
  serverError = false;
  errorText = '';

  empty = {
    "searchResults": [
      {
        "address": null,
        "threatPersons": [],
        "sourceType": "UNKNOWN"
      }
    ]
  };

  constructor(private http: HttpClient, private sharedService: SharedService) { }

  getHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      withCredentials: true
    };
    return httpOptions;
  }

  public getPersonDetails(address) {

    this.personSubject.next(true);

    this.personComponentSubject.next('');

    const tempAddress = $.extend(true, {}, address);

    this.formattedAddress = this.sharedService.getFormattedAddress(tempAddress);

    this.addressSearchSync(address).subscribe(
      data => {
        this.serverError = false;
        this.errorText = '';
        if (data.searchResults.length > 0) {
          this.personComponentSubject.next(data);

        } else {
          this.personComponentSubject.next(this.empty);
        }

      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.serverError = true;
          this.errorText = error.error["Unknown.Address"];
          if (!this.errorText)
            this.errorText  =  'General error occured. Please try again later.';
          this.personComponentSubject.next(this.empty);
        }

      });
  }


  public addressSearchSync(address) {
    return this.http.post(ConfigService.config.powerdataSearchUrl + '/addressSearchSync', address,
      this.getHeaders()).pipe(map((res: any) => res));

  }

  viewPersonSearchComponent(boolValue) {
    this.personSubject.next(boolValue);
  }

}
