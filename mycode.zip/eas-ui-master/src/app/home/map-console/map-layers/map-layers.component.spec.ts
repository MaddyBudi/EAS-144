import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapLayersComponent } from './map-layers.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../../../login/services/user.service';
import { MapsAPILoader } from '@agm/core';
import { MapLayers } from './mapLayers';

describe('MaplayersComponent', () => {
  let component: MapLayersComponent;
  let fixture: ComponentFixture<MapLayersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MapLayersComponent],
      imports: [BrowserModule,
        FormsModule,
        ReactiveFormsModule],
      providers: [{ provide: MapsAPILoader }, UserService,MapLayers],//inject geoaddress service into create-eas-predefined-location spec.ts file

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapLayersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should disable sensor default', () => {
    expect(component.mapLayers.isSensorVisible).toBeFalsy();
  });

  it('should enable sensor', () => {
    component.changeSensorFilter(true);
    expect(component.mapLayers.isSensorVisible).toBeTruthy();
  });

  it('should enable Filter', () => {
    component.changeEventFilter(true);
    component.changeLocationFilter(true);
    component.changeLawFilter(true);
    component.changeFireFilter(true);
    component.changeMedicalFilter(true);
    component.changeEASUserFilter(true);
    component.changeFieldPersonnelFilter(true);
    component.changeAnnotationFilter(true);
    component.changeHospitalFilter(true);
    component.changeFuleFilter(true);
    component.change311Filter(true);
    component.changeTMCFilter(true);
    component.changeWeartherFilter(true);
    component.changeSensorFilter(true);
    component.changeHydrantFilter(true);
    expect(component.mapLayers.isEventVisible).toBeTruthy ();
    expect(component.mapLayers.isLocationVisible).toBeTruthy ();
    expect(component.mapLayers.isLawVisible).toBeTruthy ();
    expect(component.mapLayers.isFireVisible).toBeTruthy ();
    expect(component.mapLayers.isMedicalVisible).toBeTruthy ();
    expect(component.mapLayers.isEASUsersVisible).toBeTruthy ();
    expect(component.mapLayers.isFieldPersonVisible).toBeTruthy ();
    expect(component.mapLayers.isAnnotationsVisible).toBeTruthy ();
    expect(component.mapLayers.isHospitalVisible).toBeTruthy ();
    expect(component.mapLayers.isFuelVisible).toBeTruthy ();
    expect(component.mapLayers.is311Visible).toBeTruthy ();
    expect(component.mapLayers.isTMCVisible).toBeTruthy ();
    expect(component.mapLayers.isWeatherVisible).toBeTruthy ();
    expect(component.mapLayers.isSensorVisible).toBeTruthy ();
    expect(component.mapLayers.isHydrantVisible).toBeTruthy ();
  });

  it('should disable Filter', () => {
    component.changeEventFilter(false);
    component.changeLocationFilter(false);
    component.changeLawFilter(false);
    component.changeFireFilter(false);
    component.changeMedicalFilter(false);
    component.changeEASUserFilter(false);
    component.changeFieldPersonnelFilter(false);
    component.changeAnnotationFilter(false);
    component.changeHospitalFilter(false);
    component.changeFuleFilter(false);
    component.change311Filter(false);
    component.changeTMCFilter(false);
    component.changeWeartherFilter(false);
    component.changeSensorFilter(false);
    component.changeHydrantFilter(false);
    expect(component.mapLayers.isEventVisible).toBeFalsy();
    expect(component.mapLayers.isLocationVisible).toBeFalsy();
    expect(component.mapLayers.isLawVisible).toBeFalsy();
    expect(component.mapLayers.isFireVisible).toBeFalsy();
    expect(component.mapLayers.isMedicalVisible).toBeFalsy();
    expect(component.mapLayers.isEASUsersVisible).toBeFalsy();
    expect(component.mapLayers.isFieldPersonVisible).toBeFalsy();
    expect(component.mapLayers.isAnnotationsVisible).toBeFalsy();
    expect(component.mapLayers.isHospitalVisible).toBeFalsy();
    expect(component.mapLayers.isFuelVisible).toBeFalsy();
    expect(component.mapLayers.is311Visible).toBeFalsy();
    expect(component.mapLayers.isTMCVisible).toBeFalsy();
    expect(component.mapLayers.isWeatherVisible).toBeFalsy();
    expect(component.mapLayers.isSensorVisible).toBeFalsy();
    expect(component.mapLayers.isHydrantVisible).toBeFalsy();
  });

  
  it('should partially enable and disable Filter', () => {
    component.changeEventFilter(true);
    component.changeLocationFilter(true);
    component.changeLawFilter(true);
    component.changeFireFilter(true);
    component.changeMedicalFilter(true);
    component.changeEASUserFilter(true);
    component.changeFieldPersonnelFilter(true);
    component.changeAnnotationFilter(true);
    component.changeHospitalFilter(true);
    component.changeFuleFilter(false);
    component.change311Filter(false);
    component.changeTMCFilter(false);
    component.changeWeartherFilter(false);
    component.changeSensorFilter(false);
    component.changeHydrantFilter(false);
    expect(component.mapLayers.isEventVisible).toBeTruthy ();
    expect(component.mapLayers.isLocationVisible).toBeTruthy ();
    expect(component.mapLayers.isLawVisible).toBeTruthy ();
    expect(component.mapLayers.isFireVisible).toBeTruthy ();
    expect(component.mapLayers.isMedicalVisible).toBeTruthy ();
    expect(component.mapLayers.isEASUsersVisible).toBeTruthy ();
    expect(component.mapLayers.isFieldPersonVisible).toBeTruthy ();
    expect(component.mapLayers.isAnnotationsVisible).toBeTruthy ();
    expect(component.mapLayers.isHospitalVisible).toBeTruthy ();
    expect(component.mapLayers.isFuelVisible).toBeFalsy ();
    expect(component.mapLayers.is311Visible).toBeFalsy ();
    expect(component.mapLayers.isTMCVisible).toBeFalsy ();
    expect(component.mapLayers.isWeatherVisible).toBeFalsy ();
    expect(component.mapLayers.isSensorVisible).toBeFalsy ();
    expect(component.mapLayers.isHydrantVisible).toBeFalsy ();
  });

});
