import { Component, OnInit } from '@angular/core';
import { MapLayers } from './mapLayers';
import { EasRightSidebarService } from '../eas-right-sidebar/eas-right-sidebar.service';
import { TransactionMeasures} from '../../../transactionMeasures';

@Component({
  selector: 'app-map-layers',
  templateUrl: './map-layers.component.html',
  styleUrls: ['./map-layers.component.scss']
})
export class MapLayersComponent implements OnInit {

  constructor(public mapLayers:MapLayers,private easRightSideBarService:EasRightSidebarService) { }

  ngOnInit() {
    
  }

  changeEventFilter(event){
    this.mapLayers.isEventVisible=event;
  }
  changeLocationFilter(event){
    this.mapLayers.isLocationVisible=event;
  }
  changeLawFilter(event){
    this.mapLayers.isLawVisible=event;
  }
  changeFireFilter(event){
    this.mapLayers.isFireVisible=event;
  }
  changeMedicalFilter(event){
    this.mapLayers.isMedicalVisible=event;
  }
  changeEASUserFilter(event){
    this.mapLayers.isEASUsersVisible=event;
  }
  changeFieldPersonnelFilter(event){
    this.mapLayers.isFieldPersonVisible=event;
  }
  changeAgencyFilter(event){
    this.mapLayers.isAgencyVisible=event;
  }
  changeAnnotationFilter(event){
    this.mapLayers.isAnnotationsVisible=event;
  }
  changeHospitalFilter(event){
    this.mapLayers.isHospitalVisible=event;
  }
  changeFuleFilter(event){
    this.mapLayers.isFuelVisible=event;
  }
  change311Filter(event){
    this.mapLayers.is311Visible=event;
  }
  changeTMCFilter(event){
    this.mapLayers.isTMCVisible=event;
  }

  changeWeartherFilter(event){
    this.mapLayers.isWeatherVisible=event;
  }
  changeSensorFilter(event){
    this.mapLayers.isSensorVisible=event;
  }
  changeHydrantFilter(event){
    this.mapLayers.isHydrantVisible=event;
  }
  onClose() {
    this.easRightSideBarService.toggleSidebarToggle(TransactionMeasures.close);
  }

}
