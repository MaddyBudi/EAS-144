import { TestBed } from '@angular/core/testing';

import { MapLayersService } from './map-layers.service';

describe('MapLayersService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  // it('should be created', () => {
  //   const service: MapLayersService = TestBed.get(MapLayersService);
  //   expect(service).toBeTruthy();
  // });
});
