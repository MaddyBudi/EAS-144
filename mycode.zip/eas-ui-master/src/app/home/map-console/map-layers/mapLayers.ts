export class MapLayers{
    isEventVisible:boolean=true;
    isLocationVisible:boolean=true;
    isLawVisible:boolean=true;
    isFireVisible:boolean=true;
    isMedicalVisible:boolean=true;
    isEASUsersVisible:boolean=true;
    isFieldPersonVisible:boolean=true;
    isAgencyVisible:boolean=true;
    isAnnotationsVisible:boolean=true;
    isHydrantVisible:boolean=true;
    isHospitalVisible:boolean=true;
    isFuelVisible:boolean=true;
    is311Visible:boolean=true;
    isTMCVisible:boolean=true;
    isWeatherVisible:boolean=true;
    isSensorVisible:boolean=false;
}