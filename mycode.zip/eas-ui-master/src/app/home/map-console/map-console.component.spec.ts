import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AgmCoreModule } from '@agm/core';
import { MapConsoleComponent } from './map-console.component';
import { AgmDirectionModule } from 'agm-direction';
import { EasLeftSidebarComponent } from './eas-left-sidebar/eas-left-sidebar.component';
import { EasRightSidebarComponent  } from './eas-right-sidebar/eas-right-sidebar.component';
import { EasEventMoreInformationComponent  } from '../eas-event-more-information/eas-event-more-information.component';

describe('MapConsoleComponent', () => {
  let component: MapConsoleComponent;
  let fixture: ComponentFixture<MapConsoleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports : [
            AgmCoreModule.forRoot(
      { apiKey: 'AIzaSyAsdzEUreLk_wU3PgOrOKqyPmXLrpr_TDA' }),
       AgmDirectionModule
      ],
      declarations: [ MapConsoleComponent, EasLeftSidebarComponent, EasRightSidebarComponent, EasEventMoreInformationComponent ],
      providers : [

      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapConsoleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
