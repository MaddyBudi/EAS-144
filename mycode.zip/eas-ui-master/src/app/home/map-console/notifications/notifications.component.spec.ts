import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotificationsComponent } from './notifications.component';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { MockEasEventsService} from '../../eas-events/eas-mock-events.service';


describe('NotificationsComponent', () => {
  let component: NotificationsComponent;
  let fixture: ComponentFixture<NotificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotificationsComponent ],
      imports: [
        RouterTestingModule,
        HttpClientModule,
      ],
      providers : [
        { provide: EasEventsService, useClass: MockEasEventsService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get all notifications and count should not be zero', (done) => {
     setTimeout(function () {
      expect(component.notifications.length).not.toBe(0);
      done();
    }, 1000);
  });
});
