import { Component, OnInit } from '@angular/core';
import { PanelHeaders } from '../../../panelHeaders';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { SharedService } from '../../../shared/shared.service';
import { EasRightSidebarService } from '../eas-right-sidebar/eas-right-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit {

  panelHeader: string;
  displayFailure = false;
  searchResult = false;
  notifications = [];
  constructor(private easEventsService: EasEventsService, private sharedService: SharedService,
    private easRightSidebarService: EasRightSidebarService) { }

  ngOnInit() {
    this.panelHeader = PanelHeaders.notification;
    this.getNotificationHisory();
  }
  getNotificationHisory() {
    this.displayFailure = false;
    this.searchResult = false;
    this.notifications = [];
    this.easEventsService.getNotifications().subscribe(
      data => {
        data.forEach(element => {
          this.notifications.push(element);
        });
        this.displayFailure = false;
        this.searchResult = true;
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.searchResult = false;
          this.displayFailure = true;
        }
      }
    );
  }
  onClose() {
    this.easRightSidebarService.toggleSidebarToggle(TransactionMeasures.close);
  }
}
