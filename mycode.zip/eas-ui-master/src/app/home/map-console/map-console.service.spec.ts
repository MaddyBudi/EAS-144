import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { MapConsoleService } from './map-console.service';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';

describe('MapConsoleService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
       HttpClientModule,
       RouterTestingModule,
        NotifierModule
        
      ],
  }));

  // it('should be created', () => {
  //   const service: MapConsoleService = TestBed.get(MapConsoleService);
  //   expect(service).toBeTruthy();
  // });
});
