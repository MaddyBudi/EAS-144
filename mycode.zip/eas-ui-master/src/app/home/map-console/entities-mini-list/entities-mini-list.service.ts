import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EntitiesMiniListService {
  closeMoreInformation = new Subject<string>();
  closeMoreInformation$ = this.closeMoreInformation.asObservable();

  cLoseMoreInfoEvents = new Subject<string>();
  cLoseMoreInfoEvents$ = this.cLoseMoreInfoEvents.asObservable();

  cLoseMoreInfoOthers = new Subject<string>();
  cLoseMoreInfoOthers$ = this.cLoseMoreInfoOthers.asObservable();

  closeMoreInfoForLocations = new Subject<string>();
  closeMoreInfoForLocations$ = this.closeMoreInfoForLocations.asObservable();


  clearContext = new Subject<string>();
  clearContext$ = this.clearContext.asObservable();

  constructor() { }
  closeMoreInfo() {
    this.closeMoreInformation.next();
  }
  cLoseMoreInfoEvent() {
    this.cLoseMoreInfoEvents.next();
  }
  cLoseMoreInfoOther() {
    this.cLoseMoreInfoOthers.next();
  }
  closeMoreInfoForLocation() {
    this.closeMoreInfoForLocations.next();
  }
  clearEventContext() {
    this.clearContext.next();
  }
}
