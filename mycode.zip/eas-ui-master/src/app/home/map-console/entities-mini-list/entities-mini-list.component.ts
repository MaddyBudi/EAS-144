import { Component, OnInit, Input } from '@angular/core';
import { EasLeftSidebarService } from '../eas-left-sidebar/eas-left-sidebar.service';
import { MapConsoleService } from '../map-console.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { EasResourcesService } from '../../eas-resources/eas-resources.service';
import { EasPredefinedLocationsService } from '../../eas-predefined-locations/eas-predefined-locations.service';
import { EntitiesMiniListService } from './entities-mini-list.service';
import { SharedService } from '../../../shared/shared.service';
import { DataModel } from '../../../dataModelEnum';
import $ from 'jquery';


@Component({
  selector: 'app-entities-mini-list',
  templateUrl: './entities-mini-list.component.html',
  styleUrls: ['./entities-mini-list.component.scss']
})
export class EntitiesMiniListComponent implements OnInit {
  @Input() entitiesType;
  @Input() contextEventId;
  @Input() contextEventName;
  @Input() contextEventData;
  eventContextId = '';
  easOtherEntitiesData: any;
  actionHeader: string;
  isminiView: boolean;
  isEventInfoPanelOpen: boolean;
  isMoreInfo: boolean
  panelHeader: any;
  openEventData;
  resourceAllData;
  annotationAllData;
  resourceData;
  annotationData;
  resourceAssociateData = [];
  annotationAssociateData = [];
  resourceNotAssociateData = [];
  annotationNotAssociateData = [];
  predefinedLocationData;
  selectedEntityId: string;
  displayFailureRsrc = false;
  displayFailureAnnotation = false;
  failureMsgRsrc = '';
  failureMsgAnnotation = '';
  noResourcesAvailable = 'No Resources available';
  noAnnotationsAvailable = 'No Annotations available';
  eventContextRadioButton = false;
  sortOrder = "desc";
  sortBy = "createdDate";
  isLoading = true;
  selectedLocationId;
  selectedEntity;
  constructor(private easleftSideBarService: EasLeftSidebarService, private mapConsoleService: MapConsoleService,
    public eventSvc: EasEventsService, private easResourceService: EasResourcesService, private easPredefinedLocationService: EasPredefinedLocationsService, private entitiesService: EntitiesMiniListService, private sharedService: SharedService) { }

  ngOnInit() {
    this.isminiView = true;
    this.actionHeader = PanelHeaders.miniView;
    this.isEventInfoPanelOpen = false
    this.isMoreInfo = false;
    this.panelHeader = PanelHeaders;
    this.serviceCallData();
    this.entitiesService.closeMoreInformation$.subscribe(
      data => {
        this.isMoreInfo = false;
        this.selectedEntityId = undefined;
        this.easOtherEntitiesData = undefined;
        this.selectedLocationId = undefined;
        this.selectedEntity = undefined;
      }
    );
    this.entitiesService.cLoseMoreInfoEvents$.subscribe(
      data => {
        this.selectedEntityId = undefined;
        this.mapConsoleService.isMoreInfoOpen.next(false);
      }
    );
    this.entitiesService.cLoseMoreInfoOthers$.subscribe(
      data => {
        this.isMoreInfo = false;
        this.easOtherEntitiesData = undefined;
        this.mapConsoleService.isMoreInfoOpen.next(false);
      }
    );
    this.entitiesService.clearContext$.subscribe(
      data => {
        this.eventContextRadioButton = false;
        console.log($('#allEvents').prop('checked', true));
        this.displayFailureRsrc = false;
        this.displayFailureAnnotation = false;
        this.resourceData = this.resourceAllData.slice();
        this.annotationData = this.annotationAllData.slice();
      }
    );
    this.entitiesService.closeMoreInfoForLocations$.subscribe(
      data => {
        this.selectedLocationId = undefined;
        this.mapConsoleService.isMoreInfoOpen.next(false);
      }
    );
  }
  ngOnChanges(changes: any) {
    if (changes.hasOwnProperty("contextEventId")) {
      if (changes.contextEventId.currentValue !== '') {
        this.eventContextRadioButton = true;
      }
    }
  }
  onExpand() {
    if (this.isMoreInfo)
      this.onCloseInfo()
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
    this.easleftSideBarService.changeEntitiesListTypes(this.entitiesType);
    this.isminiView = false;

  }
  onCompress() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.miniView);
    this.isminiView = true;
    this.actionHeader = PanelHeaders.miniView;
    this.isMoreInfo = false;
  }

  onClose() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }
  onOpenInfo(item) {
    this.setSelectedEntity(item);
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
    let properties = {
      payload: {
        properties: item
      }
    };
    if (item.type === 'Predefined Location') {
      this.easOtherEntitiesData = {
        dataEntityId: item.id,
        dataModel: DataModel.location,
        payLoad: properties
      };
    } else if (item.dataModel === DataModel.event) {
      this.selectedEntityId = item.entityId;
    } else {
      this.easOtherEntitiesData = {
        dataEntityId: item.entityId,
        dataModel: item.dataModel === DataModel.resource ? item.resourceObject : item.dataModel,
        payLoad: properties
      };
    }
    this.isMoreInfo = true;
    this.mapConsoleService.isMoreInfoOpen.next(true);
  }
  setSelectedEntity(item) {
    console.log(item)
    if (item.type === 'Predefined Location') {
      this.selectedEntity = item.id;
    } else {
      this.selectedEntity = item.entityId;
    }
  }
  onCloseInfo() {
    if (this.isminiView)
      this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.miniView);
    else
      this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);

    this.isMoreInfo = false;
  }
  serviceCallData() {
    this.eventSvc.getAllEvents().subscribe(
      eventData => {
        this.isLoading = false;
        this.setEventData(eventData);
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        }
      });

    this.easResourceService.getAllResources().subscribe(
      resourceData => {
        this.isLoading = false;
        this.setResourceData(resourceData);
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        }
      }
    );

    this.easPredefinedLocationService.getPredefinedLocations().subscribe(
      locationData => {
        this.isLoading = false;
        this.setPredifinedLocation(locationData);

      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        }
      });
  }

  setEventData(data) {
    const tempEventArray = [];
    this.openEventData = [];

    data.forEach(element => {
      if (element.entityId != null && element.type === "Event") {


        if (element.status != null) {
          if (element.status === "STARTED" && element.deleted === false) {
            element.eventStatusId = "4";
          }
          if (element.status === "TERMINATED" && element.deleted === false) {
            element.eventStatusId = "3";
          }
          if (element.status === "STARTED" && element.deleted === true) {
            element.eventStatusId = "2";
          }
          if (element.status === "TERMINATED" && element.deleted === true) {
            element.eventStatusId = "1";
          }
        }
        tempEventArray.push(element);
        if (element.status === 'STARTED' && element.deleted === false) {
          this.openEventData.push(element);
        }
      }
    });

  }

  setResourceData(data) {
    this.resourceAllData = [];
    this.annotationAllData = [];

    data.forEach(element => {

      if (element.entityId != null) {
        if (element.resourceObject !== DataModel.annotation) {
          this.resourceAllData.push(element);
        } else {
          this.annotationAllData.push(element);
        }
      }

    });
    this.dataBind();
  }
  setPredifinedLocation(data) {
    this.predefinedLocationData = [];
    data.forEach(element => {
      if (element.id != null) {
        this.predefinedLocationData.push(element);
      }
    });
  }
  dataBind() {
    this.resourceData = [];
    this.annotationData = [];
    this.resourceData = this.resourceAllData.slice();
    this.annotationData = this.annotationAllData.slice();
    if (this.resourceData.length === 0) {
      this.displayFailureRsrc = true;
      this.failureMsgRsrc = this.noResourcesAvailable;
    }
    if (this.annotationData.length === 0) {
      this.displayFailureAnnotation = true;
      this.failureMsgAnnotation = this.noAnnotationsAvailable;
    }
  }
  viewMapEntities(data) {
    if (typeof data.geometry !== "object")
      data.geometry = JSON.parse(data.geometry);
    const properties = {
      eventName: data.eventName
    };
    data.properties = properties;
    data.coordinates = data.geometry.coordinates;
    const entityData = this.sharedService.formPayloadForEntitiesMoreInfo([data], false, false);
    this.mapConsoleService.viewMapEntitiesMap(entityData);
  }
  onViewChange(data) {
    const entitiesData = this.sharedService.formPayloadForEntitiesMoreInfo([data], false, false);
    this.mapConsoleService.viewMapLocationMap(entitiesData);
  }
  getAssignedResources() {
    this.resourceAssociateData = [];
    this.resourceNotAssociateData = [];
    this.resourceAllData.forEach(data => {
      if (data.hasOwnProperty('assignedTo')) {

        if (data.assignedTo === this.contextEventId) {
          this.resourceAssociateData.push(data);
        }
        if (data.assignedTo !== this.contextEventId) {
          this.resourceNotAssociateData.push(data);
        }

      }
    });
  }
  getAssignedAnnotations() {
    this.annotationAssociateData = [];
    this.annotationNotAssociateData = [];
    this.annotationAllData.forEach(data => {
      if (data.hasOwnProperty('assignedTo')) {

        if (data.assignedTo === this.contextEventId) {
          this.annotationAssociateData.push(data);
        }
        if (data.assignedTo !== this.contextEventId) {
          this.annotationNotAssociateData.push(data);
        }
      }
    })
  }

  handleChange(event) {
    this.displayFailureRsrc = false;
    this.displayFailureAnnotation = false;
    this.resourceData = [];
    this.annotationData = [];
    this.getAssignedResources();
    this.getAssignedAnnotations();
    if (event.target.id === 'currentEvent') {
      this.resourceData = this.resourceAssociateData.slice();
      this.annotationData = this.annotationAssociateData.slice();
    } else if (event.target.id === 'allEvents') {
      this.resourceData = this.resourceAllData.slice();
      this.annotationData = this.annotationAllData.slice();
    } else if (event.target.id === 'notAssignedToEvent') {
      this.resourceData = this.resourceNotAssociateData.slice();
      this.annotationData = this.annotationNotAssociateData.slice();
    }
    if (this.resourceData.length === 0) {
      this.displayFailureRsrc = true;
      this.failureMsgRsrc = this.noResourcesAvailable;
    }
    if (this.annotationData.length === 0) {
      this.displayFailureAnnotation = true;
      this.failureMsgAnnotation = this.noAnnotationsAvailable;
    }
  }
}
