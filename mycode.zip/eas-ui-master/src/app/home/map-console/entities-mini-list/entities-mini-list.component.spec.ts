import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EntitiesMiniListComponent } from './entities-mini-list.component';

describe('EntitiesMiniListComponent', () => {
  let component: EntitiesMiniListComponent;
  let fixture: ComponentFixture<EntitiesMiniListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EntitiesMiniListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EntitiesMiniListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
