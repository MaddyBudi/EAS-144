import { TestBed } from '@angular/core/testing';

import { EntitiesMiniListService } from './entities-mini-list.service';

describe('EntitiesMiniListService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  // it('should be created', () => {
  //   const service: EntitiesMiniListService = TestBed.get(EntitiesMiniListService);
  //   expect(service).toBeTruthy();
  // });
});
