import { TestBed } from '@angular/core/testing';

import { MsdsService } from './msds.service';

describe('MsdsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  // it('should be created', () => {
  //   const service: MsdsService = TestBed.get(MsdsService);
  //   expect(service).toBeTruthy();
  // });
});
