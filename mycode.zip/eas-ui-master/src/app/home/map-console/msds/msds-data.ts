export class MsdsData {    
      constructor() {}
    public Name: string;
    public CAS_Number: string;
    public drugInfo: string;
    public idlh: string;
}

