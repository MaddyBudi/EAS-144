import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {ConfigService} from "../../../core/config/config-svc.service";
import {EasEventsService} from '../../eas-events/eas-events.service';
import { AppGlobals } from '../../../shared/app.globals';

@Injectable({
  providedIn: 'root'
})
export class MsdsService {
  successMessage;
  constructor(public http:HttpClient,public eventSvc:EasEventsService,public appGlobals:AppGlobals) { }
  getHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All'
      }),
      withCredentials: true
    };
    return httpOptions;
  }
  getMSDSData(chemicalName){
    return this.http.get(ConfigService.config.eventServiceUrl+this.appGlobals.getMSDSDataEndpoint
    +chemicalName, this.getHeaders()).pipe(map((res: any) => res));
  }
//   updateEventWithMSDSKeyword(eventData,msdsKeywords,socialMediaKeywords){
       
//   }
}
