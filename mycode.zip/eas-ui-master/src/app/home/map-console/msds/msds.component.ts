import { Component, OnInit,Input } from '@angular/core';
import { TransactionMeasures } from '../../../transactionMeasures';
import * as $ from 'jquery';
import { PanelHeaders } from '../../../panelHeaders';
import { FormGroup, FormBuilder, Validators, FormControl, FormsModule } from '@angular/forms';
import { MsdsService } from './msds.service';
import { SharedService } from '../../../shared/shared.service';
import { AppGlobals } from '../../../shared/app.globals';
import { EasEventsService } from '../../eas-events/eas-events.service';
import {MsdsData} from './msds-data';
import { EasLeftSidebarService } from '../eas-left-sidebar/eas-left-sidebar.service';
import { MapConsoleService } from '../map-console.service';
const swal = require('sweetalert');
let controller;
@Component({
  selector: 'app-msds',
  templateUrl: './msds.component.html',
  styleUrls: ['./msds.component.scss']
})
export class MsdsComponent implements OnInit {
  @Input() contextEventData: any;
  panelHeader: any;
  msdsForm =  new FormGroup({
    msdsk: new FormControl()
  });
msdsData={};// to store data from service
public mappedData= new MsdsData();
showMSDSData; // flag to controla a div
msdsKeywordsFromEvent;
msdsKeys=[];
eventData;
successMessage;
failureMessage;
displaySuccessMessage;
displayFailureMessage;
displayLoading;
constructor(public formGroup:FormBuilder,public msdsSvc:MsdsService,public sharedSvc:SharedService,
public eventSvc:EasEventsService,private appglobals: AppGlobals,private easLeftSideBarPanelService:EasLeftSidebarService,private mapConsoleService:MapConsoleService) {
  this.panelHeader = PanelHeaders;
}



  ngOnInit() {
    controller=this;
    if(this.contextEventData.properties.hasOwnProperty('msdsKeywords')){
    this.msdsKeywordsFromEvent=this.contextEventData.properties.msdsKeywords;
      if (this.msdsKeywordsFromEvent) {
            for(const key of Object.keys(this.msdsKeywordsFromEvent)){
              this.msdsKeys.push(this.msdsKeywordsFromEvent[key]);
            }
      }
    }else{
      this.msdsKeywordsFromEvent={};
    }
    this.msdsForm = this.formGroup.group({
      'msdsk' : [this.msdsKeys[0],Validators.required]
    });
    this.displayMSDSKDataListValues();
  }
  getMSDSData(){
    this.showMSDSData=false;
     this.displayFailureMessage=false;
      this.displaySuccessMessage=false;
    event.preventDefault();
    for (const c in this.msdsForm.controls) {
      if(this.msdsForm.controls.hasOwnProperty(c)){
      this.msdsForm.controls[c].markAsTouched();
      }
    }
   if(this.msdsForm.valid){
      this.displayLoading=true;
    this.msdsSvc.getMSDSData(this.msdsForm.get('msdsk').value).subscribe(
    data => {
      if(null !== data){
        this.displayLoading=false;
        this.showMSDSData=true;
        this.msdsData=data;
        this.checkMoreClassVisbility();
        console.log(this.msdsKeys);
        const regex = new RegExp( this.msdsKeys.join( "|" ), "i");
        console.log(regex);
        //  if(!regex.test( this.msdsForm.get('msdsk').value)|| this.msdsKeys.length===0 ){
        //   this.pushToEvent();
        //  }

    if(-1 === this.msdsKeys.findIndex(item => this.msdsForm.get('msdsk').value.toLowerCase() === item.toLowerCase()) ||
     this.msdsKeys.length===0){
      this.pushToEvent();
    }
    }else{
        this.displayLoading=false;
        this.displayFailureMessage=true;
        this.failureMessage="No data found for entered MSDS keyword";
      }
    },
    error => {
       if (error.status === 401) {
        this.sharedSvc.routeToLoginError(error.status);
      }else{
        this.displayLoading=false;
        this.displayFailureMessage=true;
        this.failureMessage="Unable to get MSDS data.Please try again later.";
      }
    });
    }
  }

// reset functionality
resetMSDSPage(){
   this.displayLoading=false;
  this.showMSDSData=false;
 this.msdsForm = this.formGroup.group({
      'msdsk' : ['']
    });
    this.displayFailureMessage=false;
    this.displaySuccessMessage=false;
}
// contains code to render
// 1.renders HTML tags from json response
// 2.Show More/Less
checkMoreClassVisbility () {
  console.log(controller.msdsData);
  if($('.more').is(':visible')){
    // 1.HTML tags from json response
    for(const key of Object.keys(controller.msdsData)){
      if(null ==controller.msdsData[key]){
       $('#'+key)[0].innerHTML='-';
      }else{
       $('#'+key)[0].innerHTML=controller.msdsData[key];
      }
    }
    Array.from(document.querySelectorAll(".msdsDiv a")).forEach(function(a){
      a.setAttribute('target', '_blank');
    });
    // 2.Show More/Less
    // controller.sharedSvc.showMoreLess();
  } else {
    setTimeout(this.checkMoreClassVisbility, 50);
  }
}
pushToEvent(){
  // let r;
  // if(!this.msdsKeys.includes(this.msdsForm.get('msdsk').value)){
  //   r = confirm("Do you want to push the keyword to Event?");
  // }
  this.sharedSvc.showYesNoAlert("Push Keyword to event ", 'Push', swalCallback, 'No, Cancel');
console.log(controller.msdsKeys[0])
    function swalCallback(yesNo) {
      if (yesNo) {
        if(controller.msdsKeys.length===0 || controller.msdsKeys[0] === '') {
          controller.contextEventData.properties.msdsKeywords={};
        }
          controller.contextEventData.properties.msdsKeywords[controller.msdsKeys.length]=controller.msdsForm.get('msdsk').value;
          controller.eventSvc.getEventDetails(controller.contextEventData.entityId).subscribe(
          data => {
            controller.eventSvc.updateEventWithMSDSandSocialMediaKeywords(data,controller.contextEventData.properties.msdsKeywords,
            controller.contextEventData.properties.socialMediaKeywords).subscribe(
            response =>{
              if(response){
              controller.displayLoading=false;
              controller.displaySuccessMessage=true;
              controller.successMessage=controller.appglobals.msdsPushToEventSuccess;
              }else {
              swal('Not Pushed!', response.status, 'Failure');
            }
            },error =>{
              if (error.status === 401) {
                      controller.sharedSvc.routeToLoginError(error.status);
              }else{
                    swal('Not Pushed!', "Please try again", 'Failure');
                    controller.displayFailureMessage=false;
                    controller.displayLoading=false;
                    controller.failureMessage=controller.appglobals.msdsPushToEventFailure;
                  }
            }
        );
      },
      error => {

      }
    );
      }
    }

}
displayMSDSKDataListValues(){
  function putValueBackFromPlaceholder() {
        var $this = $('#msdsk');
        if ($this.val() === '') {
            $this.val($this.attr('placeholder'));
            $this.attr('placeholder','');
        }
    }

    $('#msdsk')
        .on('click', function(e) {
            var $this = $(this);
            var inpLeft = $this.offset().left;
            var inpWidth = $this.width();
            var clickedLeft = e.clientX;
            var clickedInInpLeft = clickedLeft - inpLeft;
            var arrowBtnWidth = 12;
            if ((inpWidth - clickedInInpLeft) < arrowBtnWidth ) {
                $this.attr('placeholder',$this.val());
                $this.val('');
            }
            else {
                putValueBackFromPlaceholder();
            }
        })
        .on('mouseleave', putValueBackFromPlaceholder);
}
onClose(){
  this.easLeftSideBarPanelService.toggleSidebarToggle(TransactionMeasures.close);
  this.mapConsoleService.closeSideBar();
}
}
