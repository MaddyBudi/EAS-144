import { Component, OnInit, Input } from '@angular/core';
import {SensorService} from './sensor.service';
import { SharedService } from '../../../shared/shared.service';
import { AppGlobals } from '../../../shared/app.globals';
@Component({
  selector: 'app-sensor',
  templateUrl: './sensor.component.html',
  styleUrls: ['./sensor.component.scss']
})
export class SensorComponent implements OnInit {
@Input() sensorProvideEntityId: any;
historicalData;
showHistory;
displayFailureMessage;
failureMessage;
  constructor(public sensorSvc: SensorService, public sharedService: SharedService, public appGlobals: AppGlobals) { }

  ngOnInit() {
    console.log("sensor data")
    console.log(this.sensorProvideEntityId)
    // this.sensorSvc.getHistoricalData(this.sensorProvideEntityId).subscribe(
      this.sensorSvc.getHistoricalData().subscribe(
        data => {
          if (null !== data) {
            this.historicalData = data;
            this.showHistory = true;
            this.displayFailureMessage = false;
          } else {
            this.displayFailureMessage = true;
            this.failureMessage = this.appGlobals.noSensorHistoryFoundMsg;
          }
        },
        error => {
          if (error.status === 401) {
                    this.sharedService.routeToLoginError(error.status);
          } else {
            this.displayFailureMessage = true;
            this.failureMessage = this.appGlobals.fetchSensorHistoryFailureMsg;
          }
        }
      );
  }

}
