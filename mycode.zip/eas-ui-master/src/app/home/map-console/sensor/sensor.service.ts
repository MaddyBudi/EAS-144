import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {ConfigService} from '../../../core/config/config-svc.service';
import { AppGlobals } from '../../../shared/app.globals';
@Injectable({
  providedIn: 'root'
})
export class SensorService {

  constructor(public http: HttpClient, public appGlobals: AppGlobals) { }
    getHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All'
      }),
      withCredentials: true
    };
    return httpOptions;
  }
  public getHistoricalData() {
   return this.http.get(ConfigService.config.sensorServiceUrl + this.appGlobals.sensorHistoryEndpoint,
    this.getHeaders()).pipe(map((res: any) => res));
  }
  public getSensorByEntityID(id) {
   return this.http.get(ConfigService.config.sensorServiceUrl + this.appGlobals.getSensorEndpoint + '/' + id,
    this.getHeaders()).pipe(map((res: any) => res));
  }
  public updateSensorStatus(newStatus, id) {
    const payload =  newStatus;
    
   return this.http.put(ConfigService.config.sensorServiceUrl + this.appGlobals.getSensorEndpoint + '/' + id, payload,
    this.getHeaders()).pipe(map((res: any) => res));
  }
}
