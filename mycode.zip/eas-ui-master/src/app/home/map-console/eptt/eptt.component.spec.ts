// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { Component, OnInit, Inject, forwardRef, Input, NgZone } from '@angular/core';
// import { EasRightSidebarService } from '../eas-right-sidebar/eas-right-sidebar.service';
// import { EpttComponent } from './eptt.component';
// import { DebugElement } from '@angular/core';
// import { MapConsoleService } from '../map-console.service';
// import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
// import { element } from 'protractor';
// import { EpttService } from '../eptt/eptt.service';
// import { UserService } from '../../../login/services/user.service';
// import { ToastrService } from 'ngx-toastr';
// import { ToastrModule } from 'ngx-toastr';
// import { DatePipe } from '@angular/common';
// import { BrowserModule } from '@angular/platform-browser';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { HttpClientModule } from '@angular/common/http';
// import { RouterTestingModule } from '@angular/router/testing';
// import { NotifierModule } from 'angular-notifier';
// import { EasResourcesService } from '../../eas-resources/eas-resources.service';
// import { ResourceMockService } from '../../eas-resources/eas-mock-resources.service';

// describe('EpttComponent', () => {
//   let component: EpttComponent;
//   let fixture: ComponentFixture<EpttComponent>;
//   var originalTimeout;
//   let debugElement: DebugElement;
//   let epttService: EpttService;
//   let userService: UserService;
//   let easResourcesService: EasResourcesService;
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [EpttComponent],
//       imports: [
//         BrowserModule,
//         FormsModule,
//         ReactiveFormsModule,
//         HttpClientModule,
//         RouterTestingModule,
//         NotifierModule,
//         ToastrModule.forRoot()
//       ],
//       providers: [{ provide: EasResourcesService, useClass: ResourceMockService }, EasRightSidebarService, DatePipe, ToastrService, UserService],
//     })
//       .compileComponents().then(() => {
//         fixture = TestBed.createComponent(EpttComponent);
//         component = fixture.componentInstance;
//         epttService = TestBed.get(EpttService);
//         userService = TestBed.get(UserService);
//         easResourcesService = TestBed.get(EasResourcesService);
//       });
//   }));

//   beforeEach(() => {
//     epttService.loadEPTTPlugin();
//     originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
//     jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
//     userService.epttUser_mdn = '14343434344';
//     userService.epttUser_accessToken = 'BW7IMl6';
//     userService.epttUser_clientType = 'WEBCLIENTTYPE.THIRD_PARTY_DISPATCHER_CLIENT';
//   });
//   afterEach(() => {
//     jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
//   });

//   it('True if the component is created and the user is logging in successfully', (done) => {
//     setTimeout(() => {
//       fixture.detectChanges();
//       expect(component).toBeTruthy();
//       done();
//     }, 5000);
//   });

//   it('True if user name for the user is obtained'), () => {
//     expect(component.SelfName).toBeTruthy();
//   }


//   it('True if the contacts are fetched for that user'), () => {
//     expect(component.contacts).toBeTruthy;
//   }

//   it('True if the groups are fetched for that user'), () => {
//     expect(component.groups).toBeTruthy;
//   }

//   it('True if user has logged out successfully'), () => {
//     component.logoutEPTT();
//     expect(component).toBeFalsy();
//   }
// });
