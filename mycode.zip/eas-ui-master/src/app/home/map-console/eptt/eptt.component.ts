import { EasRightSidebarService } from '../eas-right-sidebar/eas-right-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { Component, OnInit, Inject, forwardRef, Input, NgZone } from '@angular/core';
import { MapConsoleService } from '../map-console.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { environment } from '../../../../environments/environment';
import * as $ from 'jquery';
import { element } from 'protractor';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import { EpttService } from '../eptt/eptt.service';
import { UserService } from '../../../login/services/user.service';
import { EasResourcesService } from '../../eas-resources/eas-resources.service';
import { promise } from 'protractor';

let logInStatus;
declare let KNCallBackMgr: any;
declare let LOGINSTATUS: any;
declare let KNPoC: any;
declare let SETUPSTATUS: any;
declare let KNTGScMgr;
declare let GETSTATUS: any;
declare let KNCntGrpMgr;
declare let WEBCLIENTTYPE: any;
declare let KNCallMgr: any;
declare let KNLocationMgr: any;
declare let ODLSTATUS: any;
declare let TGSCSTATUS: any;
declare let RECORDINGSTATUS: any;
declare let SETSTATUS: any;
declare let MODE: any;
const plotLocations = [];
let controller;
// const map: any = '';
declare let google: any;

@Component({
  selector: 'app-eptt',
  templateUrl: './eptt.component.html',
  styleUrls: ['./eptt.component.scss']
})

export class EpttComponent implements OnInit {
  panelHeader: string;
  @Input() map;
  pTTuserId;
  pTTaccessToken;
  pTTClientType;
  public PluginVersion = true;
  public nStatus = false;
  public isLogout = false;
  public loginFailed = false;
  public availabilityStatus = '2';
  public contacts = [];
  public statusIndicator: any;
  public status: any;
  public displayLoginInprogressMessage = false;
  public SelfName;
  public talkerGroupScanOn = false;
  public lowPriority: number;
  public highPriority: number;
  public normalPriorityValue: string;
  public tgsPriority;
  public tgscUpdatedList = [];
  public contactStatus = false;
  public onDemandcontacts = [];
  public onDemandSelectedContactsList = [];
  public isContactsAvailable = false;
  public groups = [];
  public isGroupsAvailable = false;
  public selectedContacts = [];
  public groupMembers = [];
  public noSelectionMsg = false;
  public outgoingCallMDN: string;
  public outgoingCallerName: string;
  public showUserDetails = false;
  public enableEpttWidget: boolean;
  public one_to_oneCall = false;
  public groupCall = false;
  public broadcastCall = false;
  public missedCall = false;
  public disableMainMenu = false;
  public showAlert = false;
  public currentCallPanel: string;
  public enableGroupMembers = false;
  public selectedGroup: any;
  public enableAdhocCallContent = false;
  public isMissedCallAvailable = false;
  public notificationList = [];
  public callEndReason = false;
  public callReasonText: String;
  public loading = false;
  public callStatus = 'Idle';
  public indicatorStyle = 'warning';
  public globalsessionId;
  public callStatusInfo = '';
  public tGSCMode;
  public missedCallMDN: string;
  public GrpmissedCallobj: any;
  public missedCallType: string;
  public showAlertAdhoc = false;
  public displayAdhocCall = false;
  public invalidAdhocMdn = false;
  public currentTab = 'contacts';
  public mainMenuIcons = 'enableContacts';
  selectedAll = false;
  groupsInTgscPanel: any;
  public sign = 'PTT_Idle_ocean';
  public geoMDNList: any;
  ipaObject: any;
  adhocMDN: string;
  OdlUserName: string;
  public isAdhocSeflCallInitiated = false;
  public isGeoCall = false;
  public isSingleContact = false;
  adhocCallForm = new FormGroup({
    adhocMdn: new FormControl()
  });
  onDemandLocationForm: FormGroup;
  displayOnDemandconfig = false;
  interval: String = environment.OnDemandLocationInterval;
  duration: String = environment.OnDemandLocationDuration;
  odlConfig: any;
  intervalLimitWarning: String;
  durationLimitWarning: String;
  invalidInterval = false;
  invalidDuration = false;
  displayUserName = '';
  public onDemandSelectionWarning = false;
  public epttUsersOnMap = [];
  geocallContacts;
  geoAlertContact;
  constructor(private easRightSideBarService: EasRightSidebarService, public mapConsoleService: MapConsoleService,

    public toastr: ToastrService, public datePipe: DatePipe, public formBuilder: FormBuilder, public epttService: EpttService,
    private easResourcesService: EasResourcesService,
    private userService: UserService, public ngZone: NgZone) {
    controller = this;
    this.onDemandLocationForm = this.formBuilder.group({
      'interval': [this.interval, Validators.required],
      'duration': [this.duration, Validators.required]
    });
    this.geocallContacts = this.epttService.selectedUsers;
    this.geoAlertContact = this.epttService.selectedUsersAlert;
  }

  ngOnInit() {
    this.panelHeader = PanelHeaders.eptt;
    this.statusIndicator = 'success';
    this.status = 'Available';
    this.displayLoginInprogressMessage = true;
    this.loading = true;
    this.pTTuserId = this.userService.epttUser_mdn;
    this.pTTaccessToken = this.userService.epttUser_accessToken;
    if (this.userService.epttUser_clientType === 'WEBCLIENTTYPE.THIRD_PARTY_DISPATCHER_CLIENT') {
      this.pTTClientType = '2';
    } else if (this.userService.epttUser_clientType === 'WEBCLIENTTYPE.THIRD_PARTY_POC_CLIENT') {
      this.pTTClientType = '1';
    }
    this.initializeEPTTCallBack();
    if (this.epttService.initiateEpttLogin) {
      this.loginEPTT();
    } else {
      this.displayLoginInprogressMessage = false;
      this.loginFailed = false;
      this.isLogout = false;
      this.knPocConfig();
      this.loading = false;
      this.enableAdhocCallContent = true;
      this.contactStatus = true;
      this.getAllContacts();
      this.getAllGroups();
      if ((this.epttService.displayCallPanel === true) && (this.currentCallPanel = 'private')) {
        this.disableMainMenu = true;
        this.mainMenuIcons = 'enableCall';
        this.epttService.displayCallPanel = false;
        this.sign = 'PTT_Floor_Taken';
        this.indicatorStyle = 'info';
        this.displayUserName = this.epttService.callingUser;
      } else if ((this.epttService.displayCallPanel === true) && (this.currentCallPanel = 'group')) {
        this.disableMainMenu = true;
        this.mainMenuIcons = 'enableCall';
        this.epttService.displayCallPanel = false;
        this.sign = 'PTT_Floor_Taken';
        this.indicatorStyle = 'info';
        this.selectedGroup = this.epttService.callingGroup;
      }
    }
  }
  onClose() {
    this.geocallContacts = [];
    this.epttService.setSelectedUsers([]);
    this.easRightSideBarService.toggleSidebarToggle(TransactionMeasures.close);
  }

  showDropDown() {
    $('#epttStatusList').css('display', 'block');
  }
  hideStatusInfo() {
    $('#epttStatusList').css('display', 'none');
  }
  changeStatus(status) {
    let statusCodeJson;
    $('#epttStatusList').css('display', 'none');
    if (status === 'success') {
      this.status = 'Available';
      statusCodeJson = { 'availabilityStatus': 2 };
    } else {
      this.status = 'Do Not Disturb';
      statusCodeJson = { 'availabilityStatus': 3 };
    }
    this.statusIndicator = status;
    console.log('Set availability status');
    KNPoC.setAvailabilityStatus(statusCodeJson);

  }
  setContacts(clicked: boolean) {
    this.currentTab = 'contacts';
    this.mainMenuIcons = 'enableContacts';
    for (let i = 0; i < this.contacts.length; i++) {
      this.contacts[i].selected = false;
    }
  }
  setGroups(clicked: boolean) {
    this.currentTab = 'groups';
    this.mainMenuIcons = 'enableGroups';
    for (let i = 0; i < this.groups.length; i++) {
      this.groups[i].selected = false;
    }
  }
  setHistory(clicked: boolean) {
    this.currentTab = 'history';
    this.mainMenuIcons = 'enableHistory';
  }
  setTGS(clicked: boolean) {
    this.currentTab = 'tgs';
    this.mainMenuIcons = 'enableTGS';
  }
  setOnDemandLocation(clicked: boolean) {
    this.currentTab = 'odl';
    this.mainMenuIcons = 'enableOnDemandLocation';
  }
  isAvailable() {
    const status = ((this.status === 'Available') ? true : false);
    return status;
  }
  selectAll() {
    this.contacts.forEach(contact => {
      contact.selected = this.selectedAll;
    });
    this.updateSelectionContact(true);
  }
  checkIfAllSelected() {
    this.selectedAll = this.contacts.every(function (item: any) {
      return item.selected === true;
    });
  }
  updateSelectionContact(contact: any) {
    if (contact === true) {
      if (this.selectedAll === true) {
        this.selectedContacts = this.contacts;
      } else {
        this.selectedContacts = [];
      }
    } else {
      const selectedMdn = contact.mdn;
      if ($('#' + selectedMdn).is(':checked')) {
        this.selectedContacts.push(contact);
        this.displayUserName = contact.name;
        contact.selected = false;
      } else {
        this.selectedContacts = this.selectedContacts.filter(eachContact => eachContact.mdn !== selectedMdn);
      }
    }
    this.isSingleContact = ((this.selectedContacts.length > 1) ? false : true);
    console.log(this.selectedContacts);
    this.noSelectionMsg = false;
  }
  makeCall(panelName: string) {
    if (panelName === 'contact') {
      if (this.selectedContacts.length > 0) {
        console.log('Private Call');
        this.one_to_oneCall = true;
        this.disableMainMenu = true;
        this.mainMenuIcons = 'enableCall';
        this.showAlert = true;
        this.currentCallPanel = 'private';
        if (this.selectedAll = true) {
          this.selectedAll = false;
          this.contacts.forEach(contact => {
            contact.selected = false;
          });
        }
        if (this.selectedContacts.length === 1) {
          this.outgoingCallMDN = this.selectedContacts[0].mdn;
          this.outgoingCallerName = this.selectedContacts[0].name;
        }
      } else {
        this.noSelectionMsg = true;
      }
    } else if (panelName === 'geocall') {
      this.isGeoCall = true;
      this.disableMainMenu = true;
      this.mainMenuIcons = 'enableCall';
      this.currentCallPanel = 'private';
      this.displayUserName = this.OdlUserName;
    }
  }
  endCall(calledFrom: string) {
    this.currentTab = 'contacts';
    this.mainMenuIcons = 'enableContacts';
    this.geocallContacts = [];
    this.epttService.setSelectedUsers([]);
    KNCallMgr.endcall();
  }
  acquireFloor() {
    if (this.one_to_oneCall) {
      console.log('........initiate the private call.............');
      this.one_to_oneCall = false;
      const jsonData = [];
      this.selectedContacts.forEach((contact) => {
        const callJson = { 'phoneNumber': contact.mdn };
        jsonData.push(callJson);
      });
      console.log('call to the following...........');
      console.log(jsonData);
      KNCallMgr.makeCall(jsonData);
      console.log('in acquirefloor method');
    } else if (this.groupCall) {
      this.groupCall = false;
      console.log('calling to the following group...........');
      const groupIdJson = { 'groupId': this.selectedGroup.groupId };
      KNCallMgr.makeGroupCall(groupIdJson);
    } else if (this.broadcastCall) {
      this.broadcastCall = false;
      console.log('broadcast calling to the following group...........');
      const groupIdJson = { 'groupId': this.selectedGroup.groupId };
      console.log(groupIdJson);
      KNCallMgr.makeBroadcastCall(groupIdJson);
    } else if (this.missedCall) {
      this.missedCall = false;
      if (this.missedCallType === 'privateMissedCall') {
        const callJson = [{ 'phoneNumber': this.missedCallMDN }];
        console.log('callback to the private missedcall...........');
        console.log(callJson);
        KNCallMgr.makeCall(callJson);
      } else if (this.missedCallType === 'groupMissedCall') {
        const missedCallGroupId = this.GrpmissedCallobj.groupId;
        const missedCallSessionID = this.GrpmissedCallobj.sessionId;
        const joinGrpCallJson = { 'groupId': missedCallGroupId, 'callSessionId': missedCallSessionID };
        console.log('Calling back to the group missed call');
        console.log(joinGrpCallJson);
        KNCallMgr.joinGroupCall(joinGrpCallJson);
      }
    } else if (this.isGeoCall) {

      console.log('........initiate the geo call.............');
      this.isGeoCall = false;
      let jsonData = [];
      jsonData = this.geoMDNList;
      console.log('call to the following...........');
      console.log(jsonData);
      KNCallMgr.makeCall(jsonData);
      this.geoMDNList = [];
    }
    this.sign = 'PTT_Floor_Aquired';
    this.callStatus = 'You';
    this.indicatorStyle = 'green';
    KNCallMgr.acquireFloor();
  }
  releaseFloor() {
    this.sign = 'PTT_Idle_ocean';
    this.callStatus = 'Idle';
    this.indicatorStyle = 'warning';
    KNCallMgr.releaseFloor();
  }
  adhocCall(formData) {
    console.log('++++++++++++++++ ADHOC CALL ++++++++++++++++++');
    console.log('this.pTTuserId : ' + this.pTTuserId);
    console.log('formData.adhocMdn : ' + formData.adhocMdn);
    if (formData.adhocMdn === this.pTTuserId) {
      this.isAdhocSeflCallInitiated = true;
      setTimeout(() => { this.isAdhocSeflCallInitiated = false; }, 3000);
    } else {
      for (const c in this.adhocCallForm.controls) {
        if (this.adhocCallForm.controls.hasOwnProperty(c)) {
          this.adhocCallForm.controls[c].markAsTouched();
        }
      }
      if (this.adhocCallForm.valid && !this.invalidAdhocMdn) {
        this.adhocMDN = formData.adhocMdn;
        this.one_to_oneCall = true;
        this.disableMainMenu = true;
        this.showAlertAdhoc = true;
        this.mainMenuIcons = 'enableAdhocCall';
        this.currentCallPanel = 'adhoc';
      }
    }
  }
  adhocAcquireFloor() {
    if (this.one_to_oneCall) {
      console.log('........initiate the private call.............');
      this.one_to_oneCall = false;
      const jsonData = [];
      console.log(this.adhocMDN);
      const callJson = { 'phoneNumber': this.adhocMDN };
      jsonData.push(callJson);
      console.log('call to the following...........');
      console.log(jsonData);
      KNCallMgr.makeCall(jsonData);
    }
    KNCallMgr.acquireFloor();
  }
  adhocReleaseFloor() {
    KNCallMgr.releaseFloor();
  }
  adhocEndCall(calledFrom: string) {
    if (calledFrom === 'template') {
      KNCallMgr.endcall();
    }
    this.showAlertAdhoc = false;
    this.disableMainMenu = false;
    this.mainMenuIcons = 'enableContacts';
  }
  sendIPA() {
    const jsonData = [];
    this.selectedContacts.forEach((contact) => {
      const ipaObj: any = { 'phoneNumber': contact.mdn };
      ipaObj.name = this.contacts.filter((obj) => {
        return obj.mdn === contact.mdn;
      });
      ipaObj.name = ipaObj.name[0].name;
      ipaObj.type = 'OutIPA';
      this.ipaObject = ipaObj;
      KNCallMgr.sendIPA(ipaObj);
    });
    if (this.selectedContacts.length === 0) {
      this.noSelectionMsg = true;
    }
    // this.selectedContacts = [];
  }
  sendIPADND(mdn) {
    const jsonData = [];
    const dndIpaObj: any = { 'phoneNumber': mdn };
    dndIpaObj.name = this.contacts.filter((obj) => {
      return obj.mdn === mdn;
    });
    dndIpaObj.name = dndIpaObj.name[0].name;
    dndIpaObj.type = 'OutIPA';
    this.ipaObject = dndIpaObj;
    KNCallMgr.sendIPA({ 'phoneNumber': mdn });
  }
  sendAdhocIPA() {
    const jsonData = [];
    KNCallMgr.sendIPA({ 'phoneNumber': this.adhocMDN });
  }
  displayGroupMembers(groups) {
    if (groups !== undefined && groups !== null) {
      this.groupMembers = groups;
    } else {
      this.groupMembers = [];
    }
    this.enableGroupMembers = true;
  }
  loginEPTT() {
    const inpJson = {
      'userId': this.pTTuserId,
      'accessToken': this.pTTaccessToken,
      'clientType': this.pTTClientType
    };
    console.log(inpJson);
    KNPoC.login(inpJson, (respJson) => {
      console.log('Inline Response login : ' + JSON.stringify(respJson));
      if (respJson.loginStatus === 3) {
        this.loginFailed = true;
        this.loading = false;
      }
      if (respJson.loginStatus === LOGINSTATUS.INPROGRESS) {
        console.log('Login In progress ' + JSON.stringify(respJson));
      }
    });
  }
  addTGSGroupPriority(group: any, priority) {
    console.log('...........selected priority...............' + priority);
    const grpListTGScJson = { 'groupId': group.groupId, 'priority': priority };
    KNTGScMgr.addGroupToTGScList(grpListTGScJson, (respJSON) => {
      console.log(JSON.stringify(respJSON));
    });
  }
  knPocConfig() {
    KNPoC.setUIReady((respJson) => {
      console.log('setUIReady: ' + JSON.stringify(respJson));
    });
    KNPoC.getSelfName((respJson) => {
      this.SelfName = respJson.selfName;
      console.log('Name :' + this.SelfName);
    });
    KNTGScMgr.getTGScConfiguration((respJSON) => {
      if (respJSON.getStatus === GETSTATUS.SUCCESS) {
        console.log('...........getTGScConfiguration.................');
        console.log(JSON.stringify(respJSON));
        const tgscConfigJson = respJSON.tgscConfig;
        const tgsPriority = [];
        this.lowPriority = tgscConfigJson.lowPriorityValue;
        this.highPriority = tgscConfigJson.highPriorityValue;
        this.normalPriorityValue = tgscConfigJson.normalPriorityValue;
        this.normalPriorityValue = tgscConfigJson.normalPriorityValue;
        console.log(this.lowPriority, this.highPriority);
        if (this.highPriority < this.lowPriority) {
          for (let i = this.highPriority; i <= this.lowPriority; i++) {
            tgsPriority.push(i.toString());
          }
        } else {
          for (let i = this.lowPriority; i <= this.highPriority; i++) {
            tgsPriority.push(i.toString());
          }
        }
        console.log('..............TGS priority numbers..........');
        console.log(tgsPriority);
        this.tgsPriority = tgsPriority;
      }
    });
  }
  sortOnAscending(property1, property2) {
    return (a, b) => {
      if (a[property1] < b[property1]) { return -1; }
      if (a[property1] > b[property1]) { return 1; }
      if (a[property2] < b[property2]) { return -1; }
      if (a[property2] > b[property2]) { return 1; }
      return 0;
    };
  }
  getAllContacts() {
    console.log('Fetching Contact List');
    KNCntGrpMgr.getAllContacts((respJson) => {
      if (respJson.getStatus === GETSTATUS.SUCCESS) {
        this.getOnDemandContacts(respJson.contacts);
        const contactsList = respJson.contacts;
        if (contactsList.length > 0) {
          contactsList.forEach(eachContact => {
            eachContact.order = (eachContact.availabilityStatus === '2') ? '1' : (eachContact.availabilityStatus === '3') ? '2' : '3';
            if (null !== plotLocations && plotLocations.length > 0) {
              plotLocations.forEach(function (plotLoc) {
                if (eachContact.mdn === plotLoc.mdn) {
                  if (undefined !== plotLoc.lat && '' !== plotLoc.lat && undefined !== plotLoc.lng && '' !== plotLoc.lng) {
                    eachContact.latlng = plotLoc.lat + ',' + plotLoc.lng;
                    eachContact.latlngInfo = '0';
                  } else {
                    eachContact.latlngInfo = '1';
                  }
                }
              });
            } else {
              eachContact.latlngInfo = '1';
            }
          });
          contactsList.sort(this.sortOnAscending('order', 'name'));
        }
        this.contactStatus = false;
        this.isContactsAvailable = true;
        this.ngZone.run(() => {
          this.contacts = contactsList;
        });
        if (this.contacts.length > 0) {
          if (this.geoAlertContact.length > 0) {
            this.getContactName(this.geoAlertContact[0].phoneNumber);
            this.geoAlert(this.geoAlertContact[0].phoneNumber, this.OdlUserName);
          }
          if (this.geocallContacts.length === 1) {
            this.getContactName(this.geocallContacts[0].phoneNumber);
            this.geocall(this.geocallContacts);
            this.geocallContacts = [];
          }
        }
      }
    });
  }
  logoutEPTT() {
    this.isLogout = true;
    this.showUserDetails = false;
    if (this.PluginVersion) {
      KNPoC.logout((respJSON) => {
        if (respJSON.logoutStatus === 3 || respJSON.logoutStatus === 4) {
          this.isLogout = false;
          this.loginFailed = false;
        } else if (respJSON.logoutStatus === 2) {
          this.isLogout = true;
        } else if (respJSON.logoutStatus === 1) {
          console.log('logout success');
          this.epttService.initiateEpttLogin = true;
        }
        console.log('Logout Status:: ' + JSON.stringify(respJSON));
      });
    }
  }
  getAllGroups() {
    console.log('Fetching Group List');
    KNCntGrpMgr.getAllGroups((respJson) => {
      if (respJson.getStatus === GETSTATUS.SUCCESS) {
        this.ngZone.run(() => {
          this.groups = respJson.groups;
        });
        this.isGroupsAvailable = true;
      }
    });
  }
  closeEpttWidget() {
    $('#epttwidget').css('display', 'none');
  }
  modifyCallObjStructIPAlert(missedcallObj) {
    missedcallObj.originator = missedcallObj.mdn;
    missedcallObj.sessionId = '';
    return missedcallObj;
  }
  manualRecording() {
    if ($('#manualRecording').prop('checked')) {
      this.startRecording();
    } else {
      this.stopRecording();
    }
  }
  startRecording() {
    const sessionIdJson = { 'sessionId': this.globalsessionId };
    console.log('start recording called');
    console.log(sessionIdJson);
    KNCallMgr.startRecording(sessionIdJson, function (respJSON) {
      if (respJSON.recordingStatus === RECORDINGSTATUS.INPROGRESS) {
        console.log('recording  start is in progress');
      }
    });
  }
  stopRecording() {
    const sessionIdJson = { 'sessionId': this.globalsessionId };
    console.log('stop recording called');
    console.log(sessionIdJson);
    KNCallMgr.stopRecording(sessionIdJson, function (respJSON) {
      if (respJSON.recordingStatus === RECORDINGSTATUS.INPROGRESS) {
        console.log('recording  stop is in progress');
      }
    });
  }
  showRecordingStatus(status) {
    if (status.recordingStatus === RECORDINGSTATUS.SUCCESS) {
      this.toastr.success('Recording Results', `Call Recorded Successfully,${status.recordingFile}`);
    } else if (status.recordingStatus === RECORDINGSTATUS.FAILURE) {
      this.toastr.error('Recording Results', `Failed to record the call`);
    } else if (status.recordingStatus === RECORDINGSTATUS.INVALID_ARGUMENTS) {
      this.toastr.error('Recording Results', `Invalid Arguments`);
    } else if (status.recordingStatus === RECORDINGSTATUS.REC_ALREADY_STARTED) {
      this.toastr.error('Recording Results', `Recording already started`);
    } else if (status.recordingStatus === RECORDINGSTATUS.REC_NOT_STARTED) {
      this.toastr.error('Recording Results', `Recording not started`);
    } else if (status.recordingStatus === RECORDINGSTATUS.INVALID_SESSION_ID) {
      this.toastr.error('Recording Results', `Invalid Session ID`);
    }
  }
  isAutoDisabled() {
    return ($('#epttAutoRecording').prop('checked')) ? false : true;
  }
  setAutoRecording() {
    let mode;
    let status;
    if ($('#epttAutoRecording').prop('checked')) {
      mode = 1;
      status = 'ON';
    } else {
      mode = 0;
      status = 'OFF';
    }
    const recordingModeJson = { 'autoRecordingMode': ((mode === 1) ? MODE.ON : MODE.OFF) };
    const message = `AutoRecording Mode is updated to ${status}`;
    KNCallMgr.setAutoRecording(recordingModeJson, (respJSON) => {
      if (respJSON.setStatus === SETSTATUS.SUCCESS) {
        this.toastr.success('AutoRecording', message);
      } else if (respJSON.setStatus === SETSTATUS.FAILURE) {
        this.toastr.error('AutoRecording', 'Failed to Updated the Status');
      } else if (respJSON.setStatus === SETSTATUS.INVALID_ARGUMENTS) {
        this.toastr.error('AutoRecording', 'Invalid Arguments');
      } else if (respJSON.setStatus === SETSTATUS.FEATURE_NOT_SUPPORTED) {
        this.toastr.error('AutoRecording', ' feature not supported');
      }
    });
  }

  setTGSCStatus() {
    let tgscModeJson;
    if ($('#epttTGSCCheckBox').prop('checked')) {
      KNTGScMgr.getTGScGroupList(respJSON => {
        console.log('settgscstatus response code');
        console.log(JSON.stringify(respJSON));
        if (respJSON.getStatus === GETSTATUS.SUCCESS) {
          console.log('.........TGS updated List start ..........');
          this.tgscUpdatedList = respJSON.tgscList;
          console.log('.........TGS updated List end..........');
          this.ngZone.run(() => {
            this.getGroupsInfo();
          });
        }
      });
      tgscModeJson = { 'tgscMode': MODE.ON };
      this.talkerGroupScanOn = true;
    } else {
      tgscModeJson = { 'tgscMode': MODE.OFF };
      this.talkerGroupScanOn = false;
    }
    KNTGScMgr.setTGScMode(tgscModeJson, (respJSON) => {
      if (respJSON.tgscStatus === TGSCSTATUS.SUCCESS) {
        console.log('success set the mode');
      }
    });
  }
  minimizeForm() {
    $('#pop_sidepanel').toggleClass('pop_sidepanel_maximize pop_sidepanel_minimize');
    $('#minimizeIcon > i').toggleClass('fa-minimize fa-window-maximize');
    $('#minimizeIcon').toggleClass('maximize-icon minimize-icon');
  }
  makeGroupCall(group) {
    console.log('makeGroupCall');
    console.log(group);
    this.selectedGroup = group;
    console.log(group.name);
    this.groupCall = true;
    this.disableMainMenu = true;
    this.mainMenuIcons = 'enableCall';
    this.currentCallPanel = 'group';
    this.outgoingCallerName = group.name;
    this.outgoingCallMDN = '0';
  }
  makeBroadcastCall(group) {
    this.broadcastCall = true;
    this.disableMainMenu = true;
    this.mainMenuIcons = 'enableCall';
    this.currentCallPanel = 'group';
    this.selectedGroup = group;
    this.outgoingCallerName = group.name;
    this.outgoingCallMDN = '1';
  }
  showStatusData(reason: any) {
    console.log('.......show call end reason........');
    console.log(reason);
    this.callEndReason = true;
    this.callReasonText = reason;
    setTimeout(() => {
      this.callEndReason = false;
      this.endCall('template');
      this.callReasonText = '';
    }, 2000);
  }
  showTalkerInfo(talkerName) {
    this.callStatus = talkerName;
  }
  getOnDemandContacts(contactList) {
    this.onDemandcontacts = [];
    contactList.forEach((contact) => {
      if (contact.memType === '1') {
        this.onDemandcontacts.push(contact);
      }
    });
    if (this.onDemandcontacts.length > 0) {
      this.onDemandcontacts.forEach((eachContact) => {
        eachContact.order = (eachContact.availabilityStatus === '2') ? '1' : (eachContact.availabilityStatus === '3') ? '2' : '3';
      });
      this.onDemandcontacts.sort(this.sortOnAscending('order', 'name'));
    }
  }
  initializeEPTTCallBack() {
    // Login-Callback
    const cb1 = (login) => {
      console.log('login');
      console.log('CB_LOGIN' + JSON.stringify(login));
      if (login.loginStatus === LOGINSTATUS.FAILURE) {
        console.log('Login Failed..');
        this.enableAdhocCallContent = false;
        this.displayLoginInprogressMessage = false;
        this.loginFailed = true;
        this.loading = false;
      } else if (login.loginStatus === LOGINSTATUS.SUCCESS) {
        this.ngZone.run(() => {
          this.epttService.initiateEpttLogin = false;
          logInStatus = login.loginStatus;
          this.knPocConfig();
          this.loading = false;
          console.log('Login Successfull..');
          this.contactStatus = true;
          console.log('going to get contacts');
          this.enableAdhocCallContent = true;
          this.getAllContacts();
          this.getAllGroups();
          this.getODLConfiguration();
        });
      }
    };
    // logout-callback
    const cb2 = (logout) => {
      this.isLogout = false;
      if (logout.logoutStatus === '1') {
        this.epttService.initiateEpttLogin = true;
        this.onClose();
      }
      console.log('CB_LOGOUT' + JSON.stringify(logout));
    };
    const cb3 = (activationStatus) => {
      console.log('CB_ACTIVATIONSTATUS' + JSON.stringify(activationStatus));
    };
    const cb4 = (subConfigInfoChange) => {
      console.log('CB_SUBCONFIGINFOCHANGE' + JSON.stringify(subConfigInfoChange));
    };
    const cb5 = (pluginStatus) => {
      console.log('CB_PLUGINSTATUS' + JSON.stringify(pluginStatus));
      const opluginStatus = JSON.parse(JSON.stringify(pluginStatus));
      if (opluginStatus.pluginStatus === '4') {
        console.log('opluginStatus::: ' + opluginStatus.pluginStatus);
        // this.detectNetworkState(true);
        this.nStatus = true;
      } else if (opluginStatus.pluginStatus === '3') {
        console.log('opluginStatus::: ' + opluginStatus.pluginStatus);
        // this.detectNetworkState(false);
        this.nStatus = false;
        // gObj.isConnected = true;
        // setTimeout(() => { gObj.isConnected = false; }, 3000);
      }
    };
    const cb6 = (ipaStatus) => {
      console.log('CB_IPASTATUS' + JSON.stringify(ipaStatus));
      if (ipaStatus.ipaStatus === 1) {
        this.isMissedCallAvailable = true;
        this.notificationList.push(this.ipaObject);
      }
      if (ipaStatus.ipaStatus === 3) {
        this.toastr.error('IP Alert', 'Failure');
      }
      if (ipaStatus.ipaStatus === 4) {
        this.toastr.error('IP Alert', 'Invalid argument passed');
      }
      if (ipaStatus.ipaStatus === 5) {
        this.toastr.error('IP Alert', ' Members offline');
      }
    };
    // callstatus callback
    const cb7 = (callStatus) => {
      console.log('CB_CALLSTATUS' + JSON.stringify(callStatus));
      this.ngZone.run(() => {
        this.toggleMicrophone(callStatus.floorStatus);
        this.showCallStatusInfo(callStatus.callStatus);
      });
      this.globalsessionId = callStatus.sessionId;
      if ('5' === callStatus.callStatus || '6' === callStatus.callStatus) {
        if ('1' === callStatus.reasonCode) {
          if ('' !== this.outgoingCallMDN && undefined !== this.outgoingCallMDN) {
            const today = new Date().getTime();
            const outgoingCall = {};
            outgoingCall['mdn'] = this.outgoingCallMDN;
            outgoingCall['name'] = this.outgoingCallerName;
            outgoingCall['time'] = this.datePipe.transform(today, 'MMM-d-y, h:mm a');
            if ('0' === this.outgoingCallMDN) {
              outgoingCall['type'] = 'OUTGOING_GROUP_CALL';
            } else if ('1' === this.outgoingCallMDN) {
              outgoingCall['type'] = 'OUTGOING_BROADCAST_CALL';
            } else {
              outgoingCall['type'] = 'OUTGOING_PRIVATE_CALL';
            }
            console.log(outgoingCall);
            this.isMissedCallAvailable = true;
            this.notificationList.push(outgoingCall);
            this.outgoingCallMDN = '';
            this.outgoingCallerName = '';
          }
        } else if (Number(callStatus.reasonCode) >= 2 && Number(callStatus.reasonCode) <= 21) {
          this.showStatusData(this.epttService.callStatus[callStatus.reasonCode]);
        } else {
          this.endCall('callback');
        }
      }
      if ('6' === callStatus.callStatus) {
        if ('1' === callStatus.reasonCode) {
          this.ngZone.run(() => {
            this.disableMainMenu = false;
            this.mainMenuIcons = 'enableContacts';
            this.currentTab = 'contacts';
            this.geocallContacts = [];
            this.epttService.setSelectedUsers([]);
          });
        }
      }
    };
    const cb8 = (callAlert) => {
      console.log('CB_CALLALERT' + JSON.stringify(callAlert));
      if ('1' === callAlert.callType) {
        this.mapConsoleService.openRightSidePanel(PanelHeaders.eptt);
        this.epttService.displayCallPanel = true;
        this.epttService.callingUser = callAlert.name;
        this.disableMainMenu = true;
        this.currentTab = '';
        this.mainMenuIcons = 'enableCall';
        this.currentCallPanel = 'private';
        this.displayUserName = callAlert.name;
        const message = 'Call from ' + callAlert.name;
        this.toastr.success('Incoming private Call', message);
      }
      if ('4' === callAlert.callType || '2' === callAlert.callType) {
        this.mapConsoleService.openRightSidePanel(PanelHeaders.eptt);
        this.epttService.displayCallPanel = true;
        this.epttService.callingGroup = callAlert;
        console.log('inside broadcast/group call');
        this.disableMainMenu = true;
        this.currentTab = '';
        this.mainMenuIcons = 'enableCall';
        this.currentCallPanel = 'group';
        const message = 'Call from' + callAlert.name;
        this.toastr.success('Incoming Group Call', message);
        this.selectedGroup = callAlert;
      }
      // log the incoming calls in history
      const today = new Date().getTime();
      const incomingCall = {};
      //  incomingCall['mdn'] = this.outgoingCallMDN;
      incomingCall['name'] = callAlert.name;
      incomingCall['time'] = this.datePipe.transform(today, 'MMM-d-y, h:mm a');
      if ('1' === callAlert.callType) {
        incomingCall['type'] = 'INCOMING_PRIVATE_CALL';
      } else if ('2' === callAlert.callType) {
        incomingCall['type'] = 'INCOMING_GROUP_CALL';
      } else if ('3' === callAlert.callType) {
        incomingCall['type'] = 'INCOMING_ADHOC_CALL';
      } else if ('4' === callAlert.callType) {
        incomingCall['type'] = 'INCOMING_BROADCAST_CALL';
      }
      console.log(incomingCall);
      this.isMissedCallAvailable = true;
      this.notificationList.push(incomingCall);
    };
    const cb9 = (talkerInfo) => {
      this.ngZone.run(() => {
        console.log('CB_TALKERINFO' + JSON.stringify(talkerInfo));
        this.showTalkerInfo(talkerInfo.name);
        this.callStatus = talkerInfo.name;
      });
    };
    const cb10 = (ipAlert) => {
      this.ngZone.run(() => {
        console.log('CB_IPALERT' + JSON.stringify(ipAlert));
        const today = new Date().getTime();
        this.isMissedCallAvailable = true;
        ipAlert.time = this.datePipe.transform(today, 'MMM-d-y, h:mm a');
        ipAlert.type = 'InIPA';
        const message = ipAlert.name + ' sent you an Instant Personal Alert' + ' at ' + ipAlert.time;
        this.notificationList.push(ipAlert);
        this.toastr.warning(ipAlert.name + ': IP Alert', message);
      });
    };
    const cb11 = (deviceStatus) => {
      console.log('CB_DEVICESTATUS' + JSON.stringify(deviceStatus));
    };
    const cb12 = (missedCallAlert) => {
      console.log('CB_MISSEDCALLALERT' + JSON.stringify(missedCallAlert));
      const today = new Date().getTime();
      missedCallAlert.time = this.datePipe.transform(today, 'MMM-d-y, h:mm a');
      missedCallAlert.type = 'InMissedCall';
      if (missedCallAlert.alertType === '1' && missedCallAlert.callType === '1') {
        this.isMissedCallAvailable = true;
        let existingMissedCall;
        existingMissedCall = $.grep(this.notificationList, (e) => {
          return e.originator === missedCallAlert.originator;
        });
        console.log('inside private missed call alert.......................');
        console.log(existingMissedCall);
        if (existingMissedCall.length === 0) {
          this.notificationList.push(missedCallAlert);
          const message = 'Missed Call from ' + missedCallAlert.name + ' at ' + missedCallAlert.time;
          this.toastr.info('Missed private Call', message);
        }
      } else if (missedCallAlert.alertType === '1' && missedCallAlert.callType === '2') {
        this.isMissedCallAvailable = true;
        let existingGrpMissedCall;
        existingGrpMissedCall = $.grep(this.notificationList, (e) => {
          return e.groupId === missedCallAlert.groupId;
        });
        console.log('inside group missed call alert.......................');
        console.log(existingGrpMissedCall);
        if (existingGrpMissedCall.length === 0) {
          this.notificationList.push(missedCallAlert);
          console.log(this.notificationList);
          const message = 'Missed Call from ' + missedCallAlert.name + ' at ' + missedCallAlert.time;
          this.toastr.info('Missed group Call', message);
        }
      } else if (missedCallAlert.alertType === '2' && missedCallAlert.callType === '2') {
        const removedMissedCallList = $.grep(this.notificationList, (e) => {
          return e.sessionId !== missedCallAlert.sessionId;
        });
        console.log(removedMissedCallList);
        this.notificationList = removedMissedCallList;
        this.isMissedCallAvailable = true;
        if (this.notificationList.length === 0) {
          this.isMissedCallAvailable = false;
        }
      }
    };
    const cb13 = (groupStatus) => {
      console.log('CB_GROUPSTATUS' + JSON.stringify(groupStatus));
      if (groupStatus.operationCode === 1) {
        groupStatus.group.priority = this.normalPriorityValue;
        this.groups.push(groupStatus.group);
      } else if (groupStatus.operationCode === 2) {
        this.groups = this.groups.filter(group => group.groupId !== groupStatus.group.groupId);
      } else if (groupStatus.operationCode === 3) {
        this.groups = this.groups.filter(group => group.groupId !== groupStatus.group.groupId);
        this.groups.push(groupStatus.group);
      }
    };
    const cb14 = (contactStatus) => {
      console.log("CB_CONTACTSTATUS" + JSON.stringify(contactStatus));
      contactStatus.forEach((newContact) => {
        if (newContact.operationCode === 1) {
          this.contacts.push(newContact.contacts);
        } else if (newContact.operationCode === 2) {
          this.contacts = this.contacts.filter(contact => contact.mdn !== newContact.contacts.mdn);
          this.selectedContacts = this.selectedContacts.filter(contact => contact.mdn !== newContact.contacts.mdn);
        } else if (newContact.operationCode === 3) {
          this.contacts = this.contacts.filter(contact => contact.mdn !== newContact.contacts.mdn);
          this.contacts.push(newContact.contacts);
          this.selectedContacts = this.selectedContacts.filter(contact => contact.mdn !== newContact.contacts.mdn);
        }
      });
    };
    const cb15 = (updatedTGScList) => {
      this.tgscUpdatedList = updatedTGScList.tgscList;
      this.updateGroupWithTGSPriority();
      this.getGroupsInfo();
    };
    const cb16 = (tgscMode) => {
      console.log('CB_TGSCMODE' + JSON.stringify(tgscMode));
      this.tGSCMode = tgscMode.tgscMode;
    };
    // contact availability callback
    const cb17: any = function contactAvailabilityStatus(contactAvailability) {
      const plotUsersOnMap = [];
      console.log('CB_CONTACTAVAILABILITYSTATUS' + JSON.stringify(contactAvailability));
      for (let i = 0; i < contactAvailability.length; i++) {
        if (contactAvailability[i].LOC !== 'NA,NA') {
          const latlng = controller.parseDMS(contactAvailability[i].LOC);
          contactAvailability[i].lat = latlng[0];
          contactAvailability[i].lng = latlng[1];
          console.log('mdn....' + contactAvailability[i].mdn + '....latitude' +
            contactAvailability[i].lat + 'longitude..' + contactAvailability[i].lng);
          let isLocationAvailable = false;
          plotLocations.forEach(function (plotLocation) {
            if (plotLocation.mdn === contactAvailability[i].mdn && !isLocationAvailable) {
              plotLocation.lat = contactAvailability[i].lat;
              plotLocation.lng = contactAvailability[i].lng;
              plotLocation.availabilityStatus = contactAvailability[i].availabilityStatus;
              isLocationAvailable = true;
            }
          });
          if (!isLocationAvailable) {
            plotLocations.push(contactAvailability[i]);
          }
        }
      }
      controller.getAllContacts();
      controller.getAllGroups();
      controller.displayLoginInprogressMessage = false;
      if (controller.onDemandSelectedContactsList.length > 0 && plotLocations.length > 0) {
        controller.onDemandSelectedContactsList.forEach(eachOnDemandContact => {
          plotLocations.forEach(eachContact => {
            if (eachContact && eachContact.mdn === eachOnDemandContact.mdn) {
              plotUsersOnMap.push(eachContact);
            }
          });
        });
      }
      // if (plotUsersOnMap.length > 0) {
      //   controller.plotEpttUserOnMap(plotUsersOnMap);
      // }
      if (plotLocations.length > 0) {
        controller.easResourcesService.updateEpttUserLocation(plotLocations).subscribe(
          data => {
            console.log(data);
          },
          error => {
            console.log(error);
          }
        );
      }

    };
    const cb18 = (selfAvailableChangeStatus) => {
      console.log('CB_SELFAVAILABILITYCHANGESTATUS' + JSON.stringify(selfAvailableChangeStatus));
      if ('2' === selfAvailableChangeStatus.selfAvailabilityChangeStatus) {
        this.setStatusIndicator('Available', 'success');
      } else if ('3' === selfAvailableChangeStatus.selfAvailabilityChangeStatus) {
        this.setStatusIndicator('Do Not Disturb', 'danger');
      }
    };
    const cb19 = (selfAvailabilityStatus) => {
      console.log('SELFAVAILABILITYSTATUS' + JSON.stringify(selfAvailabilityStatus));
      if ('2' === selfAvailabilityStatus.availabilityStatus) {
        this.setStatusIndicator('Available', 'success');
      } else if ('3' === selfAvailabilityStatus.availabilityStatus) {
        this.setStatusIndicator('Do Not Disturb', 'danger');
      }
    };
    const cb20 = (recordingStatus) => {
      console.log('CB_RECORDINGSTATUS' + JSON.stringify(recordingStatus));
      this.showRecordingStatus(recordingStatus);
    };
    const cb21 = (subscriptionStatus) => {
      console.log('CB_SUBSCRIPTIONSTATUS' + JSON.stringify(subscriptionStatus));
    };
    const cb22 = (bgcDeliveryReport) => {
      console.log('CB_BGCDELIVERYREPORT' + JSON.stringify(bgcDeliveryReport));
    };
    const cb23 = (odlStatus) => {
      console.log('CB_ODLSTATUS' + JSON.stringify(odlStatus));
    };
    KNCallBackMgr.setupCallBack(cb1, 'CB_LOGIN');
    KNCallBackMgr.setupCallBack(cb2, 'CB_LOGOUT');
    KNCallBackMgr.setupCallBack(cb3, 'CB_ACTIVATIONSTATUS');
    KNCallBackMgr.setupCallBack(cb4, 'CB_SUBCONFIGINFOCHANGE');
    KNCallBackMgr.setupCallBack(cb5, 'CB_PLUGINSTATUS');
    KNCallBackMgr.setupCallBack(cb6, 'CB_IPASTATUS');
    KNCallBackMgr.setupCallBack(cb7, 'CB_CALLSTATUS');
    KNCallBackMgr.setupCallBack(cb8, 'CB_CALLALERT');
    KNCallBackMgr.setupCallBack(cb9, 'CB_TALKERINFO');
    KNCallBackMgr.setupCallBack(cb10, 'CB_IPALERT');
    KNCallBackMgr.setupCallBack(cb11, 'CB_DEVICESTATUS');
    KNCallBackMgr.setupCallBack(cb12, 'CB_MISSEDCALLALERT');
    KNCallBackMgr.setupCallBack(cb13, 'CB_GROUPSTATUS');
    KNCallBackMgr.setupCallBack(cb14, 'CB_CONTACTSTATUS');
    KNCallBackMgr.setupCallBack(cb15, 'CB_UPDATEDTGSCLIST');
    KNCallBackMgr.setupCallBack(cb16, 'CB_TGSCMODE');
    KNCallBackMgr.setupCallBack(cb17, 'CB_CONTACTAVAILABILITYSTATUS');
    KNCallBackMgr.setupCallBack(cb18, 'CB_SELFAVAILABILITYCHANGESTATUS');
    KNCallBackMgr.setupCallBack(cb19, 'CB_SELFAVAILABILITYSTATUS');
    KNCallBackMgr.setupCallBack(cb20, 'CB_RECORDINGSTATUS');
    KNCallBackMgr.setupCallBack(cb21, 'CB_SUBSCRIPTIONSTATUS');
    KNCallBackMgr.setupCallBack(cb22, 'CB_BGCDELIVERYREPORT');
    KNCallBackMgr.setupCallBack(cb23, 'CB_ODLSTATUS');
    console.log('Initialize CallBacks done');
  }
  showCallStatusInfo(callStatus) {
    if ('1' === callStatus) {
      console.log('.........INPROGRESS.........');
      this.callStatusInfo = 'The call initiation in progress';
      this.indicatorStyle = 'info';
    } else if ('2' === callStatus) {
      console.log('.........CONNECTED.........');
      this.callStatusInfo = 'The call is being answered';
      this.indicatorStyle = 'green';
    } else if ('4' === callStatus) {
      console.log('.........RECONNECTING.........');
      this.callStatusInfo = 'The Call is reconnecting';
      this.indicatorStyle = 'info';
    } else if ('5' === callStatus) {
      console.log('......... TERMINATED.........');
      this.callStatusInfo = 'The call is terminated';
      this.indicatorStyle = 'info';
      this.endCall('callback');
    }
  }


  updateGroupWithTGSPriority() {
    console.log('..........updateGroupWithTGSPriority..............');
    if (this.tgscUpdatedList.length > 0 && this.groups.length > 0) {
      this.tgscUpdatedList.forEach((tgscList) => {
        this.groupsInTgscPanel.forEach((grpList) => {
          if (tgscList.groupId === grpList.groupId) {
            grpList.priority = tgscList.priority;
          }
        });
      });
      // compare the assigned priority and allocated priority
      const resultPrior = this.tgscUpdatedList.map((a) => {
        return a.priority;
      });
      console.log('resultPrior', resultPrior);
      // excludes the already assigned priority
      this.tgsPriority = this.tgsPriority.filter((el) => {
        return !resultPrior.includes(el);
      });
      console.log(this.tgsPriority);
    }
    this.ngZone.run(() => {} );
  }
  setStatusIndicator(status, statusIndicator) {
    this.status = status;
    this.statusIndicator = statusIndicator;
  }
  toggleMicrophone(floorStatus) {
    if ('5' === floorStatus) {
      console.log('.........you are talking.........');
      this.sign = 'PTT_Floor_Aquired';
      this.callStatus = 'You';
      this.indicatorStyle = 'green';
    } else if ('7' === floorStatus) {
      console.log('......... others talking.........');
      this.sign = 'PTT_Floor_Taken';
      this.indicatorStyle = 'info';
    } else {
      console.log('......... Floor is idle.........');
      this.sign = 'PTT_Idle_ocean';
      this.callStatus = 'Idle';
      this.indicatorStyle = 'warning';
    }
  }
  geocall(mdnList: any) {
    console.log(' GeoCall initiated...' + mdnList);
    this.geoMDNList = mdnList;
    this.makeCall('geocall');
  }
  removeTGSGroupPriority(group: any) {
    console.log('........remove group..........' + group.groupId);
    const grpListTGScJson = { 'groupId': group.groupId };
    KNTGScMgr.removeGroupFromTGScList(grpListTGScJson, (respJSON) => {
      if (respJSON.tgscStatus === TGSCSTATUS.INPROGRESS) {
        console.log(JSON.stringify(respJSON));
        this.groupsInTgscPanel.forEach((grp) => {
          if (grp.groupId === group.groupId) {
            this.tgsPriority.push(grp.priority);
            grp.priority = this.normalPriorityValue;
          }
        });
        this.sortTGSPriority();
      }
    });
  }
  updateTGSGroupPriority(group: any, priority) {
    const grpListTGScJson = { 'groupId': group.groupId, 'priority': priority };
    this.groupsInTgscPanel.forEach((grp) => {
      if (grp.groupId === group.groupId) {
        this.tgsPriority.push(grp.priority);
      }
    });
    this.sortTGSPriority();
    KNTGScMgr.updateGroupPriorityInTGScList(grpListTGScJson, function (respJSON) {
      console.log(JSON.stringify(respJSON));
    });
  }
  sortTGSPriority() {
    this.tgsPriority.sort(function (a, b) {
      if (isNaN(a) || isNaN(b)) {
        return a > b ? 1 : -1;
      }
      return a - b;
    });
  }
  makeCallFromMissedTab(missedCallObj: any) {
    console.log('Missed call object');
    console.log(missedCallObj);
    if (missedCallObj.mdn) {
      missedCallObj = this.modifyCallObjStructIPAlert(missedCallObj);
    }
    this.missedCall = true;
    this.disableMainMenu = true;
    this.mainMenuIcons = 'enableCall';
    this.currentCallPanel = 'missedCall';
    if (missedCallObj.sessionId === '') {
      this.missedCallType = 'privateMissedCall';
      this.missedCallMDN = missedCallObj.originator;
    } else if (missedCallObj.sessionId) {
      this.missedCallType = 'groupMissedCall';
      this.GrpmissedCallobj = missedCallObj;
    }
  }
  enableAdhocCall() {
    this.invalidAdhocMdn = false;
    this.adhocCallForm = this.formBuilder.group({
      'adhocMdn': ['', Validators.required]
    });
    this.displayAdhocCall = this.displayAdhocCall ? false : true;
  }
  checkAdhocMdn(mdn) {
    this.invalidAdhocMdn = mdn.length < 11 ? true : false;
  }


  parseDMS(input) {
    const parts = input.split(/[^.\d\w]+/);
    const latlng = [];
    const d1 = parts[2].slice(-1);
    const d2 = parts[5].slice(-1);
    const sec1 = parts[2].split('.');
    const sec2 = parts[5].split('.');
    const lat = this.convertDMSToDD(parts[0], parts[1], sec1[0], d1);
    const lng = this.convertDMSToDD(parts[3], parts[4], sec2[0], d2);
    latlng.push(lat);
    latlng.push(lng);
    return latlng;
  }
  convertDMSToDD(days, minutes, seconds, direction) {
    let dd: any = parseInt(days) + (parseInt(minutes) / 60) + parseInt(seconds) / (60 * 60);
    dd = parseFloat(dd);
    if (direction === 'S' || direction === 'W') {
      dd *= -1;
    } // Don't do anything for N or E
    return dd;
  }
  startPeriodicLocation() {
    const onDemandSelectedContactsList = this.onDemandSelectedContactsList;
    if (onDemandSelectedContactsList.length > 0) {
      onDemandSelectedContactsList.forEach((selectedContact) => {
        const params = {
          'phoneNumber': selectedContact.mdn,
          'interval': this.interval,
          'duration': this.duration
        };
        KNLocationMgr.startPeriodicLocation(params, (respJSON) => {
          if (respJSON.odlStatus === ODLSTATUS.INPROGRESS) {
            this.toastr.success('On demand location request', 'Started Successfully');
          } else if (Number(respJSON.odlStatus) >= 3 && Number(respJSON.odlStatus) <= 7) {
            this.toastr.warning('On demand location request', this.epttService.periodicLocationStatus[respJSON.odlStatus]);
          }
        });
      });
    } else {
      this.onDemandSelectionWarning = true;
    }
  }
  stopPeriodicLocation() {
    const onDemandSelectedContactsList = this.onDemandSelectedContactsList;
    if (onDemandSelectedContactsList.length > 0) {
      onDemandSelectedContactsList.forEach((selectedContact) => {
        const params = {
          'phoneNumber': selectedContact.mdn
        };
        KNLocationMgr.stopPeriodicLocation(params, (respJSON) => {
          if (respJSON.odlStatus === '1') {
            this.toastr.success('On demand location request', 'Stopped Successfully');
            this.onDemandSelectedContactsList = [];
          } else if (Number(respJSON.odlStatus) >= 3 && Number(respJSON.odlStatus) <= 7) {
            this.toastr.warning('On demand location request', this.epttService.periodicLocationStatus[respJSON.odlStatus]);
          }
        });
      });
    } else {
      this.onDemandSelectionWarning = true;
    }
  }
  stopAllPeriodicLocation() {
    KNLocationMgr.stopAllPeriodicLocation(respJSON => {
      if (respJSON.odlStatus === '1') {
        this.toastr.success('On demand location request', 'All periodic locations are stopped  Successfully');
        this.onDemandSelectedContactsList = [];
      } else if (Number(respJSON.odlStatus) >= 3 && Number(respJSON.odlStatus) <= 7) {
        this.toastr.warning('On demand location request', this.epttService.periodicLocationStatus[respJSON.odlStatus]);
      }
    });
  }
  enableOnDemandconfig() {
    this.displayOnDemandconfig = this.displayOnDemandconfig ? false : true;
  }
  updateOnDemandConfig(formData) {
    for (const c in this.onDemandLocationForm.controls) {
      if (this.onDemandLocationForm.controls.hasOwnProperty(c)) {
        this.onDemandLocationForm.controls[c].markAsTouched();
      }
    }
    if (this.onDemandLocationForm.valid && !this.invalidInterval && !this.invalidDuration) {
      this.interval = formData.interval;
      this.duration = formData.duration;
      this.displayOnDemandconfig = false;
      this.toastr.success('On demand location configuration', 'Updated Successfully');
    }
  }
  getODLConfiguration() {
    KNLocationMgr.getODLConfiguration((respJSON) => {
      if (respJSON.getStatus === GETSTATUS.SUCCESS) {
        this.odlConfig = respJSON.odlConfig;
        this.interval = respJSON.odlConfig.minInterval;
        this.duration = respJSON.odlConfig.minDuration;
        this.onDemandLocationForm = this.formBuilder.group({
          'interval': [this.interval, Validators.required],
          'duration': [this.duration, Validators.required]
        });
      }
    });
  }
  requestContactLocation(selectedContact) {
    const locationListJson = [{ 'phoneNumber': selectedContact.mdn }];
    KNLocationMgr.requestContactLocation(locationListJson, (respJSON) => {
      if (respJSON.odlStatus === ODLSTATUS.SUCCESS) {
        if (respJSON.odlStatus) {
          this.toastr.success(selectedContact.name, 'Location updated successfully');
        } else {
          this.toastr.warning('Contact location request', this.epttService.periodicLocationStatus[respJSON.odlStatus]);
        }
      }
    });
  }
  checkIntervalLimit(interval) {
    const ODLConfigJson = this.odlConfig;
    if (parseInt(interval) < parseInt(ODLConfigJson.minInterval) || parseInt(interval) > parseInt(ODLConfigJson.maxInterval)) {
      this.invalidInterval = true;
      this.intervalLimitWarning = 'Interval should be less than ' + ODLConfigJson.maxInterval +
        ' and greater than ' + ODLConfigJson.minInterval;
    } else {
      this.invalidInterval = false;
    }
  }
  checkDurationLimit(duration) {
    const ODLConfigJson = this.odlConfig;
    if (parseInt(duration) < parseInt(ODLConfigJson.minDuration) || parseInt(duration) > parseInt(ODLConfigJson.maxDuration)) {
      this.invalidDuration = true;
      this.durationLimitWarning = 'Interval should be less than ' + ODLConfigJson.maxDuration +
        ' and greater than ' + ODLConfigJson.minDuration;
    } else {
      this.invalidDuration = false;
    }
  }
  zoomToUserLocation(contact) {
    console.log(contact);
    if (null !== contact.latlngInfo && '' !== contact.latlngInfo && '1' !== contact.latlngInfo) {
      this.mapConsoleService.viewEpttLocations(contact);
    }
  }
  closeEpttPanel() {
    $('#eptt').css('background-color', 'rgba(0, 0, 0, 0.6)');
    // this.mapConsoleComponent.closeRightSidePanel('eptt');
  }
  getGroupsInfo() {
    this.groupsInTgscPanel = this.groups;
    this.tgscUpdatedList.forEach(eachGroupInTgscList => {
      this.groupsInTgscPanel.forEach((eachGroup) => {
        if (eachGroup.groupId === eachGroupInTgscList.groupId) {
          eachGroup.priority = eachGroupInTgscList.priority;
        }
      });
    });
    this.groupsInTgscPanel.forEach(eachGroup => {
      if (eachGroup.priority === undefined) {
        eachGroup.priority = this.normalPriorityValue;
      } else {
        const index = this.tgsPriority.indexOf(eachGroup.priority.toString(), 0);
        if (index > -1) {
          this.tgsPriority.splice(index, 1);
        }
      }
    });
  }

  onDemandLocationChange(selectedContact: any) {
    this.onDemandSelectionWarning = false;
    if ($('#' + selectedContact.mdn).is(':checked')) {
      this.onDemandSelectedContactsList.push(selectedContact);
    } else {
      this.onDemandSelectedContactsList = this.onDemandSelectedContactsList.filter(contact => contact.mdn !== selectedContact.mdn);
    }
  }
  plotEpttUserOnMap(userLocationInfo) {
    let locationInfo = [];
    if (userLocationInfo.length > 0) {
      if (this.epttUsersOnMap.length > 0) {
        for (let i = 0; i < this.epttUsersOnMap.length; i++) {
          this.epttUsersOnMap[i].setMap(null);
        }
        this.epttUsersOnMap = [];
      }
      userLocationInfo.forEach((eachUserLocationInfo) => {
        locationInfo = this.parseDMS(eachUserLocationInfo.LOC);
        this.getContactName(eachUserLocationInfo.mdn);
        const latLng = new google.maps.LatLng(locationInfo[0], locationInfo[1]);
        const markerObject = this.getEpttUserIcon(latLng, eachUserLocationInfo.mdn, this.OdlUserName);
        this.epttUsersOnMap.push(markerObject);
        this.displayEpttUserOnMap(locationInfo, markerObject);
      });
    }
  }
  getContactName(mdn) {
    if (this.contacts.length > 0) {
      this.contacts.forEach((eachContact) => {
        if (eachContact.mdn === mdn) {
          console.log(eachContact.name);
          this.OdlUserName = eachContact.name;
        }
      });
    }
  }
  getEpttUserIcon(markerPosition, mdn, name) {
    const epttIcon = {
      url: 'assets/img/epttPhone.png',
      size: new google.maps.Size(30, 38),
      origin: new google.maps.Point(0, 0),
      anchor: new google.maps.Point(0, 0)
    };
    const epttUserIcon = new google.maps.Marker({
      icon: epttIcon,
      position: markerPosition,
      map: this.map,
      mdn: mdn,
      name: name
    });
    return epttUserIcon;
  }
  geoAlert(mdn, name) {
    const jsonData = [];
    const ipaObj: any = { 'phoneNumber': mdn };
    ipaObj.name = name;
    ipaObj.type = 'OutIPA';
    this.ipaObject = ipaObj;
    KNCallMgr.sendIPA(ipaObj);
  }
  displayEpttUserOnMap(latLng, markerObject) {
    const epttInfowindow = new google.maps.InfoWindow();
    const latlng = new google.maps.LatLng(latLng[0], latLng[1]);
    const geocoder = new google.maps.Geocoder;
    let address = '';
    const pttUserCallDetails = [];
    this.map.setCenter(latlng);
    google.maps.event.addListener(markerObject, 'click', () => {
      const userMdn = { 'phoneNumber': markerObject.get('mdn') };
      pttUserCallDetails.push(userMdn);
      geocoder.geocode({ 'latLng': latlng }, (results, status) => {
        if (status.toString() === 'OK') {
          if (results[1]) {
            address = results[1].formatted_address;
            epttInfowindow.setContent(this.epttService.pttUserLocationInfo(markerObject.get('mdn'), markerObject.get('name'), address));
            epttInfowindow.open(this.map, markerObject);
            google.maps.event.addListenerOnce(epttInfowindow, 'domready', function () {
              const makeGeocall = $('#geoCall')[0];
              if (makeGeocall !== undefined) {
                makeGeocall.addEventListener('click', () => {
                  controller.geocall(pttUserCallDetails);
                });
              }
              const makeGeoAlert = $('#geoAlert')[0];
              if (makeGeoAlert !== undefined) {
                makeGeoAlert.addEventListener('click', () => {
                  controller.geoAlert(markerObject.get('mdn'), markerObject.get('name'));
                });
              }
            });
          }
        }
      });
    });
  }
}
