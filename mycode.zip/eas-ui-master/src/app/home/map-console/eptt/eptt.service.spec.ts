import { TestBed } from '@angular/core/testing';

import { EpttService } from './eptt.service';

describe('EpttService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  // it('should be created', () => {
  //   const service: EpttService = TestBed.get(EpttService);
  //   expect(service).toBeTruthy();
  // });
});
