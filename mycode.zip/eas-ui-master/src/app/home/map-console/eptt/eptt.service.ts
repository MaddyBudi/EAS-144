import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
declare let KNPoC: any;
declare let SETUPSTATUS: any;
@Injectable({
  providedIn: 'root'
})

export class EpttService {
  selectedUsers = [];
  selectedUsersAlert = [];
  public pluginUrl = 'https://lcms.ms2l.kodiakgw.com/MobileAPI/L_WebAPI_5.0.0.4/';

  public callStatus = ['', '', 'Non Kodiak user', 'Group is deleted', 'User in DND state', 'User unavailable', 'User out of coverage area',
    'All group members in group call are unavailable', 'User is Busy', 'Made call to zero contact group', 'Temporary failure',
    'User is offline', 'User is deactivated', 'Caller out of coverage area', '1-1 call with DISPATCHER',
    'Call Disconnected Due to High Priority TGSC Call', 'Call Disconnected Due to High Priority BGC Call',
    'Audio device not connected to system', 'No Active call in progress', 'Invalid Session Id', 'Invalid arguments passed',
    'Feature not supported'];
  public periodicLocationStatus = ['', '', '', 'Failure Please try again later', 'Invalid On Demand Configuration',
    'This Feature is Not Supported', 'Not in range of ODL interval Configuration', 'This Feature only for Handset Users'];

  initiateEpttLogin = true;
  displayCallPanel = false;
  epttCallType: string;
  callingUser: any;
  callingGroup: any;
  constructor() { }

  loadEPTTPlugin() {
    console.log('load eptt plugin');
    KNPoC.setPluginURL(this.pluginUrl, (respJson) => {
      console.log('setPluginURL Status: ' + respJson.setStatus);
      console.log('setPluginURL Inline Response: ' + JSON.stringify(respJson));
    });
    KNPoC.setupWebAPI((respJson) => {
      console.log('Plugin Setup Status: ' + respJson.setupStatus);
      console.log('Plugin Setup Status: ' + SETUPSTATUS.SUCCESS);
      switch (respJson.setupStatus) {
        case SETUPSTATUS.SUCCESS:
          console.log('Plugin Setup Successfull');
          break;
        case SETUPSTATUS.FAILURE:
          console.log('Failed to Load Plugin ,Please reload the Browser');
          break;
        case SETUPSTATUS.PLUGIN_NOT_INSTALLED:
          console.log('Plugin Not Installed');
          KNPoC.installPlugin((respJSON) => {
            console.log('installPlugin: ' + respJSON.setupStatus);
          });
          break;
        case SETUPSTATUS.UPGRADE_AVAILABLE:
          console.log('Plugin Upgrade Available');
          KNPoC.installPlugin((respJSON) => {
            console.log('installPlugin: ' + respJSON.setupStatus);
          });
          break;
        case SETUPSTATUS.EXTENSION_NOT_INSTALLED:
          console.log('Extension Not Installed in Chrome');
          KNPoC.installExtension((respJSON) => {
            console.log('installExtension: ' + respJSON.setupStatus);
          });
          break;
        case SETUPSTATUS.EXTENSION_INSTALL_SUCCESS:
          console.log('Extension Installed Success in Chrome');
          break;
        case SETUPSTATUS.EXTENSION_INSTALL_FAILED:
          console.log('If Extension Install Failed in Chrome');
          break;
        default:
          break;
      }
    });
  }

  pttUserLocationInfo(mdn, name, address) {
    const pTTLocationInfowindowContent = '<div id="eventMarker" ><p id ="header" class="infowindowHeader">' + name
      + '</p>' + '<table class="table-striped" class="tableFont"><tbody class="tbodyFont">'
      + '<tr><td>MDN &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
      + mdn + '</td></tr>'
      + '<tr><td>Address &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
      + address + '</td></tr>'
      + '</tbody></table></div><br/>'
      + '<em class="fa fa-phone fa-2x" style="cursor: pointer;"id="geoCall" title="Call"></em>' +
      '<em class="fa fa-comment fa-2x geoAlertPosition" id="geoAlert" style="cursor: pointer;" title="Alert"></em>';
    return pTTLocationInfowindowContent;
  }
  public setSelectedUsers(selectedUsers) {
    this.selectedUsers = selectedUsers.slice();
  }

 	public setSelectedUserAlert(selectedUsers) {	
 	this.selectedUsersAlert = selectedUsers.slice();	
 	}	 

}