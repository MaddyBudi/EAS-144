import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { EasResourcesService } from '../eas-resources.service';
import { EasResourceGroupService } from '../eas-resource-group.service';
import { AppGlobals } from '../../../shared/app.globals';
import {SharedService} from '../../../shared/shared.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { NotifierService } from 'angular-notifier';
import { ResourceGroupTo } from '../../../shared/models/resourceGroupTo';

@Component({
  selector: 'app-create-eas-resource-group',
  templateUrl: './create-eas-resource-group.component.html',
  styleUrls: ['./create-eas-resource-group.component.scss']
})
export class CreateEasResourceGroupComponent implements OnInit {
  data;
  resourceData;
  actionHeader;
  selectedResources = [];
  showCreatePage=true;
  isSearchPage=false;
  searchResourceData;
  resourceId = [];
  isFormModified=false;
  showResourceList=false;
  rowsPerPageList: Number[] = this.appGlobals.RowsPerPageList;
  defaultRowsPerPage: Number = this.appGlobals.DefaultRowsPerPage;
  payload = {
    'name': '',
    'description': ''
  };
  resourceGroupDetails: ResourceGroupTo;
  @Output() crudViewEmitter = new EventEmitter();
  resourceGroupForm = new FormGroup({
    groupName: new FormControl(),
    resourceGroupDesc: new FormControl()
  
  });
  constructor(public formGroup: FormBuilder, private easResourceService: EasResourcesService,
    private appGlobals: AppGlobals, private fb: FormBuilder,private sharedService:SharedService,
    private easResourceGroupService:EasResourceGroupService, public easleftSideBarService:EasLeftSidebarService,
    private notifierService:NotifierService) { 
      this.resourceGroupDetails = new ResourceGroupTo(this.payload);
      this.easResourceService.closeSearch$.subscribe(
            data=>{
                this.isSearchPage=false;
                this.showCreatePage=true;
                this.showResourceList=false;
                this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
            }
        );
    }

  ngOnInit() {
    this.data = this.easResourceService.getSelectedResources();
    this.resourceData = this.data;
    this.setResourceForm();
    
  }
  setResourceForm(){
    this.resourceGroupForm = this.formGroup.group({
      'groupName': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'resourceGroupDesc': ['', Validators.compose([Validators.minLength(1), Validators.maxLength(250)])],
      
    });
    this.resourceData.forEach(resource => {
      this.resourceId.push(resource.entityId);
    });
    this.resourceGroupForm.valueChanges.subscribe(data =>{
    this.isFormModified=true;
}); 
  }
  addToGroup() {
    this.isSearchPage=true;
    this.showCreatePage=false;
    this.actionHeader="Search Resource";
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
  }
  closeComponent(){
    this.isSearchPage=false;
    this.showResourceList=false;
    this.showCreatePage=true;
  }
searchDataEmitter(event){
  this.searchResourceData=event;
  this.showResourceList=true;
  this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.maxView);
}
getSelectedResource(event){
  const flag=false;
  event.forEach(element => {
    if(!this.resourceId.includes(element.entityId)){
    this.resourceData.push(element);
    this.resourceId.push(element.entityId)
    }
  });
  this.isSearchPage=false;
  this.showResourceList=false;
  this.showCreatePage=true;
  this.isFormModified=true;
}
  deleteFromGroup(resource) {

   
this.resourceData = this.resourceData.filter(function (element) {
              return element.entityId !== resource.entityId;
            }); 
           }

   
  formatResourceData(resource){
    const entityIdArray=[];
    resource.forEach(element => {
    entityIdArray.push(element.entityId);
 });
  return entityIdArray;
  }
  
  createResourceGroup(event, formData) {
    event.preventDefault();
    for (const c in this.resourceGroupForm.controls) {
      if (this.resourceGroupForm.controls.hasOwnProperty(c)) {
        this.resourceGroupForm.controls[c].markAsTouched();
      }
    }
    this.resourceGroupDetails.resources = this.formatResourceData(this.resourceData);
    if (this.resourceGroupForm.valid && this.resourceGroupDetails.resources.length >= 2) {
      this.easResourceGroupService.createResourceGroup(this.resourceGroupDetails).subscribe(
        data => {
          if (data.entityId !== null) {
            this.crudViewEmitter.emit("listGroup");
            this.notifierService.notify("success",'Resource Group "' + this.resourceGroupDetails.name + '" created successfully.');
          } else {
            this.notifierService.notify("error",this.appGlobals.createRscFailureMsg);
          }
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.notifierService.notify("error", error.error.message);
          }
        }
      );
    }else if(this.resourceGroupDetails.resources.length < 2){
      this.notifierService.notify('error','Please add atleast two resources to create a group');
    }

    // this.crudViewEmitter.emit("listGroup");
  }
   resetCreatePage(event) {
    
    this.setResourceForm();
    this.resourceData=this.easResourceService.getSelectedResources();
   console.log(this.resourceData)        
  }
 hideErrorMessage(event){
   this.resetMessageBlock();
 }
  displaySuccessPage(successMesssage) {

    this.easResourceGroupService.setdisplaySuccess(true);
    this.easResourceGroupService.setSuccessMessage(successMesssage);

  }

  displayFailurePage(failureMessage) {

    this.easResourceGroupService.setdisplayFailure(true);
    this.easResourceGroupService.setfailureMessage(failureMessage);

  }
  private resetMessageBlock() {
        this.easResourceGroupService.setSuccessMessage("");
        this.easResourceGroupService.setdisplaySuccess(false);
        this.easResourceGroupService.setfailureMessage("");
        this.easResourceGroupService.setdisplayFailure(false);
        
    }
  closeAction() {
    this.resetMessageBlock();
    this.crudViewEmitter.emit('list');
  }
}
