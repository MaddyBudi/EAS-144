import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateEasResourceGroupComponent } from './create-eas-resource-group.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import {ResourceMockService } from '../eas-mock-resources.service';
import { EasResourcesService} from '../eas-resources.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { DataTableModule } from 'angular-6-datatable';
import { MapsAPILoader } from '@agm/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
describe('CreateEasResourceGroupComponent', () => {
  let component: CreateEasResourceGroupComponent;
  let fixture: ComponentFixture<CreateEasResourceGroupComponent>;
  let message="success" 
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateEasResourceGroupComponent ],
      imports : [
        FormsModule,
        BrowserAnimationsModule,
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule,
        DataTableModule
      ],
      providers: [{ provide: MapsAPILoader },{ provide: EasResourcesService, useClass: ResourceMockService }],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateEasResourceGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
   it('True if groupName provided is valid', () => {
    component.resourceGroupForm.controls['groupName'].setValue('Test Resource Group For Karma');
    setTimeout(() => {
    expect(component.resourceGroupForm.valid).toBeTruthy();
    })
  });

  it('False if groupName provided is Invalid', () => {
    component.resourceGroupForm.controls['groupName'].setValue('');
    
    expect(component.resourceGroupForm.valid).toBeFalsy();
  });

  it('True if resourceGroupDesc is not provided is valid', () => {
    component.resourceGroupForm.controls['groupName'].setValue('Test Resource Group For Karma');
    component.resourceGroupForm.controls['resourceGroupDesc'].setValue('');
    expect(component.resourceGroupForm.valid).toBeTruthy();
  });

  it(`True if the resetCreatePage() operation is performed `, () => { // resets the page

    component.resourceGroupForm.controls['groupName'].setValue('Test');
    component.resourceGroupForm.controls['resourceGroupDesc'].setValue('Desc');
    component.resetCreatePage(event) 
    expect(component.resourceGroupForm.valid).toBeFalsy();
   
  });

  it('True if the closeaction() method is called and perform its action', (done) => {

    //checks the getlistview method is called;
    component.crudViewEmitter.emit('list');
    component.crudViewEmitter.subscribe(data => {
      expect(data).toEqual('list'); //checks the value emitted is list
      done();
    })
       component.closeAction();
    
  });

  it('True if the addToGroup() method is called and perform its action', () => {
    component.addToGroup()
    component.easleftSideBarService.easleftSidebarToggle$.subscribe(g => {
      expect(g).toEqual('50%'); //checks the value emitted is list
    })
    
  });


  it('True if the searchDataEmitter() method is called and perform its action', () => {
    component.searchDataEmitter(event)
    component.easleftSideBarService.easleftSidebarToggle$.subscribe(g => {
      expect(g).toEqual('75%'); //checks the value emitted is list
    })
    });

    it('True if the closeComponent() method is called and perform its action', () => {
      component.closeComponent()
    });

    it('True if the getSelectedResource() method is called and perform its action', (done) => {
      setTimeout(() => {
        component.getSelectedResource(component.resourceData)
        expect(component.resourceData.length).not.toBe(0);
        expect(component.resourceId.length).not.toBe(0);
       done();
        },1000);
    });

    it('True if the deleteFromGroup() method is called and perform its action', (done) => {
      setTimeout(() => {
        component.deleteFromGroup(component.resourceData[0])
        expect(component.resourceData.length).toBe(1);
       done();
        },1000);
    });

    it('True if the displaySuccessPage() method is called and perform its action', () => {
      component.displaySuccessPage(message)
    });

    it('True if the displayFailurePage() method is called and perform its action', () => {
      component.displayFailurePage(message)
    });


    it('True if the formatResourceData() method is called and perform its action', (done) => {
      setTimeout(() => {
        component.formatResourceData(component.resourceData)
       done();
        },1000);
    });


});
