// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AssociateEasResourcesComponent } from './associate-eas-resources.component';

// describe('AssociateEasResourcesComponent', () => {
//   let component: AssociateEasResourcesComponent;
//   let fixture: ComponentFixture<AssociateEasResourcesComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AssociateEasResourcesComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AssociateEasResourcesComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
