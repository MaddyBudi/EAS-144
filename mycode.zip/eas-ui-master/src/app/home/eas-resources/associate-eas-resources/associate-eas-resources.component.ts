import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-associate-eas-resources',
  templateUrl: './associate-eas-resources.component.html',
  styleUrls: ['./associate-eas-resources.component.scss']
})
export class AssociateEasResourcesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
