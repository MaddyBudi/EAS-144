import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ResourceTypeTo } from '../../../shared/models/resourceTypeTo';
import { EasResourcesService } from '../eas-resources.service';
import { NotifierService } from 'angular-notifier';
import { SharedService } from '../../../shared/shared.service';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { TransactionMeasures } from '../../../transactionMeasures';

@Component({
  selector: 'app-list-eas-resource-type',
  templateUrl: './list-eas-resource-type.component.html',
  styleUrls: ['./list-eas-resource-type.component.scss']
})
export class ListEasResourceTypeComponent implements OnInit {
  resourceTypesTo: ResourceTypeTo[];
  isLoading: boolean = true;
  failureMsgEvent: string;
  displayFailure: boolean = false;
  @Output() crudViewEmitter = new EventEmitter();
  constructor(public resourceService: EasResourcesService,
    public easleftSideBarService: EasLeftSidebarService, public mapConsoleService: MapConsoleService, public sharedService: SharedService,
    public notifierService: NotifierService) { }
  trackByIdx(index: number, obj: any): any {
    return index;
  }
  ngOnInit() {
    this.resourceService.getAllResourceTypes().subscribe(
      data => {
        this.resourceTypesTo = data;
        this.isLoading = false
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.notifierService.notify('error', error.error.message);
          this.failureMsgEvent = error.error.message;
          this.displayFailure = true;
        }
      }

    );
  }
  createResourceType() {
    this.crudViewEmitter.emit("createResourceType");
  }
  backToResourceFullView() {
    this.crudViewEmitter.emit("list");
  }
  closeAction() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }
  editResourceType(entityId: string) {
    this.resourceService.updateResourceTypeEntityId = entityId;
    this.crudViewEmitter.emit("updateResourceType");
  }
}
