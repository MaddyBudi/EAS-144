import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListEasResourceTypeComponent } from './list-eas-resource-type.component';
import { SharedPipe } from '../../shared.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DataTableModule } from 'angular-6-datatable';
import { NotifierModule } from 'angular-notifier';
import { EasResourcesService } from '../eas-resources.service';
import { ResourceMockService } from '../eas-mock-resources.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ListEasResourceTypeComponent', () => {
  let component: ListEasResourceTypeComponent;
  let fixture: ComponentFixture<ListEasResourceTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListEasResourceTypeComponent  ,   SharedPipe],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        DataTableModule,
        NotifierModule
      ],
      providers: [{ provide: EasResourcesService, useClass: ResourceMockService }],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListEasResourceTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('switch to create resource Type', () => {
    component.createResourceType();
    component.crudViewEmitter.subscribe(g => {
      expect(g).toEqual('createResourceType'); 
     })
  });
  it('switch back to resource full view', () => {
    component.backToResourceFullView();
    component.crudViewEmitter.subscribe(g => {
      expect(g).toEqual('list'); 
     })
 });
 it('close', () => {
  component.closeAction();
  expect(component).toBeTruthy();
});
 it('switch to edit resource Type', () => {
  component.editResourceType("testResourceType1");
  expect(component.resourceService.updateResourceTypeEntityId).toBeDefined();
});
});
