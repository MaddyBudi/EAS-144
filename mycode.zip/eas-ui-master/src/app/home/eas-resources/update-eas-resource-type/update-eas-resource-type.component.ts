import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ResourceTypeTo } from '../../../shared/models/resourceTypeTo';
import { EasResourcesService } from '../eas-resources.service';
import { NotifierService } from 'angular-notifier';
import { SharedService } from '../../../shared/shared.service';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { TransactionMeasures } from '../../../transactionMeasures';

@Component({
  selector: 'app-update-eas-resource-type',
  templateUrl: './update-eas-resource-type.component.html',
  styleUrls: ['./update-eas-resource-type.component.scss']
})
export class UpdateEasResourceTypeComponent implements OnInit {
model:any={};
@Output() crudViewEmitter = new EventEmitter();
  constructor(public resourceService:EasResourcesService,
    public sharedService:SharedService,public notifierService: NotifierService,public easleftSideBarService:EasLeftSidebarService,public mapconsoleService:MapConsoleService) { }

  ngOnInit() {
    if(this.resourceService.updateResourceTypeEntityId)
    this.resourceService.getResourceTypeByEntityId(this.resourceService.updateResourceTypeEntityId).subscribe(
      data=>{
        this.model=data;
      },
      error=>{
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.notifierService.notify('error', error.error.message);
        }
      }
    )
  }
  trackByIdx(index: number, obj: any): any {
    return index;
  }
  addCapabilities(index) {
    if (this.model.capabilities[this.model.capabilities.length - 1] !== "")
      this.model.capabilities[this.model.capabilities.length] = "";
  }
  removeCapabilities(index) {
    this.model.capabilities.splice(index, 1);
  }
  handleKeyEnter(event) {
    event.preventDefault();
  }
  onSubmit(){
    this.model;
  }
  backToResourceTypeView(){
    this.crudViewEmitter.emit("listResourceType");
  }
  closeAction(){
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapconsoleService.closeSideBar();
  }
  reset(){
    this.ngOnInit();
  }
  cancel(){
    this.backToResourceTypeView();
  }
}
