import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DataTableModule } from 'angular-6-datatable';
import { NotifierModule } from 'angular-notifier';
import { EasResourcesService } from '../eas-resources.service';
import { ResourceMockService } from '../eas-mock-resources.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { SharedPipe } from '../../shared.pipe';
import { UpdateEasResourceTypeComponent } from './update-eas-resource-type.component';

describe('UpdateEasResourceTypeComponent', () => {
    let component: UpdateEasResourceTypeComponent;
    let fixture: ComponentFixture<UpdateEasResourceTypeComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [UpdateEasResourceTypeComponent, SharedPipe],
            imports: [
                FormsModule,
                ReactiveFormsModule,
                HttpClientModule,
                RouterTestingModule,
                DataTableModule,
                NotifierModule
            ],
            providers: [{ provide: EasResourcesService, useClass: ResourceMockService }],
            schemas: [NO_ERRORS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(UpdateEasResourceTypeComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('should check for manditary name feild', (done) => {
        setTimeout(() => {
            component.model.name = ["Fire"]
            expect(component.model.name === "Fire").toBeFalsy();
            done();
        }, 2000);

    });
    it('should check for manditary capability feild', () => {
        component.model.capabilities = ["test"]
        expect(component.model.capabilities.length).toBeTruthy();
    });
    it('should remove capabilities', () => {
        component.model.capabilities = ["test"]
        component.removeCapabilities(0);
        expect(component.model.capabilities.length === 0).toBeTruthy();
    });
    it('should add capabilities', () => {
        component.model.capabilities = ["test"]
        component.addCapabilities(1);
        expect(component.model.capabilities.length !== 0).toBeTruthy();
    });

    it('switch back to resource type full view', () => {
        component.backToResourceTypeView();
        component.crudViewEmitter.subscribe(g => {
            expect(g).toEqual('listResourceType');
        })
    });
    it('close', () => {
        component.closeAction();
        expect(component).toBeTruthy();
    });
    it('submit', () => {
        component.model.name = "test"
        component.model.capabilities = ["test"]
        component.onSubmit();
        expect(component.model.name).toBeTruthy();
    });
    it('should reset', () => {
        component.reset();  
        expect(component).toBeTruthy();
    });

    it('should cancle', () => {
        component.cancel();  
        expect(component).toBeTruthy();
    });
});
