import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateEasResourceComponent } from './create-eas-resource.component';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { GeoAddressComponent } from '../../geo-address/geo-address.component';
import { MapsAPILoader } from '@agm/core';
import { UserService } from '../../../login/services/user.service';
import { SharedService } from '../../../shared/shared.service';

describe('CreateEasResourceComponent', () => {
  let component: CreateEasResourceComponent;
  let fixture: ComponentFixture<CreateEasResourceComponent>;
  let geoAddressComponent: GeoAddressComponent;
  let geoAddressComponentfixture: ComponentFixture<GeoAddressComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        CreateEasResourceComponent,
        GeoAddressComponent
      ],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NotifierModule,
        OwlDateTimeModule,
        OwlNativeDateTimeModule,
        HttpClientModule,
        TabsModule.forRoot()
      ]
    })
      .compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateEasResourceComponent);
    component = fixture.componentInstance;
    geoAddressComponentfixture = TestBed.createComponent(GeoAddressComponent);
    geoAddressComponent = geoAddressComponentfixture.componentInstance;
  });

  it('should create', () => {
      expect(component).toBeTruthy();
  });

  it('True if resourcename provided is valid', () => {
    component.createResourceForm.controls['name'].setValue('Test Resource For Karma');
    expect(component.createResourceForm.valid).toBeTruthy();
  });


  it(`True if  lat,long , address value is fetched from geoAddress component and name is fetched
   from createResourceForm`, (done) => {   // should get the value from the geocomponent

     component.createResourceForm.controls['name'].setValue('Test Resource For Karma');
     geoAddressComponent.geoAddressForm.controls['latitude'].setValue('42.345264');
     geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-71.096381');
     geoAddressComponent.geoAddressForm.controls['address'].setValue('1265 Boylston St, Boston, MA 02215, USA');

     geoAddressComponent.setAddress();
     setTimeout(() => {
      expect(component.createResourceForm.valid).toBeTruthy();
      expect(geoAddressComponent.geoAddressForm.valid).toBeTruthy();
      done();
      }, 1000);

    });

  it(`False if  lat,long is fetched, address value is not fetched from geoAddress component and name is fetched
   from createResourceForm`, (done) => {   // should get the value from the geocomponent

      geoAddressComponent.setValueInAddressField('42.345264', '-71.096381');
      component.createResourceForm.controls['name'].setValue('Karma Resource For Test');

      setTimeout(() => {
        geoAddressComponent.onSubmit();
        expect(component.createResourceForm.valid).toBeTruthy();
        expect(geoAddressComponent.geoAddressForm.valid).toBeFalsy();
        done();
      }, 1000);

    });

  it(`False if  address value is fetched ,lat,long is not fetched from geoAddress component and name is fetched
   from createResourceForm`, (done) => {   // should get the value from the geocomponent

      component.createResourceForm.controls['name'].setValue('Karma Resource For Test');
      geoAddressComponent.setPlaceAndAddress('1265 Boylston St, Boston, MA 02215, USA');

      setTimeout(() => {
        geoAddressComponent.onSubmit();
        expect(component.createResourceForm.valid).toBeTruthy();
        expect(geoAddressComponent.geoAddressForm.valid).toBeFalsy();
        done();
      }, 1000);

    });

  it(`True if the resetCreatemethod() operation is performed `, (done) => { // resets the page

    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('');
    geoAddressComponent.geoAddressForm.controls['longitude'].setValue('');
    geoAddressComponent.geoAddressForm.controls['address'].setValue('');
    geoAddressComponent.setAddress();
    expect(geoAddressComponent.geoAddressForm.valid).toBeFalsy();
    done();
  });

  it('True if the closeaction() method is called and perform its action', (done) => {

    //checks the getlistview method is called;
    component.crudViewEmitter.subscribe( data => {
      expect(data).toEqual('list'); //checks the value emitted is list
      done();
    })
    component.closeAction();

  });

  it('False if the closeaction() method is not called and not perform its action', (done) => {

    //checks the getlistview method is called;
    component.crudViewEmitter.subscribe(data => {
      expect(data).toEqual('list'); //checks the value emitted is list
      done();
    })
    component.closeAction();

  });


});

