import { Component, OnInit, Inject, forwardRef, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { SharedService } from '../../../shared/shared.service';
import { AppGlobals } from '../../../shared/app.globals';
declare let google: any;
import * as $ from 'jquery';
import { ListEasEventsComponent } from '../../eas-events/list-eas-events/list-eas-events.component';
import { EasResourcesService } from '../eas-resources.service';
import { NotifierService } from 'angular-notifier';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { PersonResourceTo } from '../../../shared/models/personResourceTo';
import { AgencyResourceTo } from '../../../shared/models/agencyResourceTo';
import { VehicleResourceTo } from '../../../shared/models/vehicleResourceTo';
import { EquipmentResourceTo } from '../../../shared/models/equipmentResourceTo';
import { DobTo } from '../../../shared/models/dobTo';


@Component({
  selector: 'app-create-eas-resource',
  templateUrl: './create-eas-resource.component.html',
  styleUrls: ['./create-eas-resource.component.scss']
})
export class CreateEasResourceComponent implements OnInit {
  @Output() crudViewEmitter = new EventEmitter();
  isFormModified = false;
  createResourceForm = new FormGroup({
    capability_points: new FormArray([
      new FormControl('key'),
      new FormControl('value'),
    ]),
    ability_points: new FormArray([
      new FormControl('key'),
      new FormControl('value'),
    ]),
    custom_points_equipments: new FormArray([
      new FormControl('value'),
    ]),
    name: new FormControl(),
    address: new FormControl(),
    latitude: new FormControl(),
    longitude: new FormControl(),
    email: new FormControl(),
    subType: new FormControl(),
    firstName: new FormControl(),
    middleName: new FormControl(),
    lastName: new FormControl(),
    nameSuffix: new FormControl(),
    namePrefix: new FormControl(),
    gender: new FormControl(),
    dob: new FormControl(),
    phoneNumber: new FormControl(),
    // phoneExt:new FormControl(),
    phoneType: new FormControl(),
    vNumber: new FormControl(),
    vType: new FormControl(),
    vYear: new FormControl(),
    vMake: new FormControl(),
    vModel: new FormControl(),
    vSeries: new FormControl(),
    vBodyType: new FormControl(),
    vColor1: new FormControl(),
    vColor2: new FormControl(),
    vEquipmentType: new FormControl(),
    kodiakMdn: new FormControl(),
    interpid: new FormControl(),
  });
  fullAddress;
  capabilities;
  abilities;
  resourceType1 = this.appGlobals.person;
  displayFailureCapability = false;
  displayFailureAbility = false;
  displayFailureEquipments = false;
  equipments;
  subType = 'eas-users';
  isBasicInfoActive = true;
  isAdditionalInfoActive = false;
  checkValidation: boolean;
  resourceDetails;
  personResource: PersonResourceTo;
  agencyResource: AgencyResourceTo;
  vehicleResource: VehicleResourceTo;
  equipmentResource: EquipmentResourceTo;
  constructor(public formGroup: FormBuilder, private notifierService: NotifierService,
    public resourceSvc: EasResourcesService, public sharedService: SharedService,
    private geocodeAddress: GeoAddressService, public appGlobals: AppGlobals, private fb: FormBuilder) {
    this.createResourceForm.controls['subType'].setValue(this.appGlobals.easUsers, { onlySelf: true });
    this.createResourceForm.controls['phoneType'].setValue(this.appGlobals.defaultPhType, { onlySelf: true });
    this.createResourceForm.controls['gender'].setValue(this.appGlobals.defaultGender, { onlySelf: true });
    this.createResourceForm.controls['vType'].setValue(this.appGlobals.defaultVehicleType, { onlySelf: true });
    this.createResourceForm.controls['vEquipmentType'].setValue(this.appGlobals.defaultEquipmentType, { onlySelf: true });

    this.personResource = new PersonResourceTo(this.resourceSvc.personResourcePayload);
    this.vehicleResource = new VehicleResourceTo(this.resourceSvc.vehicleResourcePayload);
    this.agencyResource = new AgencyResourceTo(this.resourceSvc.agencyResourcePayload);
    this.equipmentResource = new EquipmentResourceTo(this.resourceSvc.equipmentResourcePayload);
  }
  ngOnInit() {
    this.setResourceForm();
    this.resourceDetails = this.personResource;
  }

  setResourceForm() {
    this.createResourceForm = this.formGroup.group({
      'name': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'address': [''],
      'latitude': [''],
      'longitude': [''],
      'email': [],
      'phone': [],
      'subType': [this.appGlobals.easUsers],
      'firstName': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'middleName': [],
      'lastName': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'namePrefix': [],
      'nameSuffix': [],
      'gender': [this.appGlobals.defaultGender],
      'dob': [],
      'phoneNumber': [],
      // 'phoneExt':[],
      'phoneType': [this.appGlobals.defaultPhType],
      'vNumber': [],
      'vType': [this.appGlobals.defaultVehicleType],
      'vYear': [],
      'vMake': [],
      'vModel': [],
      'vSeries': [],
      'vBodyType': [],
      'vColor1': [],
      'vColor2': [],
      'vEquipmentType': [this.appGlobals.defaultEquipmentType],
      'capability_points': this.formGroup.array([this.formGroup.group({ key: '', value: '' })]),
      'ability_points': this.formGroup.array([this.formGroup.group({ key: '', value: '' })]),
      'custom_points_equipments': this.formGroup.array([this.formGroup.group({ value: '' })]),
      'key': [],
      'value': [],
      'kodiakMdn': [],
      'interpid': ['', Validators.compose([Validators.minLength(1), Validators.maxLength(50)])]
    });

    this.createResourceForm.valueChanges.subscribe(data => {
      this.isFormModified = true;
    });
  }

  resetCreatePage(event) {
    this.geocodeAddress.resetAll();
    this.setResourceForm();
  }

  formChange(value) {

    if (value && value === this.appGlobals.vehicle) {
      this.createResourceForm.controls['subType'].setValue(this.appGlobals.law, { onlySelf: true });
      this.resourceDetails = this.vehicleResource;
    } else if (value && value === this.appGlobals.person) {
      this.subType = 'eas-users';
      this.createResourceForm.controls['subType'].setValue(this.appGlobals.easUsers, { onlySelf: true });
      this.resourceDetails = this.personResource;
    } else if (value && value === 'Agency') {
      this.resourceDetails = this.agencyResource;
    } else if (value && value === 'Equipment') {
      this.resourceDetails = this.equipmentResource;
    }
  }
  setActiveTab(tabName) {
    if (tabName === 'basicInfo') {
      this.isBasicInfoActive = true;
      this.isAdditionalInfoActive = false;
    } else if (tabName === 'additionalInfo') {
      this.isBasicInfoActive = false;
      this.isAdditionalInfoActive = true;
    }
  }

  // subscribes to create endpoint
  createResource(event, formData) {
    this.geocodeAddress.activeAddressInfo();
    formData.address = this.geocodeAddress.address;
    formData.latitude = this.geocodeAddress.latitude;
    formData.longitude = this.geocodeAddress.longitude;
    event.preventDefault();
    this.resourceDetails.setAddress(this.sharedService.getFullAddress(this.geocodeAddress.place));
    const geo = {
      'type': 'Point',
      'coordinates': [
        parseFloat(formData.longitude),
        parseFloat(formData.latitude)
      ]
    };
    this.resourceDetails.setGeometry(geo);
    if (formData.dob !== null) {
      const dateArr = formData.dob.toString().split(' ');
      const date = {
        'day': dateArr[2],
        'month': new Date(Date.parse(dateArr[1] + ' 1, 2012')).getMonth() + 1,
        'year': dateArr[3]
      };
      this.resourceDetails.dob = new DobTo(date);
    }
    for (const c in this.createResourceForm.controls) {
      if (this.createResourceForm.controls.hasOwnProperty(c)) {
        this.createResourceForm.controls[c].markAsTouched();
      }
    }
    if (this.resourceDetails.type !== 'personResource' && this.createResourceForm.controls.name.valid 
      && this.geocodeAddress.checkValidation) {
      this.createResourceServiceCall(formData);
    } else if (this.resourceDetails.type === 'personResource' && this.createResourceForm.valid && this.geocodeAddress.checkValidation) {
      this.createResourceServiceCall(formData);
    } else {
      this.notifierService.notify('error', 'Please provide the correct details to create a resource');
      if (this.createResourceForm.value.name && this.geocodeAddress.checkValidation === false) {
        this.setActiveTab('additionalInfo');
      }
    }
  }

  createResourceServiceCall(formData) {
  this.resourceDetails.capabilities = this.formatCapabilityAttributes(this.createResourceForm.value);
      this.resourceDetails.abilities = this.formatAbilityAttributes(this.createResourceForm.value);
      this.resourceDetails.equipments = this.formatCustomAttributesEquipments(this.createResourceForm.value);
      this.resourceSvc.createResource(this.resourceDetails).subscribe(
        data => {
          if (data.entityId !== null) {
            this.notifierService.notify('success', 'Resource "' + formData.name + '" created successfully.');
            this.crudViewEmitter.emit('list');
            this.geocodeAddress.resetAll();
          } else {
            this.notifierService.notify('error', this.appGlobals.createRscFailureMsg);
          }

        },
        error => {
          const errMsg = 'Resource name -' + formData.name + ' already exists';
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else if (error.error.message === errMsg) {
            this.notifierService.notify('error', error.error.message);
          } else {
            this.notifierService.notify('error', this.appGlobals.generalErrorOccured);
          }
        }
      );
  }
  get capabilitiesKeyValuPair() {
    return this.createResourceForm.get('capability_points') as FormArray;
  }
  addCapabilitiesKeyValuePair(K, V) {
    this.capabilitiesKeyValuPair.push(this.fb.group({ key: K, value: V }));
  }
  addCapabilitiesKeyValue() {
    if (this.createResourceForm.value.capability_points[this.createResourceForm.value.capability_points.length - 1].key &&
      this.createResourceForm.value.capability_points[this.createResourceForm.value.capability_points.length - 1].value) {
      this.capabilitiesKeyValuPair.push(this.fb.group({ key: '', value: '' }));
      this.displayFailureCapability = false;
    } else {
      this.displayFailureCapability = true;
      setTimeout(() => {
        this.displayFailureCapability = false;
      }, 4000);
    }
  }

  deleteCapabilitiesKeyValue(index) {
    if (this.createResourceForm) {
      if (this.createResourceForm.value.capability_points.length > 1) {
        this.capabilitiesKeyValuPair.removeAt(index);
      } else {
        this.capabilitiesKeyValuPair.removeAt(0);
        this.addCapabilitiesKeyValuePair('', '');
      }
    }

  }
  get abilitiesKeyValuPair() {
    return this.createResourceForm.get('ability_points') as FormArray;
  }
  addAbilitiesKeyValuePair(K, V) {
    this.abilitiesKeyValuPair.push(this.fb.group({ key: K, value: V }));
  }
  addAbilitiesKeyValue() {
    if (this.createResourceForm.value.ability_points[this.createResourceForm.value.ability_points.length - 1].key &&
      this.createResourceForm.value.ability_points[this.createResourceForm.value.ability_points.length - 1].value) {
      this.abilitiesKeyValuPair.push(this.fb.group({ key: '', value: '' }));
      this.displayFailureAbility = false;
    } else {
      this.displayFailureAbility = true;
      setTimeout(() => {
        this.displayFailureAbility = false;
      }, 4000);
    }
  }

  deleteAbilitiesKeyValue(index) {
    if (this.createResourceForm) {
      if (this.createResourceForm.value.ability_points.length > 1) {
        this.abilitiesKeyValuPair.removeAt(index);
      } else {
        this.abilitiesKeyValuPair.removeAt(0);
        this.addAbilitiesKeyValuePair("", "");
      }
    }

  }
  get customValueEquipments() {
    return this.createResourceForm.get('custom_points_equipments') as FormArray;
  }
  addCustomValue() {
    if (this.createResourceForm.value.custom_points_equipments[this.createResourceForm.value.custom_points_equipments.length - 1].value) {
      this.customValueEquipments.push(this.formGroup.group({ value: '' }));
      this.displayFailureEquipments = false;
    } else {
      this.displayFailureEquipments = true;
      setTimeout(() => {
        this.displayFailureEquipments = false;
      }, 4000);
    }
  }

  deleteCustomValue(index) {
    if (this.createResourceForm.value.custom_points_equipments.length > 1) {
      this.customValueEquipments.removeAt(index);
    } else {
      this.customValueEquipments.removeAt(0);
      this.customValueEquipments.push(this.formGroup.group({ value: '' }));
    }
  }
  formatCustomAttributesEquipments(customAttr) {
    const formatted_attr = [];
    customAttr.custom_points_equipments.forEach(element => {
      formatted_attr.push(element.value);
    });
    return formatted_attr;
  }
  formatCapabilityAttributes(customAttr) {
    const formatted_attr = {};
    customAttr.capability_points.forEach(element => {
      formatted_attr[element.key] = element.value;
    });
    return formatted_attr;
  }

  formatAbilityAttributes(customAttr) {
    const formatted_attr = {};
    customAttr.ability_points.forEach(element => {
      formatted_attr[element.key] = element.value;
    });
    return formatted_attr;
  }

  blockSpecialChar(e) {
    const k = e.keyCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k === 8 || (k >= 48 && k <= 57) || k === 32);
  }
  closeAction() {
    this.crudViewEmitter.emit("list");
  }

}
