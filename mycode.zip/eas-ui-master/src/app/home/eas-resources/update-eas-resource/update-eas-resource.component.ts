import { Component, OnInit, SimpleChange, OnChanges, Input, Inject, forwardRef, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import * as $ from 'jquery';
import { SharedService } from '../../../shared/shared.service';
import { AppGlobals } from '../../../shared/app.globals';
import { EasResourcesService } from '../eas-resources.service';
import { NotifierService } from 'angular-notifier';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { PersonResourceTo } from '../../../shared/models/personResourceTo';
import { AgencyResourceTo } from '../../../shared/models/agencyResourceTo';
import { VehicleResourceTo } from '../../../shared/models/vehicleResourceTo';
import { EquipmentResourceTo } from '../../../shared/models/equipmentResourceTo';
import { DobTo } from '../../../shared/models/dobTo';

@Component({
  selector: 'app-update-eas-resource',
  templateUrl: './update-eas-resource.component.html',
  styleUrls: ['./update-eas-resource.component.scss']
})
export class UpdateEasResourceComponent implements OnInit {
  @Input() selectedResource: string;
  @Output() crudViewEmitter = new EventEmitter();
  dob;
  updateResourceForm = new FormGroup({
    capabilities: new FormArray([
      new FormControl('key'),
      new FormControl('value'),
    ]),
    abilities: new FormArray([
      new FormControl('key'),
      new FormControl('value'),
    ]),
    equipments: new FormArray([
      new FormControl('value'),
    ]),
    resourceName: new FormControl(),
    address: new FormControl(),
    latitude: new FormControl(),
    longitude: new FormControl(),
    email: new FormControl(),
    resourceObject: new FormControl(),
    resourceType: new FormControl(),
    firstName: new FormControl(),
    middleName: new FormControl(),
    lastName: new FormControl(),
    nameSuffix: new FormControl(),
    namePrefix: new FormControl(),
    gender: new FormControl(),
    dob: new FormControl(),
    phoneNumber: new FormControl(),
    // phoneExt:new FormControl(),
    phoneType: new FormControl(),
    vin: new FormControl(),
    vehicleType: new FormControl(),
    year: new FormControl(),
    make: new FormControl(),
    model: new FormControl(),
    series: new FormControl(),
    bodyType: new FormControl(),
    color1: new FormControl(),
    color2: new FormControl(),
    equipmentType: new FormControl(),
    kodiakMdn: new FormControl(),
    intrepidCallSign: new FormControl()
  });
  primaryCategoryList: any;
  displayUpdateContent = true;
  isFormModified = false;
  public resourceDetails;
  selectedItems = [];
  dropdownSettings = {};
  stateList = [];
  countyList = [];
  capabilities;
  abilities;
  newCapabilities;
  newAbilities;
  selectedResourceID;
  filterQuery: '';
  resourceType1;
  // public countiesMap = new Map();
  tabDisabled;
  resetFlag = false;
  displayFailure = false;
  displayFailureAbility = false;
  displayFailureEquipments = false;
  failureMessage = "";
  equipments;
  latitude;
  longitude;
  public resetData;
  personResource: PersonResourceTo;
  agencyResource: AgencyResourceTo;
  vehicleResource: VehicleResourceTo;
  equipmentResource: EquipmentResourceTo;
  constructor(public formGroup: FormBuilder, private resourceSvc: EasResourcesService,
    public sharedService: SharedService, public appGlobals: AppGlobals, private fb: FormBuilder,
    private notifierService: NotifierService, private geoAddressService: GeoAddressService) {

    if (this.resourceSvc.getupdateResourcedata() !== undefined) {
      this.resourceSvc.getResourceDetails(this.resourceSvc.getupdateResourcedata()).subscribe(
        data => {

          console.log(data)
          this.resourceDetails =data
          this.resetData =JSON.parse(JSON.stringify(data))
          this.resetData.geometry=JSON.stringify(this.resetData.geometry)
          this.setupdateResourceForm();
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.notifierService.notify('error', this.appGlobals.generalErrorOccured);
          }
        }
      );
    }
  }
  // sets initial update form
  ngOnInit() {
    this.resetFlag = false;



    this.updateResourceForm = this.formGroup.group({
      'resourceName': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'address': [''],
      'latitude': [''],
      'longitude': [''],
      'email': [],
      'phone': [],
      'resourceObject': [],
      'resourceType': [],
      'firstName': [],
      'middleName': [],
      'lastName': [],
      'namePrefix': [],
      'nameSuffix': [],
      'gender': [],
      'dob': [],
      'phoneNumber': [],
      // 'phoneExt':[],
      'phoneType': [],
      'vin': [],
      'vehicleType': [],
      'year': [],
      'make': [],
      'model': [],
      'series': [],
      'bodyType': [],
      'color1': [],
      'color2': [],
      'equipmentType': [],
      'kodiakMdn': [],
      'intrepidCallSign': [],
      'capabilities': this.formGroup.array([this.formGroup.group({ key: '', value: '' })]),
      'abilities': this.formGroup.array([this.formGroup.group({ key: '', value: '' })]),
      'equipments': this.formGroup.array([this.formGroup.group({ value: '' })]),
      'key': [],
      'value': []
    });
  }
  // binds value from resourceDetails to UI fields on update page
  setupdateResourceForm() {
    // const fullAddress=$.extend(true, {}, this.resourceDetails.address);
    this.latitude = this.resourceDetails.geometry['coordinates'][1];
    this.longitude = this.resourceDetails.geometry['coordinates'][0];
    this.geoAddressService.setAddressLatLng.next([this.longitude, this.latitude]);
    this.resourceType1 = this.resourceDetails.resourceObject;
    const tempDOB = this.resourceDetails.dob;
    this.dob = (tempDOB && tempDOB.day !== null && tempDOB.month !== null && tempDOB.year !== null) ? this.resourceDetails.dob.year +
      "-" + this.resourceDetails.dob.month + "-" + this.resourceDetails.dob.day : '';
    this.updateResourceForm.controls['resourceName'].setValue(this.resourceDetails.resourceName);
    this.updateResourceForm.controls['resourceObject'].setValue(this.resourceDetails.resourceObject);
    this.updateResourceForm.controls['resourceType'].setValue(this.resourceDetails.resourceType);
    if (this.resourceType1 === 'Person') {
      this.tabDisabled = false;
      this.updateResourceForm.controls['email'].setValue(this.resourceDetails.email);
      this.updateResourceForm.controls['gender'].setValue(this.resourceDetails.gender);
      this.updateResourceForm.controls['phoneNumber'].setValue(this.resourceDetails.phone.number);
      this.updateResourceForm.controls['dob'].setValue(this.dob);
      this.updateResourceForm.controls['phoneType'].setValue(this.resourceDetails.phone.phoneType);
      this.updateResourceForm.controls['namePrefix'].setValue(this.resourceDetails.name.namePrefix);
      this.updateResourceForm.controls['firstName'].setValue(this.resourceDetails.name.firstName);
      this.updateResourceForm.controls['middleName'].setValue(this.resourceDetails.name.middleName);
      this.updateResourceForm.controls['lastName'].setValue(this.resourceDetails.name.lastName);
      this.updateResourceForm.controls['nameSuffix'].setValue(this.resourceDetails.name.nameSuffix);
      this.updateResourceForm.controls['kodiakMdn'].setValue(this.resourceDetails.kodiakMdn);
      this.updateResourceForm.controls['intrepidCallSign'].setValue(this.resourceDetails.intrepidCallSign);
    } else if (this.resourceType1 === 'Vehicle' || this.resourceType1 === 'Equipment') {
      this.tabDisabled = false;
      if (this.resourceType1 === 'Vehicle') {
        this.updateResourceForm.controls['email'].setValue(this.resourceDetails.emails[0]);
        this.updateResourceForm.controls['phoneNumber'].setValue(this.resourceDetails.phones[0].number);
        this.updateResourceForm.controls['phoneType'].setValue(this.resourceDetails.phones[0].phoneType);
      }
      this.updateResourceForm.controls['vin'].setValue(this.resourceDetails.vin);
      this.updateResourceForm.controls['vehicleType'].setValue(this.resourceDetails.vehicleType);
      this.updateResourceForm.controls['year'].setValue(this.resourceDetails.year);
      this.updateResourceForm.controls['make'].setValue(this.resourceDetails.make);
      this.updateResourceForm.controls['model'].setValue(this.resourceDetails.model);
      this.updateResourceForm.controls['series'].setValue(this.resourceDetails.series);
      this.updateResourceForm.controls['bodyType'].setValue(this.resourceDetails.bodyType);
      this.updateResourceForm.controls['color1'].setValue(this.resourceDetails.color1);
      this.updateResourceForm.controls['color2'].setValue(this.resourceDetails.color2);
      this.updateResourceForm.controls['equipmentType'].setValue(this.resourceDetails.equipmentType);
    } else if (this.resourceType1 === 'Agency') {
      this.tabDisabled = true;
      this.updateResourceForm.controls['email'].setValue(this.resourceDetails.emails[0]);
      this.updateResourceForm.controls['phoneNumber'].setValue(this.resourceDetails.phones[0].number);
      // this.updateResourceForm.controls['phoneExt'].setValue(this.resourceDetails.phones[0].extension);
      this.updateResourceForm.controls['phoneType'].setValue(this.resourceDetails.phones[0].phoneType);
    }
    this.setCapabilityAttributes(this.resourceDetails.capabilities);
    this.setAbilityAttributes(this.resourceDetails.abilities);
    this.setEquipmentsAttributes(this.resourceDetails.equipments);
    this.updateResourceForm.valueChanges.subscribe(data => {
      this.isFormModified = true;
    });

  }
  concatenateDate(dateObj) {
    console.log((dateObj.year + "-" + dateObj.month + "-" + dateObj.day + 'T09:05:14.000Z').toString());
    return dateObj.year + "-" + dateObj.month + "-" + dateObj.day + 'T09:05:14.000Z';
  }
  // subscribes to update endpoint
  updateResource(event, formData) {
       event.preventDefault();
    this.geoAddressService.activeAddressInfo();
    this.resourceDetails.geometry.coordinates[1] = Number(this.geoAddressService.latitude);
    this.resourceDetails.geometry.coordinates[0] = Number(this.geoAddressService.longitude);
    console.log(this.resourceDetails.geometry)
    // formData.address = this.geoAddressService.address;
    if ( formData.hasOwnProperty('dob') && formData.dob !== null) {
      let dateArr = formData.dob.toString().split(" ");
      const date = {
        "day": dateArr[2],
        "month": new Date(Date.parse(dateArr[1] + " 1, 2012")).getMonth() + 1,
        "year": dateArr[3]
      };
      this.resourceDetails.dob = new DobTo(date);
      console.log(this.resourceDetails.dob)
    } else {
      this.resourceDetails.dob = formData.dob;
    }

    for (const c in this.updateResourceForm.controls) {
      if ((this.updateResourceForm.controls).hasOwnProperty(c)) {
        this.updateResourceForm.controls[c].markAsTouched();
      }
    }
    if (this.updateResourceForm.controls.resourceName.valid && this.updateResourceForm.controls.email.valid
      && this.updateResourceForm.controls.phoneNumber.valid && this.isFormModified && this.geoAddressService.checkValidation) {
      this.resourceDetails.setAddress(this.sharedService.getFullAddress(this.geoAddressService.place));
      this.resourceDetails.setCapabilities(this.formatCustomAttributes(this.updateResourceForm.value));
      this.resourceDetails.setAbilities(this.formatAbilityAttributes(this.updateResourceForm.value));
      this.resourceDetails.equipments = this.formatCustomAttributesEquipments(this.updateResourceForm.value);
      this.resourceDetails.geometry = JSON.stringify(this.resourceDetails.geometry)
      console.log(this.resourceDetails)
      let payload;
      if (this.resourceDetails instanceof PersonResourceTo) {
        this.personResource = this.resourceDetails;
        payload = this.personResource;
      } else if (this.resourceDetails instanceof AgencyResourceTo) {
        // this.resourceDetails.phones = [this.resourceDetails.phones];
        this.agencyResource = this.resourceDetails;
        payload = this.agencyResource;
      } else if (this.resourceDetails instanceof VehicleResourceTo) {
        this.vehicleResource = this.resourceDetails;
        payload = this.vehicleResource;
      } else if (this.resourceDetails instanceof EquipmentResourceTo) {
        this.equipmentResource = this.resourceDetails;
        payload = this.equipmentResource;
      }

      this.resourceSvc.updateResource(payload).subscribe(
        data => {
          if (data.entityId != null) {
            this.notifierService.notify('success', 'Resource "' + formData.resourceName + '" updated successfully.');
            this.crudViewEmitter.emit("list");
            this.geoAddressService.resetAll();
          } else {
            this.notifierService.notify('error', this.appGlobals.updateRscFailureMsg);
          }
        },
        error => {
          const errMsg = 'Resource name -' + formData.resourceName + ' already exists';
          console.log(errMsg);
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else if (error.error.message === errMsg) {
            this.notifierService.notify('error', error.error.message);
          } else {
            this.notifierService.notify('error', this.appGlobals.generalErrorOccured);
          }
        }
      );
    } else {
      this.notifierService.notify('error', 'Please modify the resource details/provide the correct details to update');

    }

  }

  resetUpdatePage(event) {
    this.geoAddressService.resetAll();
    this.geoAddressService.setAddressLatLng.next([this.longitude, this.latitude]);
    this.isFormModified = false;
    this.resetFlag = true;
    if (this.resourceDetails instanceof PersonResourceTo) {
    this.resourceDetails = new PersonResourceTo(JSON.parse(JSON.stringify(this.resetData)));
    } else if (this.resourceDetails instanceof AgencyResourceTo) {
    this.resourceDetails = new AgencyResourceTo(JSON.parse(JSON.stringify(this.resetData)));
    } else if (this.resourceDetails instanceof VehicleResourceTo) {
    this.resourceDetails = new VehicleResourceTo(JSON.parse(JSON.stringify(this.resetData)));
    } else if (this.resourceDetails instanceof EquipmentResourceTo) {
    this.resourceDetails = new EquipmentResourceTo(JSON.parse(JSON.stringify(this.resetData)));
    }
    this.setupdateResourceForm();
  }

  displaySuccessPage(successMesssage) {
    this.resourceSvc.setdisplaySuccess(true);
    this.resourceSvc.setSuccessMessage(successMesssage);

  }

  displayFailurePage(failureMessage) {
    this.resourceSvc.setdisplayFailure(true);
    this.resourceSvc.setfailureMessage(failureMessage);
  }

  displayUpdatePage() {
    this.displayUpdateContent = true;

    this.isFormModified = false;
  }

  setCapabilityAttributes(capabilities) {
    const count = Object.keys(capabilities).length;
    if (count === 1) {
      const key = Object.keys(capabilities)[0];
      const value = capabilities[key];
      if (key) {
        this.clearFormArray(<FormArray>this.updateResourceForm.get('capabilities'));
        this.addCapabilitiesKeyValuePair(key, value);
      } else {
        if (this.resetFlag) {
          this.clearFormArray(<FormArray>this.updateResourceForm.get('capabilities'));
          this.addCapabilitiesKeyValuePair("", "");
        }
      }
    } else {
      this.clearFormArray(<FormArray>this.updateResourceForm.get('capabilities'));
      for (const capability in capabilities) {
        if (capability) {
          const key = capability;
          const value = capabilities[capability];
          this.addCapabilitiesKeyValuePair(key, value);
        }
      }
    }

  }

  setAbilityAttributes(abilities) {
    const count = Object.keys(abilities).length;
    if (count === 1) {
      const key = Object.keys(abilities)[0];
      const value = abilities[key];
      if (key) {
        this.clearFormArray(<FormArray>this.updateResourceForm.get('abilities'));
        this.addAbilitiesKeyValuePair(key, value);
      } else {
        if (this.resetFlag) {
          this.clearFormArray(<FormArray>this.updateResourceForm.get('abilities'));
          this.addAbilitiesKeyValuePair("", "");
        }
      }
    } else {
      this.clearFormArray(<FormArray>this.updateResourceForm.get('abilities'));
      for (const capability in abilities) {
        if (capability) {
          const key = capability;
          const value = abilities[capability];
          this.addAbilitiesKeyValuePair(key, value);
        }
      }
    }

  }
  setEquipmentsAttributes(equipments) {
    this.clearFormArray(<FormArray>this.updateResourceForm.get('equipments'));
    for (const equipment in equipments) {
      if (equipment) {
        const value = equipments[equipment];
        this.customValueEquipments.push(this.formGroup.group({ value: value }));
      }
    }
  }

  clearFormArray = (formArray: FormArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }

  get capabilitiesKeyValuPair() {
    return this.updateResourceForm.get('capabilities') as FormArray;
  }

  addCapabilitiesKeyValuePair(K, V) {
    this.capabilitiesKeyValuPair.push(this.fb.group({ key: K, value: V }));
  }
  addCapabilitiesKeyValue() {
    if (this.updateResourceForm.value.capabilities[this.updateResourceForm.value.capabilities.length - 1].key &&
      this.updateResourceForm.value.capabilities[this.updateResourceForm.value.capabilities.length - 1].value) {
      this.capabilitiesKeyValuPair.push(this.fb.group({ key: '', value: '' }));
      this.displayFailure = false;
    } else {
      //this.failureMessage = "key and value should have proper value";
      this.displayFailure = true;
      setTimeout(() => {
        this.displayFailure = false;
      }, 4000);
    }
  }

  deleteCapabilitiesKeyValue(index) {
    if (this.updateResourceForm) {
      if (this.updateResourceForm.value.capabilities.length > 1) {
        this.capabilitiesKeyValuPair.removeAt(index);
      } else {
        this.capabilitiesKeyValuPair.removeAt(0);
        this.addCapabilitiesKeyValuePair("", "");
      }
    }

  }

  get abilitiesKeyValuPair() {
    return this.updateResourceForm.get('abilities') as FormArray;
  }


  addAbilitiesKeyValuePair(K, V) {
    this.abilitiesKeyValuPair.push(this.fb.group({ key: K, value: V }));
  }
  addAbilitiesKeyValue() {
    if (this.updateResourceForm.value.abilities[this.updateResourceForm.value.abilities.length - 1].key &&
      this.updateResourceForm.value.abilities[this.updateResourceForm.value.abilities.length - 1].value) {
      this.abilitiesKeyValuPair.push(this.fb.group({ key: '', value: '' }));
      this.displayFailureAbility = false;
    } else {
      //this.failureMessage = "key and value should have proper value";
      this.displayFailureAbility = true;
      setTimeout(() => {
        this.displayFailureAbility = false;
      }, 4000);
    }
  }

  deleteAbilitiesKeyValue(index) {
    if (this.updateResourceForm) {
      if (this.updateResourceForm.value.abilities.length > 1) {
        this.abilitiesKeyValuPair.removeAt(index);
      } else {
        this.abilitiesKeyValuPair.removeAt(0);
        this.addAbilitiesKeyValuePair("", "");
      }
    }

  }
  get customValueEquipments() {
    return this.updateResourceForm.get('equipments') as FormArray;
  }
  addCustomValue() {
    if (this.updateResourceForm.value.equipments[this.updateResourceForm.value.equipments.length - 1].value) {
      this.customValueEquipments.push(this.formGroup.group({ value: '' }));
      this.failureMessage = "";
      this.displayFailureEquipments = false;
    } else {
      this.failureMessage = "Please enter a proper value";
      this.displayFailureEquipments = true;
      setTimeout(() => {
        this.failureMessage = "";
        this.displayFailureEquipments = false;
      }, 4000);
    }
  }

  deleteCustomValue(index) {
    if (this.updateResourceForm.value.equipments.length > 1) {
      this.customValueEquipments.removeAt(index);
    } else {
      this.customValueEquipments.removeAt(0);
      this.customValueEquipments.push(this.formGroup.group({ value: '' }));
    }
  }

  formatCustomAttributesEquipments(customAttr) {
    const formatted_attr = [];
    customAttr.equipments.forEach(element => {
      formatted_attr.push(element.value);
    });
    return formatted_attr;
  }
  formatCustomAttributes(customAttr) {
    const formatted_attr = {};
    customAttr.capabilities.forEach(element => {
      formatted_attr[element.key] = element.value;
    });
    console.log(formatted_attr)
    return formatted_attr;
  }

  formatAbilityAttributes(customAttr) {
    const formatted_attr = {};
    customAttr.abilities.forEach(element => {
      formatted_attr[element.key] = element.value;
    });
    console.log(formatted_attr)
    return formatted_attr;
  }

  blockSpecialChar(e) {
    const k = e.keyCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k === 8 || (k >= 48 && k <= 57) || k === 32);
  }
  closeAction() {
    this.crudViewEmitter.emit("list");
  }
}
