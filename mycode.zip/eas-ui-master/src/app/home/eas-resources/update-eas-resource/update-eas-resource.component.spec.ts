import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpdateEasResourceComponent } from './update-eas-resource.component';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { GeoAddressComponent } from '../../geo-address/geo-address.component';
import { MapsAPILoader } from '@agm/core';
import { UserService } from '../../../login/services/user.service';
import { SharedService } from '../../../shared/shared.service';
import { PersonResourceTo } from '../../../shared/models/personResourceTo';
import { EasResourcesService } from '../eas-resources.service';
import { ResourceMockService } from '../eas-mock-resources.service';

describe('UpdateEasResourceComponent', () => {
  let component: UpdateEasResourceComponent;
  let fixture: ComponentFixture<UpdateEasResourceComponent>;
  let geoAddressComponent: GeoAddressComponent;
  let geoAddressComponentfixture: ComponentFixture<GeoAddressComponent>;
  let resourceService: EasResourcesService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        UpdateEasResourceComponent,
        GeoAddressComponent
      ],
      providers: [
        // EasResourcesService
        { provide: EasResourcesService, useClass: ResourceMockService }
      ],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NotifierModule,
        OwlDateTimeModule,
        OwlNativeDateTimeModule,
        HttpClientModule,
        TabsModule.forRoot()
      ]
    })
      .compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateEasResourceComponent);
    geoAddressComponentfixture = TestBed.createComponent(GeoAddressComponent);
    component = fixture.componentInstance;
    geoAddressComponent = geoAddressComponentfixture.componentInstance;
    resourceService = TestBed.get(EasResourcesService);

  });

  it('True if the component is created successfully', () => {
    expect(component).toBeTruthy();
  });

  it('should set the resourceDetails', (done) => {
    setTimeout(() => {
      expect(component.updateResourceForm.valid).toBeTruthy();
      done();
    }, 1000);

  });

  it('True if resourcename provided is valid', () => {
    component.updateResourceForm.controls['resourceName'].setValue('Test Resource For Karma');
    expect(component.updateResourceForm.valid).toBeTruthy();
  });

  it('False if the inputs were does not given in updateResourceForm', () => {
    expect(geoAddressComponent.geoAddressForm.valid && component.updateResourceForm.valid).toBeFalsy();
  });

  it('True if  lat,long , address value and name provided in UpdateResourceForm', (done) => {

    component.updateResourceForm.controls['resourceName'].setValue('Karma Resource For Test');
    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('42.345264');
    geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-71.096381');
     geoAddressComponent.geoAddressForm.controls['address'].setValue('1265 Boylston St, Boston, MA 02215, USA');

    setTimeout(() => {
      expect(component.updateResourceForm.valid && geoAddressComponent.geoAddressForm.valid).toBeTruthy();
      done();
    }, 1000);

  });

  it('False if Address is not provided from updateResourceForm', (done) => {   // should get the value from the geocomponent

    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('-73.934306');
    geoAddressComponent.geoAddressForm.controls['longitude'].setValue('40.797878');
    component.updateResourceForm.controls['resourceName'].setValue('Karma Resource For Test');

    setTimeout(() => {
    expect(component.updateResourceForm.valid).toBeTruthy();
    done();
    }, 1000);
  });

  it('False if lat,long is not provided in updateResourceForm', () => {   // should get the value from the geocomponent
    geoAddressComponent.geoAddressForm.controls['address'].setValue('1265 Boylston St, Boston, MA 02215, USA');
    expect(component.updateResourceForm.valid && geoAddressComponent.geoAddressForm.valid).toBeFalsy();

  });

  it('False if latitude is given and address, longitude are not given in updateResourceForm', (done) => {
    component.updateResourceForm.controls['resourceName'].setValue('Test Resource For KArma');
    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('40.739197');
    geoAddressComponent.setAddress();
    setTimeout(() => {
      expect(geoAddressComponent.geoAddressForm.valid && component.updateResourceForm.valid).toBeFalsy();
      done();
    }, 1000);
  });

  it('True if the resetUpdatetemethod() operation is performed ', (done) => { // resets the page

    component.updateResourceForm.controls['resourceName'].setValue('Test Resource For KArma');
    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('-73.934306');
    geoAddressComponent.geoAddressForm.controls['longitude'].setValue('40.797878');
    geoAddressComponent.geoAddressForm.controls['address'].setValue('2321, 1st Avenue,New York,NYNew York County');
   
    expect(geoAddressComponent.geoAddressForm.valid && component.updateResourceForm.valid).toBeTruthy();
    setTimeout(() => {
      component.resetUpdatePage(event);
      expect(geoAddressComponent.geoAddressForm.valid && component.updateResourceForm.valid).toBeFalsy();
      done();
    }, 1000);

  });

  it('True if the closeaction() method is called and perform its action', (done) => {

    component.crudViewEmitter.subscribe(g => {
      expect(g).toEqual('list');
      done();
    });
    component.closeAction();

  });
});
