// import { TestBed, inject } from '@angular/core/testing';

// import { EasResourceGroupService } from './eas-resource-group.service';

// describe('EasResourceGroupService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [EasResourceGroupService]
//     });
//   });

//   it('should be created', inject([EasResourceGroupService], (service: EasResourceGroupService) => {
//     expect(service).toBeTruthy();
//   }));
// });
