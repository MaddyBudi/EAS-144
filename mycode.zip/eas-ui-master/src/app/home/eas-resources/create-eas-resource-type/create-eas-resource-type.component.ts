import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ResourceTypeTo } from '../../../shared/models/resourceTypeTo';
import { EasResourcesService } from '../eas-resources.service';
import { NotifierService } from 'angular-notifier';
import { SharedService } from '../../../shared/shared.service';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { TransactionMeasures } from '../../../transactionMeasures';


@Component({
  selector: 'app-create-eas-resource-type',
  templateUrl: './create-eas-resource-type.component.html',
  styleUrls: ['./create-eas-resource-type.component.scss']
})
export class CreateEasResourceTypeComponent implements OnInit {
  model: any = {};
  resourceTypeTo: ResourceTypeTo;
  @Output() crudViewEmitter = new EventEmitter();

  constructor(public resourceService: EasResourcesService, public sharedService: SharedService, 
    public notifierService: NotifierService,public easleftSideBarService:EasLeftSidebarService,public mapconsoleService:MapConsoleService) {
    this.model.capabilities = [""]
  }

  ngOnInit() {

  }
  trackByIdx(index: number, obj: any): any {
    return index;
  }
  onSubmit() {
    this.model.capabilities = this.model.capabilities.filter(function (el) {
      return el != "";
    });
    if (this.model.capabilities.length > 0) {
      
      this.resourceTypeTo = new ResourceTypeTo(this.model);
      this.resourceService.createResourceType(this.model).subscribe(
        data => { 
          if (data.entityId) {
            this.notifierService.notify('success', this.resourceTypeTo.name + ' has created successfully.');
            this.backToResourceTypeView();
          }
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.notifierService.notify('error', error.error.message);
          }
        }
      );
    }
  }

  addCapabilities(index) {
    if (this.model.capabilities[this.model.capabilities.length - 1] !== "")
      this.model.capabilities[this.model.capabilities.length] = "";
  }
  removeCapabilities(index) {
    this.model.capabilities.splice(index, 1);
  }
  handleKeyEnter(event) {
    event.preventDefault();
  }

  backToResourceTypeView(){
    this.crudViewEmitter.emit("listResourceType");
  }

  closeAction(){
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapconsoleService.closeSideBar();
  }
  reset(){
    this.model = {};
    this.model.capabilities = [""]
  }
  cancel(){
    this.backToResourceTypeView();
  }
}
