import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DataTableModule } from 'angular-6-datatable';
import { NotifierModule } from 'angular-notifier';
import { EasResourcesService } from '../eas-resources.service';
import { ResourceMockService } from '../eas-mock-resources.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { CreateEasResourceTypeComponent } from './create-eas-resource-type.component';
import { SharedPipe } from '../../shared.pipe';

describe('CreateEasResourceTypeComponent', () => {
  let component: CreateEasResourceTypeComponent;
  let fixture: ComponentFixture<CreateEasResourceTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CreateEasResourceTypeComponent, SharedPipe],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        DataTableModule,
        NotifierModule
      ],
      providers: [{ provide: EasResourcesService, useClass: ResourceMockService }],
      schemas: [NO_ERRORS_SCHEMA]
    })
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateEasResourceTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should add capabilities', () => {
    component.addCapabilities(1);
    component.model.capabilities = ["test"]
    expect(component.model.capabilities.length !== 0).toBeTruthy();
  });
  it('should remove capabilities', () => {
    component.model.capabilities = []
    component.removeCapabilities(1);
    expect(component.model.capabilities.length === 0).toBeTruthy();
  });

  it('switch back to resource type full view', () => {
    component.backToResourceTypeView();
    component.crudViewEmitter.subscribe(g => {
      expect(g).toEqual('listResourceType');
    })
  });

  it('submit', () => {
    component.model.name = "test"
    component.model.capabilities = ["test"]
    component.onSubmit();
    expect(component.model.name).toBeTruthy();
  });
  it('close', () => {
    component.closeAction();
    expect(component).toBeTruthy();
  });
  it('should reset', () => {
    component.reset();
    expect(component).toBeTruthy();
  });

  it('should cancle', () => {
    component.cancel();
    expect(component).toBeTruthy();
  });
});
