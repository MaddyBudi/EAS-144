// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EasResourcesComponent } from './eas-resources.component';

// describe('EasResourcesComponent', () => {
//   let component: EasResourcesComponent;
//   let fixture: ComponentFixture<EasResourcesComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EasResourcesComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EasResourcesComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
