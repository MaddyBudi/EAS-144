import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { SharedService } from '../../../shared/shared.service';
import { environment } from '../../../../environments/environment';
import {  AppGlobals } from '../../../shared/app.globals';
import {ConfigService} from "../../../core/config/config-svc.service";
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AssignEasResourcesService {
  setGroup = false;
  assignAddressToResource = new Subject<any>();
  assignAddressToResource$ = this.assignAddressToResource.asObservable();
  closeMoreInformation = new Subject<any>();
  closeMoreInformation$ = this.closeMoreInformation.asObservable();
  
  constructor(private http: HttpClient, private appglobals: AppGlobals) { }
  // set HTTP Headers
  setHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'ASSIGN-RELEASE-RSRC'
      }),
      withCredentials: true
    };
    return httpOptions;
  }
  // call to assign resources to an event
    public assignResource(assignedRsrcs, eventId) {
    return this.http.put(ConfigService.config.eventServiceUrl + 
      '/assignResourcesToEvent?ENTITY_ID=' + eventId, assignedRsrcs, this.setHeaders()).pipe(map((res: any) => res));
  }
  // call to release resources from an event  
   public releaseResource(releasedRsrcs, eventId) {
    return this.http.put(ConfigService.config.eventServiceUrl + 
      '/releaseResourcesToEvent?ENTITY_ID=' + eventId, releasedRsrcs, this.setHeaders()).pipe(map((res: any) => res));
  }
  public assignAddress(address) {
    this.assignAddressToResource.next(address)
  }
  public closeMoreInfo() {
    this.closeMoreInformation.next();
  }
}
