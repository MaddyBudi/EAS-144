// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AssignEasResourcesComponent } from './assign-eas-resources.component';

// describe('AssignEasResourcesComponent', () => {
//   let component: AssignEasResourcesComponent;
//   let fixture: ComponentFixture<AssignEasResourcesComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AssignEasResourcesComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AssignEasResourcesComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
