// import { TestBed } from '@angular/core/testing';

// import { AssignEasResourcesService } from './assign-eas-resources.service';

// describe('AssignEasResourcesService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: AssignEasResourcesService = TestBed.get(AssignEasResourcesService);
//     expect(service).toBeTruthy();
//   });
// });
