import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EasResourceGroupService } from '../eas-resource-group.service';
import { AssignEasResourcesService } from './assign-eas-resources.service';
import { SharedService } from '../../../shared/shared.service';
import { AppGlobals } from '../../../shared/app.globals';
import * as $ from 'jquery';
import * as moment from 'moment';
import { EasResourcesService } from '../eas-resources.service';
import { EasEventsService } from '../../eas-events/eas-events.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { NotifierService } from 'angular-notifier';
// import { CdkDragDrop, moveItemInArray, transferArrayItem  } from '@angular/cdk/drag-drop';
import { ResourceTo } from '../../../shared/models/resourceTo';
import { AddressTo } from '../../../shared/models/addressTo';

declare let google: any;
let controller;
@Component({
  selector: 'app-assign-eas-resources',
  templateUrl: './assign-eas-resources.component.html',
  styleUrls: ['./assign-eas-resources.component.scss']
})
export class AssignEasResourcesComponent implements OnInit {
  @Output() crudViewTypeEmitter = new EventEmitter();
  @Output() eventContextEventMain = new EventEmitter();
  @Input() contextEventData;
  @Input() contextEventId;
  public selectedevent_payload: any;
  public resourceData = [];
  public resourceGroupData = [];
  public assignedResourceData = [];
  public assignedResources = [];
  public availableResourceData = [];
  public filteredData = [];
  public filteredDataMap = {};
  public releasedResources = [];
  public tempAssignRsrcs = [];
  public tempReleaseRsrcs = [];
  public displaySuccess = false;
  public displayFailure = false;
  public successMessage = "";
  public failureMessage = "";
  public showSubmitAlert = false;
  public showComponent = false;
  sortOrder = "asc";
  sortBy = "name";
  dispatchAddress = new AddressTo("");
  rowsPerPageList = [5, 10];
  defaultRowsPerPage = 5;
  currentObject;
  filterQueryAssign;
  filterQueryRelease;
  filterQueryAssignGroup;
  isMoreInfo = false;
  easOtherEntitiesData: any;
  eventAddress;
  selectedEventAddress;
  totalMembersCountInGroup = 0;
  availableMembersCountInGroup = 0;
  assignedMembersCountInGroup = 0;
  availableGroupMembersDetails = [];
  totalGroupMembersDetails = [];
  currentGroup: any;
  currentEvent;
  checkFlag = false;
  constructor(public resourceSvc: EasResourcesService, public assignEasResourcesService: AssignEasResourcesService,
    public sharedService: SharedService, public eventSvc: EasEventsService,
    private appglobals: AppGlobals, public mapConsoleService: MapConsoleService,
    public easleftSideBarService: EasLeftSidebarService, public notifierService: NotifierService,
    public easResourceGroupService: EasResourceGroupService) {
    this.assignEasResourcesService.assignAddressToResource$.subscribe(
      data => {
        this.assignResourceToAddress(data);
      });
    this.assignEasResourcesService.closeMoreInformation$.subscribe(
      data => {
        this.isMoreInfo = false;
      }
    )
  }

  public ngOnInit(): void {
    controller = this;
    if (!this.checkFlag)
      this.initObservable();

  }
  initObservable() {
    this.clearData();
    this.getResourcesOnLoad();
    this.selectedevent_payload = this.eventSvc.getSelectedEventPayload();
    this.selectedEventAddress = this.selectedevent_payload.payload.properties.eventAddress;
    this.dispatchAddress = new AddressTo('');

  }
  ngOnChanges(changes) {
    if (changes.hasOwnProperty("contextEventData")) {
      this.currentEvent = changes.contextEventData.currentValue;
      const address = new AddressTo(this.contextEventData.address);
      this.contextEventId = this.contextEventData.entityId;
      const data = {
        'payload': {
          'entityId': this.currentEvent.entityId,
          'properties': {
            'eventAddress': address,
            'eventName': this.currentEvent.properties.eventName
          }
        }
      };
      this.eventSvc.setSelectedEventPayload(data);
    }
    this.initObservable();
    this.checkFlag = true;

  }

  public getResourcesOnLoad() {
    this.resourceSvc.getAllResources().subscribe(
      data => {
        this.filteredData = this.filterAnnotations(data);
        this.filteredData.forEach(element => {
          if (element.assigned && element.assignedTo === this.selectedevent_payload.payload.entityId) {
            this.assignedResourceData.push(element)
          } else if (!element.assigned) {
            this.availableResourceData.push(element)
          }
          this.filteredDataMap[element.entityId] = element;
        });
        this.showComponent = true;
        this.resourceSvc.getAllResourcesGroup().subscribe(
          data => {
            this.resourceGroupData = data;
            data.forEach(element => {
              this.getGroupMembers(element);
            });

          },
          error => {
            if (error.status === 401) {
              this.sharedService.routeToLoginError(error.status);
            } else {
              this.notifierService.notify('error', 'Unable to get resources. Please try again later.');
            }
          }
        );
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.failureMessage = "Unable to get resources. Please try again later.";
          this.displayFailure = true;
        }
      }
    );

    if (this.availableResourceData.length > 0 || this.assignedResourceData.length > 0) {
      this.displayFailure = false;
    } else {
      this.failureMessage = "No assigned or available resources found. Please try again later.";
      this.displayFailure = true;
    }
  }

  public filterAnnotations(data) {
    const filteredData = data.filter(function (element) {
      controller.filteredDataMap[element.entityId] = element;
      return element.resourceObject !== 'ANNOTATION';
    });
    return filteredData;
  }
  public clearData() {
    this.resourceData = [];
    this.resourceGroupData = [];
    this.assignedResourceData = [];
    this.assignedResources = [];
    this.availableResourceData = [];
    this.filteredData = [];
    this.filteredDataMap = {};
    this.releasedResources = [];
    this.tempAssignRsrcs = [];
    this.tempReleaseRsrcs = [];
  }
  updateAssignment(e) {
    this.showSubmitAlert = true;
    const submitBtn = $('#submitBtn');
    submitBtn.prop('disabled', true);

    if (this.assignedResources.length > 0) {
      this.assignEasResourcesService.assignResource(this.assignedResources, this.selectedevent_payload.payload.entityId).subscribe(
        data => {
          this.showComponent = false;
          this.showSubmitAlert = false;
          this.notifierService.notify('success', 'Resources are assigned to  "'
            + this.selectedevent_payload.payload.properties.eventName + '" successfully');
          this.eventSvc.displaySuccess = true;
          this.eventContextEventMain.emit({
            "eventContextId": this.selectedevent_payload.payload.entityId,
            "eventContextName": this.selectedevent_payload.payload.properties.eventName
          });
          if (this.contextEventId === data.entityId) {
            data.properties.assignedResources = data.assignedResources;
            data.properties.assignedAnnotations = data.assignedAnnotations;
             this.mapConsoleService.setEventContext(data);
          }
          if (!this.checkFlag) {
            this.getListView();
          } else {
            this.onClose();
          }
        },
        error => {
          this.showSubmitAlert = false;
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.failureMessage = "Unable to assign resources. Please try again later.";
            this.displayFailure = true;
          }
        }
      );
    }
    if (this.releasedResources.length > 0) {
      this.assignEasResourcesService.releaseResource(this.releasedResources, this.selectedevent_payload.payload.entityId).subscribe(
        data => {
          this.notifierService.notify('success', 'Resources are released from "'
            + this.selectedevent_payload.payload.properties.eventName + '" successfully');
          this.eventSvc.displaySuccess = true;
          this.showComponent = false;
          this.showSubmitAlert = false;
          this.eventContextEventMain.emit({
            "eventContextId": this.selectedevent_payload.payload.entityId,
            "eventContextName": this.selectedevent_payload.payload.properties.eventName
          });
          if (this.contextEventId === data.entityId) {
            data.properties.assignedResources = data.assignedResources;
            data.properties.assignedAnnotations = data.assignedAnnotations;
             this.mapConsoleService.setEventContext(data);
          }
          if (!this.checkFlag) {
            this.getListView();
          } else {
            this.onClose();
          }
        },
        error => {
          this.showSubmitAlert = false;
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.failureMessage = "Unable to release resources. Please try again later.";
            this.displayFailure = true;
          }
        }
      );
    }
  }

  addToAssigned(e, data) {
    if (e === true) {
      if (data.dispatchAddress.state === null || data.dispatchAddress.state === undefined) {
        data.dispatchAddress = this.selectedevent_payload.payload.properties.eventAddress;
      }
      let resourceTo = new ResourceTo("");
      resourceTo.entityId = data.entityId;
      resourceTo.dispatchAddress = data.dispatchAddress;
      const resourceDispatch: ResourceTo = this.filteredDataMap[data.entityId];
      resourceDispatch.dispatchAddress = data.dispatchAddress;
      this.tempAssignRsrcs.push(resourceTo);
      this.tempReleaseRsrcs.forEach(element => {
        if (element.entityId === data.entityId) {
          this.tempReleaseRsrcs.splice(this.tempReleaseRsrcs.indexOf(data.entityId), 1);
        }
      })
    } else {
      if (data.dispatchAddress !== null) {
        data.dispatchAddress = new AddressTo("");
      }
      this.tempAssignRsrcs.forEach(element => {
        if (element.entityId === data.entityId) {
          this.tempAssignRsrcs.splice(this.tempAssignRsrcs.indexOf(data.entityId), 1);
        }
      })
    }
  }

  addToReleased(e, data) {
    if (e.target.checked) {
      let resourceTo = new ResourceTo("");
      resourceTo.entityId = data.entityId;
      resourceTo.dispatchAddress = data.dispatchAddress;
      this.tempReleaseRsrcs.push(resourceTo);
      this.tempAssignRsrcs.forEach(element => {
        if (element.entityId === data.entityId) {
          this.tempAssignRsrcs.splice(this.tempAssignRsrcs.indexOf(data.entityId), 1);
        }
      })
    } else {
      this.tempReleaseRsrcs.forEach(element => {
        if (element.entityId === data.entityId) {
          this.tempReleaseRsrcs.splice(this.tempReleaseRsrcs.indexOf(data.entityId), 1);
        }
      })
    }
  }

  assign() {
    this.resourceGroupData.forEach(element => {
      element.checked = false;
    });
    if (this.tempAssignRsrcs.length > 0 && this.availableResourceData.length > 0) {
      this.filterQueryAssign = '';
      this.filterQueryAssignGroup = '';
      for (let i = 0; i < this.tempAssignRsrcs.length; i++) {
        // (<HTMLInputElement>document.getElementById('groupCheckBox')).checked = false;
        const resource: ResourceTo = this.filteredDataMap[this.tempAssignRsrcs[i].entityId];
        if (resource) {
          if (!this.assignedResourceData.includes(resource)) {
            this.assignedResourceData.push(resource);
            if (!this.assignedResources.includes(this.tempAssignRsrcs[i])) {
              this.assignedResources.push(this.tempAssignRsrcs[i]);
            }
          } else {
            const index = this.assignedResources.findIndex(element =>
              element.entityId === this.tempAssignRsrcs[i].entityId);
            this.assignedResources.splice(index, 1);
            this.assignedResources.push(this.tempAssignRsrcs[i]);
          }
          if (this.availableResourceData.includes(resource)) {
            this.availableResourceData.splice(this.availableResourceData.indexOf(resource), 1);
          }
        }
      }
    }
    this.tempAssignRsrcs = [];
  }

  release() {
    if (this.tempReleaseRsrcs.length > 0 && this.assignedResourceData.length > 0) {
      this.filterQueryRelease = '';
      for (let i = 0; i < this.tempReleaseRsrcs.length; i++) {
        const resource = this.filteredDataMap[this.tempReleaseRsrcs[i].entityId];
        if (resource) {
          if (!this.availableResourceData.includes(resource)) {
            this.availableResourceData.push(resource);
            if (!this.releasedResources.includes(this.tempReleaseRsrcs[i])) {
              this.releasedResources.push(this.tempReleaseRsrcs[i]);
            }
          }
          if (this.assignedResourceData.includes(resource)) {
            this.assignedResourceData.splice(this.assignedResourceData.indexOf(resource), 1);
          }
        }
      }
    }
    this.tempReleaseRsrcs = [];
  }

  resetRsrcAssignment() {
    this.assignedResourceData = [];
    this.assignedResources = [];
    this.availableResourceData = [];
    this.releasedResources = [];
    this.tempAssignRsrcs = [];
    this.tempReleaseRsrcs = [];
    this.filteredData.forEach(element => {
      if (element.assigned && element.assignedTo === this.selectedevent_payload.payload.entityId) {
        this.assignedResourceData.push(element)
      } else {
        this.availableResourceData.push(element)
      }
    })
  }

  closeAction(event) {
    this.getListView();
  }

  getListView() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
    this.crudViewTypeEmitter.emit('list');
    this.checkFlag = false;
  }
  onClose() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
    this.checkFlag = false;
  }
  assignAddress(type, item) {
    if (type === "dispatchAddressGroup") {
      this.assignEasResourcesService.setGroup = true;
      this.currentGroup = item;
    }
    this.currentObject = item;
    this.notifierService.notify("info", "Please select an address from the map")
    this.mapConsoleService.assignAddress(item);
  }
  addressAutoComplete(e, data, type) {
    const autocomplete = new google.maps.places.Autocomplete(document.getElementById(e));
    autocomplete.addListener('place_changed', () => {
      const loc = [];
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ 'address': (<HTMLInputElement>document.getElementById(e)).value }, (results, status) => {
        if (status === google.maps.GeocoderStatus.OK) {
          loc[0] = results[0].geometry.location.lat();
          loc[1] = results[0].geometry.location.lng();
          const place = results[0];
          const address = this.sharedService.getFullAddress(place);
          const addressTo = new AddressTo(address);
          if (type !== "dispatchAddressGroup") {
            this.currentObject = data;
            this.currentObject.dispatchAddress = addressTo;
          } else {
            data.availableMembersCountInGroup.forEach(element => {
              data.dispatchAddress = addressTo
            })
          }
        }
      });
    });
  }
  assignResourceToAddress(data) {
    const addressTo = new AddressTo(data);
    if (this.assignEasResourcesService.setGroup === false || this.assignEasResourcesService.setGroup === undefined) {
      this.currentObject.dispatchAddress = addressTo;
    } else {
      this.assignEasResourcesService.setGroup = undefined;
      this.currentGroup.dispatchAddress = addressTo;
    }
    this.currentObject = undefined;
    this.currentGroup = undefined;
  }
  getLocalDate(date) {
    if (date !== null && date !== undefined) {
      const dateArr = date.split("T");
      const newDate = moment(dateArr[0], "DD-MM-YYYY").format('YYYY-MM-DD');
      const newDate1 = dateArr[0] + ' ' + dateArr[1];
      const stillUtc = moment.utc(newDate1);
      const local = moment(newDate1).local().format('YYYY-MM-DD HH:mm:ss');
      return local;
    } else {
      return null;
    }
  }
  viewResource(data) {
    // const entityData = [];
    if (typeof data.geometry !== "object")
      data.geometry = JSON.parse(data.geometry);
    this.mapConsoleService.viewMapEntitiesMap(this.sharedService.formPayloadForEntitiesMoreInfo([data],false,false));
  }
  viewResourceInfo(data) {
    const properties = {
      payload: { properties: data }
    }
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.maxView);
    this.isMoreInfo = true;
    this.easOtherEntitiesData = {
      dataEntityId: data.entityId,
      dataModel: data.resourceObject,
      payLoad: properties
    }
  }
  getGroupMembers(item) {
    this.totalGroupMembersDetails = [];
    this.availableGroupMembersDetails = [];
    this.availableMembersCountInGroup = 0;
    this.assignedMembersCountInGroup = 0;
    item.availableMembersCountInGroup = [];
    item.totalMembersCountInGroup = item.resources.length;
    this.totalMembersCountInGroup = item.resources.length;
    item.checked = false;
    if (!item.hasOwnProperty('dispatchAddress'))
      item.dispatchAddress = new AddressTo('');
    item.resources.forEach(data => {
      this.filteredData.forEach(element => {
        if (data === element.entityId) {
          this.totalGroupMembersDetails.push(element);
        }
      })
    })
    item.resources.forEach(data => {
      const index = this.filteredData.findIndex(element =>
        element.entityId === data && element.status === 'Available');
      if (index >= 0) {
        const content = this.filteredData[index];
        this.availableGroupMembersDetails.push(content);
        item.availableMembersCountInGroup.push(content.entityId);
      }
    })
    item.assignedMembersCountInGroup = item.totalMembersCountInGroup - item.availableMembersCountInGroup.length;
  }
  addToAssignedGroup(e, item) {
    item.checked = e.target.checked;
    if (e.target.checked) {
      item.availableMembersCountInGroup.forEach(data => {
        if (item.dispatchAddress.state === null || item.dispatchAddress.state === undefined) {
          item.dispatchAddress = this.selectedEventAddress;
        }
        const resource = new ResourceTo('');
        resource.entityId = data;
        resource.dispatchAddress = item.dispatchAddress;
        const resourceDispatch: ResourceTo = this.filteredDataMap[data];
        resourceDispatch.dispatchAddress = item.dispatchAddress;
        this.addToAssigned(true, resource);
      })
    }
    else {
      item.dispatchAddress = new AddressTo("");
      this.tempAssignRsrcs = [];
    }
  }
}
