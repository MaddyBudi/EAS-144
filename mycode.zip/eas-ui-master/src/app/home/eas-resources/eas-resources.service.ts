import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { AppGlobals } from '../../shared/app.globals';
import { ConfigService } from '../../core/config/config-svc.service';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs';
import { PersonResourceTo } from '../../shared/models/personResourceTo';
import { AgencyResourceTo } from '../../shared/models/agencyResourceTo';
import { VehicleResourceTo } from '../../shared/models/vehicleResourceTo';
import { EquipmentResourceTo } from '../../shared/models/equipmentResourceTo';
import { ResourceTo } from '../../shared/models/resourceTo';
import { AnnotationTo } from '../../shared/models/annotationTo';
import { ResourceTypeTo } from '../../shared/models/resourceTypeTo';

declare let google: any;

@Injectable({
  providedIn: 'root'
})
export class EasResourcesService {
  personComponentSubject = new Subject<boolean>();
  personComponent = this.personComponentSubject.asObservable();
  closeSearchResourceSubject = new Subject<string>();
  closeSearchResource$ = this.closeSearchResourceSubject.asObservable();
   closeSearch = new Subject<string>();
  closeSearch$ = this.closeSearch.asObservable();
  closeMoreInformation = new Subject<string>();
  closeMoreInformation$ = this.closeMoreInformation.asObservable();
  updateResourcedata;
  displaySuccess: boolean = false;
  displayFailure: boolean = false;
  successMessage: String;
  failureMessage: String;
  selectedResource;
  updateResourceTypeEntityId:string;
  allResourceData;
   availabilityStatus={
    '1':'Offline',
    '2':'Available',
    '3':'DND'
  };
  sortBy;
  sortOrder;
  address = {
"streetAddress1":"",
"streetAddress2":"",
"city":"",
"zip":"",
"state":"",
"county":"",
  };
name = {
  "namePrefix":"",
"nameSuffix":"",
"firstName":"",
"middleName":"",
"lastName":"",
};
phone = {
  "number": null,
"phoneType":"BUSINESS",
};
  personResourcePayload = {
"dataModel":"RESOURCE",
"resourceName":"",
"resourceObject":"Person",
"resourceType":"eas-users",
"status":"Available",
"assigned":false,
"address": this.address,
"properties":{},    
"capabilities":{},
"abilities":{},
"name": this.name,
"dob":{ },
"gender":"MALE",
"email": null,
"phone":this.phone,
"intrepidCallSign":"",
"kodiakMdn":null
};
vehicleResourcePayload = {
"type":"vehicleResource",
"dataModel":"RESOURCE",
"resourceName":"",
"resourceObject":"Vehicle",
"resourceType":"Law",
"status":"Available",
"assigned":false,
"address": this.address,
"properties":{},
"capabilities":{},
"abilities":{},
"year":"",
"make":"",
"model":"",
"series":"",
"bodyType":"",
"color1":"",
"color2":"",
"equipmentType":"FIRE",
"equipments":[""],
"vin":"",
"vehicleType":"AUTOMOBILE",
"emails":[],
"phones":[this.phone]
};
agencyResourcePayload = {

"type":"agencyResource",
"dataModel":"RESOURCE",
"resourceName":"",
"resourceObject":"Agency",
"status":"Available",
"assigned":false,
"address": this.address,
"properties":{},
"capabilities":{},
"abilities":{},
"emails":[],
"phones":[this.phone]
};
equipmentResourcePayload = {
"type":"equipmentResource",
"dataModel":"RESOURCE",
"resourceName":"",
"resourceObject":"Equipment",
"status":"Available",
"assigned":false,
"address": this.address,
"properties":{},
"dispatchAddress":"",
"capabilities":{},
"abilities":{},
"year":"",
"make":"",
"model":"",
"series":"",
"bodyType":"",
"color1":"",
"color2":"",
"equipmentType":"FIRE",
"equipments":[""]
};
  constructor(private http: HttpClient, private appglobals: AppGlobals) { }
  getHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All'
      }),
      withCredentials: true
    };
    return httpOptions;
  }
  // sends event details to create endpoint and creates an event
  public createResource(payload) {
    payload.geometry=JSON.stringify(payload.geometry)
    console.log(payload);
    return this.http.post(ConfigService.config.resourceServiceUrl + '/create', payload, this.getHeaders()).pipe(map((res: any) => res));
  }

  public getAllResources(){
    return this.http.get(ConfigService.config.resourceServiceUrl + '/getAll',
    this.getHeaders()).pipe(map((event => this.convertListToListObject(event))));
  }
  public getAllResourcesGroup() {

    return this.http.get(ConfigService.config.resourceServiceUrl + '/getAllResourceGroups',
    this.getHeaders()).pipe(map((res: any) => res));
  }
  // closes an event by passing its ID
  public closeResource(event) {
    console.log(event);
    const entityId = event.entityId;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All',
      }), withCredentials: true
    };
    return this.http.delete(ConfigService.config.resourceServiceUrl + '/delete?ENTITY_ID=' + entityId, httpOptions).pipe(
      map((res: any) => res));
  }
  
  // gets an event by its ID
  public getResourceDetails(entityId) {
    //const entityId = event.entityId;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All',
      }), withCredentials: true
    };
    return this.http.get(ConfigService.config.resourceServiceUrl + '/get?ENTITY_ID=' + entityId,
     httpOptions).pipe(map((event => this.convertResponseToObject(event))));
  }

  public  getResourceDetailsById(entityId) {
    const  httpOptions  =  {
      headers:  new  HttpHeaders({
        'Content-Type':  'application/json',
        'transactionId':  'sample',
        'reportType':  'All',
      }),  withCredentials:  true
    };
    return  this.http.get(ConfigService.config.resourceServiceUrl  +  '/get?ENTITY_ID='  +  entityId,  httpOptions).pipe(map((res:  any)  =>  res));
  }

  // updates an event by passing updated data
  public updateResource(payload) {
    return this.http.put(ConfigService.config.resourceServiceUrl + '/update', payload, this.getHeaders()).pipe(map((res: any) => res));
  }
  public getAllEvents() {
    return this.http.get(ConfigService.config.eventServiceUrl + '/getAllEvents', this.getHeaders()).pipe(map((res: any) => res));
  }
  public searchNearBy(formData) {
    console.log(formData)
    //return null;
    return this.http.get(ConfigService.config.resourceServiceUrl + '/searchByLocation?distance=' + formData.distance + '&lat=' + formData.latitude + '&lng=' + formData.longitude,
     this.getHeaders()).pipe(map((event => this.convertListToListObject(event))));
  }

  public searchAssociatedResources(formData) {
    console.log(formData)
    //return null;
    return this.http.get(ConfigService.config.resourceServiceUrl + '/getAssignedResourcesToEvent?assignedTo=' + formData.eventName + '&assigned=' + formData.assigned, 
    this.getHeaders()).pipe(map((event => this.convertListToListObject(event))));
  }
  public searchByCriteria(formData) {
    const capabilities = {};
    const abilities = {};
    if (null != formData.capKey && "" != formData.capKey && null != formData.capValue && "" != formData.capValue) {
      capabilities[formData.capKey] = formData.capValue;
    } else if (null != formData.capKey && "" != formData.capKey && null == formData.capValue && "" != formData.capValue) {
      capabilities[formData.capKey] = "";
    }
    if (null != formData.abilityKey && "" != formData.abilityKey && null != formData.abilityValue && "" != formData.abilityValue) {
      abilities[formData.abilityKey] = formData.abilityValue;
    } else if (null != formData.abilityKey && "" != formData.abilityKey && null == formData.abilityValue && "" != formData.abilityValue) {
      abilities[formData.abilityKey] = "";
    }
    let payload = {
      "type": "resource",
      "resourceName": formData.name,
      "capabilities": capabilities,
      "abilities": abilities,
      "address": {
      },
    }
    if (null !== formData.zip && "" != formData.zip) {
      payload.address["zip"] = formData.zip;
    }
    if (null != formData.state && "" != formData.state) {
      payload.address["state"] = formData.state;
    }
    if (null != formData.county && "" != formData.county) {
      payload.address["county"] = formData.county;
    }
    console.log(formData)
    return this.http.post(ConfigService.config.resourceServiceUrl + '/search', payload,
    this.getHeaders()).pipe(map((event => this.convertListToListObject(event))));
  }

  /**
  * getResourceByEventId
  */
  public getAssignedResourcesByEventId(assignedTo: string, assigned: boolean) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All'
      }), withCredentials: true
    };
    return this.http.get(ConfigService.config.resourceServiceUrl + '/getAssignedResourcesToEvent?assignedTo='
     + assignedTo + '&assigned=' + assigned, httpOptions).pipe(map((res: any) => res));
  }
  

  public getResourceNameOnTypeAheadSvc(fieldName, startsWith, from) {
    const resourceName = 'resourceName';
    return this.http.get(ConfigService.config.resourceServiceUrl + '/findResourcesByStartswith?fieldName='
    + fieldName + '&value=' + startsWith, this.getHeaders()).pipe(map((res: any) => res));
  }
  public getCapabilityKeysSvc() {
    console.log("called");
    const capability = 'capabilities';
    return this.http.get(ConfigService.config.resourceServiceUrl + '/findResourcesFieldKeys?fieldName='
    + capability, this.getHeaders()).pipe(map((res: any) => res));
  }
  public getAbilityKeysSvc() {
    const ability = 'abilities';
    return this.http.get(ConfigService.config.resourceServiceUrl + '/findResourcesFieldKeys?fieldName='
    + ability, this.getHeaders()).pipe(map((res: any) => res));
  }

    /**
   * deleteResource
   */
  public deleteResource(entityID) {
    return this.http.delete(ConfigService.config.resourceServiceUrl + '/delete?ENTITY_ID=' + entityID, this.getHeaders()).pipe(map((res: any) => res));

  }

  viewPersonSearchComponent(boolValue) {
    this.personComponentSubject.next(boolValue);
  }

  /**
   * setupdateResourcedata()
   */
  public setupdateResourcedata(data) {
    this.updateResourcedata = data;
  }

  /**
   * getupdateResourcedata
   */
  public getupdateResourcedata() {
    return this.updateResourcedata;
  }
  public setdisplaySuccess(displaySuccess) {
    this.displaySuccess = displaySuccess;
  }
  public getdisplaySuccess() {
    return this.displaySuccess;
  }
  public setdisplayFailure(displayFailure) {
    this.displayFailure = displayFailure;
  }
  public getdisplayFailure() {
    return this.displayFailure;
  }
  public setSuccessMessage(successMessage) {
    this.successMessage = successMessage;
  }
  public getSuccessMessage() {
    return this.successMessage;
  }
  public getfailureMessage() {
    return this.failureMessage;
  }
  public setfailureMessage(failureMessage) {
    this.failureMessage = failureMessage;
  }
  public setSelectedResources(data) {
    this.selectedResource = data;
  }
  public getSelectedResources() {
    return this.selectedResource;
  }
  public setAllResourceData(data) {
    this.allResourceData = data;
  }
  public getAllResourceData() {
    return this.allResourceData;
  }
  public closeSearchResource() {
     this.closeSearchResourceSubject.next();
  }

  /**
   * createResourceType
object:ResourceTypeTO   */
  public createResourceType(payload:ResourceTypeTo) {

    return this.http.post(ConfigService.config.resourceServiceUrl + '/createResourceType', payload, this.getHeaders()).pipe(map((res: any) => res));
 
  }

  public getAllResourceTypes() {
    return this.http.get(ConfigService.config.resourceServiceUrl + '/getAllResourceType',
    this.getHeaders()).pipe(map((event => this.convertResponseToobjectResourceType(event)))); 
  }

  /**
   * getResourceTypeByEntityId
   */
  public getResourceTypeByEntityId(entityId:string) {

    return this.http.get(ConfigService.config.resourceServiceUrl + '/getResourceType?ENTITY_ID=' + entityId,
    this.getHeaders()).pipe(map((event => this.convertResponseToObjectResourceTypeTo(event))));
  }
  public updateEpttUserLocation(userDetails) {
    if (userDetails !== null && userDetails !== undefined) {
    const kodiakContacts = [];
    const geocoder = new google.maps.Geocoder();
     userDetails.forEach(element => {
       let payload;
       payload = {
      'dataModel': 'RESOURCE',
      'resourceObject': 'Person',
      'resourceType': 'field-personnel',
      'geometry': JSON.stringify({
        'type': 'Point',
        'coordinates': [element.lng, element.lat]
      }),
      'kodiakMdn': element.mdn,
      'status': this.availabilityStatus[element.availabilityStatus],
      'lastKodiakUpdateDate': new Date().toISOString(),
      'type':  'personResource'
       };

     kodiakContacts.push(payload);
     });
    if (kodiakContacts !== null) {
      return this.http.post(ConfigService.config.resourceServiceUrl + '/updateEPTTResourceLocation', kodiakContacts,
      this.getHeaders()).pipe(map((res: any) => res));
    }
    }
  }
  closeMoreInfo() {
    this.closeMoreInformation.next();
  }
  public updateResourceLocation(payload) {
    return this.http.put(ConfigService.config.resourceServiceUrl + '/update', payload, this.getHeaders()).pipe(map((res: any) => res));
  }

  convertListToListObject(object:any) {
   let resourceTO = [];
  object.forEach(element => {
    if (element.resourceObject === 'Person') {
    const personResourceTo = new PersonResourceTo(element);
    resourceTO.push(personResourceTo);
    } else if (element.resourceObject === 'Vehicle') {
   const vehicleResourceTo = new VehicleResourceTo(element);
    resourceTO.push(vehicleResourceTo);
    }  else if (element.resourceObject === 'Agency') {
   const agencyResourceTo = new AgencyResourceTo(element);
    resourceTO.push(agencyResourceTo);
    }  else if (element.resourceObject === 'Equipment') {
   const equipmentResourceTo = new EquipmentResourceTo(element);
    resourceTO.push(equipmentResourceTo);
    } else if (element.resourceObject === 'ANNOTATION') {
      const annotationTo = new AnnotationTo(element);
       resourceTO.push(annotationTo);
       }

  });

  return resourceTO;
  }
  convertResponseToObject(object:any) {
    if(object.resourceObject === 'Person') {
       const personResourceTo = new PersonResourceTo(object);
       return personResourceTo;
    } else if(object.resourceObject === 'Vehicle') {
       const vehicleResourceTo = new VehicleResourceTo(object);
       return vehicleResourceTo;
    } else if(object.resourceObject === 'Agency') {
       const agencyResourceTo = new AgencyResourceTo(object);
       return agencyResourceTo;
    } else if(object.resourceObject === 'Equipment') {
       const equipmentResourceTo = new EquipmentResourceTo(object);
       return equipmentResourceTo;
    }
}
convertResponseToobjectResourceType(object: any) {
  let resourceTypesTo = [];
  object.forEach((element: any) => {
    const resourceTypeTo = new ResourceTypeTo(element);
    resourceTypesTo.push(resourceTypeTo);
  });

  return resourceTypesTo;
}

convertResponseToObjectResourceTypeTo(object:any) {

     const resourceTypeTo = new ResourceTypeTo(object);
     return resourceTypeTo;

}
}
