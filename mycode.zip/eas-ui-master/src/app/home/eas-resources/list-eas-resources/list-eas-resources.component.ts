import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { EasResourcesService } from '../eas-resources.service';
import { SharedService } from '../../../shared/shared.service';
import { AppGlobals } from '../../../shared/app.globals';
import { AssignEasResourcesService } from '../../eas-resources/assign-eas-resources/assign-eas-resources.service';
import { PersonService } from '../../map-console/person/person.service';
const swal = require('sweetalert');
import * as $ from 'jquery';
import * as moment from 'moment';
import { HomeService } from '../../home.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import { NotifierService } from 'angular-notifier';
import { EntitiesMiniListService } from '../../map-console/entities-mini-list/entities-mini-list.service';


@Component({
    selector: 'app-list-eas-resources',
    templateUrl: './list-eas-resources.component.html',
    styleUrls: ['./list-eas-resources.component.scss']
})
export class ListEasResourcesComponent implements OnInit {


    @Output() viewMapResource = new EventEmitter();
    @Output() crudViewEmitter = new EventEmitter();
    @Input() searchResourceData;
    @Output() getSelectedResource = new EventEmitter();
    @Input() contextEventId;
    @Input() contextEventName;

    isCreatePage = false;
    isEditPage = false;
    isSearchPage = false;
    selectedResource: any;
    failureMessage: String;
    rowsPerPageList: Number[] = this.appglobals.RowsPerPageList;
    defaultRowsPerPage: Number = this.appglobals.DefaultRowsPerPage;
    displaySuccess = false;
    successMessage: String;
    actionHeader: String;
    personData;
    vehicleData;
    easOtherEntitiesData: any;
    isMoreInfo: boolean = false;
    agencyData;
    isModule = false;
    sortOrder = "desc";
    sortBy = "createdDate";
    marked = false;
    selectedId = [];
    multipleLocations = [];
    markedAll = false;
    selectedAllResources = false;
    public searchresourceDatalength;
    data;
    fromSearchPage = false;
    resourceData = [];
    resourceAssociateData = [];
    resourceNotAssociateData = [];
    personAddress: any;
    eventContextRadioButton = false;
    displayFailureRsrc = false;
    failureMsgRsrc = '';
    groupHeader;
    noResourcesAvailable = 'No Resources available';
    isLoading = true;
    resourceAllData = [];
    selectedEntityId;
    constructor(public resourceSvc: EasResourcesService, public sharedService: SharedService,
        private appglobals: AppGlobals, public assignRsrcService: AssignEasResourcesService,
        private personService: PersonService, private homeService: HomeService, private easleftSideBarService: EasLeftSidebarService,
        private mapConsoleService: MapConsoleService, private notifierService: NotifierService,
        private entitiesMiniListService: EntitiesMiniListService) {

        this.resourceSvc.closeSearchResource$.subscribe(
            data => {
                this.isSearchPage = false;
                this.actionHeader = "Resource Full View";
                this.groupHeader = "Create Group";
                this.getResources();

            }
        );
        this.resourceSvc.closeMoreInformation$.subscribe(
            data => {
                this.isMoreInfo = false;
                this.selectedEntityId = undefined;
            }
        );
        this.entitiesMiniListService.clearContext$.subscribe(
            data => {
                this.eventContextRadioButton = false;
                this.resourceData = this.resourceAllData.slice();
                this.displayFailureRsrc = false;
            }
        );


    }


    public ngOnInit(): void {
        this.actionHeader = "Resource Full View";
        this.groupHeader = "Create Group";
        if (this.searchResourceData === undefined) {
            this.getResources();
        } else {
            this.setResourceData(this.searchResourceData, true);
            this.actionHeader = "Resource Search Results";
            this.groupHeader = "Add to group";
        }

        if (this.resourceSvc.sortBy && this.resourceSvc.sortOrder) {
            this.sortBy = this.resourceSvc.sortBy;
            this.sortOrder = this.resourceSvc.sortOrder;
        }
    }


    public ngOnDestroy() {


    }
    ngOnChanges(changes: any) {
        if (changes.hasOwnProperty("contextEventId")) {
            if (changes.contextEventId.currentValue !== '') {
                this.eventContextRadioButton = true;
            }
        }
    }
    getResources() {
        this.resourceSvc.getAllResources().subscribe(
            data => {
                this.resourceData = this.filterAnnotations(data);
                this.resourceAllData = this.resourceData;
                this.isLoading = false;
                this.resourceSvc.setAllResourceData(this.resourceData);
                console.log(this.resourceData);
            },
            error => {
                if (error.status === 401) {
                    this.sharedService.routeToLoginError(error.status);
                } else {
                    this.notifierService.notify('error' , 'Unable to get resources. Please try again later.');
                }
            }
        );
    }
    filterAnnotations(data) {
        const filteredData = data.filter(function (element) {
            return element.resourceObject !== 'ANNOTATION';
        });
        return filteredData;
    }
    setResourceData(data, fromSearch) {
        if (data.length === 0) {
            this.displayFailureRsrc = true;
            this.failureMsgRsrc = 'No results available';
            this.resourceData = [];
        } else {
            this.displayFailureRsrc = false;
            this.failureMsgRsrc = '';
            this.resourceData = data;
            this.isLoading = false;
        }
    }

    createResource(event) {
        this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
        this.crudViewEmitter.emit("create");
    }

    searchResource(event) {
        if (this.isMoreInfo)
            this.isMoreInfo = false;
        this.isSearchPage = true;
        this.actionHeader = "Resource Search Results";
        this.groupHeader = "Add to group";
        this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.maxView);
    }

    editResource(entityId) {
        this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
        this.crudViewEmitter.emit("update");
        this.resourceSvc.setupdateResourcedata(entityId);

    }
    resourceType(){
        this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
        this.crudViewEmitter.emit("listResourceType");
    }
    closeResource(event) {
        this.isEditPage = false;
        this.isCreatePage = false;
        this.displaySuccess = false;
        let assignedEventId;
        swal({
            title: 'Are you sure?',
            text: 'Delete the Resource "' + event.resourceName + '"',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Yes, Delete',
            cancelButtonText: 'No, cancel',
            closeOnConfirm: true,
            closeOnCancel: true
        }, (isConfirm) => {
            if (isConfirm) {
                if (null !== event && event.assignedTo) {
                    assignedEventId = event.assignedTo;
                    const temp = [];
                    const payload={
                        "dispatchAddress":event.dispatcherAddress,
                        "entityId":event.entityId,
                        "type":"resource"
                    }
                    temp.push(payload);
                    this.assignRsrcService.releaseResource(temp, event.assignedTo).subscribe(
                        res => {
                       this.deleteResource(event , "deleted and released");
                        },
                        error => {
                       this.notifierService.notify("error","Unable to release resource. Please try again later.");
                        });
                } else {
                    this.deleteResource(event , "deleted");
                }
            }
        });
    }
    deleteResource(event ,msg) {
        this.resourceSvc.deleteResource(event.entityId).subscribe(
                                data => {
                                    if (true === data) {
                                        this.notifierService.notify("success", 'Resource "' + event.resourceName + '" '+ msg +' successfully.')
                                        this.getResources();
                                    } else {
                                        swal('Not Deleted!', 'Please try again', 'Failure');
                                        this.notifierService.notify("error", "Unable to delete resource.Please try again later.")
                                    }
                                },
                                error => {
                                    if (error.status === 401) {
                                        this.sharedService.routeToLoginError(error.status);
                                    } else {
                                        swal('Not Deleted!', "Please try again", 'Failure');
                                    }
                                }
                            );
    }
    closeAction() {
        this.isEditPage = false;
        this.isCreatePage = false;
        this.isSearchPage = false;
        this.displaySuccess = false;
        // if (this.failureMessage === 'No records match your search criteria.') {
        //     this.displayFailure = false;
        // }
        this.getResources()
        //this.fromSearchPage=false;
    }
    onViewChange(data) {
        if (typeof data.geometry !== "object")
            data.geometry = JSON.parse(data.geometry);
        const entityData = this.sharedService.formPayloadForEntitiesMoreInfo([data], false, true);
        this.mapConsoleService.viewMapEntitiesMap(entityData);
    }

    toggleVisibility(e, id) {
        this.marked = e.target.checked;
        if (this.marked) {
            this.selectedId.push(id);
            this.resourceData.forEach(element => {
                if (id === element.id) {
                    element.checkboxFlag = true;
                }
            });
            if (this.selectedId.length === this.resourceData.length) {
                this.selectedAllResources = true;
            }
        } else {
            console.log(this.selectedId)
            const index = this.selectedId.indexOf(id);
            if ((index) > -1) {
                this.selectedId.splice(index, 1);
                this.selectedAllResources = false;
                this.resourceData.forEach(element => {
                    if (id === element.id) {
                        element.checkboxFlag = false;
                    }
                });
            }
        }
    }

    toggleVisibilityAllLocations(e) {
        this.markedAll = e.target.checked;
        if (this.markedAll === true) {
            this.selectedAllResources = true;
            this.resourceData.forEach(element => {
                element.checkboxFlag = true;
                this.selectedId.push(element.entityId);
            });
        } else if (this.markedAll === false) {
            this.selectedAllResources = false;
            this.resourceData.forEach(element => {
                element.checkboxFlag = false;
            });
            this.selectedId = [];
        }
    }

    plotSelectedResources() {
        if (this.resourceData.length === 0) {
            this.notifierService.notify('error', 'No Resources are available to view');
        } else if ((!this.selectedAllResources) && (this.selectedId.length === 0)) {
            this.notifierService.notify('error', 'Please select atleast one resource to view');
        } else if (this.selectedAllResources) {
            this.selectedResource = this.resourceData;
            this.selectedResource.forEach(element => {
                element.coordinates = this.getViewCoordinates(element);
            });
            this.mapConsoleService.viewMapEntitiesMap(this.resourceData);
        } else if (this.selectedId.length >= 1) {
            this.multipleLocations = this.getSelectedLocations();
            this.multipleLocations.forEach(element => {
                element.coordinates = this.getViewCoordinates(element);
            });
            const entityData = this.sharedService.formPayloadForEntitiesMoreInfo(this.multipleLocations, false, true);
            this.mapConsoleService.viewMapEntitiesMap(entityData);
        }
        this.onClose();
    }

    getSelectedLocations() {
        const locationData = [];
        this.selectedId.forEach(id => {
            this.resourceData.forEach(element => {
                if (id === element.entityId) {
                    locationData.push(element);
                }
            });
        });
        return locationData;
    }

    getViewCoordinates(item) {
        const tempCoordinates = [];
        const viewCoordinates = [];
        tempCoordinates.push(item.coordinates);
        viewCoordinates.push(tempCoordinates);
        return viewCoordinates;
    }

    viewPersonSearchComponent(address) {
        this.mapConsoleService.openRightSidePanel(PanelHeaders.powerDataSearch);
        this.personService.getPersonDetails(address);
    }

    ShowListIcons(id: string): void {
        document.getElementById(id).style.display = "block";
    }

    HideListIcons(id: string): void {
        document.getElementById(id).style.display = "none";
    }

    navigateTo(event) {
        if (event === 'CreateResourceGroup') {
            this.selectedResource = this.getResourceGroupData();
            this.displayCreateResourceGroup(this.selectedResource);
        } else if (event === 'ViewResourceGroups') {
            this.crudViewEmitter.emit('listGroup');
        }

        this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
        console.log(event);
    }
    getResourceGroupData() {
        let data;
        if (this.selectedAllResources) {
            data = this.resourceData;
        } else {
            data = this.getSelectedLocations();
        }
        return data;
    }
    displayCreateResourceGroup(selectedResource) {

        if (selectedResource.length >= 2 && this.searchResourceData === undefined) {
            this.resourceSvc.setSelectedResources(this.selectedResource);
            this.crudViewEmitter.emit('createGroup');
        } else if (this.searchResourceData !== undefined) {

            this.getSelectedResource.emit(selectedResource);
        } else {
            this.notifierService.notify('error', 'Please select atleast two resource to create a group');

            // this.resourceSvc.setfailureMessage("Please select atleast two resource to create a group");
            // this.resourceSvc.setdisplayFailure(true);
        }
    }

    onCompress() {
        this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.miniView);
        this.easleftSideBarService.changeEntitiesListTypes(PanelHeaders.entitiesMiniView);
    }
    onClose() {
        if (this.searchResourceData !== undefined) {
            this.resourceSvc.closeSearch.next();
        } else {
            this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
            this.mapConsoleService.closeSideBar();
        }
        this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
    }
    onOpenInfo(data) {
        // data.address = data.personAddress;
        this.selectedEntityId = data.entityId;
        const properties = {
            payload:{
            properties: data
        }
        }
        if (this.isSearchPage) {
            this.isMoreInfo = true;
            this.isSearchPage = false
            this.easOtherEntitiesData = {
                dataEntityId: data.entityId,
                dataModel: data.resourceObject,
                payLoad: properties
            }
        } else {
            this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.maxView);
            this.isMoreInfo = true;
            this.easOtherEntitiesData = {
                dataEntityId: data.entityId,
                dataModel: data.resourceObject,
                payLoad: properties
            }
        }
    }
    getAssignedResources() {
        this.resourceAssociateData = [];
        this.resourceNotAssociateData = [];
        this.resourceAllData.forEach(element => {
            if (element.hasOwnProperty("assignedTo")) {

                if (element.assignedTo === this.contextEventId) {
                    this.resourceAssociateData.push(element);
                }
                if (element.assignedTo !== this.contextEventId) {
                    this.resourceNotAssociateData.push(element);
                }

            }
        })
    }
    handleChange(event) {
        this.resourceData = [];
        this.displayFailureRsrc = false;
        this.getAssignedResources();
        if (event.target.id === "currentEvent") {
            this.resourceData = this.resourceAssociateData.slice();
        } else if (event.target.id === "allEvents") {
            this.resourceData = this.resourceAllData.slice();
        } else if (event.target.id === "notAssignedToEvent") {
            this.resourceData = this.resourceNotAssociateData.slice();
        }
        if (this.resourceData.length === 0) {
            this.displayFailureRsrc = true;
            this.failureMsgRsrc = this.noResourcesAvailable;
        }
    }

    onSortBy(event) {
        this.resourceSvc.sortBy = event;
    }

    onSortOrder(event) {
        this.resourceSvc.sortOrder = event;
    }
}
