import { Component, OnInit, Inject, forwardRef ,Output ,EventEmitter,Input} from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormsModule } from '@angular/forms';
import * as $ from 'jquery';
import { EasResourcesService } from '../../eas-resources.service';
import { SharedService } from '../../../../shared/shared.service';
import { AppGlobals } from '../../../../shared/app.globals';
import { ListEasResourcesComponent } from '../list-eas-resources.component';
import { EasLeftSidebarService } from '../../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import {TransactionMeasures} from '../../../../transactionMeasures';
import { PanelHeaders } from '../../../../panelHeaders';
import { stateModel } from'../../../../shared/models/states';
declare let google: any;

@Component({
  selector: 'app-search-eas-resource',
  templateUrl: './search-eas-resource.component.html',
  styleUrls: ['./search-eas-resource.component.scss']
})
export class SearchEasResourceComponent implements OnInit {
  @Output() searchDataEmitter=new EventEmitter();
  @Output() crudViewEmitter = new EventEmitter();
  @Input() fromCreate;
  resourceSearchForm = new FormGroup({
    name: new FormControl(),
    state: new FormControl(),
    county: new FormControl(),
    zip: new FormControl(),
    capKey: new FormControl(),
    capValue: new FormControl(),
    abilityKey: new FormControl(),
    abilityValue: new FormControl(),
    SEA_eventName: new FormControl(),
    SUR_eventName: new FormControl(),
    SN_eventName: new FormControl(),
    address: new FormControl(),
    distance: new FormControl(),
    disUnit: new FormControl(),
    searchradio: new FormControl()
  });
  searchResourceType1 = "searchByCriteria";
  eventData = [];
  fulladdress;
  openEventData = [];
  latitude = 0.0;
  longitude = 0.0;
  stateList = [];
  resourceNames = [];
  counties = [];
  zipCodes = [];
  capValues = [];
  abiValues = [];
  capKeys = [];
  abilityKeys = [];
  enterCapKey = false;
  enterAbilityKey = false;
  constructor(public formGroup: FormBuilder, @Inject(forwardRef(() => ListEasResourcesComponent)) public _parent: ListEasResourcesComponent,
    public resourceSvc: EasResourcesService, public sharedService: SharedService, public appGlobals: AppGlobals,
    public easLeftSidebarService: EasLeftSidebarService) {
  }

  ngOnInit() {
    this.resourceSearchForm = this.formGroup.group({
      name: [null],
      state: [''],
      county: [null],
      zip: [null],
      capKey: [''],
      capValue: [null],
      abilityKey: [''],
      abilityValue: [null],
      SEA_eventName: ['',],
      SUR_eventName: ['',],
      SN_eventName: ['',],
      address: [null],
      distance: ['5'],
      disUnit: ['miles'],
      searchradio: ['searchByCriteria']
    });
    this.formControlValueChanged();
    this.getEvents();
    this.getCapabilityKeys();
    this.getAbilityKeys();
    this.stateList = stateModel.stateList;
  }
  formControlValueChanged() {
    const searchAssignedResources = this.resourceSearchForm.get('SEA_eventName');
    const searchUnAssignedResources = this.resourceSearchForm.get('SUR_eventName');
    const resourceName = this.resourceSearchForm.get('name');
    const address = this.resourceSearchForm.get('address');
    const state = this.resourceSearchForm.get('state');
    const distance = this.resourceSearchForm.get('distance')
    this.resourceSearchForm.get('searchradio').valueChanges.subscribe(
      (mode: string) => {
        if (mode === this.appGlobals.searchAssociatedEvents) {
          resourceName.clearValidators();
          state.clearValidators();
          searchUnAssignedResources.clearValidators();
          address.clearValidators();
          distance.clearValidators();
          searchAssignedResources.setValidators([Validators.required]);
        } else if (mode === this.appGlobals.searchUnassignedResources) {
          resourceName.clearValidators();
          state.clearValidators();
          searchAssignedResources.clearValidators();
          address.clearValidators();
          distance.clearValidators();
          searchUnAssignedResources.setValidators([Validators.required]);
        } else if (mode === this.appGlobals.searchNearby) {
          resourceName.clearValidators();
          state.clearValidators();
          searchUnAssignedResources.clearValidators();
          searchAssignedResources.clearValidators();
          address.setValidators([Validators.required]);
          distance.setValidators([Validators.required]);
        } else if (mode = this.appGlobals.searchByCriteria) {
          searchUnAssignedResources.clearValidators();
          searchAssignedResources.clearValidators();
          address.clearValidators();
          distance.clearValidators();
        }
      });
  }
  setSearchForm() {
    this.resourceSearchForm = this.formGroup.group({
      'name': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'state': [],
      'county': [''],
      'zip': ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(6)])],
      'capKey': [],
      'capValue': [],
      'abilityKey': [],
      'abilityValue': [],
      'SEA_eventName': [],
      'SUR_eventName': [],
      'SN_eventName': [],
      'address': [''],
      'distance': ['', '5'],
      'disUnit': ['', 'kilometers'],
    });
    // this._parent.displayFailure = false;
    // this._parent.displaySuccess = false;

  }
  getEvents() {
    this.resourceSvc.getAllEvents().subscribe(
      data => {
        data.forEach(element => {
          if (element.status === 'STARTED' && element.deleted === false) {
            this.openEventData.push(element);
          }
        });
        this.eventData = this.openEventData;
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.displayFailurePage(this.appGlobals.generalErrorOccured);
        }
      }
    );
  }
  addressAutoComplete() {
    const autocomplete = new google.maps.places.Autocomplete(<HTMLInputElement>document.getElementById('searchResourceAddress'));
    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();
      const loc = [];
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ 'address': (<HTMLInputElement>document.getElementById('searchResourceAddress')).value }, (results, status) => {
        if (status === google.maps.GeocoderStatus.OK) {
          loc[0] = results[0].geometry.location.lat();
          loc[1] = results[0].geometry.location.lng();
          if (undefined != loc[0] && undefined != loc[1]) {
            this.latitude = loc[0];
            this.longitude = loc[1];
          }
          //console.log(this.fulladdress)
          this.resourceSearchForm.controls['address'].setValue(place.formatted_address);
        } else {
          console.log('Geocoder failed due to: ' + status);
        }
      });
    });
  }
  onItemSelect(item: any) {
    console.log(item);
  }
  onSelectAll(items: any) {
    console.log(items);
  }

  searchResource(event, formData) {
    // this._parent.displayResourceResults = false;
    event.preventDefault();
    for (const c in this.resourceSearchForm.controls) {
      if (this.resourceSearchForm.controls.hasOwnProperty(c)) {
        this.resourceSearchForm.controls[c].markAsTouched();
      }
    }
    if (this.resourceSearchForm.valid) {
      console.log(formData);
      formData.latitude = this.latitude;
      formData.longitude = this.longitude;
      console.log(this.resourceSearchForm.controls['state'].value);
      //alert(this.searchResourceType1)
      if (this.appGlobals.searchNearby === this.searchResourceType1) {
        formData.distance = ('miles' === formData.disUnit) ? this.convertMilesToKm(formData.distance) : formData.distance;
        this.resourceSvc.searchNearBy(formData).subscribe(
          data => {
            let filteredData = this.filterAnnotationFromResourceData(data);
            if (filteredData.length > 0) {
              this.displaySuccessPage();
            } else {
              this.displayFailurePage(this.appGlobals.nrfMsg);
            }
          },
          error => {
            if (error.status === 401) {
              this.sharedService.routeToLoginError(error.status);
            } else {
              this.displayFailurePage(this.appGlobals.generalErrorOccured);
            }
          }
        );
      } else if (this.appGlobals.searchAssociatedEvents === this.searchResourceType1 || this.appGlobals.searchUnassignedResources === this.searchResourceType1) {
        if (this.appGlobals.searchAssociatedEvents === this.searchResourceType1) {
          formData.assigned = true;
          formData.eventName = formData.SEA_eventName;
        } else if (this.appGlobals.searchUnassignedResources === this.searchResourceType1) {
          formData.assigned = false;
          formData.eventName = formData.SUR_eventName;
        }
        this.resourceSvc.searchAssociatedResources(formData).subscribe(
          data => {
            let filteredData = this.filterAnnotationFromResourceData(data);
            if (filteredData.length > 0) {
              this.displaySuccessPage();
            } else {
              this.displayFailurePage(this.appGlobals.nrfMsg);
            }
          },
          error => {
            if (error.status === 401) {
              this.sharedService.routeToLoginError(error.status);
            } else {
              this.displayFailurePage(this.appGlobals.generalErrorOccured);
            }
          }
        );
      }
      else if (this.appGlobals.searchByCriteria === this.searchResourceType1) {
        this.resourceSvc.searchByCriteria(formData).subscribe(
          data => {
            let filteredData = this.filterAnnotationFromResourceData(data);
            if (filteredData.length > 0) {
              this.displaySuccessPage();
            } else {
              this.displayFailurePage(this.appGlobals.nrfMsg);
            }
          },
          error => {
            if (error.status === 401) {
              this.sharedService.routeToLoginError(error.status);
            } else {
              this.displayFailurePage(this.appGlobals.generalErrorOccured);
            }
          }
        );
      }
    }
  }
  filterAnnotationFromResourceData(data) {
    let filteredData;
    // if(data.length>0){
    filteredData = data.filter(function (element) {
      return element.resourceObject !== 'ANNOTATION';
    });
    // }
    if(this.fromCreate!==undefined){
    this.searchDataEmitter.emit(filteredData);
    }else{
    this._parent.setResourceData(filteredData, true);

    }
    return filteredData;
  }
  displayFailurePage(failureMessage) {
    // this._parent.displayFailure = true;
    this._parent.failureMessage = failureMessage;
    this._parent.setResourceData([], false);
    // this._parent.displayResourceResults = false;
  }
  displaySuccessPage() {
    // this._parent.displayFailure = false;
    // this._parent.displayResourceResults = true;
  }
  convertMilesToKm(miles) {
    let km: number = miles * 1.60934;
    return km;
  }
  getResourceNameOnTypeAhead(input) {
    console.log(input.target.value);
    this.callTypeAheadService('resourceName', input.target.value, null)
  }
  getCapabilityValuesOnTypeAhead(input) {
    const key = this.resourceSearchForm.get('capKey').value;
    if ('' === key) {
      this.enterCapKey = true;
    } else {
      this.enterCapKey = false;
      this.callTypeAheadService('capabilities.' + key, input.target.value, 'capability');
    }
  }
  getAbilityValuesOnTypeAhead(input) {
    const key = this.resourceSearchForm.get('abilityKey').value;
    if ('' === key) {
      this.enterAbilityKey = true;
    } else {
      this.enterAbilityKey = false;
      this.callTypeAheadService('abilities.' + key, input.target.value, 'ability');
    }

  }
  getCountyValuesOnTypeAhead(input) {
    const county = 'address.county';
    console.log(input.target.value);
    this.callTypeAheadService(county, input.target.value, null)
  }
  getZipCodeValuesOnTypeAhead(input) {
    const zip = 'address.zip';
    console.log(input.target.value);
    this.callTypeAheadService(zip, input.target.value, null)
  }
  callTypeAheadService(field, startsWith, from) {
    this.resourceSvc.getResourceNameOnTypeAheadSvc(field, startsWith, from).subscribe(
      data => {
        console.log(data);
        if ('resourceName' === field) {
          this.resourceNames = data;
          console.log(this.resourceNames)
        } else if ('address.county' === field) {
          this.counties = data;
        } else if ('address.zip' === field) {
          this.zipCodes = data;
        } else if ('capability' === from) {
          if (data && data[0]) {
            this.capValues=[];
            let key = Object.keys(data[0].capabilities);
            this.capValues.push(data[0].capabilities[key[0]]);
          }
        } else if ('ability' === from) {
          if (data && data[0]) {
            this.abiValues=[];
            let key = Object.keys(data[0].abilities);
            this.abiValues.push(data[0].abilities[key[0]]);
          }
          //this.abiValues=data;
        }
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.displayFailurePage(this.appGlobals.generalErrorOccured);
        }
      }
    );
  }
  getCapabilityKeys() {

    this.resourceSvc.getCapabilityKeysSvc().subscribe(
      data => {
        console.log(data);
        this.capKeys = data;
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.displayFailurePage(this.appGlobals.generalErrorOccured);
        }
      }
    );
  }
  getAbilityKeys() {

    this.resourceSvc.getAbilityKeysSvc().subscribe(
      data => {
        console.log(data);
        this.abilityKeys = data;
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.displayFailurePage(this.appGlobals.generalErrorOccured);
        }
      }
    );
  }
  hideResults() {
    // this._parent.displayResourceResults = false;
  }
  onClose() {
    console.log(this.fromCreate)
    if( this.fromCreate === true){
    // this.easLeftSidebarService.toggleSidebarToggle(TransactionMeasures.fullView);
    // this.easLeftSidebarService.changeEntitiesListTypes(PanelHeaders.resources);
    this.resourceSvc.closeSearch.next();
    } else {
    this.easLeftSidebarService.cLoseMoreInfo();
    }
  }
}
