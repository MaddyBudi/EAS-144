// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { SearchEasResourceComponent } from './search-eas-resource.component';

// describe('SearchEasResourceComponent', () => {
//   let component: SearchEasResourceComponent;
//   let fixture: ComponentFixture<SearchEasResourceComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ SearchEasResourceComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SearchEasResourceComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
