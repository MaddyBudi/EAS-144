import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ListEasResourcesComponent } from './list-eas-resources.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { SharedPipe } from '../../../home/shared.pipe';
import { DataTableModule } from 'angular-6-datatable';
import { SearchEasResourceComponent } from './search-eas-resource/search-eas-resource.component';
import { EasEventMoreInformationComponent } from '../../eas-event-more-information/eas-event-more-information.component';
import {ResourceMockService } from '../eas-mock-resources.service';
import { EasResourcesService} from '../eas-resources.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ListEasResourcesComponent', () => {
  let component: ListEasResourcesComponent;
  let fixture: ComponentFixture<ListEasResourcesComponent>;
  // let eventMoreInfoComponent: EasEventMoreInformationComponent;
  // let eventMoreInfoCFixture: ComponentFixture<EasEventMoreInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
        ListEasResourcesComponent,
        SearchEasResourceComponent,
        SharedPipe,
        EasEventMoreInformationComponent
        ],
    imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule,
        OwlDateTimeModule,
        OwlNativeDateTimeModule,
        TabsModule.forRoot(),
        DataTableModule
      ],
      providers: [{ provide: EasResourcesService, useClass: ResourceMockService }],
       schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListEasResourcesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
 
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

    it('should get all resources and count should not be zero', (done) => {
    component.getResources();
     setTimeout(function () {
      expect(component.resourceData.length).not.toBe(0);
      done();
    }, 1000);
  });

  it('True if the createResource() method is called and perform its action', (done) => {

    component.crudViewEmitter.subscribe(g => {
      expect(g).toEqual('create'); 
      done();
    })
    component.createResource(null);

  });

  it('True if the editResource() method is called and perform its action', (done) => {

   
    component.crudViewEmitter.subscribe(g => {
      expect(g).toEqual('update'); 
      done();
    })
    component.editResource(null);

  });

});
