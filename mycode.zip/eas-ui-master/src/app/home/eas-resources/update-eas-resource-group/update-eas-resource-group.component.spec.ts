// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { UpdateEasResourceGroupComponent } from './update-eas-resource-group.component';

// describe('UpdateEasResourceGroupComponent', () => {
//   let component: UpdateEasResourceGroupComponent;
//   let fixture: ComponentFixture<UpdateEasResourceGroupComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ UpdateEasResourceGroupComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(UpdateEasResourceGroupComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
