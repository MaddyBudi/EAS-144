import { Component, OnInit, SimpleChange, OnChanges, Input, Inject, forwardRef, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { EasResourceGroupService } from '../eas-resource-group.service';
import { EasResourcesService } from '../eas-resources.service';
import * as $ from 'jquery';
import { SharedService } from '../../../shared/shared.service';
import {AppGlobals} from '../../../shared/app.globals';
import * as moment from 'moment';
import { TransactionMeasures } from '../../../transactionMeasures';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { NotifierService } from 'angular-notifier';
import { ResourceGroupTo } from '../../../shared/models/resourceGroupTo';

@Component({
  selector: 'app-update-eas-resource-group',
  templateUrl: './update-eas-resource-group.component.html',
  styleUrls: ['./update-eas-resource-group.component.scss']
})
export class UpdateEasResourceGroupComponent implements OnInit, OnChanges {
  @Input() selectedResource: string;
  @Output() crudViewEmitter = new EventEmitter();
  updateResourceForm = new FormGroup({
    groupName: new FormControl(),
    resourceGroupDesc: new FormControl(),

  });
  primaryCategoryList: any;
  displayUpdateContent = true;
  isFormModified = false;
  public resourceDetails;
  filterQuery: '';
  allResourceNames = [];
  tabEnabled = true;
  resetFlag = false;
  deletedResources = [];
  removedResources = [];
  displaySuccessMsg = false;
  displayFailureMsg = false;
  successMessage;
  failureMessage;
  resourceData = [];
  actionHeader;
  selectedResources;
  showUpdatePage = false;
  isSearchPage = false;
  searchResourceData;
  showResourceList = false;
  groupResourceDetail;
  groupmembers = [];
  resourceId = [];
  rowsPerPageList: Number[] = this.appGlobals.RowsPerPageList;
  defaultRowsPerPage: Number = this.appGlobals.DefaultRowsPerPage;
  resourceGroupDetails: ResourceGroupTo;
  constructor(public formGroup: FormBuilder, private resourceGroupSvc: EasResourceGroupService,
    public sharedService: SharedService, public appGlobals: AppGlobals, private fb: FormBuilder,
    private resourceSvc: EasResourcesService, private easleftSideBarService: EasLeftSidebarService,
    private notifierService: NotifierService) {
    this.resourceSvc.closeSearch$.subscribe(
      data => {
        this.isSearchPage = false;
        this.showUpdatePage = true;
        this.showResourceList = false;
      }
    );
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {

  }
  // sets initial update form
  ngOnInit() {
    this.resetFlag = false;
    if (this.resourceGroupSvc.getupdateResourceGroupdata() !== undefined) {
      this.resourceGroupSvc.getResourceDetails(this.resourceGroupSvc.getupdateResourceGroupdata()).subscribe(
        data => {
          console.log(data);
          this.resourceGroupDetails = data;
          this.setupdateResourceForm();
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.notifierService.notify('error', this.appGlobals.generalErrorOccured);
          }
        }
      );
    }


    this.updateResourceForm = this.formGroup.group({
      'groupName': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'resourceGroupDesc': ['', Validators.compose([Validators.minLength(1), Validators.maxLength(250)])],

    });

  }
  // binds value from resourceDetails to UI fields on update page
  setupdateResourceForm() {
    this.updateResourceForm.controls['groupName'].setValue(this.resourceGroupDetails.name);
    this.updateResourceForm.controls['resourceGroupDesc'].setValue(this.resourceGroupDetails.description);
    if (this.resetFlag === false) {
      const data = this.setResources(this.resourceGroupDetails.resources);
    }

    this.updateResourceForm.valueChanges.subscribe(data => {
      this.isFormModified = true;
    });

  }
  setResources(resources) {

    resources.forEach(element => {
      this.resourceSvc.getAllResourceData().forEach(resource => {
        if (resource.entityId === element) {
          this.resourceData.push(resource);
          this.resourceId.push(resource.entityId);
        }
      });

    });
    console.log(this.resourceData)
    // this.groupmembers=this.resourceData;
    this.showUpdatePage = true;
    return this.resourceData;
  }
  setResourceDetails(resourceDetail) {
    let resourceData;
    if (resourceDetail.entityId !== null) {

      resourceData = {
        'resourceName': resourceDetail.resourceName,
        'entityId': resourceDetail.entityId,
        'status': resourceDetail.status,
        'resourceObject': resourceDetail.resourceObject,
        "createdDate": this.getLocalDate(resourceDetail.createdDate),
        'updatedOn': this.getLocalDate(resourceDetail.lastModifiedDate)
      };

      console.log("setResourceDetails");
      console.log(resourceData)
    }
    return resourceData;
  }
  getLocalDate(date) {
    if (date !== null && date !== undefined) {
      console.log(date);
      const dateArr = date.split("T");
      console.log(dateArr);
      const newDate = moment(dateArr[0], "DD-MM-YYYY").format('YYYY-MM-DD');
      const newDate1 = dateArr[0] + ' ' + dateArr[1];
      const stillUtc = moment.utc(newDate1);
      const local = moment(newDate1).local().format('YYYY-MM-DD HH:mm:ss');
      return local;
    } else {
      return null;
    }
  }
  addToGroup() {
    this.isSearchPage = true;
    this.showUpdatePage = false;
    this.actionHeader = "Search Resource";
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
  }
  closeComponent() {
    this.isSearchPage = false;
    this.showResourceList = false;
    this.showUpdatePage = true;
  }
  searchDataEmitter(event) {
    this.searchResourceData = event;
    this.showResourceList = true;
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.maxView);
  }
  getSelectedResource(event) {
    event.forEach(element => {
      if (!this.resourceId.includes(element.entityId)) {
        this.resourceData.push(element);
        this.resourceId.push(element.entityId)
      }
    });
    this.isSearchPage = false;
    this.showResourceList = false;
    this.isFormModified = true;
    this.showUpdatePage = true;
  }
  deleteFromGroup(resource) {

    this.isFormModified = true;
    this.resourceData = this.resourceData.filter(function (element) {
      return element.entityId !== resource.entityId;
    });
  }


  formatResourceData(resources) {
    const entityIdArray = [];
    resources.forEach(element => {
      entityIdArray.push(element.entityId);
    });
    return entityIdArray;
  }

  updateResource(event, formData) {
    event.preventDefault();
    for (const c in this.updateResourceForm.controls) {
      if ((this.updateResourceForm.controls).hasOwnProperty(c)) {
        this.updateResourceForm.controls[c].markAsTouched();
      }
    }
    console.log(this.updateResourceForm.controls)
    this.resourceGroupDetails.resources = this.formatResourceData(this.resourceData);
    if (this.updateResourceForm.controls.groupName.valid && this.isFormModified && this.resourceGroupDetails.resources.length >= 2) {

      this.resourceGroupSvc.updateResourceGroup(this.resourceGroupDetails).subscribe(
        data => {
          if (data.entityId != null) {
            this.notifierService.notify("success", 'Resource Group "' + this.resourceGroupDetails.name + '" updated successfully.');
            this.crudViewEmitter.emit("listGroup");
          } else {
            this.notifierService.notify("error", this.appGlobals.updateRscFailureMsg);
          }
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.notifierService.notify("error", this.appGlobals.generalErrorOccured);
          }
        }
      );
    } else if (this.resourceGroupDetails.resources.length < 2) {
      this.notifierService.notify('error', 'Please add atleast two resources to update a group')
    }

  }

  resetUpdatePage(event) {
    this.isFormModified = false;
    this.resetFlag = true;
    this.resourceData = [];
    this.setupdateResourceForm();
    this.resourceData = this.setResources(this.resourceGroupDetails.resources);
   
  }

  displaySuccessPage(successMesssage) {
    this.resourceGroupSvc.setdisplaySuccess(true);
    this.resourceGroupSvc.setSuccessMessage(successMesssage);

  }

  displayFailurePage(failureMessage) {
    this.resourceGroupSvc.setdisplayFailure(true);
    this.resourceGroupSvc.setfailureMessage(failureMessage);
  }

  displayUpdatePage() {
    this.displayUpdateContent = true;

    this.isFormModified = false;
  }
  closeAction() {
    this.crudViewEmitter.emit("listGroup");
  }
}
