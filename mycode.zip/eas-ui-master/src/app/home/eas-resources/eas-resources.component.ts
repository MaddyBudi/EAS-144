import { Component, OnInit, Input } from '@angular/core';
import { CrudView } from './crudview'
import { EasResourcesService } from './eas-resources.service';
@Component({
  selector: 'app-eas-resources',
  templateUrl: './eas-resources.component.html',
  styleUrls: ['./eas-resources.component.scss']
})
export class EasResourcesComponent implements OnInit {
  @Input() contextEventId;
  @Input() contextEventName;

  crudView: CrudView = new CrudView();
  constructor(private easResourcesService: EasResourcesService) { }

  ngOnInit() {
    this.crudView.viewType = "list";
    this.easResourcesService.sortBy = null;
    this.easResourcesService.sortOrder = null;
  }

  crudViewEmitter(event: String) {
    this.crudView.viewType = event;
  }

}
