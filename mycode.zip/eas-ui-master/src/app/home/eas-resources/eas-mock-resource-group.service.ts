import { Observable, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { UnitTestConstants } from '../../common/enums/unit-test-constants-enum';
@Injectable()
export class MockEasResourceGroupService{
  displaySuccess = false;
  successMessage: String;
  displayFailure = false;
  failureMessage: String;
  updateResourcedata;
    constructor(private http: HttpClient) { }

    public getAllResources() {
        return this.http.get(UnitTestConstants.resourcegroupPayloadUrl).pipe(map((res: any) => res));
      }
      public setSuccessMessage(successMessage) {
        this.successMessage = successMessage;
      }
      public setdisplaySuccess(displaySuccess) {
        this.displaySuccess = displaySuccess;
      }
      
  public setdisplayFailure(displayFailure) {
    this.displayFailure = displayFailure;
  }
  public setfailureMessage(failureMessage) {
    this.failureMessage = failureMessage;
  }

  public setupdateResourceGroupdata(data) {
    this.updateResourcedata=data;

  }
}
