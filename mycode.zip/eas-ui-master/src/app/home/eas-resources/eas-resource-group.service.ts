import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { AppGlobals } from '../../shared/app.globals';
import { ConfigService } from "../../core/config/config-svc.service";
import { Observable } from 'rxjs';
import { Subject } from 'rxjs';
import { ResourceGroupTo } from '../../shared/models/resourceGroupTo';


@Injectable({
  providedIn: 'root'
})
export class EasResourceGroupService {
  displaySuccess = false;
  displayFailure = false;
  successMessage: String;
  failureMessage: String;
  updateResourcedata;
  constructor(private http: HttpClient, private appglobals: AppGlobals) { }

   getHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All'
      }),
      withCredentials: true
    };
    return httpOptions;
  }
  public setdisplaySuccess(displaySuccess) {
    this.displaySuccess = displaySuccess;
  }

  public getdisplaySuccess() {
    return this.displaySuccess;
  }

  public setdisplayFailure(displayFailure) {
    this.displayFailure = displayFailure;
  }

  public getdisplayFailure() {
    return this.displayFailure;
  }


  public setSuccessMessage(successMessage) {
    this.successMessage = successMessage;
  }

  public getSuccessMessage() {
    return this.successMessage;
  }
  public getfailureMessage() {
    return this.failureMessage;
  }

  public setfailureMessage(failureMessage) {
    this.failureMessage = failureMessage;
  }

  public setupdateResourceGroupdata(data) {
    this.updateResourcedata=data;

  }
   public getupdateResourceGroupdata() {
    return this.updateResourcedata;

  }
    public createResourceGroup(resourceGroupDetails){
      let payload;
    payload = {

      "name": resourceGroupDetails.name,
      "description":resourceGroupDetails.description,
      "resources":resourceGroupDetails.resources

    };
    console.log(payload);
    return this.http.post(ConfigService.config.resourceServiceUrl + '/createResourceGroup',
             payload, this.getHeaders()).pipe(map((res: any) => res));
  }
    public getAllResources() {

    return this.http.get(ConfigService.config.resourceServiceUrl + '/getAllResourceGroups',
    this.getHeaders()).pipe(map((res: any) => res));
  }
  public getResourceDetails(entityId) {

    return this.http.get(ConfigService.config.resourceServiceUrl + '/getResourceGroup?ENTITY_ID=' + entityId,
                         this.getHeaders()).pipe(map((res: any) => res));
  }
  public updateResourceGroup(resourceGroupDetails: ResourceGroupTo){
     return this.http.put(ConfigService.config.resourceServiceUrl + '/updateResourceGroup',
     resourceGroupDetails, this.getHeaders()).pipe(map((res: any) => res));
  }
  public deleteResourceGroup(entityID) {
     return this.http.delete(ConfigService.config.resourceServiceUrl + '/deleteResourceGroup?ENTITY_ID=' + entityID,
                            this.getHeaders()).pipe(map((res: any) => res));

  }

  public assignResGroupToEvent(eventId, groupId, address) {
    return this.http.put(ConfigService.config.eventServiceUrl + '/assignResourceGroupsToEvent?ENTITY_ID='+ eventId + '&GROUP_ID=' + groupId,address,
    this.getHeaders()).pipe(map((res: any) => res));
  }
}
