// import { TestBed } from '@angular/core/testing';

// import { EasResourcesService } from './eas-resources.service';

// describe('EasResourcesService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: EasResourcesService = TestBed.get(EasResourcesService);
//     expect(service).toBeTruthy();
//   });
// });
