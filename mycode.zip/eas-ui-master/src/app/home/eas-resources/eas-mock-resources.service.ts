import { PersonResourceTo } from '../../shared/models/personResourceTo';
import { Observable, Subject} from 'rxjs';
import { ConfigService } from '../../core/config/config-svc.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { AnnotationTo } from '../../shared/models/annotationTo';
import { UnitTestConstants } from '../../common/enums/unit-test-constants-enum';
import { ResourceTypeTo } from '../../shared/models/resourceTypeTo';


declare let google: any;

@Injectable()
export class ResourceMockService {
  ResourcetypeEntityId='testResourceType1'
  updateResourceEntityId = '3a96b235-5375-4503-a975-6e60908c153c';
  closeSearchResourceSubject = new Subject<string>();
  closeSearchResource$ = this.closeSearchResourceSubject.asObservable();
  closeSearch = new Subject<string>();
  closeSearch$ = this.closeSearch.asObservable();
  closeMoreInformation = new Subject<string>();
  closeMoreInformation$ = this.closeMoreInformation.asObservable();
  allResourceData;
  updateResourceTypeEntityId;
  updateResourcedata;
   availabilityStatus={
    '1':'Offline',
    '2':'Available',
    '3':'DND'
  };
  selectedResource : any[]=
  [{"type":"personResource",
  "createdBy":"blitoff",
  "createdDate":"2019-03-15T07:32:05.163+0000",
  "lastModifiedBy":"blitoff",
  "lastModifiedDate":"2019-03-18T17:17:39.815+0000",
  "entityId":"3a96b235-5375-4503-a975-6e60908c153c",
  "dataModel":"RESOURCE",
  "organizationName":"test-org1",
  "resourceName":"Kings County resource",
  "resourceObject":"Person",
  "resourceType":"eas-users",
  "assigned":true,
  "status":"NotAvailable",
  "assignedTo":"0138fabe-fbaa-453b-ad39-6b77105bd0fc",
  "geometry":"{\"type\":\"Point\",\"coordinates\":[-73.987103,40.688001]}",
  "properties":{
  },
  "address":{
  "dateFirstReported":null,
  "dateLastReported":null,
  "streetAddress1":"345, Atlantic Ave",
  "streetAddress2":"",
  "city":"",
  "zip":"11201-5829",
  "state":"NY",
  "county":"Kings County",
  "geocodedAddress":null,
  "locationId":null,
  "poBox":false,
  "searchAddress":false,
  "sourceType":"UNKNOWN"
  },
  "dispatchAddress":{
  "dateFirstReported":null,
  "dateLastReported":null,
  "streetAddress1":"",
  "streetAddress2":"",
  "city":"Boulder",
  "zip":"",
  "state":"CO",
  "county":"Boulder County",
  "geocodedAddress":null,
  "locationId":null,
  "poBox":false,
  "searchAddress":false,
  "sourceType":"UNKNOWN"
  },
  "capabilities":{
  "":""
  },
  "abilities":{
  "":""
  },
  "name":{
  "namePrefix":"",
  "nameSuffix":"",
  "firstName":"",
  "middleName":"",
  "lastName":"",
  "sourceType":"UNKNOWN"
  },
  "gender":"MALE",
  "dob":null,
  "email":null,
  "phone":{
  "number":null,
  "phoneType":"BUSINESS",
  "carrier":null,
  "sourceType":"UNKNOWN"
  },
  "intrepidCallSign":"",
  "kodiakMdn":null,
  "lastKodiakUpdateDate":null
  },
  {
  "type":"personResource",
  "createdBy":"blitoff",
  "createdDate":"2019-03-15T09:34:00.063+0000",
  "lastModifiedBy":"blitoff",
  "lastModifiedDate":"2019-03-19T09:01:19.267+0000",
  "entityId":"2c0e7329-f04a-4cc1-a333-e7a3235f010b",
  "dataModel":"RESOURCE",
  "organizationName":"test-org1",
  "resourceName":"Washington Resource",
  "resourceObject":"Person",
  "resourceType":"eas-users",
  "assigned":true,
  "status":"NotAvailable",
  "assignedTo":"8355eaa8-7068-4a75-99e3-e84aa41f9dd7",
  "geometry":"{\"type\":\"Point\",\"coordinates\":[-120.740139,47.751074]}",
  "properties":{
  },
  "address":{
  "dateFirstReported":null,
  "dateLastReported":null,
  "streetAddress1":"",
  "streetAddress2":"",
  "city":"",
  "zip":"",
  "state":"WA",
  "county":"",
  "geocodedAddress":null,
  "locationId":null,
  "poBox":false,
  "searchAddress":false,
  "sourceType":"UNKNOWN"
  },
  "dispatchAddress":{
  "dateFirstReported":null,
  "dateLastReported":null,
  "streetAddress1":"310, McMillan Dr NW",
  "streetAddress2":"",
  "city":"Washington",
  "zip":"20001-1032",
  "state":"DC",
  "county":"",
  "geocodedAddress":null,
  "locationId":null,
  "poBox":false,
  "searchAddress":false,
  "sourceType":"UNKNOWN"
  },
  "capabilities":{
  "":""
  },
  "abilities":{
  "":""
  },
  "name":{
  "namePrefix":"",
  "nameSuffix":"",
  "firstName":"",
  "middleName":"",
  "lastName":"",
  "sourceType":"UNKNOWN"
  },
  "gender":"MALE",
  "dob":null,
  "email":null,
  "phone":{
  "number":null,
  "phoneType":"BUSINESS",
  "carrier":null,
  "sourceType":"UNKNOWN"
  },
  "intrepidCallSign":"",
  "kodiakMdn":null,
  "lastKodiakUpdateDate":null
  }]

  constructor(private http: HttpClient) { }

  public getResourceDetails(updateResourceEntityId): Observable<PersonResourceTo> {
    return this.http.get<PersonResourceTo>(UnitTestConstants.resourcePayloadUrl).pipe(map((res => this.convertResponseToObject(res[0]))));
  }
  public getupdateResourcedata() {
    return this.updateResourceEntityId;
  }
  
  public createResourceType(payload:ResourceTypeTo): Observable<any> {
    return this.getResourceTypeByEntityId(this.ResourcetypeEntityId); 
    }
  public getSelectedResources() {

    return this.selectedResource;
  }
  

  public getAllResources() {

    return this.http.get(UnitTestConstants.resourcePayloadUrl).pipe(map((res) => this.convertListToListObject(res)));

  }

  public getResourceTypeByEntityId(entityId:string) {

    return this.http.get(UnitTestConstants.resourceTypeSinglePayloadUrl).pipe(map((event => this.convertResponseToObjectResourceTypeTo(event))));
  }
  public setAllResourceData(data) {
    this.allResourceData = data;
  }

  public setupdateResourcedata(data) {
    this.updateResourcedata = data;
  }
  public updateEpttUserLocation(userDetails) {
    // if (userDetails !== null && userDetails !== undefined) {
    //   const kodiakContacts = [];
    //   const geocoder = new google.maps.Geocoder();
    //   userDetails.forEach(element => {
    //     let payload;
    //     payload = {
    //       'dataModel': 'RESOURCE',
    //       'resourceObject': 'Person',
    //       'resourceType': 'field-personnel',
    //       'geometry': JSON.stringify({
    //         'type': 'Point',
    //         'coordinates': [element.lng, element.lat]
    //       }),
    //       'kodiakMdn': element.mdn,
    //       'status': this.availabilityStatus[element.availabilityStatus],
    //       'lastKodiakUpdateDate': new Date().toISOString(),
    //       'type': 'personResource'
    //     };

    //     kodiakContacts.push(payload);
    //   });
    //   if (kodiakContacts !== null) {
    //     return this.http.post(UnitTestConstants.resourcePayloadUrl, kodiakContacts).pipe(map((res: any) => res));
    //   }
    // }
  }

  public getAllResourceTypes() {
    return this.http.get(UnitTestConstants.resourceTypePayloadUrl).pipe(map((event => this.convertResponseToobjectResourceType(event)))); 
  }
  convertResponseToObject(object: any) {
    if (object.resourceObject === 'Person') {
      const personResourceTo = new PersonResourceTo(object);
      console.log(personResourceTo);
      return personResourceTo;
    }
  }
  convertListToListObject(object: any) {
    let resourceTO = [];
    object.forEach(element => {
      if (element.resourceObject === 'Person') {
        const personResourceTo = new PersonResourceTo(element);
        resourceTO.push(personResourceTo);
      }
    });

    return resourceTO;
  }
  convertResponseToobjectResourceType(object: any) {
    let resourceTypesTo = [];
    object.forEach((element: any) => {
      const resourceTypeTo = new ResourceTypeTo(element);
      resourceTypesTo.push(resourceTypeTo);
    });
  
    return resourceTypesTo;
  }
  
  convertResponseToObjectResourceTypeTo(object:any) {
  
       const resourceTypeTo = new ResourceTypeTo(object);
       return resourceTypeTo;
  
  }
}
