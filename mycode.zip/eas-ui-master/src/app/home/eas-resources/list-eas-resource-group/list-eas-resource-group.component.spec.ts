import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ListEasResourceGroupComponent } from './list-eas-resource-group.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { DataTableModule } from 'angular-6-datatable';
import {MockEasResourceGroupService } from '../eas-mock-resource-group.service';
import { EasResourceGroupService} from '../eas-resource-group.service';
import { SharedPipe } from '../../shared.pipe';
import { MapsAPILoader } from '@agm/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('ListEasResourceGroupComponent', () => {
  let component: ListEasResourceGroupComponent;
  let fixture: ComponentFixture<ListEasResourceGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListEasResourceGroupComponent, SharedPipe], 
      imports : [
        FormsModule,
        BrowserAnimationsModule,
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule,
        DataTableModule
      ],
      providers: [{ provide: MapsAPILoader },{ provide: EasResourceGroupService, useClass: MockEasResourceGroupService }],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListEasResourceGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get all Resource Group and count should not be zero', (done) => {
    component.getAllResourceData()
     setTimeout(function () {
      expect(component.resourceData.length).not.toBe(0);  
      done();
    }, 1000);
  });

  it('True if the editResource() method is called and perform its action', (done) => {
    component.crudViewEmitter.emit('updateGroup');
      component.crudViewEmitter.subscribe(data => {
        expect(data).toEqual('updateGroup'); 
      })
      component.getAllResourceData
      setTimeout(() => {
       component.editResource(component.resourceData[0]);
      done();
  }, 1000);
  });
  
  it('True if the getResourceList() method is called and perform its action', () => {
    component.crudViewEmitter.emit('list');
    component.crudViewEmitter.subscribe(data => {
      expect(data).toEqual('list');  
    })
    component.getResourceList()

  });


});
