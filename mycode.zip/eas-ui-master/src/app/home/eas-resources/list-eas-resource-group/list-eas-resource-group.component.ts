import { Component, OnInit ,Output,EventEmitter} from '@angular/core';
import { EasResourceGroupService } from '../eas-resource-group.service';
import {AppGlobals} from '../../../shared/app.globals';
import {SharedService} from '../../../shared/shared.service';
import { AssignEasResourcesService } from '../assign-eas-resources/assign-eas-resources.service';
import * as moment from 'moment';
import { NotifierService } from 'angular-notifier';
import { ResourceGroupTo } from '../../../shared/models/resourceGroupTo';
const swal = require('sweetalert');



@Component({
  selector: 'app-list-eas-resource-group',
  templateUrl: './list-eas-resource-group.component.html',
  styleUrls: ['./list-eas-resource-group.component.scss']
})
export class ListEasResourceGroupComponent implements OnInit {

resourceData;
displaySuccess;
displayFailure;
successMessage;
failureMessage;
sortOrder = "desc";
sortBy = "createdDate";
@Output() crudViewEmitter = new EventEmitter();
rowsPerPageList: Number[] = this.appglobals.RowsPerPageList;
defaultRowsPerPage: Number = this.appglobals.DefaultRowsPerPage;
  constructor(private easResourceGroupService:EasResourceGroupService, private appglobals: AppGlobals,
              private sharedService:SharedService,private assignRsrcService:AssignEasResourcesService,
              private notifierService:NotifierService) { }

  ngOnInit() {
this.getAllResourceData();
 
  }
    getAllResourceData(){
this.easResourceGroupService.getAllResources().subscribe(
            data => {
            //   this.setResourceData(data);
              this.resourceData = data;
              this.displayFailure = false;
            },
            error => {
                if (error.status === 401) {
                    this.sharedService.routeToLoginError(error.status);
                } else {
                  this.notifierService.notify('error' ,"Unable to get resources. Please try again later.");
                }
            }
        );  
    }
// setResourceData(data){
//    const tempResourceArray = [];
//         this.resourceData = [];
//         data.forEach(element => {
//             if (element.entityId !== null) {
              
//                 const resourceData = {
//                     'resourceName': element.name,
//                     'entityId': element.entityId,

//                     "createdDate": this.getLocalDate(element.createdDate),
//                     'lastModifiedDate': this.getLocalDate(element.lastModifiedDate)

                   
//                 };
               
//                 tempResourceArray.push(resourceData);
//             }
//         });
    
//             this.resourceData = tempResourceArray;
        
// }
        private resetMessageBlock() {
        this.easResourceGroupService.setSuccessMessage("");
        this.easResourceGroupService.setdisplaySuccess(false);
        this.easResourceGroupService.setfailureMessage("");
        this.easResourceGroupService.setdisplayFailure(false);
        
    }
    //   getLocalDate(date) {
    //     if (date !== null && date !== undefined) {
    //         const dateArr = date.split("T");
    //         const newDate = moment(dateArr[0], "DD-MM-YYYY").format('YYYY-MM-DD');
    //         const newDate1 = dateArr[0] + ' ' + dateArr[1];
    //         const stillUtc = moment.utc(newDate1);
    //         const local = moment(newDate1).local().format('YYYY-MM-DD HH:mm:ss');
    //         return local;
    //     } else {
    //         return null;
    //     }
    // }
      getResourceList(){
        this.resetMessageBlock();
        this.crudViewEmitter.emit('list');
      }
    editResource(resourceGroupDetails: ResourceGroupTo) {
        this.resetMessageBlock();
        this.crudViewEmitter.emit("updateGroup");
        this.easResourceGroupService.setupdateResourceGroupdata(resourceGroupDetails.entityId);
      
    }
        closeResource(resourceGroupDetails: ResourceGroupTo) {
        this.resetMessageBlock();
        swal({
            title: 'Are you sure?',
            text: 'Delete the Resource "' + resourceGroupDetails.name + '"',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Yes, Delete',
            cancelButtonText: 'No, cancel',
            closeOnConfirm: true,
            closeOnCancel: true
        }, (isConfirm) => {
            if (isConfirm) {
                this.easResourceGroupService.deleteResourceGroup(resourceGroupDetails.entityId).subscribe(
                    data => {
                        if (null === data) {
                            this.notifierService.notify("success",'Resource Group "' + resourceGroupDetails.name +" deleted successfully");
                            this.getAllResourceData();
                        } else {
                            swal('Not Deleted!', 'Please try again', 'Failure');
                            this.displayFailure = true;
                            this.notifierService.notify("error","Unable to delete resource.Please try again later.");
                        }
                    },
                    error => {
                        if (error.status === 401) {
                            this.sharedService.routeToLoginError(error.status);
                        } else {
                            swal('Not Deleted!', "Please try again", 'Failure');
                        }
                    }
                );
            }
        });
    }

}

