import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MapConsoleService } from '../map-console/map-console.service';
import { EasAnnotationsService } from '../eas-annotations/eas-annotations.service';
import { AssignEasResourcesService } from '../eas-resources/assign-eas-resources/assign-eas-resources.service';
import { EasResourcesService } from '../eas-resources/eas-resources.service';
import { AppGlobals } from '../../shared/app.globals';
import { EasEventsService } from '../eas-events/eas-events.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SensorService } from '../map-console/sensor/sensor.service';
import { SharedService } from '../../shared/shared.service';
import * as moment from 'moment';
import * as $ from 'jquery';
const swal = require('sweetalert');
import { NotifierService } from 'angular-notifier';
import { DataModel } from '../../dataModelEnum';
import { EasPredefinedLocationsService } from '../eas-predefined-locations/eas-predefined-locations.service';
import { EasOtherEntitiesInformationService } from './eas-other-entities-information.service';
let controller;
let that;
@Component({
  selector: 'app-eas-other-entities-information',
  templateUrl: './eas-other-entities-information.component.html',
  styleUrls: ['./eas-other-entities-information.component.scss']
})
export class EasOtherEntitiesInformationComponent implements OnInit {
  dataEntityId: any;
  dataModel: any;
  @Input() easOtherEntitiesData: any;
  @Output() cameraObjectEmitter = new EventEmitter();
  public capabilities;
  public abilities;
  public entityData;
  public showCapabilities;
  public showAbilities;
  public showSensorDetails;
  public showData = false;
  public showError = false;
  public sensorHistory;
  public sensorData;
  public sensorProvideEntityId;
  constructor(private http: HttpClient,
    public mapConsoleService: MapConsoleService, private annotationSvc: EasAnnotationsService, private resourceSvc: EasResourcesService,
    private appglobals: AppGlobals, private eventService: EasEventsService, private sensorSvc: SensorService,
    private sharedSvc: SharedService, private notifierService: NotifierService,
    private easPredefinedLocationsService: EasPredefinedLocationsService,
    private easOtherEntitiesInformationService:EasOtherEntitiesInformationService) {
    that = this;
    that.easOtherEntitiesInformationService.selectedCameraData$.subscribe(
      data => {
        this.entityData = data;
      }
    );
  }
  ngOnInit() {
    controller = this;
    // this.initCall();

  }

  ngOnChanges(changes) {

    this.showSensorDetails = false;
    this.sensorHistory = false;

    if (changes.hasOwnProperty("easOtherEntitiesData")) {
      this.easOtherEntitiesData = changes.easOtherEntitiesData.currentValue;
      if (changes.easOtherEntitiesData.currentValue.dataModel === "SENSOR") {
        this.sensorProvideEntityId = this.easOtherEntitiesData.payLoad.payload.properties.provider_Id;
      }

      this.dataEntityId = this.easOtherEntitiesData.dataEntityId;
      this.dataModel = this.easOtherEntitiesData.dataModel;
      this.initCall();
    }

  }

  initCall() {
    if (this.dataModel === 'Agency' || this.dataModel === 'Vehicle' || this.dataModel === 'Person' || this.dataModel === 'Equipment') {
      this.resourceSvc.getResourceDetailsById(this.dataEntityId).subscribe(
        data => {
          if (data) {
            this.showData = true;
            if (data.assignedTo !== null && data.assignedTo !== "") {
              this.eventService.getEventDetails(data.assignedTo).subscribe(eventdata => {
                if (eventdata !== null) {
                  this.setResourceDetails(data, eventdata.eventName);
                }
                else {
                  this.setResourceDetails(data, "Not assigned to any event");
                }
              });
            } else {
              this.setResourceDetails(data, "Not assigned to any event");
            }
          }
        },
        error => {
          this.showError = true;
          console.log(error.error.message);
        }
      );
    } else if (this.dataModel === 'ANNOTATION') {
      this.annotationSvc.getAnnotationDetails(this.dataEntityId).subscribe(
        data => {
          if (data) {
            this.showData = true;
            console.log(data);
            if (data.assignedTo !== "" && data.assignedTo !== null) {
              this.eventService.getEventDetails(data.assignedTo).subscribe(
                eventData => {
                  if (eventData !== null) {
                    this.setAnnotationDetails(data, eventData.eventName);
                  }
                  else {
                    this.setResourceDetails(data, "Not assigned to any event");
                  }
                }

              );
            } else {
              this.setAnnotationDetails(data, "Not assigned to any event");
            }
          }
        },
        error => {
          this.showError = true;
          console.log(error.error.message);
        }
      );
    } else if (this.dataModel === 'TRAFFIC') {
      const trafficMetaData = {
        'Latitude': this.easOtherEntitiesData.payLoad.payload.geometry.coordinates[1],
        'Longitude': this.easOtherEntitiesData.payLoad.payload.geometry.coordinates[0],
        'Name': this.easOtherEntitiesData.payLoad.payload.properties.name,
        'Description': this.easOtherEntitiesData.payLoad.payload.properties.providerFullName,
        'Provider': this.easOtherEntitiesData.payLoad.payload.properties.provider_id,
        'Orientation': this.easOtherEntitiesData.payLoad.payload.properties.orientation

      };

      this.easOtherEntitiesData.payLoad.trafficMetaData = trafficMetaData;
      this.setSituationalData(this.easOtherEntitiesData.payLoad);
    } else if (this.dataModel === 'SENSOR') {
      this.sensorSvc.getSensorByEntityID(this.sensorProvideEntityId).subscribe(
        data => {
          if (data) {
            this.showData = true;
            this.sensorData = data;
            this.setSensorDetails(data);
          }
        },
        error => {
          this.showError = true;
          console.log(error.error.message);
        }
      );

    } else if (this.dataModel === DataModel.location) {
      this.entityData = this.frameObject(this.easOtherEntitiesData.payLoad.payload.properties, this.appglobals.locationMetaData,
        ['name', 'address', 'createdBy', 'createdDate']);
    } else {
      this.mapConsoleService.getSituationalData(this.dataModel, this.dataEntityId).subscribe(
        data => {
          if (data) {
            this.showData = true;
            console.log(data);
            this.setSituationalData(data);
          }
        },
        error => {
          this.showError = true;
          console.log(error.error.message);
        }
      );

    }
  }
  notSorted(obj) {
    if (!obj) {
      return [];
    }
    return Object.keys(obj);
  }
  setSituationalData(data) {
    this.showData = true;
    console.log((this.dataModel === 'TRAFFIC'));
    if (this.dataModel === 'TRAFFIC') {
      this.entityData = data.trafficMetaData;
      this.cameraObjectEmitter.emit(data);
    }
    if (this.dataModel === 'HYDRANT') {
      if (data.properties.hydrantid) {
        this.entityData = this.frameObject(data, this.appglobals.hydrantMetaData,
          ['latitude', 'longitude', 'hydrantid', 'valve_angle', 'valveid']);
      } else if (data.properties.hydrant_id) {
        this.entityData = this.frameObject(data, this.appglobals.hydrantMetaData,
          ['latitude', 'longitude', 'hydrant_id', 'location_description', 'valve_angle', 'valveid']);
      }
    }
    if (this.dataModel === 'HOSPITAL') {
      this.entityData = this.frameObject(data, this.appglobals.hospitalMetaData,
        ['source', 'latitude', 'longitude', 'hospital_name', 'address', 'city', 'county_name', 'phone_number', 'zip_code']);

    }
    if (this.dataModel === 'FUEL') {
      this.entityData = this.frameObject(data, this.appglobals.fuelMetaData,
        ['latitude', 'longitude', 'station_name', 'street_address', 'city', 'country',
          'station_phone', 'zip', 'fuel_type_code', 'groups_with_access_code']);

    }
    if (this.dataModel === 'DATA311') {
      this.entityData = this.frameObject(data, this.appglobals.data311MetaData,
        ['lat', 'long', 'service_name', 'service_code', 'status', 'status_notes', 'address', 'agency_responsible']);
      console.log(this.entityData);
    }

    if (this.dataModel === 'WEATHER') {

      this.entityData = {
        'Name': data.properties.name,
        'Temperature': data.properties.temperature.value + ' degC',
        'Pressure': data.properties.barometricPressure.value + ' Pa',
        'Minimum Temperature': (data.properties.minTemperatureLast24Hours.value !== null) ?
          data.properties.minTemperatureLast24Hours.value + ' degC' : 'Not Available',
        'Maximum Temperature': (data.properties.maxTemperatureLast24Hours.value !== null) ?
          data.properties.maxTemperatureLast24Hours.value + ' degC' : 'Not Available',
        'Humidity': data.properties.relativeHumidity.value + ' percent',
        'Sealevel Pressure': data.properties.seaLevelPressure.value + ' Pa'
      };

    }
  }
  setAnnotationDetails(data, eventName) {
    if (this.dataModel === 'ANNOTATION') {
      this.entityData = this.frameObject(data, this.appglobals.annotationMetaData,
        ['resourceName', 'annotationType', 'annotationDesc', 'createdDate', 'lastModifiedDate', 'status',
          'streetAddress1', 'streetAddress2', 'city', 'zip', 'state', 'county']);
      this.entityData["Updated Date"] = this.getLocalDate(this.entityData["Updated Date"]);
      this.entityData["Created Date"] = this.getLocalDate(this.entityData["Created Date"]);
      this.entityData["Assigned To"] = eventName;
      this.capabilities = data.properties.capabilities;
      this.showCapabilities = (this.capabilities) ? true : false;
      console.log(this.entityData);
    }
  }

  setSensorDetails(data) {
    this.showSensorDetails = true;
    this.entityData = this.frameObject(data, this.appglobals.sensorMetaData,
      ['name', 'dataValue', 'dataType', 'description', 'status']);
  }

  setResourceDetails(data, eventName) {
    if (this.dataModel === 'Person') {
      this.entityData = this.frameObject(data, this.appglobals.resourceMetaData,
        ['resourceName', 'status', 'createdDate', 'lastModifiedDate', 'streetAddress1', 'streetAddress2', 'city', 'zip', 'state'
          , 'county', 'gender', 'email', 'number']);
      if (data.dob && data.dob.day !== null &&
        data.dob.month !== null && data.dob.year !== null) {
        this.entityData["Date of Birth"] = data.dob.day + '/' + data.dob.month + '/'
          + data.dob.year;
        console.log(this.entityData);
      } else {
        this.entityData["Date of Birth"] = "Not Available";
      }
      this.getDetails(data);
      this.entityData["Updated Date"] = this.getLocalDate(this.entityData["Updated Date"]);
      this.entityData["Created Date"] = this.getLocalDate(this.entityData["Created Date"]);
      this.entityData["Assigned To"] = eventName;
    }
    if (this.dataModel === 'Vehicle') {
      this.entityData = this.frameObject(data, this.appglobals.vehicleMetaData,
        ['resourceName', 'status', 'createdDate', 'lastModifiedDate', 'streetAddress1', 'streetAddress2', 'city', 'zip', 'state'
          , 'county', 'number', 'vin', 'vehicleType', 'year', 'make', 'model', 'series', 'bodyType', 'color1', 'color2', 'equipmentType']);
      this.entityData["Email"] = (data.emails[0] && data.emails[0] !== null)
        ? data.emails[0] : "Not Available";
      this.getDetails(data);
      this.entityData["Updated Date"] = this.getLocalDate(this.entityData["Updated Date"]);
      this.entityData["Created Date"] = this.getLocalDate(this.entityData["Created Date"]);
      this.entityData["Assigned To"] = eventName;
    }
    if (this.dataModel === 'Agency') {
      this.entityData = this.frameObject(data, this.appglobals.vehicleMetaData,
        ['resourceName', 'status', 'createdDate', 'lastModifiedDate', 'streetAddress1', 'streetAddress2', 'city', 'zip', 'state'
          , 'county', 'number']);
      this.entityData["Email"] = (data.emails[0] && data.emails[0] !== null)
        ? data.emails[0] : "Not Available";
      this.entityData["Updated Date"] = this.getLocalDate(this.entityData["Updated Date"]);
      this.entityData["Created Date"] = this.getLocalDate(this.entityData["Created Date"]);
      this.entityData["Assigned To"] = eventName;
    }
    if (this.dataModel === 'Equipment') {
      this.entityData = this.frameObject(data, this.appglobals.vehicleMetaData,
        ['resourceName', 'status', 'createdDate', 'lastModifiedDate', 'streetAddress1', 'streetAddress2', 'city', 'zip', 'state'
          , 'county', 'year', 'make', 'model', 'series', 'bodyType', 'color1', 'color2', 'equipmentType']);
      this.getDetails(data);
      this.entityData["Updated Date"] = this.getLocalDate(this.entityData["Updated Date"]);
      this.entityData["Created Date"] = this.getLocalDate(this.entityData["Created Date"]);
      this.entityData["Assigned To"] = eventName;
    }

  }
  frameObject(object, metaData, keys) {
    const obj = {};
    for (const key in keys) {
      if (keys.hasOwnProperty(key)) {
        let value;
        if (object) {
          value = controller.findVal(object, keys[key]);
          obj[metaData[keys[key]]] = (value !== undefined && value !== null && value !== "") ? value : "Not Available";
        }
      }
    }
    return obj;
  }

  findVal(object, key) {
    let value;
    Object.keys(object).some(function (k) {
      if (k === key) {
        value = object[k];
        return true;
      }
      if (object[k] && typeof object[k] === 'object') {
        value = controller.findVal(object[k], key);
        return value !== undefined;
      }
    });
    return value;
  }
  getDetails(data) {
    this.capabilities = data.capabilities;
    this.showCapabilities = (this.capabilities) ? true : false;

    this.abilities = data.abilities;
    this.showAbilities = (this.abilities) ? true : false;
    console.log(this.entityData);
  }
  getLocalDate(date) {
    if (date !== null && date !== undefined) {
      console.log(date);
      const dateArr = date.split("T");
      console.log(dateArr);
      const newDate = moment(dateArr[0], "DD-MM-YYYY").format('YYYY-MM-DD');
      const newDate1 = dateArr[0] + ' ' + dateArr[1];
      const stillUtc = moment.utc(newDate1);
      const local = moment(newDate1).local().format('YYYY-MM-DD HH:mm:ss');
      return local;
    } else {
      return null;
    }
  }
  updateSensorStatus(changeEvent, sensorData) {
    const newStatus = changeEvent.target.value;
    if ('' !== newStatus) {
      this.sharedSvc.showYesNoAlert('Update Sensor Status to ' + newStatus, 'Update', swalCallback, 'No, cancel');
    }
    function swalCallback(yesNo) {
      if (yesNo) {
        that.sensorSvc.updateSensorStatus(newStatus, that.sensorProvideEntityId).subscribe(
          data => {
            that.notifierService.notify('success', 'Sensor updated with Status "' + newStatus + '" successfully.');
          },
          error => {
            if (error.status === 401) {
              that.sharedService.routeToLoginError(error.status);
            } else {
              swal('Not Updated!', 'Please try again', 'Failure');
            }
          }
        );
      }
    }
  }
  showSensorHistory() {
    this.sensorHistory = true;
  }
}
