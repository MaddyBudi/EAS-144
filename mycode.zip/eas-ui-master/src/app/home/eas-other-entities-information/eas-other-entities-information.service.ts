import { Injectable } from '@angular/core';
import { Subject,Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EasOtherEntitiesInformationService {
  selectedCameraData = new Subject<any>();
  selectedCameraData$ = this.selectedCameraData.asObservable();
  constructor() {
  }
}
