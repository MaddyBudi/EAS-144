// import { TestBed } from '@angular/core/testing';

// import { EasOtherEntitiesInformationService } from './eas-other-entities-information.service';

// describe('EasOtherEntitiesInformationService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: EasOtherEntitiesInformationService = TestBed.get(EasOtherEntitiesInformationService);
//     expect(service).toBeTruthy();
//   });
// });
