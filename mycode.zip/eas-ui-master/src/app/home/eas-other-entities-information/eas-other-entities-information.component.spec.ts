// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EasOtherEntitiesInformationComponent } from './eas-other-entities-information.component';

// describe('EasOtherEntitiesInformationComponent', () => {
//   let component: EasOtherEntitiesInformationComponent;
//   let fixture: ComponentFixture<EasOtherEntitiesInformationComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EasOtherEntitiesInformationComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EasOtherEntitiesInformationComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
