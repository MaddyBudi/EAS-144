import { Component, OnInit ,ViewChild} from '@angular/core';
import { UserService } from '../../login/services/user.service';
import { Router } from '@angular/router';

declare var $: any;
const screenfull = require('screenfull');

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})

export class NavigationComponent implements OnInit {
  @ViewChild('fsbutton') fsbutton;
  constructor(private userService:UserService,private router: Router) { }

  ngOnInit() {
  }

  toggleFullScreen1(event){
    const elem=document;
    if(elem.body.requestFullscreen){
      elem.body.requestFullscreen();
    }
  
  }
  newWindow(){
 const url=location.origin+"/appconsole"
   window.open(url, '_blank')
  }
  signOut(){
    this.router.navigate(['LoginComponent', { error: 'Logged out' }], { skipLocationChange: true });
  }
}
