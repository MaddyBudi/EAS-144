import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NavigationComponent } from './navigation.component';
import { LoginComponent } from '../../login/login.component';
import { AppComponent } from '../../app.component';
import { Component, OnInit, ViewChild} from '@angular/core';
import { UserService } from '../../login/services/user.service';
import { Router } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Location } from "@angular/common";
import { fakeAsync, tick} from '@angular/core/testing';
import {RouterTestingModule} from "@angular/router/testing";

import { NotifierModule } from 'angular-notifier';

describe('NavigationComponent', () => {
  let component: NavigationComponent;
  let fixture: ComponentFixture<NavigationComponent>;
  let location: Location;
  let router: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NavigationComponent, LoginComponent, AppComponent],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule,

      ],
      providers: [UserService],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavigationComponent);
    component = fixture.componentInstance;
    router = TestBed.get(Router);
    location = TestBed.get(Location);
    router.initialNavigation();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('True if window is in full screen view', () => {
    component.toggleFullScreen1(event);
    expect(component).toBeTruthy();
  })

  it('True if a new window is opened', () => {
    component.newWindow();
    expect(component).toBeTruthy();
  })

  it('True if the user has logged out successfully and redirected to LoginComponent', fakeAsync(() => {
    router.navigate(['']);
    expect(location.path()).toBe('/');
  }));
});
