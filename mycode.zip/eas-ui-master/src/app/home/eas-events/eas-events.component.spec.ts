// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EasEventsComponent } from './eas-events.component';

// describe('EasEventsComponent', () => {
//   let component: EasEventsComponent;
//   let fixture: ComponentFixture<EasEventsComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EasEventsComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EasEventsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
