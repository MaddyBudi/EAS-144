import { Component, OnInit, OnChanges, Input, Output, Inject, forwardRef, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { EasEventsService } from '../eas-events.service';
import { SharedService } from '../../../shared/shared.service';
import * as $ from 'jquery';
import { MapConsoleService } from '../../map-console/map-console.service';
import { DROPZONE_CONFIG } from 'ngx-dropzone-wrapper';
import { DropzoneConfigInterface, DropzoneDirective } from 'ngx-dropzone-wrapper';
import { ConfigService } from "../../../core/config/config-svc.service";
import { AppGlobals } from '../../../shared/app.globals';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { NotifierService } from 'angular-notifier';
const Dropzone = require('../../../../../node_modules/dropzone/dist/dropzone-amd-module');
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { EventTo } from '../../../shared/models/eventTo';
import { NotesTo } from '../../../shared/models/notesTo'
@Component({
  selector: 'app-update-eas-events',
  templateUrl: './update-eas-events.component.html',
  styleUrls: ['./update-eas-events.component.scss']
})
export class UpdateEasEventsComponent implements OnInit {
  @Input() isCancel: boolean;
  @Output() crudViewTypeEmitter = new EventEmitter();
  @Input() selectedEventIdFromMap;
  @Output() eventContextEventMain = new EventEmitter();
  @Input() contextEventId;
  failureMessage = "";
  displayFailureMsds = false;
  displayFailureSocialMedia = false;
  updateEventForm = new FormGroup({
    eventName: new FormControl(),
    eventDesc: new FormControl(),
    eventNotes: new FormControl(),
    address: new FormControl(),
    eventLatitude: new FormControl(),
    eventLongitude: new FormControl(),
    eventCoords: new FormControl(),
    eventStatus: new FormControl(),
    eventDate: new FormControl(),
    fillColor: new FormControl(),
    creator: new FormControl(),
    organizationName: new FormControl(),
    eventPriority: new FormControl(),
    createdDate: new FormControl(),
    eventType: new FormControl(),
    custom_points_msds: new FormArray([
      new FormControl('value'),
    ]),
    custom_points_social_media: new FormArray([
      new FormControl('value'),
    ]),
  });
  primaryCategoryList: any;
  displayUpdateContent = true;
  isFormModified = false;
  resetFlag = false;
  eventDetails: EventTo;
  resetData: EventTo
  selectedEventID;
  selectedItems = [];
  eventNotes: NotesTo[];
  dropdownSettings = {};
  stateList = [];
  countyList = [];
  filterQuery: '';
  msdsKeywords;
  socialMediaKeywords;
  attachedFileIds = [];
  imageIdList = [];
  eventType;
  dropzone;
  fullAddress;
  latitude;
  longitude;
  attachedFilesCount = 0;
  filesUploadedCount = 0;
  eventserviceurl:String
  public countiesMap = new Map();
  checkFlag = false;
  constructor(public formGroup: FormBuilder, private eventSvc: EasEventsService, public sharedService: SharedService,
    public mapConsoleService: MapConsoleService, public appGlobals: AppGlobals, private fb: FormBuilder, public easleftSideBarService: EasLeftSidebarService, private notifierService: NotifierService,
    private geocodeAddress: GeoAddressService) {
    this.eventDetails = new EventTo(this.eventSvc.payload);
  }
  get fileDropped(): boolean {
    if (this.dropzone) {
      return this.dropzone.files.length > 0;
    }
    return false;
  }
  ngOnChanges(changes) {
    if (changes.hasOwnProperty("selectedEventIdFromMap")) {
      this.selectedEventIdFromMap = changes.selectedEventIdFromMap.currentValue;
      this.attachedFileIds = [];
      this.checkFlag = true;
    }

  }

  // sets initial update form
  ngOnInit() {
    this.selectedEventID = (this.selectedEventIdFromMap === undefined) ? this.eventSvc.getEventId() : this.selectedEventIdFromMap;
    this.eventserviceurl=this.eventSvc.getconfigServiceUrl();
    this.dropzone = new Dropzone('div#my_dropzone', {
      url: this.eventserviceurl + this.appGlobals.attachFilesEndpoint + this.selectedEventID,
      autoProcessQueue: false,
      hiddenInputContainer: '#dropzone-drop-area',
      dictDefaultMessage: 'Browse on images to uploadds',
      method: "post",
      maxFiles: 5,
      acceptedFiles: 'image/*',
      clickable: '#dropzone-drop-area',
      previewsContainer: '#dropzone-drop-area',
      withCredentials: true,
      previewTemplate: `
      <div class="dz-preview dz-file-preview">
        <div class="dz-details">
          <img data-dz-thumbnail/>
        </div>
      </div>
      `
    });
    this.dropzone.autoDiscover = false;

    this.dropzone.on('addedfile', (file) => {
      this.isFormModified = true;
      this.attachedFilesCount = this.attachedFilesCount + 1;
    });
    this.dropzone.on('success', (file) => {
      this.filesUploadedCount = this.filesUploadedCount + 1;
      if (this.attachedFilesCount <= 5) {
        if (this.filesUploadedCount === this.attachedFilesCount) {
          this.dropZoneSuccessMessage();
        }
      } else {
        if (this.filesUploadedCount === 5) {
          this.dropZoneSuccessMessage();
        }
      }
    });
    this.dropzone.on("error", function (file, message) {
      $("#dzErrorMsg").text(message);
      this.removeFile(file);
    });
    console.log("in on init");
    this.getEventDetail(this.selectedEventID);
    this.setEventForm();
  }

  getEventDetail(eventId) {

    this.eventSvc.getEventDetails(eventId).subscribe(
      data => {
 
        this.eventDetails = data;
        this.resetData = JSON.parse(JSON.stringify(data));
        this.resetData.geometry = JSON.stringify(this.resetData.geometry);
        this.imageIdList = (null !== data.attachedFilesId) ? data.attachedFilesId : [];
        this.resetFlag = false;
        this.setupdateEventForm(this.resetFlag);

      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.eventSvc.displayFailure = (this.selectedEventIdFromMap === undefined) ? true : false;
          this.eventSvc.setFailureMessage('General error occured. Please try again later.');
        }
      }
    );
  }
  dropZoneSuccessMessage() {
    this.filesUploadedCount = 0;
    this.attachedFilesCount = 0;
    this.notifierService.notify('success', 'Files are uploaded to "' + this.dropzone.eventName + '" event successfully');
  }
  setEventForm() {
    this.updateEventForm = this.formGroup.group({
      'eventName': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'eventDesc': ['', Validators.compose([Validators.minLength(1), Validators.maxLength(250)])],
      'eventNotes': [],
      'address': [''],
      'eventLatitude': [],
      'eventLongitude': [],
      'eventCoords': [],
      'eventStatus': [],
      'eventDate': [],
      'fillColor': [],
      'creator': [],
      'organizationName': [],
      'eventPriority': [],
      'createdDate': [],
      'eventType': [],
      'custom_points_msds': this.formGroup.array([this.formGroup.group({ value: '' })]),
      'custom_points_social_media': this.formGroup.array([this.formGroup.group({ value: '' })]),
    });

  }

  resetUpdatePage() {
    this.geocodeAddress.resetAll();
    this.geocodeAddress.setAddressLatLng.next([this.longitude, this.latitude]);
    this.isFormModified = false;
    this.resetFlag = true;
    this.updateEventForm.reset(this.resetData);
    this.eventDetails = new EventTo(JSON.parse(JSON.stringify(this.resetData)));
    this.setupdateEventForm(this.resetFlag);
    $('#dzErrorMsg').text('');
  }


  // binds value from eventDetails to UI fields on update page
  setupdateEventForm(resetFlag) {
    if (!resetFlag) {
      if (this.eventDetails.attachedFilesId && null !== this.eventDetails.attachedFilesId && this.eventDetails.attachedFilesId.length > 0) {
        this.eventDetails.attachedFilesId.forEach(element => {
          this.attachedFileIds.push(this.eventserviceurl + this.appGlobals.retrieveAttachedFilesEndpoint + element);
        });
      }
    }
    let latlngCenter = [];
    if (this.eventDetails.geometry['type'] !== "Point" && this.eventDetails.geometry['type'] !== "LineString") {
      latlngCenter = this.sharedService.getPolygonCenter(this.eventDetails.geometry['coordinates'][0]);
      this.longitude = latlngCenter[0];
      this.latitude = latlngCenter[1];
      this.geocodeAddress.disableAddressLatLng.next();
    } else if (this.eventDetails.geometry['type'] === 'LineString') {

      this.latitude = (this.eventDetails.geometry['coordinates'][0][1] + this.eventDetails.geometry['coordinates'][1][1]) / 2;
      this.longitude = (this.eventDetails.geometry['coordinates'][0][0] + this.eventDetails.geometry['coordinates'][1][0]) / 2;
      this.geocodeAddress.disableAddressLatLng.next();
    } else {
      this.latitude = this.eventDetails.geometry['coordinates'][1];
      this.longitude = this.eventDetails.geometry['coordinates'][0];
    }
    this.geocodeAddress.setAddressLatLng.next([this.longitude, this.latitude]);
    this.geocodeAddress.coordinates = this.eventDetails.geometry['coordinates'];
    this.updateEventForm.controls['eventCoords'].setValue(this.eventDetails.geometry['coordinates']);
    this.updateEventForm.controls['fillColor'].setValue(this.eventDetails.properties['fill']);
    this.setCustomAttributesMsds(this.eventDetails.properties['msdsKeywords']);
    this.setCustomAttributesSocialMedia(this.eventDetails.properties['socialMediaKeywords']);
    this.eventNotes = this.eventDetails.eventNotes;
    this.updateEventForm.controls['eventName'].setValue(this.eventDetails.eventName);
    this.updateEventForm.controls['eventDesc'].setValue(this.eventDetails.eventDesc);
    this.updateEventForm.controls['eventType'].setValue(this.eventDetails.eventType);
    this.eventType = this.eventDetails.eventType;
    this.updateEventForm.controls['eventStatus'].setValue(this.eventDetails.status);
    this.updateEventForm.controls['eventDate'].setValue(this.eventDetails.properties['eventDate']);
    this.updateEventForm.controls['creator'].setValue(this.eventDetails.creator);
    this.updateEventForm.controls['organizationName'].setValue(this.eventDetails.organizationName);
    this.updateEventForm.controls['eventPriority'].setValue(this.eventDetails.priority);
    this.updateEventForm.controls['createdDate'].setValue(this.eventDetails.createdDate);
    this.updateEventForm.get('eventCoords').disable();
    this.updateEventForm.get('creator').disable();
    this.updateEventForm.get('createdDate').disable();
    this.updateEventForm.get('eventType').disable();
    this.updateEventForm.controls['eventNotes'].setValue('');
    if (this.eventDetails.status === "TERMINATED") {
      this.updateEventForm.controls['eventStatus'].disable();
    }
    if (this.dropzone) {
      this.dropzone.removeAllFiles();
    }
    this.updateEventForm.valueChanges.subscribe(data => {
      this.isFormModified = true;
    });

  }
  // subscribes to update endpoint
  updateEvent(event, formData) {
    this.geocodeAddress.activeAddressInfo();
    formData.latitude = this.geocodeAddress.latitude;
    formData.longitude = this.geocodeAddress.longitude;
    if (this.eventDetails.geometry['type'] == "Point")
    formData.eventCoords = this.geocodeAddress.coordinates;
    formData.address = this.sharedService.getFullAddress(this.geocodeAddress.place);
    this.fullAddress = this.sharedService.getFullAddress(this.geocodeAddress.place);
    event.preventDefault();
    
    this.eventDetails.setAddress(this.fullAddress);
    const geo = {
      "type": this.eventDetails.geometry['type'],
      "coordinates": (this.eventDetails.geometry['type'] !== 'Point') ? formData.eventCoords :
        [
          parseFloat(formData.longitude),
          parseFloat(formData.latitude)
        ],
    };
    this.eventDetails.setGeometry(geo);
    this.eventDetails.properties['msdsKeywords'] = this.formatCustomAttributesMsds(this.updateEventForm.value);
    this.eventDetails.properties['socialMediaKeywords'] = this.formatCustomAttributesSocialMedia(this.updateEventForm.value);
    this.eventDetails.attachedFilesId = this.imageIdList;

    for (const c in this.updateEventForm.controls) {
      if ((this.updateEventForm.controls).hasOwnProperty(c)) {
        this.updateEventForm.controls[c].markAsTouched();
      }
    }
    if (this.fileDropped) {
      this.isFormModified = true;
      this.upload(this.eventDetails);
    }
    if (this.isFormModified && this.updateEventForm.valid && this.geocodeAddress.checkValidation) {
      this.eventSvc.updateEvent(this.eventDetails).subscribe(
        data => {
          this.geocodeAddress.resetAll();
          if (data.status === "TERMINATED") {
            this.eventSvc.releaseEventResourcesAnnotations(data);
            this.eventSvc.clearContext(this.selectedEventID);
            this.mapConsoleService.setEventContext(null);
          }
          if (data.entityId != null) {
            this.notifierService.notify("success", 'Event "' + formData.eventName + '" updated successfully.')
            if (this.selectedEventIdFromMap !== undefined) {
              this.mapConsoleService.setEventContext(data)
              this.onClose();
            } else {
              this.getListView();
            }
            if (this.contextEventId === data.entityId) {
              this.mapConsoleService.setEventContext(data);
            }
          } else {
            this.notifierService.notify("error", "Unable to update an event now.")
          }
          if (this.isFormModified) {
            this.eventContextEventMain.emit({ "geometry": data.geometry, "socialMediaKeywords": data.properties.socialMediaKeywords });
          }
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.notifierService.notify("error", "General error occured. Please try again later.")
          }
        }
      );
    } else {
      this.notifierService.notify("error", "Please modify the event details/provide the correct details to update.")
      setTimeout(() => {
        this.eventSvc.displayFailure = false;
      }, 2000);
      $('#eventName').focus();
    }
  }

  refreshNotes() {
    this.eventSvc.getEventDetails(this.selectedEventID).subscribe(
      data => {
        this.eventNotes = data.eventNotes;

      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.notifierService.notify("error", "General error occured. Please try again later.")

        }
      }
    );
  }
  closeAction(event) {
    this.getListView();
  }
  getListView() {
    this.crudViewTypeEmitter.emit('list');
    this.easleftSideBarService.changeEntitiesListTypes(PanelHeaders.events);
    this.checkFlag = false;
  }
  // onUploadError(event) {
  // }
  // onSendingmultiple(event) {
  // }
  // onSending(event) {
  // }
  // onUploadSuccess(imageDetails) {
  //   this.imageIdList.push(imageDetails[1][0]);
  //   this.isFormModified = true;
  // }
  get customValueMsds() {
    return this.updateEventForm.get('custom_points_msds') as FormArray;
  }
  get customValueSocialMedia() {
    return this.updateEventForm.get('custom_points_social_media') as FormArray;
  }
  blockSpecialChar(e) {
    const k = e.keyCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k === 8 || (k >= 48 && k <= 57) || k === 32);
  }

  addCustomValue(value: string) {
    if (value === 'msds') {
      if (this.updateEventForm.value.custom_points_msds[this.updateEventForm.value.custom_points_msds.length - 1].value) {
        this.customValueMsds.push(this.formGroup.group({ value: '' }));
        this.failureMessage = "";
        this.displayFailureMsds = false;
      } else {
        this.failureMessage = "Please enter a proper value";
        this.displayFailureMsds = true;
        setTimeout(() => {
          this.failureMessage = "";
          this.displayFailureMsds = false;
        }, 4000);
      }
    } else if (value === 'social_media') {
      if (this.updateEventForm.value.custom_points_social_media[this.updateEventForm.value.custom_points_social_media.length - 1].value) {
        this.customValueSocialMedia.push(this.formGroup.group({ value: '' }));
        this.failureMessage = "";
        this.displayFailureSocialMedia = false;
      } else {
        this.failureMessage = "Please enter a proper value";
        this.displayFailureSocialMedia = true;
        setTimeout(() => {
          this.failureMessage = "";
          this.displayFailureSocialMedia = false;
        }, 4000);
      }
    }
  }

  deleteCustomValue(index, value: string) {
    if (value === 'msds') {
      if (this.updateEventForm.value.custom_points_msds.length > 1) {
        this.customValueMsds.removeAt(index);
      } else {
        this.customValueMsds.removeAt(0);
        this.customValueMsds.push(this.formGroup.group({ value: '' }));
      }
    } else if (value === 'social_media') {
      if (this.updateEventForm.value.custom_points_social_media.length > 1) {
        this.customValueSocialMedia.removeAt(index);
      } else {
        this.customValueSocialMedia.removeAt(0);
        this.customValueSocialMedia.push(this.formGroup.group({ value: '' }));
      }
    }
  }

  formatCustomAttributesMsds(customAttr) {
    const formatted_attr = [];
    customAttr.custom_points_msds.forEach(element => {
      formatted_attr.push(element.value);
    });
    return formatted_attr;
  }
  formatCustomAttributesSocialMedia(customAttr) {
    const formatted_attr = [];
    customAttr.custom_points_social_media.forEach(element => {
      formatted_attr.push(element.value);
    });
    return formatted_attr;
  }
  clearFormArray = (formArray: FormArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }
  setCustomAttributesMsds(msdsKeywords) {
    this.clearFormArray(<FormArray>this.updateEventForm.get('custom_points_msds'));
    for (const msdsKeyword in msdsKeywords) {
      if (msdsKeyword) {
        const value = msdsKeywords[msdsKeyword];
        this.customValueMsds.push(this.formGroup.group({ value: value }));
      }
    }
  }
  setCustomAttributesSocialMedia(socialMediaKeywords) {
    this.clearFormArray(<FormArray>this.updateEventForm.get('custom_points_social_media'));
    for (const socialMediaKeyword in socialMediaKeywords) {
      if (socialMediaKeyword) {
        const value = socialMediaKeywords[socialMediaKeyword];
        this.customValueSocialMedia.push(this.formGroup.group({ value: value }));
      }
    }
  }
  upload(data) {
    this.dropzone.eventName = data.eventName;
    this.dropzone.options.parallelUploads = 5;
    this.dropzone.processQueue();
  }
  onClose() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
    this.checkFlag = false;
  }
}
