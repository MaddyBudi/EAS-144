import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import * as $ from 'jquery';
import { UpdateEasEventsComponent } from './update-eas-events.component';
import { GeoAddressComponent } from '../../geo-address/geo-address.component';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { AppGlobals } from '../../../shared/app.globals';
import { EasEventsService } from '../eas-events.service';
import { MockEasEventsService } from '../eas-mock-events.service';
import { EventTo } from '../../../shared/models/eventTo';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { SharedPipe } from '../../shared.pipe';
import { MapsAPILoader } from '@agm/core';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { SharedService } from '../../../shared/shared.service';
import { doesNotThrow } from 'assert';
import { domRendererFactory3 } from '@angular/core/src/render3/interfaces/renderer';
describe('UpdateEasEventsComponent', () => {
  let component: UpdateEasEventsComponent;
  let fixture: ComponentFixture<UpdateEasEventsComponent>;
  let appglobals = new AppGlobals();
  let geoAddressComponent: GeoAddressComponent;
  let geoAddressComponentfixture: ComponentFixture<GeoAddressComponent>;
  let service: EasEventsService;
  // let mockService : ConfigService
  let jqdiv;
  let payload: any =
  {
    "dataModel": appglobals.eventDataModel,
    "eventName": '',
    "address": '',
    "properties": {
      "eventDate": '',
      "stroke": '',
      "stroke-width": 0,
      "stroke-opacity": 1,
      "fill": '',
      "fill-opacity": 0.35,
      "msdsKeywords": '',
      "socialMediaKeywords": '',
    },
    "eventType": '',
    "priority": '',
    "status": "STARTED",
    "eventDesc": '',
    "owner": "EAS-USER",
    "geometry": "{\"type\":\"Point\",\"coordinates\":[-76.802938,38.986243]}",
    "type": '',
    "createdBy":""
  };

  let specialcharpayload ={
    "key": "2",
    "keyCode":50
  }
  beforeEach(async(() => {

    TestBed.configureTestingModule({

      declarations: [UpdateEasEventsComponent, GeoAddressComponent, SharedPipe],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule,
        OwlDateTimeModule,
        OwlNativeDateTimeModule
      ],
      providers: [
         GeoAddressService,
         EasLeftSidebarService,
         SharedService,
        { provide: EasEventsService, useClass: MockEasEventsService },
        { provide: MapsAPILoader }
      ]
    })
      .compileComponents().then(() => {
        fixture = TestBed.createComponent(UpdateEasEventsComponent);
        geoAddressComponentfixture = TestBed.createComponent(GeoAddressComponent);
        component = fixture.componentInstance;
        geoAddressComponent = geoAddressComponentfixture.componentInstance;
        const div = document.createElement('div');
        const divDropzone = document.createElement('div');
        div.setAttribute('id', 'my_dropzone');
        divDropzone.setAttribute('id', 'dropzone-drop-area');
        divDropzone.classList.add("dropzone-drop-area");
        div.appendChild(divDropzone);
        document.body.appendChild(div);
        jqdiv = $(div);
        service = TestBed.get(EasEventsService);
      });


  }));

  beforeEach(() => {
    
    component.eventDetails = new EventTo(Object.assign({}, payload));
    component.resetData = new EventTo(Object.assign({}, payload));
    fixture.detectChanges();
    geoAddressComponentfixture.detectChanges();


  });
  afterEach(() => {
    jqdiv.remove();
  })



  it('True if the component is created successfully', () => {
    expect(component).toBeTruthy();
  });

  it('should validate update form with exisiting data', (done) => {
    setTimeout( ()=> {
      expect(component.updateEventForm.valid).toBeTruthy();
     done();
    }, 1000);
 
  });

  it('should invalid update events form if the inputs were not given', () => {
    expect(geoAddressComponent.geoAddressForm.valid && component.updateEventForm.valid).toBeFalsy();
  });

  it('should invalid update event form if event name,event desc and coordinates are given but not address is given', (done) => {

    component.updateEventForm.controls['eventName'].setValue('Test Event');
    component.updateEventForm.controls['eventDesc'].setValue('sample testing');
    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('40.739197');
    geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-73.990860');
    setTimeout( ()=> {
      expect(geoAddressComponent.geoAddressForm.valid && component.updateEventForm.valid).toBeFalsy();
       done();
    }, 1000);
  });



  it('should invalid update events form if event name, event description are given but address, coordinates are empty', (done) => {

    setTimeout(function () {
      component.updateEventForm.controls['eventName'].setValue('Test event');
      component.updateEventForm.controls['eventDesc'].setValue('sample testing');
      geoAddressComponent.geoAddressForm.controls['latitude'].setValue('');
      geoAddressComponent.geoAddressForm.controls['longitude'].setValue('');
      geoAddressComponent.setAddress();
      expect(geoAddressComponent.geoAddressForm.valid && component.updateEventForm.valid).toBeFalsy();
       done();
    }, 1000);
  });

  it('should invalid update event form if address, coordinates are given but event name, event description are empty', () => {
    geoAddressComponent.geoAddressForm.controls['address'].setValue('123 5th Ave, New York, NY 10003, USA');
    expect(geoAddressComponent.geoAddressForm.valid && component.updateEventForm.valid).toBeFalsy();
  });

  it('should invalid update event form if latitude is given and address, longitude are not given', (done) => {

    setTimeout(() => {
      component.updateEventForm.controls['eventName'].setValue('Test Event');
      component.updateEventForm.controls['eventDesc'].setValue('sample testing');
      geoAddressComponent.geoAddressForm.controls['latitude'].setValue('40.739197');
      geoAddressComponent.geoAddressForm.controls['longitude'].setValue('');
      geoAddressComponent.setAddress();
      expect(geoAddressComponent.geoAddressForm.valid && component.updateEventForm.valid).toBeFalsy();
      done();
    }, 1000);
  });

  it('should close update event form when clicking cancel button', (done) => {
    component.crudViewTypeEmitter.subscribe(
      data => {
        expect(data).toEqual('list');
        done();
      }
    );
    component.closeAction(null);
  });

  it('True if the resetUpdatetemethod() operation is performed ', (done) => { // resets the page

    component.updateEventForm.controls['eventName'].setValue('Test Resource For KArma');
    geoAddressComponent.geoAddressForm.controls['latitude'].setValue('-73.934306');
    geoAddressComponent.geoAddressForm.controls['longitude'].setValue('40.797878');
    geoAddressComponent.geoAddressForm.controls['address'].setValue('2321, 1st Avenue,New York,NYNew York County');

    expect(geoAddressComponent.geoAddressForm.valid && component.updateEventForm.valid).toBeTruthy();
    setTimeout(() => {
      component.resetUpdatePage();

      expect(component.updateEventForm.valid).toBeTruthy();
      done();
    }, 1000);

  });

  it('True if the closeaction() method is called and perform its action', (done) => {

    //checks the getlistview method is called;
    component.crudViewTypeEmitter.emit('list');
    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('list'); //checks the value emitted is list
      done();
    })
    component.closeAction(null);

  });

  it('True if the onClose() method is called and perform its action', () => {
  
   
    component.easleftSideBarService.easleftSidebarToggle$.subscribe(g => {
      expect(g).toEqual('0%'); //checks the value emitted is list
    })
    component.onClose()

  });

  it('should validate update form with exisiting data', (done) => {
    setTimeout( ()=> {
      component.refreshNotes()
      expect(component.eventNotes.length).not.toBe(0);
     done();
    }, 1000);
 
  });

  it('True if the addCustomValue() method is called and perform its action', (done) => {
    setTimeout( ()=> {
    component.addCustomValue('msds')
    expect(component.customValueMsds.length).toBe(3)
    component.addCustomValue('social_media')
    expect(component.customValueSocialMedia.length).toBe(3)
    done();
  }, 1000);
  });
  // it('True if the addCustomValue() operation is performed ', (done) => { // resets the page

  //   component.updateEventForm.value.custom_points_msds[component.updateEventForm.value.custom_points_msds.length].value=""
  //   component.updateEventForm.value.custom_points_social_media[component.updateEventForm.value.custom_points_social_media.length].value=""
  //   setTimeout(() => {
  //     component.addCustomValue('msds')
  //     expect(component.customValueMsds.length).toBe(2)
  //     component.addCustomValue('social_media')
  //     expect(component.customValueSocialMedia.length).toBe(2)
  //     done();
  //   }, 1000);

  // });
  it('True if the deleteCustomValue() method is called and perform its action', (done) => {
    setTimeout( ()=> {
    component.deleteCustomValue(0,'msds')
    expect(component.customValueMsds.length).toBe(1)
    component.deleteCustomValue(0,'social_media')
    expect(component.customValueSocialMedia.length).toBe(1)
    done();
  }, 1000);
  });

  it('True if the formatCustomAttributesMsds() and formatCustomAttributesSocialMedia method is called', (done) => {
    setTimeout( ()=> {
    component.formatCustomAttributesMsds(component.updateEventForm.value)
    component.formatCustomAttributesSocialMedia(component.updateEventForm.value)
    done();
  }, 1000);
  });

  it('should validate blockSpecialChar form with exisiting data', () => {
      component.blockSpecialChar(specialcharpayload)
      expect(specialcharpayload.keyCode).toBe(50); 
  });

  it('should validate upload form with exisiting data', (done) => {
    setTimeout( ()=> {
    component.upload(component.eventDetails)
    done();
  }, 1000);
  });
  
});
