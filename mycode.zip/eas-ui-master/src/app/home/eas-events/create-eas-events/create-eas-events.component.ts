import { Component, OnInit, Inject, forwardRef, Input, OnChanges, SimpleChange, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { EasEventsService } from '../eas-events.service';
import { MapConsoleService } from '../../map-console/map-console.service';
import * as $ from 'jquery';
import { SharedService } from '../../../shared/shared.service';
import { UserService } from '../../../login/services/user.service';
import { ConfigService } from '../../../core/config/config-svc.service';
import { AppGlobals } from '../../../shared/app.globals';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { NotifierService } from 'angular-notifier';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { DataModel } from '../../../dataModelEnum';
import { EventTo } from '../../../shared/models/eventTo';
import { NotesTo } from '../../../shared/models/notesTo'

const Dropzone = require('../../../../../node_modules/dropzone/dist/dropzone-amd-module');
declare let google: any;
const map = null;

@Component({
  selector: 'app-create-eas-events',
  templateUrl: './create-eas-events.component.html',
  styleUrls: ['./create-eas-events.component.css']
})
export class CreateEasEventsComponent implements OnInit {
  @Input() markerEventData: any;
  @Output() crudViewTypeEmitter = new EventEmitter();
  failureMessage = '';
  displayFailureMsds = false;
  displayFailureSocialMedia = false;
  _markerEventData = new FormGroup({ eventData: new FormControl() });
  eventForm = new FormGroup({
    eventName: new FormControl(),
    eventDesc: new FormControl(),
    eventNotes: new FormControl(),
    eventAddress: new FormControl(),
    eventLatitude: new FormControl(),
    eventLongitude: new FormControl(),
    eventCoords: new FormControl(),
    fillColor: new FormControl(),
    formedCoords: new FormControl(),
    eventDate: new FormControl(),
    shapeType: new FormControl(),
    eventPriority: new FormControl(),
    type: new FormControl(),
    dob: new FormControl(),
    eventType: new FormControl(),
    custom_points_msds: new FormArray([
      new FormControl('value'),
    ]),
    custom_points_social_media: new FormArray([
      new FormControl('value'),
    ])
  });
  eventNames = [];
  displayCreateContent = true;
  eventAddr = '';
  fulladdress;
  showRestBtn = true;
  showCancelBtn = false;
  formedCoords = [];
  eventTypes = [];
  msdsKeywordsFromComp;
  socialMediaKeywordsFromComp;
  dropzone;
  eventDataFromMap;
  eventLatitude;
  eventLongitude;
  eventAddress;
  eventShapeType = 'Point';
  isFormModified = false;
  event: EventTo;
  eventNotes: NotesTo;
  attachedFilesCount = 0;
  filesUploadedCount = 0;
  geoAddressCoordinates = [];
     
  @Output() eventContextEventMain = new EventEmitter();
  constructor(public formGroup: FormBuilder, public eventSvc: EasEventsService, public sharedService: SharedService,
    public mapConsoleService: MapConsoleService, public userService: UserService, private fb: FormBuilder,
    public appglobals: AppGlobals, public easleftSideBarService: EasLeftSidebarService, private notifierService: NotifierService,
    private geocodeAddress: GeoAddressService) {
    this.eventForm.controls['eventPriority'].setValue("low", { onlySelf: true });
    this.eventForm.controls['type'].setValue("Event", { onlySelf: true });
    this.event=new EventTo(this.eventSvc.payload);
    this.eventNotes=new NotesTo(this.eventSvc.notes);
  }
  get fileDropped(): boolean {
    if (this.dropzone) {
      return this.dropzone.files.length > 0;
    }
    return false;
  }
  ngOnInit() {
    this.eventTypes = this.userService.eventType;
    this.setEventForm();
    this.dropzone = new Dropzone('div#my_dropzone', {
      url: 'test url',
      autoProcessQueue: false,
      hiddenInputContainer: '#dropzone-drop-area',
      dictDefaultMessage: 'Browse on images to uploadds',
      method: 'post',
      maxFiles: 5,
      acceptedFiles: 'image/*',
      clickable: '#dropzone-drop-area',
      previewsContainer: '#dropzone-drop-area',
      withCredentials: true,
      previewTemplate: `
      <div class='dz-preview dz-file-preview'>
        <div class='dz-details'>
          <img data-dz-thumbnail/>
        </div>
      </div>
      `
    });
    this.dropzone.autoDiscover = false;
    this.dropzone.on('addedfile', (file) => {
      this.attachedFilesCount = this.attachedFilesCount + 1;
    });
    this.dropzone.on('success', (file) => {
      this.filesUploadedCount = this.filesUploadedCount + 1;
      if (this.attachedFilesCount <= 5) {
        if (this.filesUploadedCount === this.attachedFilesCount) {
          this.dropZoneSuccessMessage();
        }
      } else {
        if (this.filesUploadedCount === 5) {
          this.dropZoneSuccessMessage();
        }
      }
    });
    this.dropzone.on('error', function (file, message) {
      $('#dzErrorMsg').text(message);
      this.removeFile(file);
    });
    setTimeout(() => {
      this.isFormModified = false;
    }, 60);
    if (this.markerEventData) {
      this.getEventShapeFromMap(this.markerEventData);
    }
  }
  dropZoneSuccessMessage() {
    this.filesUploadedCount = 0;
    this.attachedFilesCount = 0;
    this.notifierService.notify('success', 'Files are uploaded to "' + this.dropzone.eventName + '" event successfully');
  }
  // subscribes to create endpoint
  createEvent(event, formData) {
    this.geocodeAddress.activeAddressInfo();
    formData.address = this.geocodeAddress.address;
    formData.latitude = this.geocodeAddress.latitude;
    formData.longitude = this.geocodeAddress.longitude;
    formData.eventCoords = this.geocodeAddress.coordinates;
    event.preventDefault();
    this.event.setAddress(this.sharedService.getFullAddress(this.geocodeAddress.place));
    const geo = {
      'type': this.eventShapeType,
      'coordinates': (this.eventShapeType !== 'Point') ? [formData.eventCoords] :
        [
          parseFloat(formData.longitude),
          parseFloat(formData.latitude)
        ],
    };
    this.event.setGeometry(geo);
    this.event.properties['stroke'] = (formData.fillColor) ? formData.fillColor : '';
    this.event.properties['fill'] = (formData.fillColor) ? formData.fillColor : '';
    this.event.properties['msdsKeywords'] = this.formatCustomAttributesMsds(this.eventForm.value);
    this.event.properties['socialMediaKeywords'] = this.formatCustomAttributesSocialMedia(this.eventForm.value);
    this.event.eventType = formData.eventType;
    this.event.priority = formData.eventPriority;
    this.event.type = formData.type;
    for (const c in this.eventForm.controls) {
      if (this.eventForm.controls.hasOwnProperty(c)) {
        this.eventForm.controls[c].markAsTouched();
      }
    }
  if (this.eventForm.valid  && this.geocodeAddress.checkValidation) {

  console.log(this.event);
   this.eventSvc.createEvent(this.event).subscribe(
        data => {
          if (data.type === 'Event') {
               this.mapConsoleService.setEventContext(data);
          }
         if (data.entityId !== null) {
            if (this.eventNotes && this.eventNotes.comment.trim() !== '') {
              this.eventNotes.entityId = data.entityId;
              this.eventSvc.setNotes(this.eventNotes).subscribe(
                data1 => {
                });
            }
            this.getListView();
            if (this.fileDropped) {
              this.upload(data);
            }
            this.notifierService.notify('success', this.event.type + '"' + this.event.eventName + '" created successfully.');
            this.geocodeAddress.resetAll();
            this.onClose();
          } else {
            this.notifierService.notify('error', 'Unable to create an event now.');
          }
        },
        error => {
          if (error.status === 401) {
            this.sharedService.routeToLoginError(error.status);
          } else {
            this.notifierService.notify('error', 'General error occured. Please try again later.');
            this.getListView();
          }
        }
      );
    } else {
      $('#eventName').focus();
      this.notifierService.notify('error', 'Please provide the correct details to create an event.');
      setTimeout(() => {
        this.eventSvc.displayFailure = false;
      }, 2000);
    }
  }
  setEventForm() {

    this.eventForm = this.formGroup.group({
      'eventName': ['', Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(50)])],
      'eventDesc': ['', Validators.compose([Validators.minLength(1), Validators.maxLength(250)])],
      'eventAddress': [''],
      'eventLatitude': [''],
      'eventLongitude': [''],
      'eventCoords': [],
      'eventStatus': [],
      'fillColor': [],
      'formedCoords': [],
      'eventDate': [],
      'shapeType': this.eventShapeType,
      'eventNotes': [],
      'eventPriority': ['low'],
      'custom_points_msds': this.formGroup.array([this.formGroup.group({ value: '' })]),
      'custom_points_social_media': this.formGroup.array([this.formGroup.group({ value: '' })]),
      'dob': [],
      'eventType': ['', Validators.required],
      'type': ['Event']
    });
    if (this.dropzone) {
      this.dropzone.removeAllFiles();
    }
    this.eventForm.valueChanges.subscribe(data => {
      this.isFormModified = true;
    });
  }

  resetCreatePage(event) {
    this.geoAddressCoordinates = [];
    if (!this.markerEventData) { this.geocodeAddress.resetAll(); }
    this.eventForm.reset();
    this.setEventForm();
    $('#dzErrorMsg').text('');
    this.isFormModified = false;
  }

  getEventShapeFromMap(newShape) {
    if (newShape.type === google.maps.drawing.OverlayType.MARKER) {
      this.eventShapeType = 'Point';
    } else {
      this.eventShapeType = 'Polygon';
      this.geocodeAddress.disableAddressLatLng.next();
    }
    const data = {
      shape: newShape,
      dataModel: DataModel.event
    };
    this.geocodeAddress.getMapObjects.next(data);
  }

  closeAction(event) {
    this.getListView();
  }
  getListView() {
    this.crudViewTypeEmitter.emit('list');
    this.easleftSideBarService.changeEntitiesListTypes(PanelHeaders.events);
  }
  get customValueMsds() {
    return this.eventForm.get('custom_points_msds') as FormArray;
  }
  get customValueSocialMedia() {
    return this.eventForm.get('custom_points_social_media') as FormArray;
  }
  blockSpecialChar(e) {
    const k = e.keyCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k === 8 || (k >= 48 && k <= 57) || k === 32);
  }
  addCustomValue(value: string) {
    if (value === 'msds') {
      if (this.eventForm.value.custom_points_msds[this.eventForm.value.custom_points_msds.length - 1].value) {
        this.customValueMsds.push(this.formGroup.group({ value: '' }));
        this.failureMessage = '';
        this.displayFailureMsds = false;
      } else {
        this.failureMessage = 'Please enter a proper value';
        this.displayFailureMsds = true;
        setTimeout(() => {
          this.failureMessage = '';
          this.displayFailureMsds = false;
        }, 4000);
      }
    } else if (value === 'social_media') {
      if (this.eventForm.value.custom_points_social_media[this.eventForm.value.custom_points_social_media.length - 1].value) {
        this.customValueSocialMedia.push(this.formGroup.group({ value: '' }));
        this.failureMessage = '';
        this.displayFailureSocialMedia = false;
      } else {
        this.failureMessage = 'Please enter a proper value';
        this.displayFailureSocialMedia = true;
        setTimeout(() => {
          this.failureMessage = '';
          this.displayFailureSocialMedia = false;
        }, 4000);
      }
    }
  }

  deleteCustomValue(index, value: string) {
    if (value === 'msds') {
      if (this.eventForm.value.custom_points_msds.length > 1) {
        this.customValueMsds.removeAt(index);
      } else {
        this.customValueMsds.removeAt(0);
        this.customValueMsds.push(this.formGroup.group({ value: '' }));
      }
    } else if (value === 'social_media') {
      if (this.eventForm.value.custom_points_social_media.length > 1) {
        this.customValueSocialMedia.removeAt(index);
      } else {
        this.customValueSocialMedia.removeAt(0);
        this.customValueSocialMedia.push(this.formGroup.group({ value: '' }));
      }
    }
  }
  formatCustomAttributesMsds(customAttr) {
    const formatted_attr = [];
    customAttr.custom_points_msds.forEach(element => {
      formatted_attr.push(element.value);
    });
    return formatted_attr;
  }
  formatCustomAttributesSocialMedia(customAttr) {
    const formatted_attr = [];
    customAttr.custom_points_social_media.forEach(element => {
      formatted_attr.push(element.value);
    });
    return formatted_attr;
  }
  upload(data) {
    this.dropzone.options.parallelUploads = 5;
    this.dropzone.eventName = data.eventName;
    this.dropzone.options.url = ConfigService.config.eventServiceUrl + this.appglobals.attachFilesEndpoint + data.entityId;
    this.dropzone.processQueue();
  }
  onClose() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }

}
