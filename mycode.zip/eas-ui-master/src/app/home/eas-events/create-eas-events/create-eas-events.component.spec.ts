import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import * as $ from 'jquery';
import { CreateEasEventsComponent } from './create-eas-events.component';
import { NotifierModule } from 'angular-notifier';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { GeoAddressComponent } from '../../geo-address/geo-address.component';
import { MapsAPILoader } from '@agm/core';
import { UserService } from '../../../login/services/user.service';
import { GeoAddressService } from '../../geo-address/geo-address.service';
import { SharedService } from '../../../shared/shared.service';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';

describe('CreateEasEventsComponent', () => {
  let component: CreateEasEventsComponent;
  let fixture: ComponentFixture<CreateEasEventsComponent>;
  let geoAddressComponent: GeoAddressComponent;
  let geoAddressComponentfixture: ComponentFixture<GeoAddressComponent>;
  let jqdiv;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CreateEasEventsComponent, GeoAddressComponent],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule,
        OwlDateTimeModule,
        OwlNativeDateTimeModule
      ],
      providers: [{ provide: MapsAPILoader }, UserService, GeoAddressService, SharedService, EasLeftSidebarService],

    })
      .compileComponents();
    fixture = TestBed.createComponent(CreateEasEventsComponent);
    component = fixture.componentInstance;
    geoAddressComponentfixture = TestBed.createComponent(GeoAddressComponent);
    geoAddressComponent = geoAddressComponentfixture.componentInstance;
    const div = document.createElement('div');
    const divDropzone = document.createElement('div');
    div.setAttribute('id', 'my_dropzone');
    divDropzone.setAttribute('id', 'dropzone-drop-area');
    divDropzone.classList.add("dropzone-drop-area");
    div.appendChild(divDropzone);
    document.body.appendChild(div);
    jqdiv = $(div);

  }));

  beforeEach(() => {
    fixture.detectChanges();
  });
  afterEach(()=>{
    jqdiv.remove();
  })
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should validate create form', () => {
    component.eventForm.controls["eventName"].setValue("karma Event");
    component.eventForm.controls["eventDesc"].setValue("karma Event Description");
    component.eventForm.controls["eventType"].setValue("ACCIDENT");
    console.log(component.eventForm);
    expect(component.eventForm.valid).toBeTruthy();
  });

  it(`True if lat,long , address value is fetched from geoAddress component and name is fetched
  from createEventForm`, (done) => { // should get the value from the geocomponent
      component.eventForm.controls["eventName"].setValue("karma Event");
      component.eventForm.controls["eventDesc"].setValue("karma Event Description");
      component.eventForm.controls["eventType"].setValue("ACCIDENT");
      geoAddressComponent.geoAddressForm.controls['latitude'].setValue('42.345264');
      geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-71.096381');
      geoAddressComponent.geoAddressForm.controls['address'].setValue('1265 Boylston St, Boston, MA 02215, USA');

      geoAddressComponent.setAddress();
      setTimeout(() => {
        expect(component.eventForm.valid).toBeTruthy();
        expect(geoAddressComponent.geoAddressForm.valid).toBeTruthy();
        done();
      }, 1000);

    });
  it(`True if lat,long , address value is fetched from geoAddress component and name is fetched
    from createEventForm for predefined event`, (done) => { // should get the value from the geocomponent
      component.eventForm.controls["eventName"].setValue("karma Event");
      component.eventForm.controls["eventDesc"].setValue("karma Event Description");
      component.eventForm.controls["eventType"].setValue("ACCIDENT");
      geoAddressComponent.geoAddressForm.controls['latitude'].setValue('42.345264');
      geoAddressComponent.geoAddressForm.controls['longitude'].setValue('-71.096381');
      geoAddressComponent.geoAddressForm.controls['address'].setValue('1265 Boylston St, Boston, MA 02215, USA');
      component.eventForm.controls["type"].setValue("Predefined Event");
      geoAddressComponent.setAddress();
      setTimeout(() => {
        expect(component.eventForm.valid).toBeTruthy();
        expect(geoAddressComponent.geoAddressForm.valid).toBeTruthy();
        done();
      }, 1000);

    });
  it('should check for incorrect event name', () => {
     component.eventForm.controls["eventDesc"].setValue("karma Event Description");
    component.eventForm.controls["eventType"].setValue("ACCIDENT");
    expect(component.eventForm.valid).toBeFalsy();
  });
  it('should check for incorrect event Type', () => {
    component.eventForm.controls["eventName"].setValue("karma Event");
    component.eventForm.controls["eventDesc"].setValue("karma Event Description");
    expect(component.eventForm.valid).toBeFalsy();
  });
  it('should validate create form for predefined event', () => {
    component.eventForm.controls["eventName"].setValue("karma Event");
    component.eventForm.controls["eventDesc"].setValue("karma Event Description");
    component.eventForm.controls["eventType"].setValue("ACCIDENT");
    component.eventForm.controls["type"].setValue("Predefined Event");
    expect(component.eventForm.valid).toBeTruthy();
  });

  it('should check for incorrect event name for predefined event', () => {
    component.eventForm.controls["eventDesc"].setValue("karma Event Description");
    component.eventForm.controls["eventType"].setValue("ACCIDENT");
    component.eventForm.controls["type"].setValue("Predefined Event");
    expect(component.eventForm.valid).toBeFalsy();
  });
  it('should check for incorrect event Type for predefined event', () => {
     component.eventForm.controls["eventName"].setValue("karma Event");
    component.eventForm.controls["eventDesc"].setValue("karma Event Description");
      expect(component.eventForm.valid).toBeFalsy();
  });

  it('True if the closeaction() method is called and perform its action', (done) => {

    //checks the getlistview method is called;
    component.crudViewTypeEmitter.emit('list');
    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('list'); //checks the value emitted is list
      done();
    })
    component.closeAction(null);

  });

  it('False if the closeaction() method is not called and not perform its action', (done) => {

    //checks the getlistview method is called;
    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('list'); //checks the value emitted is list
      done();
    })
    component.closeAction(null);
  });



});
