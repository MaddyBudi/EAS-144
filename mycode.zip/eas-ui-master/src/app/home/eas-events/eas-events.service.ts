import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ConfigService } from "../../core/config/config-svc.service";
import { AppGlobals } from '../../shared/app.globals';
import { EasAnnotationsService } from '../eas-annotations/eas-annotations.service';
import { NavigationService } from '../navigation/navigation.service';
import { ContextBarService } from '../context-bar/context-bar.service';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs';
import { AssignEasResourcesService } from '../eas-resources/assign-eas-resources/assign-eas-resources.service';
import { EventTo } from '../../shared/models/eventTo';
import { ResourceTo } from '../../shared/models/resourceTo';
import { EasResourcesService } from '../eas-resources/eas-resources.service';
@Injectable({
  providedIn: 'root'
})
export class EasEventsService {
  selectedEventId: any;
  selectedEvent:any;
  successMessage: string;
  failureMessage: string;
  displaySuccess = false;
  displayFailure = false;
  selectedevent_payload: any;
  resourcesData = [];
  closeMoreInformation = new Subject<string>();
  closeMoreInformation$ = this.closeMoreInformation.asObservable();
  assignResourceToAddress = new Subject<any>();
  assignResourceToAddress$ = this.assignResourceToAddress.asObservable();
  
   notes ={
        "comment":''
      }

      payload = {
        "dataModel": this.appglobals.eventDataModel,
        "eventName": '',
        "address": '',
        "properties": {
          "eventDate": '',
          "stroke": '',
          "stroke-width": 0,
          "stroke-opacity": 1,
          "fill": '',
          "fill-opacity": 0.35,
          "msdsKeywords": '',
          "socialMediaKeywords": '',
        },
        "eventType": '',
        "priority": '',
        "status": "STARTED",
        "eventDesc": '',
        "owner": "EAS-USER",
        "type":'',
        "createdBy":""
  
      };
      
  constructor(private http: HttpClient, private appglobals:  AppGlobals, private assignResourceService: AssignEasResourcesService,
    private annotationService: EasAnnotationsService,private contextBarService:ContextBarService,
    private navigationService: NavigationService, private easResourcesService: EasResourcesService) { }
  getHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All'
      }),
      withCredentials: true
    };
    return httpOptions;
  }
  setEventId(eventId) {
    this.selectedEventId = eventId;
  }
  getEventId() {
    return this.selectedEventId;
  }
  setEvent(event) {
    this.selectedEvent = event;
  }
  getEvent() {
    return this.selectedEvent;
  }
  getSelectedEventPayload() {
    return this.selectedevent_payload;
  }
  setSelectedEventPayload(selectedevent_payload) {
    this.selectedevent_payload = selectedevent_payload;
  }
  setSuccessMessage(message) {
    this.successMessage = message;
  }
  getSuccessMessage() {
    return this.successMessage;
  }
  setFailureMessage(message) {
    this.failureMessage = message;
  }
  getFailureMessage() {
    return this.failureMessage;
  }
  // sends event details to create endpoint and creates an event
  public createEvent(payload) {
   
    payload.geometry=JSON.stringify(payload.geometry)
    return this.http.post(ConfigService.config.eventServiceUrl + '/create', payload, this.getHeaders()).pipe(map((res: any) => res));
  }
  
  public setNotes(eventNotes) {
    return this.http.put(ConfigService.config.eventServiceUrl + '/appendEventNotes?ENTITY_ID=' + eventNotes.entityId,
    eventNotes, this.getHeaders()).pipe(map((res: any) => res));
  }
  // gets all events from DB
  public getAllEvents():Observable<EventTo[]>{
    return this.http.get<EventTo[]>(ConfigService.config.eventServiceUrl + '/getAllEvents', 
      this.getHeaders()).pipe(map(( event => this.convertListToListObject(event))));
  }
  // closes an event by passing its ID
  public closeEvent(event) {
    const geo = {
      "type": event.shapeType,
      "coordinates": event.coordinates,
    };
    const payload = {
      "dataModel": this.appglobals.eventDataModel,
      "eventName": event.eventName,
      "status": "Closed",
      "creator": event.creator,
      "organizationName": event.organizationName,
      "entityId": event.entityID,
      "address": event.eventFullAddress ? event.eventFullAddress : event.eventAddress,
      "eventDesc": event.eventDesc,
      "priority": event.eventPriority,
      "properties": {
        "eventDate": event.eventDate,
        "stroke": event.fillColor,
        "stroke-width": 0,
        "stroke-opacity": 1,
        "fill": event.fillColor,
        "fill-opacity": 0.35
      },
      "geometry": JSON.stringify(geo)
    };

    return this.http.put(ConfigService.config.eventServiceUrl + '/update', payload, this.getHeaders()).pipe(map((res: any) => res));
  }
  // gets an event by its ID
  public getEventDetails(eventId):Observable<EventTo>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'transactionId': 'sample',
        'reportType': 'All'
      })
      , withCredentials: true
    };
    return this.http.get<EventTo>(ConfigService.config.eventServiceUrl + '/getEvent?ENTITY_ID=' + eventId, httpOptions)
    .pipe(map(( event => this.convertResponseToObject(event))));
  }

  // updates an event by passing updated data
  public updateEvent( eventData:EventTo) {

    eventData.geometry = JSON.stringify(eventData.geometry);
    // eventData.location = { "x": formData.eventLongitude, "y": formData.eventLatitude };
    return this.http.put(ConfigService.config.eventServiceUrl + '/update', eventData, this.getHeaders()).pipe(map((res: any) => res));
  }
  public updateEventLocation(eventData) {
    
    return this.http.put(ConfigService.config.eventServiceUrl + '/update', eventData, this.getHeaders()).pipe(map((res: any) => res));
  }
  
  public updateEventWithMSDSandSocialMediaKeywords(eventData, msdsKeywords, socialMediaKeywords) {
    eventData.properties.msdsKeywords = msdsKeywords;
    eventData.geometry = JSON.stringify(eventData.geometry);
    // eventData.properties.socialMediaKeywords=socialMediaKeywords;
    return this.http.put(ConfigService.config.eventServiceUrl + '/update', eventData, this.getHeaders()).pipe(map((res: any) => res));
  }
  public absorbEvent(payload) {
    return this.http.put(ConfigService.config.eventServiceUrl
      + '/absorbEvent?ABSORBEREVENTID=' + payload.absorber + '&ABSORBEEVENTID='
      + payload.absorbee, {}, this.getHeaders()).pipe(map((res: any) => res));
  }

  public updateEventFromChat(id, eventNotes) {
    console.log("notes" + eventNotes);
    const payload = {
      "comment": eventNotes[0].comment
    };
    console.log(payload);
    return this.http.put(ConfigService.config.eventServiceUrl + '/appendEventNotes?ENTITY_ID=' + id,
      payload, this.getHeaders()).pipe(map((res: any) => res));
  }

  public updateEventLocation1(eventData, coordinates, newAddress, color) {
    const geometry = {
      "type": (coordinates[0].length > 2) ? "Polygon" : "Point",
      "coordinates": coordinates
    };
    const payload = {
      "entityId": eventData.payload.entityId,
      "dataModel": "EVENT",
      "creator": eventData.payload.properties.creator,
      "eventName": eventData.payload.properties.eventName,
      "organizationName": eventData.payload.properties.organizationName,
      "address": {
        "streetAddress1": newAddress.streetAddress1,
        "streetAddress2": newAddress.streetAddress2,
        "city": newAddress.city,
        "zip": newAddress.zip,
        "state": newAddress.state,
        "county": newAddress.county,
      },
      "eventNotes": eventData.payload.properties.eventNotes,
      "eventDesc": eventData.payload.properties.eventDesc,
      "closedOn": eventData.payload.properties.closedOn,
      "assignedResources": eventData.payload.properties.assignedResources,
      "assignedAnnotations": eventData.payload.properties.assignedAnnotations,
      "contributors": eventData.payload.properties.contributors,
      "absorbes": eventData.payload.properties.absorbes,
      "absorber": eventData.payload.properties.absorber,
      "geometry": JSON.stringify(geometry),
      "properties": {
        "stroke": color,
        "stroke-width": 0,
        "stroke-opacity": 1,
        "fill": color,
        "fill-opacity": 0.35
      },
      "attributes": {
        "eventDate": eventData.payload.properties.eventDate
      },
      "status": eventData.payload.status,
      "memberOf": eventData.payload.properties.memberOf,
      "priority": eventData.payload.properties.priority
    }; return this.http.put(ConfigService.config.eventServiceUrl + '/update', payload, this.getHeaders()).pipe(map((res: any) => res));
  }

  getAllResources() {
    this.easResourcesService.getAllResources().subscribe(response => {
      this.resourcesData = response;
      console.log(this.resourcesData);
    }, error => {
      console.log('Error occured' + error);
    });
  }

  getResourceInfoToRelease(assignedResources , entityId) {
   this.easResourcesService.getAllResources().subscribe(response => {
      this.resourcesData = response;
      console.log(this.resourcesData);
      const releasedResourcesInfo = [];
    assignedResources.forEach(eachResourceId => {
      const index = this.resourcesData.findIndex(eachResource => eachResource.entityId === eachResourceId);
      if (~index) {
        const data = this.resourcesData[index];
        const resourceTo = new ResourceTo("");
      resourceTo.entityId = data.entityId;
      resourceTo.dispatchAddress = data.dispatchAddress;
        releasedResourcesInfo.push(resourceTo);
      }
    });
    this.releaseEventResources(releasedResourcesInfo, entityId);
    }, error => {
      console.log('Error occured' + error);
    });    
  }
  
  releaseEventResourcesAnnotations(event:EventTo) {
    console.log(event);
    if (event.assignedResources) {
      this.getResourceInfoToRelease(event.assignedResources, event.entityId);
    }
    if (event.assignedAnnotations) {
      this.releaseEventAnnotations(event.assignedAnnotations, event.entityId);
    }
  }
  releaseEventResources(eventResources, eventId) {
    this.assignResourceService.releaseResource(eventResources, eventId).subscribe(
      response => {
        console.log("Event resources are released successfully");
      },
      error => {
        console.log("error occurred in release resource");
      });
  }
  
  releaseEventAnnotations(eventAnnotations, eventId) {
    this.annotationService.releaseAnnotations(eventAnnotations, eventId).subscribe(Response => {
      console.log("Event annotations are released successfully");
    },
      error => {
        console.log("error occurred in release annotation");
      });
  }


  getNotifications() {
    return this.http.get(ConfigService.config.eventServiceUrl + '/getAllNotification', this.getHeaders()).pipe(map((res: any) => res));

  }

  clearContext(eventId) {
    // this.contextBarService.clearContext(eventId);
  }


  public getTwitterFeeds(socialMediaKeyword, point, eventId) {
    const payload = {
      "searchKeyword": socialMediaKeyword,
      "point": point,
      "eventId": eventId
    };
    return this.http.post(ConfigService.config.eventServiceUrl + '/searchTweets', payload, this.getHeaders()).pipe(map((res: any) => res));
  }

  public getFacebookFeeds(socialMediaKeyword, point, eventId) {
    const payload = {
      "searchKeyword": socialMediaKeyword,
      "point": point,
      "eventId": eventId
    };
    return this.http.post(ConfigService.config.eventServiceUrl + '/searchFBPosts', payload, this.getHeaders()).pipe(map((res: any) => res));
  }

  /**
   * deleteEvent
   */
  public deleteEvent(entityID) {
    return this.http.delete(ConfigService.config.eventServiceUrl + '/deleteEvent?ENTITY_ID=' +
    entityID, this.getHeaders()).pipe(map((res: any) => res));
  }

  /**
   * ConvertToevent
   */
  public ConvertToevent(object:EventTo) {
    return this.http.put(ConfigService.config.eventServiceUrl + '/convert', object, this.getHeaders()).pipe(map((res: any) => res));

  }

  closeMoreInfo(){
    this.closeMoreInformation.next();
  }
  assignAddress(data){
    this.assignResourceToAddress.next(data);
  }

  convertListToListObject(object:any){ 
    let eventTo=[];
    object.forEach(element => {
  
      const event=new EventTo(element);
      eventTo.push(event);
      
    });
    return eventTo;
   }
   convertResponseToObject(object){
    const event=new EventTo(object);
    return event;
  
   }
   getconfigServiceUrl(){
    return  ConfigService.config.eventServiceUrl
  }

}
