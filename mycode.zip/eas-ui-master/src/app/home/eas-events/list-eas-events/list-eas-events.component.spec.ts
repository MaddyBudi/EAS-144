import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ListEasEventsComponent } from './list-eas-events.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfigService } from '../../../core/config/config-svc.service';
import { NotifierModule } from 'angular-notifier';
import { APP_INITIALIZER } from '@angular/core';
import { EasEventsService } from '../eas-events.service';
import {ResourceMockService } from '../../eas-resources/eas-mock-resources.service';
import { EasResourcesService} from '../../eas-resources/eas-resources.service';
import {  MockEasEventsService } from '../eas-mock-events.service';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { SharedPipe } from '../../shared.pipe';
import {By} from '@angular/platform-browser';
import { DataTableModule } from 'angular-6-datatable';
import { EasEventMoreInformationComponent } from '../../../home/eas-event-more-information/eas-event-more-information.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { doesNotThrow } from 'assert';
import { SharedService } from 'src/app/shared/shared.service';


// export function initializeApp(configService: ConfigService) {
//   return () => configService.getConfig();
// }

describe('ListEasEventsComponent', () => {
  let component: ListEasEventsComponent;
  let fixture: ComponentFixture<ListEasEventsComponent>;
  let leftsideservice : EasLeftSidebarService
  // let predefinput: HTMLElement;
  // let eventinput: HTMLElement;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListEasEventsComponent,
        SharedPipe,
        EasEventMoreInformationComponent
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        RouterTestingModule,
        NotifierModule,
        DataTableModule
      ],
      providers: [
        ConfigService,
        SharedService,
        EasLeftSidebarService,
        // { provide: APP_INITIALIZER, useFactory: initializeApp, deps: [ConfigService], multi: true },
        { provide: EasEventsService, useClass: MockEasEventsService },
        { provide: EasResourcesService, useClass: ResourceMockService }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListEasEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get all events and count should not be zero', (done) => {
    component.getEvents()
     setTimeout(function () {
      expect(component.eventAll.length).not.toBe(0);
      done();
    }, 1000);
  });


  it('True if the createEvent() method is called and perform its action', () => {
  
    //checks the getlistview method is called;
    component.crudViewTypeEmitter.emit('create');
    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('create'); //checks the value emitted is list
    })
    component.createEvent(null)

  });

  it('True if the editEvent() method is called and perform its action', (done) => {

    //checks the getlistview method is called;
    component.crudViewTypeEmitter.emit('update');
    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('update'); //checks the value emitted is list
     
    })
      component.getEvents()
      setTimeout(() => {
        component.editEvent(component.eventAll[0]);
        done();
      }, 1000);
  });

  it('True if the assignReleaseResourceGroup() method is called and perform its action', (done) => {
  
    //checks the getlistview method is called;
    component.crudViewTypeEmitter.emit('assignReleaseResourceGroup');
    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('assignReleaseResourceGroup'); //checks the value emitted is list
    })
    component.getEvents()
    setTimeout(() => {
      component.assignReleaseResourceGroup(component.eventAll[0]);
      component.setEventDataForAssignRelease(component.eventAll[0]);
      done();
    }, 1000);

  });

  
  it('True if the attachFiles() method is called and perform its action', (done) => {
  
    //checks the getlistview method is called;
    component.crudViewTypeEmitter.emit('attach');
    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('attach'); //checks the value emitted is list
    })
    setTimeout(() => {
    component.attachFiles(component.eventAll[0])
    done();
    },1000);

  });

  it('True if the assignResource() method is called and perform its action', (done) => {
  
    //checks the getlistview method is called;
    component.crudViewTypeEmitter.emit('assignResources');
    component.crudViewTypeEmitter.subscribe(g => {
      expect(g).toEqual('assignResources'); //checks the value emitted is list
    })
    setTimeout(() => {
    component.assignResource(component.eventAll[0])
    done();
      },1000);
  });
    
  it('True if the toggleVisibility() method is called and perform its action', (done) => {
   
    setTimeout(() => {
    component.toggleVisibility(true,(component.eventAll[0]));
    expect(component.selectedEvents.length).not.toBe(0);
    done();
  },1000);
  setTimeout(() => {
    component.toggleVisibility(false,(component.eventAll[0]));
    expect(component.selectedEvents.length).toBe(0);
    done();
  },1000);
 
  });

  it('True if the plotSelectedEvents() method is called with no Selected Events and perform its action', () => {
    component.plotSelectedEvents();
    expect(component.selectedEvents.length).toBe(0);
  });

  it('True if the plotSelectedEvents() method is called with one selected events and perform its action', (done) => {
    component.getEvents()
    setTimeout(() => {
    component.toggleVisibility(true,(component.eventAll[0]));
    component.toggleVisibility(true,(component.eventAll[1]));
    component.plotSelectedEvents();
    expect(component.selectedEvents.length).not.toBe(0);
    done();
  },1000);
  });

  it('True if the onCompress() method is called and perform its action', () => {
  
   
    component.easleftSideBarService.easleftSidebarToggle$.subscribe(g => {
      expect(g).toEqual('25%'); //checks the value emitted is list
    })
    component.easleftSideBarService.changeEntitiesListType$.subscribe(g => {
      expect(g).toEqual('Entities Mini View'); //checks the value emitted is list
    })
    component.onCompress()

  });

  it('True if the onOpenInfo() method is called and perform its action', (done) => {
    component.getEvents()
    setTimeout(() => {
      component.onOpenInfo(component.eventAll[0])
      component.easleftSideBarService.easleftSidebarToggle$.subscribe(g => {
      expect(g).toEqual('75%'); //checks the value emitted is list
    })
    done();
  },1000);
    

  });

  it('True if the onClose() method is called and perform its action', () => {
  
   
    component.easleftSideBarService.easleftSidebarToggle$.subscribe(g => {
      expect(g).toEqual('0%'); //checks the value emitted is list
    })
    component.onClose()

  });

  it('True if the addPredefinedEvents() method is called and perform its action', (done) => {
    component.getEvents()
    setTimeout(() => {
      component.addPredefinedEvents(true)
      expect(component.eventData.length).not.toBe(0);
      done();
    },1000
    )
  });

  it('True if the addEvents() method is called and perform its action', (done) => {
    component.getEvents()
    setTimeout(() => {
      component.addEvents(false)
      expect(component.eventData.length).toBe(0);
      done();
    },1000
    )
  });

  it('True if the onViewChange() method is called and perform its action', (done) => {
    component.getEvents()
    setTimeout(() => {
      component.onViewChange(component.eventData[0])
      done();
    },1000
    )
  });

  // it('True if the viewPersonSearchComponent() method is called and perform its action', (done) => {
  //   component.getEvents()
  //   setTimeout(() => {
  //     component.viewPersonSearchComponent(component.eventData[0].address)
  //     component.mapConsoleService.rightSidePanel$.subscribe(data => {
  //       expect(data).toEqual('PowerData Search');  
  //     })
  //     done();
  //   },1000
  //   )
  // });

  // it('True if the addEvents() method is called and perform its action', (done) => {
  //   component.getEvents()
  //   let createPasteButton = fixture.debugElement.query(By.css("#predefinedEventCheckbox"));
  //   createPasteButton.triggerEventHandler("click",null);
  //   fixture.detectChanges();
  //   setTimeout(() => {
  //     component.addEvents(false)
  //     done();
  //   },1000
  //   )
  // });



});
