import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EasEventsService } from '../eas-events.service';
import { SharedService } from '../../../shared/shared.service';
import { environment } from '../../../../environments/environment';
import { AppGlobals } from '../../../shared/app.globals';
import { HomeService } from '../../home.service';
import * as _ from 'lodash';
import * as $ from 'jquery';
import { PersonService } from '../../map-console/person/person.service';
import { ConfigService } from "../../../core/config/config-svc.service";
import { debugOutputAstAsTypeScript } from '@angular/compiler';
import { EasLeftSidebarService } from '../../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { TransactionMeasures } from '../../../transactionMeasures';
import { PanelHeaders } from '../../../panelHeaders';
import { MapConsoleService } from '../../map-console/map-console.service';
import { NotifierService } from 'angular-notifier';
import { EventTo } from '../../../shared/models/eventTo';
import { element } from '@angular/core/src/render3';
import { EasResourcesService } from '../../eas-resources/eas-resources.service';
import { EasAnnotationsService } from '../../eas-annotations/eas-annotations.service';
import { AssignEasResourcesService } from '../../eas-resources/assign-eas-resources/assign-eas-resources.service';

declare let google: any;
let controller;
const Dropzone = require('../../../../../node_modules/dropzone/dist/dropzone-amd-module');
const swal = require('sweetalert');
@Component({
  selector: 'app-list-eas-events',
  templateUrl: './list-eas-events.component.html',
  styleUrls: ['./list-eas-events.component.scss']
})

export class ListEasEventsComponent implements OnInit {
  @Input() contextEventId;
  @Output() crudViewTypeEmitter = new EventEmitter();

  public eventAll = [];
  public eventData = [];
  public predefinedEventData = [];
  public eventSourceData = [];
  coords = [];
  public latLngAddressMap = {};
  displayListView = false;
  rowsPerPageList: Number[] = this.appglobals.RowsPerPageList;
  defaultRowsPerPage: Number = this.appglobals.DefaultRowsPerPage;
  selectedAllEvents = false;
  markedAll = false;
  actionHeader: String;
  openEventData = [];
  selectedEvents = [];
  selectedId = [];
  sortBy = "createdDate";
  sortOrder = "desc";
  marked = false;
  isModule = false;
  isGlobalCheckboxEnable;
  fromModule = true;
  dropzone;
  eventResources = [];
  isRsrcAssignment = false;
  selectedevent_payload: any;
  toggleEvent: boolean = true;
  personAddress: any;
  selectedEntityId: string;
  isMoreInfo: boolean;
  isLoading = true;
  resourcesData = [];
  releasedResourcesInfo = [];
  constructor(public http: HttpClient, public eventSvc: EasEventsService,
    public sharedService: SharedService, private appglobals: AppGlobals, public homeSvc: HomeService,
    private personService: PersonService, public easleftSideBarService: EasLeftSidebarService,
    public mapConsoleService: MapConsoleService, private notifierService: NotifierService,
    private easResourcesService: EasResourcesService, private assignEasResourcesService: AssignEasResourcesService,
    private easAnnotationsService: EasAnnotationsService) {
  }

  ngOnInit() {
    // this.eventSvc.displaySuccess=false;
    // this.eventSvc.displayFailure=false;
    controller = this;
    this.getEvents();
    this.eventSvc.closeMoreInformation$.subscribe(
      data => {
        this.isMoreInfo = false;
        this.selectedEntityId = undefined;
      }
    );
  }

  ngOnChanges(changes) {
    if (changes.hasOwnProperty("contextEventId"))
      this.contextEventId = changes.contextEventId.currentValue;
  }

  getEvents() {
    this.eventSvc.getAllEvents().subscribe(
      data => {
        this.eventAll = [];
        this.eventSourceData = [];
        this.predefinedEventData = [];
        this.isLoading = false;
        this.eventSvc.displayFailure = false
        this.sortEvents(data);
        this.eventAll.forEach(
          data => {
            if (data.type === 'Event') {
              this.eventSourceData.push(data);
            } else {
              this.predefinedEventData.push(data);
            }
          }
        );
        this.displayListView = true;
        if ($('#predefinedEventCheckbox').is(':checked')) {
          this.addPredefinedEvents(true);
        } else {
          this.addPredefinedEvents(false);
        }
        if (this.toggleEvent || $('#eventCheckbox').is(':checked')) {
          this.toggleEvent = false;
          this.addEvents(true);
        } else {
          this.addEvents(false);
        }
      },
      error => {
        if (error.status === 401) {
          this.sharedService.routeToLoginError(error.status);
        } else {
          this.eventSvc.displayFailure = true;
          this.displayListView = false;
          this.eventSvc.failureMessage = "Unable to get events. Please try again later.";
        }
      }
    );
  }

  sortEvents(data){

    data.forEach(element => {
        if (element.status === "STARTED" && element.deleted === false) {
            this.eventAll.push(element);
        }
    }
    );

    this.eventAll.sort((a,b)=>{
        if (a.createdDate > b.createdDate) { return -1; }
        if (a.createdDate < b.createdDate) { return 1; }
    });
    var tempEventArray = [];

    data.forEach(element => {
        if (element.status === "TERMINATED" && element.deleted === false) {
            tempEventArray.push(element);
        }
    }
    );

    tempEventArray.sort((a,b)=>{
        if (a.createdDate > b.createdDate) { return -1; }
        if (a.createdDate < b.createdDate) { return 1; }
    });

    tempEventArray.forEach(element=>{
        this.eventAll.push(element);
    });

    tempEventArray=[]

    data.forEach(element => {
        if (element.status === "STARTED" && element.deleted === true) {
            tempEventArray.push(element);
        }
    }
    );

    tempEventArray.sort((a,b)=>{
        if (a.createdDate > b.createdDate) { return -1; }
        if (a.createdDate < b.createdDate) { return 1; }
    });

    tempEventArray.forEach(element=>{
        this.eventAll.push(element);
    });

    tempEventArray=[]

    data.forEach(element => {
        if (element.status === "TERMINATED" && element.deleted === true) {
            tempEventArray.push(element);
        }
    }
    );
    tempEventArray.sort((a,b)=>{
        if (a.createdDate > b.createdDate) { return -1; }
        if (a.createdDate < b.createdDate) { return 1; }
    });

    tempEventArray.forEach(element=>{
        this.eventAll.push(element);
    });

}

  addPredefinedEvents(event) {
    this.eventData = [];
    if (event) {

      if ($('#eventCheckbox').is(':checked')) {
        this.eventData = this.eventSourceData.slice();
        this.predefinedEventData.forEach(
          data => {
            this.eventData.push(data);
          }
        );
      } else {
        this.eventData = this.predefinedEventData.slice();
      }


    } else {

      if ($('#eventCheckbox').is(':checked')) {
        this.eventData = this.eventSourceData.slice();
      } else {
        this.eventData = [];
      }
    }
  }

  addEvents(event) {
    
    this.eventData = [];
    if (event) {
      if ($('#predefinedEventCheckbox').is(':checked')) {
        this.eventData = this.eventSourceData.slice();
        this.predefinedEventData.forEach(
          data => {
            this.eventData.push(data);
          }
        );
      } else {

        this.eventData = this.eventSourceData.slice();

      }

    } else {
      
      if ($('#predefinedEventCheckbox').is(':checked')) {
        this.predefinedEventData.forEach(
          data => {
            this.eventData.push(data);
          }
        );
      } else {
        this.eventData = [];
      }
    }
  }





  onViewChange(data) {
    if (typeof data.geometry !== "object")
      data.geometry = JSON.parse(data.geometry);
    data.properties['eventName'] = data.eventName;
   const entityData = this.sharedService.formPayloadForEntitiesMoreInfo([data], false, true);
    this.mapConsoleService.viewMapEntitiesMap(entityData);
  }
  createEvent(event) {
    this.eventSvc.displaySuccess = false;
    this.eventSvc.displayFailure = false;
    this.crudViewTypeEmitter.emit('create');
  }

  editEvent(event) {
    this.eventSvc.displaySuccess = false;
    this.eventSvc.displayFailure = false;
    this.crudViewTypeEmitter.emit('update');
    this.eventSvc.setEventId(event.entityId);
  }
  convertToEvent(item) {
    this.sharedService.showYesNoAlert("Convert Event: " + item.eventName, 'Convert', swalCallback, 'No, cancel');
    let that = this;
    function swalCallback(result) {
      if (result) {
        that.eventSvc.getEventDetails(item.entityId).subscribe(
          data => {    
            if (data.entityId !== null) {
              data.type = "Event"
              console.log(data.geometry);
              const json = JSON.stringify(data.geometry);
              data.geometry = json;
              that.eventSvc.ConvertToevent(data).subscribe(
                data => {
                  if (data.entityId !== null) {
                    that.getEvents();
                    that.eventSvc.displaySuccess = true;
                    that.notifierService.notify('success', ' Predefined Event "' + data.eventName + '" Converted to Event successfully.')
                  }
                  else {
                    that.notifierService.notify("error", "Error occured .Unable to convert to event now.")
                  }
                },
                error => {
                  if (error.status === 401) {
                    that.sharedService.routeToLoginError(error.status);
                  } else {

                    swal('Not Converted!', "Please try again", 'Failure');
                  }
                }
              );
            }
          },
          error => {
            if (error.status === 401) {
              that.sharedService.routeToLoginError(error.status);
            } else {
              swal('Not Converted!', "Please try again", 'Failure');
            }
          }
        );
      }
    }
  }

  closeEvent(event: EventTo) {
    let that = this;
    this.sharedService.showYesNoAlert("Delete the Event  " + event.eventName, 'Delete', swalCallback, 'No, cancel')
    function swalCallback(yesNo) {
      if (yesNo) {
        that.eventSvc.deleteEvent(event.entityId).subscribe(
          data => {
            if (data) {
              if (event.entityId === that.contextEventId) {
                that.mapConsoleService.setEventContext(null);
              }
              that.eventSvc.releaseEventResourcesAnnotations(event);
              that.getEvents();
              that.eventSvc.clearContext(event.entityId);
              that.notifierService.notify("success", '"' + event.type + '"  "' + event.eventName + '" deleted successfully.')
            } else {
              that.notifierService.notify("error", "Error occured .Unable to close an event now.")
              swal('Not Removed!', data.status, 'Failure');
            }
          },
          error => {
            swal('Not Removed!', "Please try again", 'Failure');
          }
        );
      }
    }
  }

  // getViewCoordinates(item) {
  //   const tempCoordinates = [];
  //   const viewCoordinates = [];
  //   tempCoordinates.push(item.coordinates);
  //   viewCoordinates.push(tempCoordinates);
  //   return viewCoordinates;
  // }
  attachFiles(item) {
    this.eventSvc.displaySuccess = false;
    this.eventSvc.displayFailure = false;
    this.crudViewTypeEmitter.emit('attach');
    this.eventSvc.setEventId(item.entityID);
    this.eventSvc.setEvent(item);
  }

  viewPersonSearchComponent(address) {
    this.mapConsoleService.openRightSidePanel(PanelHeaders.powerDataSearch);
    this.personService.getPersonDetails(address);
  }



  assignResource(item) {
    this.isRsrcAssignment = true;
    this.crudViewTypeEmitter.emit('assignResources');
    this.setEventDataForAssignRelease(item);
  }

  toggleVisibility(isChecked, item: EventTo) {
    if (isChecked) {
      // item = JSON.parse(JSON.stringify(item))
      if (typeof item.geometry !== "object")
      item.geometry = JSON.parse(item.geometry);

      if(item.geometry['type'] === 'Point')
      item.geometry['coordinates']=[[item.geometry['coordinates']]];
      
      this.selectedEvents.push(item);
    }
    else {
      var index = this.selectedEvents.findIndex(x => x.entityId == item.entityId);
      if (~index) {
        this.selectedEvents.splice(index, 1);
      }
    }
  }

  plotSelectedEvents() {
    if (this.selectedEvents.length === 0) {
      this.notifierService.notify('error', 'Please select atleast one event to view');
    } else {
      const entityData = this.sharedService.formPayloadForEntitiesMoreInfo(this.selectedEvents, false, true);
      this.mapConsoleService.viewMapEntitiesMap(entityData);
      this.onClose();
    }
  }
  onCompress() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.miniView);
    this.easleftSideBarService.changeEntitiesListTypes(PanelHeaders.entitiesMiniView);
  }
  onClose() {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.close);
    this.mapConsoleService.closeSideBar();
  }
  onOpenInfo(item) {
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.maxView);
    this.selectedEntityId = item.entityId;
    this.isMoreInfo = true;
  }
  assignReleaseResourceGroup(eventData) {
    this.setEventDataForAssignRelease(eventData);
    this.crudViewTypeEmitter.emit('assignReleaseResourceGroup');
  }
  setEventDataForAssignRelease(eventData) {
    this.selectedevent_payload = {
      "payload": {
        "entityId": eventData.entityId,
        "properties": {
          "eventName": eventData.eventName,
          "eventAddress": eventData.address
        }
      }
    };
    this.eventSvc.setSelectedEventPayload(this.selectedevent_payload);
    this.easleftSideBarService.toggleSidebarToggle(TransactionMeasures.fullView);
  }
  
}
