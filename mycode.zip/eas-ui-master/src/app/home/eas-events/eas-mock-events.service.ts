import { Observable, Subject } from 'rxjs';
import { EventTo } from '../../shared/models/eventTo';
import { ConfigService } from "../../core/config/config-svc.service";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { UnitTestConstants } from '../../common/enums/unit-test-constants-enum';
import { AppGlobals } from '../../shared/app.globals';
@Injectable()
export class MockEasEventsService {
  appglobals = new AppGlobals();
  entityId = '944d3dff-870e-4329-9d7d-c22f6a3ffa8e';
  selectedEventId: any;
  selectedEvent:any;
  selectedevent_payload: any;
  closeMoreInformation = new Subject<string>();
  closeMoreInformation$ = this.closeMoreInformation.asObservable();
    constructor(private http: HttpClient) { }
    public getEventId() {
      return this.entityId;
    }

    payload = {
      "dataModel": this.appglobals.eventDataModel,
      "eventName": '',
      "address": '',
      "properties": {
        "eventDate": '',
        "stroke": '',
        "stroke-width": 0,
        "stroke-opacity": 1,
        "fill": '',
        "fill-opacity": 0.35,
        "msdsKeywords": '',
        "socialMediaKeywords": '',
      },
      "eventType": '',
      "priority": '',
      "status": "STARTED",
      "eventDesc": '',
      "owner": "EAS-USER",
      "type":'',
      "createdBy":""
    };
    
    closeMoreInfo(){
      this.closeMoreInformation.next();
    }
     public getAllEvents(): Observable<EventTo[]> {
    return this.http.get<EventTo[]>(UnitTestConstants.eventPayloadUrl).pipe(map((res) => this.convertEventListToListObject(res)));
  }

  public getTwitterFeeds(socialMediaKeyword, point, eventId) {
    const payload = {
      "searchKeyword": socialMediaKeyword,
      "point": point,
      "eventId": eventId
    };
    return this.http.get(UnitTestConstants.twitterPayloadUrl).pipe(map((res: any) => res));
  }

  public getFacebookFeeds(socialMediaKeyword, point, eventId) {
    const payload = {
      "searchKeyword": socialMediaKeyword,
      "point": point,
      "eventId": eventId
    };
    return this.http.get(UnitTestConstants.facebookPayloadUrl).pipe(map((res: any) => res));
  }
  // gets an event by its ID
  public getEventDetails(eventId):Observable<EventTo>{
    return this.http.get<EventTo>(UnitTestConstants.singleEventPayloadUrl)
    .pipe(map(( event => this.convertResponseToObject(event))));
  }

  getNotifications() {
    return this.http.get(UnitTestConstants.notificationPayloadUrl).pipe(map((res: any) => res));

  }

    convertEventListToListObject(object: any) {
    let eventTo = [];
    object.forEach(element => {

      const event = new EventTo(element);
      eventTo.push(event);

    });
    return eventTo;
  }
  convertResponseToObject(object){
    const event=new EventTo(object);
    return event;
  
   }
   getconfigServiceUrl(){
    return "test"
 }

 setEventId(eventId) {
  this.selectedEventId = eventId;
}

setSelectedEventPayload(selectedevent_payload) {
  this.selectedevent_payload = selectedevent_payload;
}
setEvent(event) {
  this.selectedEvent = event;
}
public ConvertToevent(object:EventTo): Observable<any> {
  return this.getEventDetails(this.entityId)

}
}
