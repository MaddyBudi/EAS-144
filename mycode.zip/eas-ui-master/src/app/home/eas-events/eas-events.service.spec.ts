// import { TestBed } from '@angular/core/testing';

// import { EasEventsService } from './eas-events.service';

// describe('EasEventsService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: EasEventsService = TestBed.get(EasEventsService);
//     expect(service).toBeTruthy();
//   });
// });
