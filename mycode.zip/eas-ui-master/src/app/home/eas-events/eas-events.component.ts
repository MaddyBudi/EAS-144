import { Component, OnInit, Input } from '@angular/core';
import { CrudView } from './crudview';
import { EasEventsService } from './eas-events.service';
@Component({
  selector: 'app-eas-events',
  templateUrl: './eas-events.component.html',
  styleUrls: ['./eas-events.component.scss']
})
export class EasEventsComponent implements OnInit {
  @Input() contextEventId;
  crudview: CrudView = new CrudView();
  constructor(public easEventSvc: EasEventsService) { }

  ngOnInit() {
    this.crudview.viewType = 'list';
    this.easEventSvc.displaySuccess = false;
    this.easEventSvc.displayFailure = false;
  }

  ngOnChanges(changes) {
    if (changes.hasOwnProperty("contextEventId"))
      this.contextEventId = changes.contextEventId.currentValue;
  }

  crudViewTypeCatcher(viewType) {
    console.log(viewType);
    this.crudview.viewType = viewType;
  }
}
