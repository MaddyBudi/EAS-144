import { Component, OnInit, Input } from '@angular/core';
import { EasLeftSidebarService } from '../map-console/eas-left-sidebar/eas-left-sidebar.service';
import { TransactionMeasures } from '../../transactionMeasures';
import { EasEventMoreInformationService } from '../eas-event-more-information/eas-event-more-information.service';
import { EasOtherEntitiesInformationService } from '../eas-other-entities-information/eas-other-entities-information.service';
import * as $ from 'jquery';

let controller;
@Component({
  selector: 'app-camera-widget',
  templateUrl: './camera-widget.component.html',
  styleUrls: ['./camera-widget.component.scss']
})
export class CameraWidgetComponent implements OnInit {
  @Input() cameraObject;
  camerObjects = [];
  isfirst=true;
  isSecond=false; 
  isThird=false;
  isFourth=false; 
  firstCameraUrl: string;
  firstCamerarefreshRate:number;
  secondCameraUrl:string;
  secondCamerarefreshRate:number;
  thirdCameraUrl: string;
  thirdCamerarefreshRate:number;
  fourCameraUrl:string;
  fourCamerarefreshRate:number;
  selectedImage;
  
  constructor(private easLeftBarService:EasLeftSidebarService,private easEventMoreInformationService:EasEventMoreInformationService,
              private easOtherEntitiesInformationService: EasOtherEntitiesInformationService) { }

  ngOnInit() {
controller = this;
  }
  ngOnChanges(changes): void {
     this.cameraHandler(changes.cameraObject.currentValue)
  }
  cameraHandler(object) {
    if (this.isfirst) {
      this.camerObjects.splice(0,0,object);
      const url = new URL(object.payload.properties.fullJpeg);
      this.firstCamerarefreshRate =parseInt(url.searchParams.get("refreshRate"));
      this.firstCameraUrl = object.payload.properties.fullJpeg+"&timeStamp="+new Date().getTime();
      $("#firstCameraId").remove();
      setTimeout(() => {
        const rootDiv = document.getElementById('firstCamera');
        if (rootDiv !== undefined && rootDiv !== null) {
         const imageContent = document.createElement('img');
          imageContent.id="firstCameraId"
          imageContent.src =this.firstCameraUrl;
          imageContent.setAttribute('style', "width: -webkit-fill-available;");
          imageContent.dataset.cameraId = imageContent.id;
          imageContent.addEventListener('click', function() {
              controller.changeMoreInfo(imageContent, object);
          });
          rootDiv.appendChild(imageContent);
          setInterval(() => {
            const url = new URL(this.firstCameraUrl);
            const timeStamp:number=new Date().getTime();
            url.searchParams.set("timeStamp",timeStamp.toString())
            this.firstCameraUrl=url.toString();
          }, this.firstCamerarefreshRate)
          }
      }, 600);
     this.isfirst=false;
      this.isSecond=true;
    }else if (this.isSecond) {
      this.camerObjects.splice(1,1,object);
      const url = new URL(object.payload.properties.fullJpeg);
      this.secondCamerarefreshRate =parseInt(url.searchParams.get("refreshRate"));
      this.secondCameraUrl = object.payload.properties.fullJpeg+"&timeStamp="+new Date().getTime();
      $("#secondCameraId").remove();
      setTimeout(() => {
        const rootDiv = document.getElementById('secondCamera');
        if (rootDiv !== undefined && rootDiv !== null) {
         const imageContent = document.createElement('img');
          imageContent.id="secondCameraId"
          imageContent.src =this.secondCameraUrl;
          imageContent.setAttribute('style', "width: -webkit-fill-available;");
          imageContent.dataset.cameraId = imageContent.id;
          imageContent.addEventListener('click', function() {
               controller.changeMoreInfo(imageContent, object);
          });
          rootDiv.appendChild(imageContent);
          setInterval(() => {
            const url = new URL(this.secondCameraUrl);
            const timeStamp:number=new Date().getTime();
            url.searchParams.set("timeStamp",timeStamp.toString())
            this.secondCameraUrl=url.toString();
          }, this.secondCamerarefreshRate)
          }
      }, 600);
     
      this.isSecond=false;
      this.isThird=true;
    }else if (this.isThird) {
      this.easEventMoreInformationService.toogleCameraFeed();
      this.camerObjects.splice(2,2,object);
      const url = new URL(object.payload.properties.fullJpeg);
      this.thirdCamerarefreshRate =parseInt(url.searchParams.get("refreshRate"));
      this.thirdCameraUrl = object.payload.properties.fullJpeg+"&timeStamp="+new Date().getTime();
      $("#thirdCameraId").remove();
      setTimeout(() => {
        const rootDiv = document.getElementById('thirdCamera');
        if (rootDiv !== undefined && rootDiv !== null) {
         const imageContent = document.createElement('img');
          imageContent.id="thirdCameraId"
          imageContent.src =this.thirdCameraUrl;
          imageContent.setAttribute('style', "width: -webkit-fill-available;");
          imageContent.dataset.cameraId = imageContent.id;
          imageContent.addEventListener('click', function() {
               controller.changeMoreInfo(imageContent, object);
          });
          rootDiv.appendChild(imageContent);
          setInterval(() => {
            const url = new URL(this.thirdCameraUrl);
            const timeStamp:number=new Date().getTime();
            url.searchParams.set("timeStamp",timeStamp.toString())
            this.thirdCameraUrl=url.toString();
          }, this.thirdCamerarefreshRate)
          }
      }, 600);
        this.isThird=false;
      this.isFourth=true;
    }else if(this.isFourth) {
      this.camerObjects.splice(3,3,object);
      const url = new URL(object.payload.properties.fullJpeg);
      this.fourCamerarefreshRate =parseInt(url.searchParams.get("refreshRate"));
      this.fourCameraUrl = object.payload.properties.fullJpeg+"&timeStamp="+new Date().getTime();
      $("#fourthCameraId").remove();
      setTimeout(() => {
        const rootDiv = document.getElementById('fourthCamera');
        if (rootDiv !== undefined && rootDiv !== null) {
         const imageContent = document.createElement('img');
          imageContent.id="fourthCameraId"
          imageContent.src =this.fourCameraUrl;
          imageContent.setAttribute('style', "width: -webkit-fill-available;");
          imageContent.dataset.cameraId = imageContent.id;
          imageContent.addEventListener('click', function() {
            controller.changeMoreInfo(imageContent, object);
          });
          rootDiv.appendChild(imageContent);
          setInterval(() => {
            const url = new URL(this.fourCameraUrl);
            const timeStamp:number=new Date().getTime();
            url.searchParams.set("timeStamp",timeStamp.toString())
            this.fourCameraUrl=url.toString();
          }, this.fourCamerarefreshRate)
          }
      }, 600);
          this.isFourth=false;
      this.isfirst=true;
    }
  }
onClose(){
  this.easEventMoreInformationService.closeCameraFeed();
  this.easLeftBarService.toggleSidebarToggle(TransactionMeasures.miniView)
}
changeMoreInfo(imageContent, object) {
  if(controller.selectedImage) {
                 controller.selectedImage.setAttribute('style', "width: -webkit-fill-available;");
   }
    controller.selectedImage = imageContent;
    console.log(controller.selectedImage);
    imageContent.setAttribute('style', "width: -webkit-fill-available;border-top-width: 4px;border-bottom-width: 4px;border-right-width: 0px;border-left-width: 0px; border-color: #bff596;   border-style: solid;");
    console.log(imageContent);
    this.easOtherEntitiesInformationService.selectedCameraData.next(object.trafficMetaData);
}
}
