import { Injectable } from '@angular/core';
import { ConfigService } from '../../core/config/config-svc.service';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContextBarService {
  evtSource;
  notificationFromDMS = new Subject<string>();
  notificationFromDMS$ = this.notificationFromDMS.asObservable();
  constructor() { }

    dmsServiceCall() {
    const url = ConfigService.config.dmsStreamUrl + '/notification';
    this.evtSource = new EventSource(url, { withCredentials: true });
    this.evtSource.onopen = (event) => {
    };
    this.evtSource.onmessage = (event) => {
      this.sendNotification(JSON.parse(event.data));
    };
  }

  sendNotification(data) {
    this.notificationFromDMS.next(data);
  }
}
