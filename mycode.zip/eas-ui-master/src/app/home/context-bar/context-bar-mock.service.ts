import { Observable, Subject } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class MockContextBarService {
  notificationFromDMS = new Subject<string>();
  notificationFromDMS$ = this.notificationFromDMS.asObservable();

  public dmsServiceCall() {

  }
  sendNotification(data) {
      this.notificationFromDMS.next(data);
  }
}