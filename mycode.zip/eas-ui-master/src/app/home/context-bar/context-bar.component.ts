import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HomeService } from '../home.service';
import { EasEventsService } from '../eas-events/eas-events.service';
import { SharedService } from '../../shared/shared.service';
import { MapConsoleService } from '../map-console/map-console.service';
import { ConfigService } from '../../core/config/config-svc.service';
import $ from 'jquery';
import { EntitiesMiniListService } from '../map-console/entities-mini-list/entities-mini-list.service';
import { ToastrService } from 'ngx-toastr';
import { ContextBarService } from './context-bar.service';

@Component({
  selector: 'app-context-bar',
  templateUrl: './context-bar.component.html',
  styleUrls: ['./context-bar.component.scss']
})
export class ContextBarComponent implements OnInit {
  @Output() clearContext = new EventEmitter();
  contextEventId: string;
  contextEventName: string;
  displayFailure = false;
  searchResult = false;
  notifications = [];
  panelHeader: string;
  public evtSource: any;
  public notification = '';
  constructor(public homeService: HomeService, public mapConsoleService: MapConsoleService, public easEventsService: EasEventsService,
    private entitiesMiniListService: EntitiesMiniListService, private toastr: ToastrService, private contextBarService: ContextBarService) {
    this.homeService.contextSource$.subscribe(
      data => {
        if (data) {
          this.contextEventId = data.entityId;
          this.contextEventName = data.properties.eventName;
        } else {
          this.clearContextEvent();
        }
      }
    );
    this.contextBarService.notificationFromDMS$.subscribe(
      data => {
        if (data) {
          this.notificationAssign(data);
        }
      }
    );
  }

  ngOnInit() {
    this.contextBarService.dmsServiceCall();

  }

  clearContextEvent() {
    this.contextEventId = '';
    this.contextEventName = '';
    this.mapConsoleService.clearContext();
    this.entitiesMiniListService.clearEventContext();
  }
  ShowListIcons(id: string): void {
    document.getElementById(id).style.display = 'block';
  }
  HideListIcons(id: string): void {
    document.getElementById(id).style.display = 'none';
  }
  openNotificationsPanel() {
    this.mapConsoleService.displayNotifications();
  }

  notificationAssign(eventStreamData: any) {
    if (eventStreamData.message) {
      this.notification = eventStreamData.message;
      this.toastr.info(this.notification, 'Notification:', {
        timeOut: 10000,
        positionClass: 'toast-bottom-right',
        closeButton: true
      });
    }
  }
  displayOnlyEventAssociatedData() {
    this.mapConsoleService.displayOnlyEventAssociatedData.next();
    }
}
