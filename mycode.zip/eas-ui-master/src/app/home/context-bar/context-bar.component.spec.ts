import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { ContextBarComponent } from './context-bar.component';
import { RouterTestingModule } from '@angular/router/testing';
import { NotifierModule } from 'angular-notifier';
import { ToastrModule } from 'ngx-toastr';
import { MockContextBarService } from './context-bar-mock.service';
import { ContextBarService } from './context-bar.service';
import { HomeService } from '../home.service';


describe('ContextBarComponent', () => {
  let component: ContextBarComponent;
  let fixture: ComponentFixture<ContextBarComponent>;
  let service: ContextBarService;
  let homeService: HomeService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContextBarComponent ,
        ],
      imports: [
        HttpClientModule,
        NotifierModule,
        RouterTestingModule,
        ToastrModule.forRoot()
      ],
      providers: [
        { provide: ContextBarService, useClass: MockContextBarService },
        HomeService,
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContextBarComponent);
    component = fixture.componentInstance;
    service = TestBed.get(ContextBarService);
    homeService = TestBed.get(HomeService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set eventContext value from homeservice', () => {
    const payload = {
      'entityId' : 'acc0a104-eb60-4fad-aa9b-c9a0fdab0eff',
      'properties': {
        'eventName': 'sample'
      }
    };
    homeService.setContextEvent(payload);
    expect(component.contextEventId).toEqual('acc0a104-eb60-4fad-aa9b-c9a0fdab0eff');
    expect(component.contextEventName).toEqual('sample');
  });

  it('should clear context from homeservice', () => {
 
    homeService.setContextEvent(null);
    expect(component.contextEventId).toEqual('');
    expect(component.contextEventName).toEqual('');
  });

  it('should set notification for data from dms', () => {
 
    const data = {'message': 'test'};
    service.sendNotification(data);
    expect(component.notification).toEqual('test');
  });

});

