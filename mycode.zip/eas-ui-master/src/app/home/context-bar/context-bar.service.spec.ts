// import { TestBed } from '@angular/core/testing';

// import { ContextBarService } from './context-bar.service';

// describe('ContextBarService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: ContextBarService = TestBed.get(ContextBarService);
//     expect(service).toBeTruthy();
//   });
// });
