
export class ResourceTypeTo {

    public entityId:String ;
	public name:String;
    public organizationName:String;
    public description:String;
    public capabilities:String[];

    constructor(object){
        this.entityId=object.entityId
        this.name=object.name
        this.organizationName=object.organizationName
        this.description=object.description
        this.capabilities=object.capabilities
    }
}