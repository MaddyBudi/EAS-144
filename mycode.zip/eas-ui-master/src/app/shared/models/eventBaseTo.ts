import { AuditBaseTo } from './auditTo';
import { AddressTo } from './addressTo';
import { NotesTo } from './notesTo';
import { SharedService } from '../shared.service';
export class EventBaseTo extends AuditBaseTo{

public entityId : String;
public dataModel : String;
public creator : String;
public eventName : String;
public organizationName : String;
public address : AddressTo;
public eventNotes:NotesTo[]=[];
public eventDesc : String;
public closedOn : Date;
public assignedResources : String[];
public assignedAnnotations : String[];
public contributors : String[];
public absorbes : String[];
public absorber : String;
public geometry : Object;
public properties: Map<String, Object>;
public attachedFilesId : String[];
public type : String
public sharedService: SharedService

constructor(object)
{
   super(object);
   this.entityId=object.entityId;
   this.dataModel=object.dataModel;
   this.creator=object.creator;
   this.eventName=object.eventName;
   this.organizationName=object.organizationName;
   if(object.hasOwnProperty('address'))
   this.address=new AddressTo(object.address);
   else
   this.address=new AddressTo(this.sharedService.getSensorAddress(object));
  
   if(object.eventNotes)
   object.eventNotes.forEach(element => {
      let notes=new NotesTo(element)
        this.eventNotes.push(notes)   
   }
   );
   this.eventDesc=object.eventDesc;
   this.closedOn=object.closedOn;
   this.assignedResources=object.assignedResources;
   this.assignedAnnotations=object.assignedAnnotations;
   this.contributors=object.contributors;
   this.absorbes=object.absorbes;
   this.absorber=object.absorber;
   if(object.hasOwnProperty('geometry'))
   this.geometry=JSON.parse(object.geometry);
   this.properties=object.properties;
   this.attachedFilesId=object.attachedFilesId;
   this.type=object.type;

}

public setGeometry(object) {
   this.geometry=object;
   
}
public setAddress(object) {
   this.address=new AddressTo(object);
}

}