import { StateTo } from './stateTo.enum';


export class AddressTo {


    public streetAddress1: string;
    public streetAddress2: string;
    public city: string;
    public zip: string;
    public state: StateTo;
    public county: string;


	constructor(object) {
        this.streetAddress1=object.streetAddress1
        this.streetAddress2=object.streetAddress2
        this.city=object.city
        this.state=object.state
        this.zip=object.zip
        this.county=object.county
	}
    

    /**
     * tostring
     */
    public tostring(): string {
        const street1 = this.streetAddress1 ? this.streetAddress1 + ',' : '' ;
        const street2 = this.streetAddress2 ? this.streetAddress2+ ',' : '' ;
        const city = this.city ? this.city + ',' : '';
        const county =this.county ? this.county : '';
        const state =this.state ? this.state : '';
        return street1+street2+city+state+county;
    }
}



