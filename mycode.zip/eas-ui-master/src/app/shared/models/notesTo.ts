import { AuditBaseTo } from './auditTo';
export class NotesTo extends AuditBaseTo{
    public entityId : String;
    public eventName : String;
    public creator : String;
    public comment : String;
    constructor(object)
{
   super(object);
   this.entityId=object.entityId;
   this.eventName=object.eventName;
   this.creator=object.creator;
   this.comment=object.comment;
}

}