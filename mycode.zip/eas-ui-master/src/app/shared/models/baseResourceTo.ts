import { AddressTo } from './addressTo';
import { AuditBaseTo } from './auditTo';
export class BaseResourceTo extends AuditBaseTo {

    public entityId:String ;
	public dataModel:String;
	public organizationName:String;
	public resourceName:String;
	public resourceObject:String;
	public resourceType:String;
	public assigned:boolean;
	public status:String;
	public assignedTo:String;
	public geometry:Object;
	public properties: Map<String, Object>;
	public address:AddressTo;
    

	constructor(object) {
        super(object);
        this.entityId=object.entityId;
        this.dataModel=object.dataModel;
        this.organizationName=object.organizationName;
        this.resourceName=object.resourceName;
        this.resourceObject=object.resourceObject;
        this.resourceType=object.resourceType;
        this.assigned=object.assigned;
        this.status=object.status;
        this.assignedTo=object.assignedTo;
        if(object.hasOwnProperty('geometry'))
        this.geometry=JSON.parse(object.geometry);
        if(object.hasOwnProperty('address') && object.address !== null)
        this.address=new AddressTo(object.address);
        this.properties=object.properties;
    }
    
    /**
     * setGeometry
     */
    public setGeometry(object) {
        this.geometry=object;
        
    }

/**
 * setAddress
 */
public setAddress(object) {
    this.address=new AddressTo(object);
}

}
