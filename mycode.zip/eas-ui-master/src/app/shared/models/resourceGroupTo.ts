import { AuditBaseTo } from './auditTo';

export class ResourceGroupTo extends AuditBaseTo {
    
    public entityId:String;
    public name:String;
    public organizationName:String;
    public description:String;
    public resources: Array<String>;
    
    
    constructor(object) {
        super(object);
        this.entityId = object.entityId;
        this.name = object.name;
        this.organizationName = object.organizationName;
        this.description = object.description;
        this.resources = object.resoucres;
    }
    
}