import { EventBaseTo } from './eventBaseTo'

export class EventTo extends EventBaseTo{
public status : String;
public memberOf : String;
public priority : String;
public intrepidId : String;
public eventType : String;
public deleted : Boolean;
public owner : String;

constructor(object)
{
   super(object);
   this.status=object.status;
   this.memberOf=object.memberOf;
   this.priority=object.priority;
   this.intrepidId=object.intrepidId;
   this.eventType=object.eventType;
   this.deleted=object.deleted;
   this.owner=object.owner;
}


}