import { ResourceTo } from './resourceTo';

export class EquipmentResourceTo extends ResourceTo {
    public type: String = 'equipmentResource';
    public  year: String;
    public  make: String;
    public  model: String;
    public  series: String;
    public  bodyType: String;
    public  color1: String;
    public  color2: String;
    public  equipmentType: String;
    public  equipments: Array<String>;

    constructor(object) {
        super(object);
        this.year = object.year;
        this.make = object.make;
        this.model = object.model;
        this.series = object.series;
        this.bodyType = object.bodyType;
        this.color1 = object.color1;
        this.color2 = object.color2;
        this.equipments = object.equipments;
        this.equipmentType = object.equipmentType;

    }
}