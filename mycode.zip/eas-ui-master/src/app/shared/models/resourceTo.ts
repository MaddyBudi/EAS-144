import { AddressTo } from './addressTo';
import {BaseResourceTo } from './baseResourceTo';

export class ResourceTo extends BaseResourceTo {
    public type:String = 'resource';
    public dispatchAddress: AddressTo;
	public capabilities: Object ;
    public abilities: Object ;
    public checkboxFlag: boolean = false;
    
    constructor(object) {
        super(object);
        if(object.hasOwnProperty('dispatchAddress') && object.dispatchAddress !== null)
        this.dispatchAddress = new AddressTo(object.dispatchAddress);
        else
        this.dispatchAddress = new AddressTo("");
        this.capabilities = object.capabilities;
        this.abilities = object.abilities;
    }
    
    public setCapabilities(object) {
        this.capabilities=object;
        
    }
    public setAbilities(object) {
        this.abilities=object;
        
    }

}