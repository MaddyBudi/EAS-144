export class PhoneTo {
    public number: String;
    public phoneType: String;
    
    constructor(object) {
        this.number = object.number;
        this.phoneType = object.phoneType;
    }
}