export class DobTo {
    public age: String;
    public day: String;
    public month: String;
    public year: String;
 
    constructor(object) {
        this.age = object.age;
        this.month = object.month;
        this.day = object.day;
        this.year = object.year;

    }
     public tostring(): string {
    const dob = (this.day !== null && this.month !== null && this.year !== null) ? this.year + '-' + this.month + '-' + this.day : '';
        return dob;
    }
}