import { BaseResourceTo } from './baseResourceTo';


export class AnnotationTo extends BaseResourceTo {
    public type:string='annotation';
    public annotationType:String;
    public annotationDesc:String;

    constructor(object){
        super(object);
        this.annotationType=object.annotationType;
        this.annotationDesc=object.annotationDesc
    }
        


}
