export class AuditBaseTo {
    private createdBy: String;
    public createdDate: Date;
    private lastModifiedBy: String;
    private lastModifiedDate: Date;

    constructor(object) {
        this.createdBy = object.createdBy
        this.createdDate = object.createdDate
        this.lastModifiedBy = object.lastModifiedBy
        this.lastModifiedDate = object.lastModifiedDate
    }
}