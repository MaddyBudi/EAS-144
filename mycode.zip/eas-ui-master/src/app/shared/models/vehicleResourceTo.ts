import { EquipmentResourceTo } from './equipmentResourceTo';
import { PhoneTo } from './phoneTo';

export class VehicleResourceTo extends EquipmentResourceTo {
    public type: String = 'vehicleResource';
    private vin: String;
    private vehicleType: String;
    private emails: Array<String>;
    public phones: PhoneTo[] = [];
    constructor(object) {
        super(object);
        this.vin = object.vin;
        this.vehicleType = object.vehicleType;
        this.emails = object.emails;
         if(object.hasOwnProperty('phones') && object.phones.length !== 0) {
             object.phones.forEach(element => {
                 const  phone = new PhoneTo(element);
                  this.phones.push(phone);
               });
             }
    }
}