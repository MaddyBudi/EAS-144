import { PersonNameTo } from './personNameTo';
import { ResourceTo } from './resourceTo';
import { DobTo } from './dobTo';
import { PhoneTo } from './phoneTo';

export class PersonResourceTo extends ResourceTo {
    public type: String = 'personResource';
    private  name: PersonNameTo;
    private  gender: String;
    private  dob: DobTo;
    private  email: String;
    private  phone: PhoneTo ;
    private  intrepidCallSign: String;
    private  kodiakMdn: String;
    private  lastKodiakUpdateDate: Date;

    constructor(object) {
        super(object);
        if(object.hasOwnProperty('name') && object.name !== null)
        this.name = new PersonNameTo(object.name);
        this.gender = object.gender;
        if(object.hasOwnProperty('dob') && object.dob !== null)
        this.dob = new DobTo(object.dob);
        this.email = object.email;
        if(object.hasOwnProperty('phone') && object.phone !== null)
        this.phone = new PhoneTo(object.phone);
        this.intrepidCallSign = object.intrepidCallSign;
        this.kodiakMdn = object.kodiakMdn;
        this.lastKodiakUpdateDate = object.lastKodiakUpdateDate;
    }
}