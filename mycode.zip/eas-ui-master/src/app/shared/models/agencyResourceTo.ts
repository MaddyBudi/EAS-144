import { PersonNameTo } from './personNameTo';
import { PhoneTo } from './phoneTo';
import { ResourceTo } from './resourceTo';

export class AgencyResourceTo extends ResourceTo {
    public type: String = 'agencyResource';
    public emails: Array<String>;
    public phones: PhoneTo[] = [];

    constructor(object) {
        super(object);
        this.emails = object.emails;
        if(object.hasOwnProperty('phones') && object.phones.length !== 0) {
             object.phones.forEach(element => {
                 const  phone = new PhoneTo(element);
                  this.phones.push(phone);
               });
             }

    }

}