export class PersonNameTo {
    public  namePrefix: String;
    public  nameSuffix: String;
    public  firstName: String;
    public  middleName: String;
    public  lastName: String;

    constructor(object) {
        this.firstName = object.firstName;
        this.middleName = object.middleName;
        this.lastName = object.lastName;
        this.namePrefix = object.namePrefix;
        this.nameSuffix = object.nameSuffix;

    }
}
