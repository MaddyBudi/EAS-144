export class LocationTo {
     id: number;
     name: String;
     type: String;
     geometry: Map<String, Object>;
     properties: Map<String, Object>;
     createdBy: String;
     createdDate: Date;
     constructor(object?:any)
     {
       this.id=object.id;
        this.name=object.name;
        this.type=object.type;
        this.geometry=object.geometry;
        this.properties=object.properties;
        this.createdBy=object.createdBy;
        this.createdDate=object.createdDate;
     }
     
  /**
   * setGeoMetry
object   
this.geometry=*/
  public setGeoMetry(object) {
    this.geometry=object
    
  }
}
