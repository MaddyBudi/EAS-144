import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class AppGlobals {

  readonly OnDemandLocationInterval = '200';
  readonly OnDemandLocationDuration = '1800';
  mapHeight = 0;
  readonly adminUser = 'ADMIN';
  readonly normalUser = 'USER';
  readonly param_iss = '?iss=';
  readonly param_targetUri = '&target_link_uri=';
  readonly providerWest = 'west';
  readonly providerGoogle = 'google';
  readonly targetUri = window.location.protocol + '//' + window.location.hostname + ':' + window.location.port + '/appconsole';
  readonly RowsPerPageList = [5, 10, 15];
  readonly DefaultRowsPerPage = 5;
  readonly eventDataModel = 'EVENT';
  readonly annotationDataModel = 'RESOURCE';
  readonly resourceObject = 'ANNOTATION';
  readonly selected_color = '2px solid #789';
  readonly unselected_color = '2px solid #fff';
  readonly defaultZoomSize = '5';
  readonly zoomAdjusterFactor = '6';
  readonly defaultOrgLat = '34.0522';
  readonly defaultOrgLan = '-118.2437';
  readonly streamZoomLevel = 13;
  readonly eventIcon = 'assets/img/map-event.png';
  readonly annotationAvailIcon = 'assets/img/pin-1024-available.png';
  readonly annotationNotAvailIcon = 'assets/img/pin-1024-unavailable.png';
  readonly hydrantIcon = 'assets/img/mapHydrants.svg';
  readonly annotationType = 'annotation';
  readonly hospitalIcon = 'assets/img/mapHospital.svg';
  readonly fuelIcon = 'assets/img/mapElectricFuel.svg';
  readonly data311Icon = 'assets/img/311.svg';
  readonly trafficIcon = 'assets/img/video-camera.svg';
  readonly cameraIcon = 'assets/img/video-camera-green.svg';
  readonly weatherIcon = 'assets/img/weather.svg';
  readonly easUsersAvailIcon = 'assets/img/eas-user-1024-available.png';
  readonly easUsersNotAvailIcon = 'assets/img/eas-user-1024-unavailable.png';
  readonly fieldPersonnelAvailIcon = 'assets/img/field-user-1024-available.png';
  readonly fieldPersonnelNotAvailIcon = 'assets/img/field-user-1024-unavailable.png';
  readonly lawAvailIcon = 'assets/img/law-1024-available.png';
  readonly lawNotAvailIcon = 'assets/img/law-1024-unavailable.png';
  readonly fireAvailIcon = 'assets/img/fire-1024-available.png';
  readonly fireNotAvailIcon = 'assets/img/fire-1024-unavailable.png';
  readonly medicalAvailIcon = 'assets/img/med-1024-available.png';
  readonly medicalNotAvailIcon = 'assets/img/med-1024-unavailable.png';
  readonly agencyAvailIcon = 'assets/img/resources-agency-1024-available.png';
  readonly agencyNotAvailIcon = 'assets/img/resources-agency-1024-unavailable.png';
  readonly sensorIcon = 'assets/img/sensor_marker.svg';
  readonly person = 'Person';
  readonly vehicle = 'Vehicle';
  readonly agency = 'Agency';
  readonly easUsers = 'eas-users';
  readonly fieldPersonnel = 'field-personnel';
  readonly law = 'Law';
  readonly fire = 'Fire';
  readonly medical = 'Medical';
  readonly noEventsAvailable = 'No events available';
  readonly noOpenEventsAvailable = 'No open events available';
  readonly noPredefinedLocationsAvailable = 'No predefined locations available.';
  readonly noResourcesAvailable = 'No resources available';
  readonly noAnnotationsAvailable = 'No annotations available';
  readonly situationalDataURL = {
    'AIRQUALITY': '/AirQuality/',
    'HYDRANT': '/Hydrant/',
    'HOSPITAL': '/Hospital/',
    'FUEL': '/AlternateFuel/',
    'DATA311': '/ServiceRequest/',
    'TRAFFIC': '/TrafficCamera/',
    'WEATHER': '/WeatherFromStation/'
  };
  readonly trafficMetaData = {
    'latitude': 'Latitude',
    'longitude': 'Longitude',
    'name': 'Name',
    'description': 'Description',
    'provider': 'Provider',
    'orientation': 'Orientation'

  };
  readonly hydrantMetaData = {
    'latitude': 'Latitude',
    'longitude': 'Longitude',
    'hydrant_id': 'Hydrant Id',
    'hydrantid': 'Hydrant Id',
    'valve_angle': 'Valve Angle',
    'valveid': 'Valve Id',
    'location_description': 'Location Description'
  };
  readonly hospitalMetaData = {
    'source': 'Source',
    'latitude': 'Latitude',
    'longitude': 'Longitude',
    'hospital_name': 'Hospital Name',
    'address': 'Address',
    'city': 'City',
    'county_name': 'County Name',
    'phone_number': 'Phone Number',
    'zip_code': 'Zip Code'
  };
  readonly fuelMetaData = {
    'latitude': 'Latitude',
    'longitude': 'Longitude',
    'station_name': 'Station Name',
    'street_address': 'Street Address',
    'city': 'City',
    'country': 'Country',
    'station_phone': 'Station Phone',
    'zip': 'Zip',
    'fuel_type_code': 'Fuel Type Code',
    'groups_with_access_code': 'Groups with access code'
  };
  readonly data311MetaData = {
    'lat': 'Latitude',
    'long': 'Longitude',
    'service_name': 'Service Name',
    'service_code': 'Service Code',
    'status': 'Status',
    'status_notes': 'Status Notes',
    'address': 'Address',
    'agency_responsible': 'Agency Responsible'
  };
  readonly weatherMetaData = {

    'temp': 'Temperature',
    'pressure': 'Pressure',
    'humidity': 'Humidity',
    'temp_min': 'Minimum Temperature',
    'temp_max': 'Maximum Temperature',
    'sea_level': 'Sea level',
    'grnd_level': 'Ground Level',
    'speed': 'Speed'
  };
  readonly resourceMetaData = {
    'resourceName': 'Resource Name',
    'resourceType': 'Resource Type',
    'status': 'Status',
    'createdDate': 'Created Date',
    'lastModifiedDate': 'Updated Date',
    'streetAddress1': 'Street Address1',
    'streetAddress2': 'Street Address2',
    'city': 'City',
    'zip': 'Zip',
    'state': 'State',
    'county': 'County',
    'gender': 'Gender',
    'email': 'Email',
    'number': 'Phone Number'
  };
  readonly vehicleMetaData = {
    'resourceName': 'Resource Name',
    'resourceType': 'Resource Type',
    'status': 'Status',
    'createdDate': 'Created Date',
    'lastModifiedDate': 'Updated Date',
    'streetAddress1': 'Street Address1',
    'streetAddress2': 'Street Address2',
    'city': 'City',
    'zip': 'Zip',
    'state': 'State',
    'county': 'County',
    'gender': 'Gender',
    'email': 'Email',
    'number': 'Phone Number',
    'vin': 'Vin',
    'vehicleType': 'Vehicle Type',
    'year': 'Year',
    'make': 'Make',
    'model': 'Model',
    'series': 'Series',
    'bodyType': 'Body Type',
    'color1': 'Color 1',
    'color2': 'Color 2',
    'equipmentType': 'Equipment Type'

  };
  readonly annotationMetaData = {
    'resourceName': 'Annotation Name',
    'annotationType': 'Annotation Type',
    'annotationDesc': 'Annotation Description',
    'status': 'Status',
    'createdDate': 'Created Date',
    'lastModifiedDate': 'Updated Date',
    'streetAddress1': 'Street Address1',
    'streetAddress2': 'Street Address2',
    'city': 'City',
    'zip': 'Zip',
    'state': 'State',
    'county': 'County',


  };
  readonly sensorMetaData = {
    'name': 'Sensor Name',
    'dataValue': 'Current Value(Area Temperature)',
    'dataType': 'Type',
    'description': 'Description',
    'status': 'Status'
  };
  readonly locationMetaData = {
    'name': 'Location Name',
    'address': 'Address',
    'createdBy': 'createdBy',
    'createdDate': 'Created Date'
  };
  readonly available = 'Available';
  readonly notAvailable = 'NotAvailable';
  readonly defaultPhType = 'BUSINESS';
  readonly defaultGender = 'MALE';
  readonly defaultVehicleType = 'AUTOMOBILE';
  readonly defaultEquipmentType = 'FIRE';
  readonly createRscFailureMsg = 'Unable to create Resource. Please try again later';
  readonly generalErrorOccured = 'General error occured. Please try again later.';
  readonly searchNearby = 'searchNearby';
  readonly searchByCriteria = 'searchByCriteria';
  readonly searchUnassignedResources = 'searchUnassignedResources';
  readonly attachFilesEndpoint = '/uploadAttachment?ENTITY_ID=';
  readonly retrieveAttachedFilesEndpoint = '/getAttachment?fileId=';
  readonly sensorHistoryEndpoint = '/Observations';
  readonly getSensorEndpoint = '/Sensors';
  readonly getMSDSDataEndpoint = '/getMSDSInfo?MSDS_COMPOUND_NAME=';
  readonly searchAssociatedEvents = 'searchAssociatedEvents';
  readonly nrfMsg = 'No records match your search criteria.';
  readonly updateRscFailureMsg = 'Unable to update an resource now.';
  readonly msdsPushToEventSuccess = 'The entered keyword has been added to event';
  readonly msdsPushToEventFailure = 'Unable to add the entered keyword to event.Please try again later.';
  readonly uploadFilesSuccessMsg = 'File(s) uploaded successfully.';
  readonly uploadFilesFailureMsg = 'File(s) upload failure.Please try again later.';
  readonly noSensorHistoryFoundMsg = 'No history information found.';
  readonly fetchSensorHistoryFailureMsg = 'Unable to get history information for the sensor.Please try again later.';
  fillColor = 'red';
  strokeOpacity = 0.1;
  fillOpacity = 0.2;
  lineStrokeOpacity = 0.4;
  constructor() { }

}

