import { Injectable } from '@angular/core';
import { localeData } from 'moment';
import { filter } from 'rxjs/operators';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import * as moment from 'moment';
import { promise } from 'protractor';
import { DataModel } from '../dataModelEnum';
const swal = require('sweetalert');

declare let google: any;
@Injectable({
  providedIn: 'root'
})

export class SharedService {

  constructor(public router: Router) { }
  address;
  response: any;
  geocoder = new google.maps.Geocoder();
  strokeOpacity = 0.8;
  strokeWeight = 3;
  fieldPersonnelResource='field-personnel';
  easUsersResource='eas-users';
  agencyResource='Agency';
  lawResource='Law';
  fireResource='Fire';
  medicalResource='Medical';

  polygonGetBoundingBox(shape, entityType) {
    const coordinates = [];
    google.maps.Polygon.prototype.getBoundingBox = function () {
      const bounds = new google.maps.LatLngBounds();
      this.getPath().forEach(function (element, index) {
        bounds.extend(element);
      });
      return (bounds);
    };
    if (entityType === DataModel.location) {
      for (let i = 0; i < shape.getPath().getLength(); i++) {
        coordinates.push({ lat: shape.getPath().getAt(i).lat(), lng: shape.getPath().getAt(i).lng() });
      }
    } else  {
      for (let i = 0; i < shape.getPath().getLength(); i++) {
        coordinates.push([shape.getPath().getAt(i).lng(), shape.getPath().getAt(i).lat()]);
      }
      coordinates.push(coordinates[0]);
    }
    const latLngCoordinates = {
      'latitude': shape.getBoundingBox().getCenter().lat(),
      'longitude': shape.getBoundingBox().getCenter().lng(),
      'coordinates': coordinates
    };
    return latLngCoordinates;
  }
  getRectangleLatLng(shape) {

    const coordinates = [];
    const rectangleBounds = shape.getBounds();
    coordinates.push({ lat: rectangleBounds.getNorthEast().lat(), lng: rectangleBounds.getNorthEast().lng() });
    coordinates.push({ lat: rectangleBounds.getSouthWest().lat(), lng: rectangleBounds.getSouthWest().lng() });
    const latLngCoordinates = {
      'centerLat': rectangleBounds.getCenter().lat(),
      'centerLng': rectangleBounds.getCenter().lng(),
      'coordinates': coordinates
    };

    return latLngCoordinates;
  }
  createMarkerObject(mapObject, position, draggable, icon, filterName, label) {
    const marker = new google.maps.Marker({
      map: mapObject,
      position: position,
      draggable: draggable,
      icon: icon,
      filterName: filterName,
      label: label
    });
    return marker;
  }
  createShape(mapOject, shapeType, shapeProperty, color, filterName) {
    let shape;
    if (shapeType === 'polygon') {
      shape = new google.maps.Polygon({
        paths: shapeProperty,
        map: mapOject,
        fillColor: color,
        filterName: filterName,
        strokeOpacity: this.strokeOpacity,
        strokeWeight: this.strokeWeight,
        strokeColor: color
      });
    } else if (shapeType === 'rectangle') {
      shape = new google.maps.Rectangle({
        bounds: shapeProperty,
        map: mapOject,
        fillColor: color,
        filterName: filterName,
        strokeOpacity: this.strokeOpacity,
        strokeWeight: this.strokeWeight,
        strokeColor: color,
      });
      // console.log("bounds");
      // console.log(shape.shapeProperty)
    } else if (shapeType === 'circle') {
      shape = new google.maps.Circle({
        radius: shapeProperty.radius,
        center: shapeProperty.center,
        map: mapOject,
        fillColor: color,
        filterName: filterName,
        strokeOpacity: this.strokeOpacity,
        strokeWeight: this.strokeWeight,
        strokeColor: color,

      });
    }

    return shape;
  }
  getFullAddress(place) {
    // console.log(place);
    if (place) {

      const tempRoom = this.extractFromAdress(place.address_components, 'room');
      const room = tempRoom !== '' ? tempRoom + ", " : '';
      const tempFloor = this.extractFromAdress(place.address_components, 'floor');
      const floor = tempFloor !== '' ? tempFloor + ", " : '';
      const tempPremise = this.extractFromAdress(place.address_components, 'premise');
      const premise = tempPremise !== '' ? tempPremise + ", " : '';
      const tempSubpremise = this.extractFromAdress(place.address_components, 'subpremise');
      const subpremise = tempSubpremise !== '' ? tempSubpremise + ", " : '';
      const tempBusStation = this.extractFromAdress(place.address_components, 'bus_station');
      const busStation = tempBusStation !== '' ? tempBusStation + ", " : '';

      const tempStreetNumber = this.extractFromAdress(place.address_components, 'street_number');
      const streetNumber = tempStreetNumber !== '' ? tempStreetNumber + ", " : '';
      const tempRoute = this.extractFromAdress(place.address_components, 'route');
      const route = tempRoute !== '' ? tempRoute + ", " : '';
      const tempSublocality = this.extractFromAdress(place.address_components, 'sublocatity');
      const sublocality = tempSublocality !== '' ? tempSublocality + ", " : '';

      const tempState = this.extractFromAdress(place.address_components, 'administrative_area_level_1');
      const state = tempState !== '' ? tempState : '';

      const tempCounty = this.extractFromAdress(place.address_components, 'administrative_area_level_2');
      const county = tempCounty !== '' ? tempCounty : '';

      const tempCity = this.extractFromAdress(place.address_components, 'locality');
      const city = tempCity !== '' ? tempCity : '';

      const tempZipcode = this.extractFromAdress(place.address_components, 'postal_code');
      const zipcode = tempZipcode !== '' ? tempZipcode : '';
      const tempZipcodeSuffix = this.extractFromAdress(place.address_components, 'postal_code_suffix');
      const zipcodeSuffix = tempZipcodeSuffix !== '' ? tempZipcodeSuffix : '';

      const line1 = room + floor + subpremise + premise + busStation;
      const line2 = streetNumber + route + sublocality;

      let streetAddress1 = '';
      let streetAddress2 = '';
      let zip = '';
      if (line1 !== '') {
        streetAddress1 = line1.trim().slice(0, -1);
        streetAddress2 = line2.trim().slice(0, -1);
      } else {
        streetAddress1 = line2.trim().slice(0, -1);
        streetAddress2 = '';
      }
      if (zipcodeSuffix !== '') {
        zip = zipcode + '-' + zipcodeSuffix;
      } else {
        zip = zipcode;
      }

      const address = {
        "streetAddress1": streetAddress1,
        "streetAddress2": streetAddress2,
        "city": city,
        "zip": zip,
        "state": state,
        "county": county
      };
      // console.log(address);
      // address.streetAddress1 = address.streetAddress1 !== '' ? address.streetAddress1 + ', ' : '';
      // address.streetAddress2 = address.streetAddress2 !== '' ? address.streetAddress2 + ', ' : '';
      // address.county = address.county !== '' ? address.county + ', ' : '';

      // console.log(address.streetAddress1 + address.streetAddress2 +
      //  address.city + ', ' + address.state + ', ' + address.county + address.zip);

      return address;
    }
  }
  extractFromAdress(components, type) {
    if (components && components.length > 0) {
      for (let i = 0; i < components.length; i++) {
        for (let j = 0; j < components[i].types.length; j++) {
          if (components[i].types[j] === type) {
            return components[i].short_name;
          }
        }
      }

      return '';
    }
  }
  getPolygonCenter(coordinates) {
    const lat = [];
    const lng = [];
    const polygonCenter = [];
    coordinates.forEach((value) => {
      lng.push(value[0]);
      lat.push(value[1]);
    });
    const tempCenter = lng => lng.reduce((a, b) => a + b, 0) / lng.length;
    polygonCenter.push(tempCenter(lng));
    polygonCenter.push(tempCenter(lat));
    console.log(polygonCenter);
    return polygonCenter;
  }


   getSensorAddress(event){
    let latCenter;
    let lngCenter;
    let latlngCenter = [];
    let Address
     if(event.geometry.type!="Point"){
      latlngCenter=this.getPolygonCenter(event.geometry.coordinates)
      lngCenter=latlngCenter[0];
      latCenter=latlngCenter[1];
      Address=this.getAddressFromCenter(latCenter,lngCenter);
      return Address
     }
     else{
      latCenter=event.geometry.coordinates[1];
      lngCenter = event.geometry.coordinates[0];
      this.getAddressFromCenter(latCenter,lngCenter);
      return Address
     }
  }

  getAddressFromCenter(latitude, longitude): Promise<any> {
    return new Promise((resolve, reject) => {
     let that = this;
    const latlng = new google.maps.LatLng(latitude, longitude);
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ 'latLng': latlng }, (results, status) => {
      if (status === google.maps.GeocoderStatus.OK) {
        const place = results[0];
        console.log(place);
        resolve(that.getFullAddress(place));
              }
               else {
        console.log('Geocoder failed due to: ' + status);
      }
    });
  });
}

  getFormattedAddress(fulladdress) {
    const address = fulladdress;
    if (address) {
      address.streetAddress1 = (address.streetAddress1) ? address.streetAddress1.trim() + ', ' : '';
      address.streetAddress2 = (address.streetAddress2) ? address.streetAddress2.trim() + ', ' : '';
      address.county = (address.county) ? address.county.trim() + ', ' : '';
      address.city = (address.city) ? address.city.trim() + ', ' : '';
      address.state = (address.state) ? address.state.trim() + ', ' : '';
      const newaddress = address.streetAddress1 + address.streetAddress2 +
        address.city + address.state +
        address.county + address.zip;
      if (newaddress.trim().slice(-1) === ',') {
        return newaddress.trim().slice(0, -1);
      }
      return newaddress;
    }
  }
  routeToLoginError(statusCode: any) {
    if (statusCode === 401) {
      this.router.navigate(['LoginComponent', { error: "Session Expired" }], { skipLocationChange: true });
    }
  }
  getInfoWindow(entityType, attribute1, attribute2, attribute3, attribute4, attribute5) {
    const colAlignment = "<td class=" + '"infowindowtdstyle"' + "></td>";
    const colAdjustment = "<tr><td class=" + '"colAdjustment"' + "></td></tr>";
    if (entityType) {
      let contentString = '';
      if (entityType === 'sensor') {
        contentString =
          '<div id="eventMarker" ><p id ="header" class="infowindowHeader">' + attribute1
          + '</p><table class="table-striped" class="tableFont"><tbody class="tbodyFont">'
          + '<tr><td class="infowindowtdstyle">Address &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute2 + '</td></tr>'
          + '<tr><td class="infowindowtdstyle">Description &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute5 + '</td></tr>'
          + '<tr><td class="infowindowtdstyle">Current Reading &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute3 + '</td></tr>'
          + '</tbody></table></div>' + '<br><em class="fa fa-history fa-2x infowindowfaicons"'
          + ' id="viewSensorHistory" title="View History"></em>'
          + ' <a href="'+attribute4+'" target="_blank" title="View Pdf">'
          +'<em class="fa fa-file-pdf-o fa-2x infowindowfaicons" ></em></a>';
      }else if (entityType === "event") {
        contentString =
          '<div id="eventMarker" ><p id ="header" class="infowindowHeader">' + attribute1
          + '</p><table class="table-striped" class="tableFont"><tbody class="tbodyFont">'
          + '<tr><td class="infowindowtdstyle">Address &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute2 + '</td></tr>'
          + '<tr><td class="infowindowtdstyle">Description &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute3 + '</td></tr>'
          + '</tbody></table></div>' + '<br><em class="fa fa-info-circle fa-2x infowindowfaicons"'
          + ' id="moredetails" title="More Info"></em>' + '<em class="fa fa-comments fa-2x infowindowfaicons"'
          + ' id="viewComments" title="View Comments"></em>'
          + ' <em class="fa fa-pencil-square-o fa-2x infowindowfaicons" id="updateEvent" title="Update Event"></em>'
          + ' <em class="fa fa-trash-o fa-2x infowindowfaicons"'
          + ' id="closeEvent" title="Delete Event"></em>'
          + ' <em class="fa fa-object-group fa-2x infowindowfaicons"'
          + 'id = "absorbradio" title="Absorb event"></em>'
          + '<em class="fa fa-object-ungroup fa-2x infowindowfaicons"'
          + 'id="editEventLocation" title="Edit Event Location"></em>'
          + '<em class="fa fa-link fa-2x infowindowfaicons"'
          + 'id="editRsrcAssignment" title="Assign/Release Resources"></em>';
        if ('CHEMICAL SPILL' === attribute4) {
          contentString += '<em class="fa fa-flask fa-2x infowindowfaicons"'
            + 'id="viewMSDSData" title="View MSDS Data"></em>';
        }
      } else if (entityType === "absorbEvent") {
        contentString = '<div id="absorbEventMarker" ><p class="pHeader">Do you want to absorb this event ?</p>' +
          '<div class="divLeft"><button class="btn btn-primary pull-right dragableButton" id="absorbEvent"> Absorb'
          + '</button><div><button class="btn btn-primary pull-right dragableButton" id="cancelAbsorb"> Cancel</button>' +
          '</div>';
      } else if (entityType === "annotation") {
        //  console.log("annotation");
        contentString =
          '<div id="annotationMarker" ><p id ="header" class="infowindowHeader">' + attribute1
          + '</p><table class="table-striped" class="tableFont"><tbody class="tbodyFont">'
          + '<tr><td class="infowindowtdstyle">Address &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute2 + '</td></tr>'
          + '<tr><td class="infowindowtdstyle">Status &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute3 + '</td></tr>'
          + '</tbody></table></div>' + '<br><em class="fa fa-info-circle fa-2x infowindowfaicons" id="moreInfo" title="More Info"></em>' +
          '<em class="fa fa-pencil-square-o fa-2x infowindowfaicons"'
          + ' id="updateAnnotation" title="Update Annotation"></em>' + '<em class="fa fa-trash-o fa-2x infowindowfaicons"'
          + ' id="closeAnnotation" title="Delete Annotation"></em>';
      } else if (entityType === 'location') {
        contentString = '<div id="locationMarker" ><p id ="header" class="infowindowHeader">' + attribute1
          + '</p><table class="table-striped" class="tableFont"><tbody class="tbodyFont">'
          + '<tr><td class="infowindowtdstyle">Address &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute2 + '</td></tr></tbody></table></div>'
          + '<br><em class="fa fa-pencil-square-o fa-2x infowindowfaicons" id="updateLocation" title="Update Location"></em>'
          + '<em class="fa fa-trash-o fa-2x infowindowfaicons" id="deleteLocation" title="Delete Location"></em>';
      } else if (entityType === this.lawResource || entityType === this.fireResource || entityType === this.medicalResource
        || entityType === this.easUsersResource || entityType === this.fieldPersonnelResource || entityType === this.agencyResource ) {
        contentString = '<div id="resourceMarker" ><p id ="header" class="infowindowHeader">' + attribute1
          + '</p><table class="table-striped" class="tableFont"><tbody class="tbodyFont">'
          + '<tr><td class="infowindowtdstyle">Address &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute2 + '</td></tr>'
          + '<tr><td class="infowindowtdstyle">Status &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute3 + '</td></tr>'
          + '<tr><td class="infowindowtdstyle">Organization Name &nbsp;&nbsp;</td><td class="infowindowtdstyle">'
          + attribute4 + '</td></tr>'
          + '</tbody></table></div>' + '<br><em class="fa fa-info-circle fa-2x infowindowfaicons" id="moreInfo" title="More Info"></em>';
          if(entityType === this.fieldPersonnelResource){
            contentString = contentString +
            '<i class="material-icons routeInfoIconPosition " id="routeInfoIcon" title="Routing Info-ETA">directions</i>';
                      }
      } else if (entityType === "dragable") {
        contentString =
          '<div id="editLocation"><p class="pHeader">Do you want to update the event location?</p>' +
          '<div class="divLeft"><button class="btn btn-primary pull-right dragableButton" id="changeLocation"> Update'
          + '</button><div><button class="btn btn-primary pull-right dragableButton" id="cancel"> Cancel</button>' +
          '</div>';
      }
      return contentString;
    }
  }
  getSituationalDataInfowindow(additionalInfo, infoMap, headingContent, imageIcon) {
    const header = "<p id =" + '"header"' + " class= " + '"situationaldataHeader"' + ">";
    const heading = headingContent + "</p>";
    const colAlignment = "<td class=" + '"infowindowtdstyle"' + ">" + "</td>";
    const imgAlignment = "<td class=" + '"imgAlignment"' + ">" + "</td>";
    const colAdjustment = "<tr><td class=" + '"colAdjustment"' + ">" + "</td></tr>";
    const icon = "<img src= '" + imageIcon + " 'class =" + '"situationalDataIcon"' + ">";
    let contentString = header + heading + icon + '<table class="table-striped text-sm"><tbody class="' + '"tbodyFont"' + '">';

    infoMap.forEach((val, key) => {

      contentString = contentString + '<tr>' + colAlignment + '<td class=' + '"infoMap">' + key + ' &nbsp;&nbsp;</td>'
        + '<td class=' + '"infoMap">' + val + '</td></tr>';
    });
    if (additionalInfo) {
      contentString = contentString + '<tr>' + imgAlignment
        + "<img id='traffic_cam' src= '" + additionalInfo + '&time=' + new Date().getTime()
        + "' class =" + '"situationalDataAdditionalInfo"' + ">" + '</tr>';
    }
    contentString = contentString + colAdjustment + colAdjustment + colAdjustment + '</tbody></table></div>'
      + '<br><em class="fa fa-info-circle fa-2x infowindowfaicons" id="moreInfo" title="More Info"></em>';
    return contentString;
  }
  showMoreLess() {
    const showChar = 500;  // How many characters are shown by default
    const moretext = "Show more >";
    const lesstext = "Show less";
    $('.more').each(function () {
      const content = $(this).html();
      console.log(content);
      if (content.length > showChar) {
        const c = content.substr(0, showChar);
        const h = content.substr(showChar, content.length - showChar);
        const html = c + '</span>&nbsp;&nbsp;<span ' +
          'class="morecontent"><span style="display:none;">' + h + '</span><a href="" class="morelink">'
          + moretext + '</a></span>';
        $(this).html(html);
      }
    });

    $(".morelink").click(function () {
      if ($(this).hasClass("less")) {
        $(this).removeClass("less");
        $(this).html(moretext);
      } else {
        $(this).addClass("less");
        $(this).html(lesstext);
      }
      $(this).parent().prev().toggle();
      $(this).prev().toggle();
      return false;
    });
  }

  getLocalDate(date) {
    if (date !== null && date !== undefined) {
      let dateArr; dateArr = date.split("T");
      let newDate; newDate = moment(dateArr[0], "DD-MM-YYYY").format('YYYY-MM-DD');
      let newDate1; newDate1 = newDate + ' ' + dateArr[1];
      let stillUtc; stillUtc = moment.utc(newDate1);
      let local; local = moment(stillUtc).local().format('YYYY-MM-DD HH:mm:ss');
      return local;
    } else {
      return null;

    }

  }
  showYesNoAlert(message,action,swalCallback,cancelButtonText) {
    swal({
      title: 'Are you sure?',
      text: message,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DD6B55',
      confirmButtonText: 'Yes,'+ action,
      cancelButtonText: cancelButtonText,
      closeOnConfirm: true,
      closeOnCancel: true
    }, swalCallback);

  }



getFormattedAddressFromCenter(latitude, longitude) {

    return new Promise((resolve, reject) => {
     let that = this;
    const latlng = new google.maps.LatLng(latitude, longitude);
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ 'latLng': latlng }, (results, status) => {
      if (status === google.maps.GeocoderStatus.OK) {
        const place = results[0];
        console.log(place.formatted_address);
         resolve(place.formatted_address);
              } else {
        console.log('Geocoder failed due to: ' + status);
      }
    });
  });
}

markerFuelIconUrl() {
  return ('assets/img/mapElectricFuel.svg')
}
markerEventIconUrl(data) {
  if (data.payload.geometry.type === "Point")
    return ('assets/img/event-map-svg.svg')
  else
    return ('assets/img/event-map-svg-polygon.svg')
}
markerSensorIconUrl() {
  return ('assets/img/sensor_marker.svg')
}
markerAnnoationIconUrl(data) {
  if (data.payload.status === "Available")
    return ('assets/img/annotation-map-avialable.svg')
  else
    return ('assets/img/annotation-map-unavialable.svg')
}
markerEASUserIconUrl(data) {
  if (data.payload.status === "Available")
    return ('assets/img/eas-user-1024-available.svg')
  else
    return ('assets/img/eas-user-1024-unavailable.svg')
}
markerFeildPersonIconUrl(data) {
  if (data.payload.status === "Available")
    return ('assets/img/field-user-1024-available.svg')
  else
    return ('assets/img/field-user-1024-unavailable.svg')
}
markerLawIconUrl(data) {
  if (data.payload.status === "Available")
    return ('assets/img/law-1024-available.svg')
  else
    return ('assets/img/law-1024-unavailable.svg')
}
markerFireIconUrl(data) {
  if (data.payload.status === "Available")
    return ('assets/img/fire-1024-available.svg')
  else
    return ('assets/img/fire-1024-unavailable.svg')
}
markerLocationIconUrl() {
  return ('assets/img/map-location-128x128-svg.svg')
}
markerEpttIconUrl() {
  return ('assets/img/epttIcon.svg')
}
markerMedicalIconUrl(data) {
  if (data.payload.status === "Available")
    return ('assets/img/med-1024-available.svg')
  else
    return ('assets/img/med-1024-unavailable.svg')
}
markerHospitalIconUrl() {
  return ('assets/img/mapHospital.svg')
}

markerHydrantIconUrl() {
  return ('assets/img/mapHydrants.svg')
}

markerTrafficIconUrl() {
  return ("assets/img/video-camera.svg")
}

markerAgencyResourceIconUrl(data) {
  if (data.payload.status === "Available") {
    return ("assets/img/resources-agency-1024-available.svg")
  } else {
    return ("assets/img/resources-agency-1024-unavailable.svg")
  }
}
markerWeatherIconUrl(data) {
return ('assets/img/weather.svg')
}

getRectangleCoordinates(newShape, dataModelType) {
  let latitude;
  let longitude;
  const tempCoord = [];
  const rectangleBounds = newShape.getBounds();
  const start = rectangleBounds.getNorthEast();
  const end = rectangleBounds.getSouthWest();
  const center = rectangleBounds.getCenter();
  latitude = center.lat();
  longitude = center.lng();
  tempCoord.push({ lat: start.lat(), lng: start.lng() });
  tempCoord.push({ lat: end.lat(), lng: start.lng() });
  tempCoord.push({ lat: end.lat(), lng: end.lng() });
  tempCoord.push({ lat: start.lat(), lng: end.lng() });
  tempCoord.push({ lat: start.lat(), lng: start.lng() });
  if (dataModelType === DataModel.location) {
    return this.returnLatLngCoord(latitude, longitude, tempCoord);
  } else {
    const objects = new Array();
    for (let i = 0; i < tempCoord.length; i++) {
      objects[i] = new Array();
      objects[i].push(tempCoord[i].lng);
      objects[i].push(tempCoord[i].lat);
    }
    return this.returnLatLngCoord(latitude, longitude, objects);
  }
}
returnLatLngCoord(lat, long, coord) {
  const latLngCoordinates = {
    'latitude': lat,
    'longitude': long,
    'coordinates': coord
  };
  return latLngCoordinates;
}
formPayloadForEntitiesMoreInfo(data, isFromMap, isFromFullList) {
  data[0].properties.isFromMap = isFromMap;
  data[0].properties.isFromFullList = isFromFullList;
  data[0].properties.assignedResources = data[0].assignedResources;
  data[0].properties.assignedAnnotations = data[0].assignedAnnotations;
  const entityData = {
      'payload': data,
  };
  return entityData;
}
}









