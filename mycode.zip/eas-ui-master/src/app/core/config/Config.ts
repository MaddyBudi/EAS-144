export interface Config {
	production: boolean,
    redirectUri: string;
    userServiceUrl: string;
    authServiceUrl: string;
    targetUri: string;
    dmsStreamUrl: string;
    eventServiceUrl: string;
    annotationServiceUrl:string;
    locationServiceUrl:string;
    situationaldataUrl:string;
    resourceServiceUrl:string;
    powerdataSearchUrl: string;
    fetchSensorHistoryInfoUrl:string;
    sensorServiceUrl:string;

}
