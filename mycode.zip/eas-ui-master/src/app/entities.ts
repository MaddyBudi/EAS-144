export enum Entities{
    events="EVENT",
    resources="RESOURCE",
    annotations="ANNOTATION",
    locations="LOCATION",
}